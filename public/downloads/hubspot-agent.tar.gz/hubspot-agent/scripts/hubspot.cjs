#!/usr/bin/env node
/**
 * HubSpot Agent Skill — Core Script
 * Full CRM operations: contacts, companies, deals, tickets, notes, associations.
 * Auth: Private App Access Token.
 */
'use strict';

const https = require('https');

const TOKEN = process.env.HUBSPOT_ACCESS_TOKEN;
if (!TOKEN) {
  console.error(JSON.stringify({ error: 'HUBSPOT_ACCESS_TOKEN environment variable not set' }));
  process.exit(1);
}

// ─── HTTP Helper ────────────────────────────────────────────────────────────

function hubspotApi(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null;
    const opts = {
      method,
      hostname: 'api.hubapi.com',
      path,
      headers: {
        Authorization: `Bearer ${TOKEN}`,
        'Content-Type': 'application/json',
      },
    };
    if (payload) opts.headers['Content-Length'] = Buffer.byteLength(payload);

    const req = https.request(opts, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString();
        try {
          const data = JSON.parse(raw);
          if (res.statusCode === 429) {
            const retryAfter = parseInt(res.headers['retry-after'] || '10', 10);
            console.error(`Rate limited. Retrying in ${retryAfter}s...`);
            setTimeout(() => hubspotApi(method, path, body).then(resolve).catch(reject), retryAfter * 1000);
            return;
          }
          if (res.statusCode >= 400) {
            resolve({ error: data.message || `HTTP ${res.statusCode}`, status: res.statusCode, category: data.category });
          } else {
            resolve(data);
          }
        } catch {
          if (res.statusCode === 204) resolve({ success: true });
          else resolve({ error: 'parse_error', _raw: raw.substring(0, 200), _status: res.statusCode });
        }
      });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// ─── Helper ─────────────────────────────────────────────────────────────────

function extractProperties(obj, keys) {
  const result = { id: obj.id };
  const props = obj.properties || {};
  if (keys) {
    keys.forEach(k => { if (props[k] !== undefined) result[k] = props[k]; });
  } else {
    Object.assign(result, props);
  }
  return result;
}

const CONTACT_PROPS = ['firstname', 'lastname', 'email', 'phone', 'company', 'jobtitle', 'lifecyclestage', 'hs_lead_status', 'createdate', 'lastmodifieddate'];
const COMPANY_PROPS = ['name', 'domain', 'industry', 'numberofemployees', 'city', 'state', 'country', 'createdate'];
const DEAL_PROPS = ['dealname', 'amount', 'pipeline', 'dealstage', 'closedate', 'hubspot_owner_id', 'createdate'];
const TICKET_PROPS = ['subject', 'content', 'hs_pipeline', 'hs_pipeline_stage', 'hs_ticket_priority', 'createdate'];

// ─── Search ─────────────────────────────────────────────────────────────────

async function searchObjects(objectType, query, properties) {
  const resp = await hubspotApi('POST', `/crm/v3/objects/${objectType}/search`, {
    query,
    limit: 20,
    properties,
  });
  if (resp.error) return resp;
  return {
    results: resp.results?.map(r => extractProperties(r, properties)),
    total: resp.total,
  };
}

// ─── Contacts ───────────────────────────────────────────────────────────────

async function cmdSearchContacts(query) {
  return searchObjects('contacts', query, CONTACT_PROPS);
}

async function cmdGetContact(contactId) {
  const resp = await hubspotApi('GET', `/crm/v3/objects/contacts/${contactId}?properties=${CONTACT_PROPS.join(',')}`, null);
  if (resp.error) return resp;
  return extractProperties(resp, CONTACT_PROPS);
}

async function cmdCreateContact(propsJson) {
  const properties = JSON.parse(propsJson);
  const resp = await hubspotApi('POST', '/crm/v3/objects/contacts', { properties });
  if (resp.error) return resp;
  return { success: true, id: resp.id, properties: resp.properties };
}

async function cmdUpdateContact(contactId, propsJson) {
  const properties = JSON.parse(propsJson);
  const resp = await hubspotApi('PATCH', `/crm/v3/objects/contacts/${contactId}`, { properties });
  if (resp.error) return resp;
  return { success: true, id: resp.id };
}

async function cmdListContacts(limit = 10) {
  const resp = await hubspotApi('GET', `/crm/v3/objects/contacts?limit=${limit}&properties=${CONTACT_PROPS.join(',')}`, null);
  if (resp.error) return resp;
  return { results: resp.results?.map(r => extractProperties(r, CONTACT_PROPS)), total: resp.total };
}

// ─── Companies ──────────────────────────────────────────────────────────────

async function cmdSearchCompanies(query) {
  return searchObjects('companies', query, COMPANY_PROPS);
}

async function cmdGetCompany(companyId) {
  const resp = await hubspotApi('GET', `/crm/v3/objects/companies/${companyId}?properties=${COMPANY_PROPS.join(',')}`, null);
  if (resp.error) return resp;
  return extractProperties(resp, COMPANY_PROPS);
}

async function cmdCreateCompany(propsJson) {
  const properties = JSON.parse(propsJson);
  const resp = await hubspotApi('POST', '/crm/v3/objects/companies', { properties });
  if (resp.error) return resp;
  return { success: true, id: resp.id, properties: resp.properties };
}

async function cmdUpdateCompany(companyId, propsJson) {
  const properties = JSON.parse(propsJson);
  const resp = await hubspotApi('PATCH', `/crm/v3/objects/companies/${companyId}`, { properties });
  if (resp.error) return resp;
  return { success: true, id: resp.id };
}

// ─── Deals ──────────────────────────────────────────────────────────────────

async function cmdSearchDeals(query) {
  return searchObjects('deals', query, DEAL_PROPS);
}

async function cmdGetDeal(dealId) {
  const resp = await hubspotApi('GET', `/crm/v3/objects/deals/${dealId}?properties=${DEAL_PROPS.join(',')}`, null);
  if (resp.error) return resp;
  return extractProperties(resp, DEAL_PROPS);
}

async function cmdCreateDeal(propsJson) {
  const properties = JSON.parse(propsJson);
  const resp = await hubspotApi('POST', '/crm/v3/objects/deals', { properties });
  if (resp.error) return resp;
  return { success: true, id: resp.id, properties: resp.properties };
}

async function cmdUpdateDeal(dealId, propsJson) {
  const properties = JSON.parse(propsJson);
  const resp = await hubspotApi('PATCH', `/crm/v3/objects/deals/${dealId}`, { properties });
  if (resp.error) return resp;
  return { success: true, id: resp.id };
}

async function cmdListDeals(limit = 10) {
  const resp = await hubspotApi('GET', `/crm/v3/objects/deals?limit=${limit}&properties=${DEAL_PROPS.join(',')}`, null);
  if (resp.error) return resp;
  return { results: resp.results?.map(r => extractProperties(r, DEAL_PROPS)), total: resp.total };
}

// ─── Tickets ────────────────────────────────────────────────────────────────

async function cmdCreateTicket(propsJson) {
  const properties = JSON.parse(propsJson);
  const resp = await hubspotApi('POST', '/crm/v3/objects/tickets', { properties });
  if (resp.error) return resp;
  return { success: true, id: resp.id, properties: resp.properties };
}

async function cmdUpdateTicket(ticketId, propsJson) {
  const properties = JSON.parse(propsJson);
  const resp = await hubspotApi('PATCH', `/crm/v3/objects/tickets/${ticketId}`, { properties });
  if (resp.error) return resp;
  return { success: true, id: resp.id };
}

async function cmdSearchTickets(query) {
  return searchObjects('tickets', query, TICKET_PROPS);
}

// ─── Notes ──────────────────────────────────────────────────────────────────

async function cmdAddNote(objectType, objectId, noteText) {
  // Create engagement note
  const resp = await hubspotApi('POST', '/crm/v3/objects/notes', {
    properties: {
      hs_note_body: noteText,
      hs_timestamp: new Date().toISOString(),
    },
  });
  if (resp.error) return resp;
  const noteId = resp.id;

  // Associate with object
  const typeMap = { contact: 'contacts', company: 'companies', deal: 'deals', ticket: 'tickets' };
  const assocType = typeMap[objectType] || objectType;
  const assocResp = await hubspotApi('PUT',
    `/crm/v3/objects/notes/${noteId}/associations/${assocType}/${objectId}/note_to_${objectType}`, null);

  return { success: true, noteId, associated: !assocResp.error };
}

// ─── Associations ───────────────────────────────────────────────────────────

async function cmdAssociate(fromType, fromId, toType, toId) {
  // Normalize: accept both "contact" and "contacts"
  const fromPlural = fromType.endsWith('s') ? fromType : fromType + 's';
  const toPlural = toType.endsWith('s') ? toType : toType + 's';
  const fromSingular = fromType.endsWith('s') ? fromType.slice(0, -1) : fromType;
  const toSingular = toType.endsWith('s') ? toType.slice(0, -1) : toType;
  const assocLabel = `${fromSingular}_to_${toSingular}`;
  const resp = await hubspotApi('PUT',
    `/crm/v3/objects/${fromPlural}/${fromId}/associations/${toPlural}/${toId}/${assocLabel}`, null);
  if (resp.error) return resp;
  return { success: true, from: `${fromType}:${fromId}`, to: `${toType}:${toId}` };
}

// ─── Pipelines ──────────────────────────────────────────────────────────────

async function cmdPipelines() {
  const resp = await hubspotApi('GET', '/crm/v3/pipelines/deals', null);
  if (resp.error) return resp;
  return {
    pipelines: resp.results?.map(p => ({
      id: p.id,
      label: p.label,
      stages: p.stages?.map(s => ({ id: s.id, label: s.label, displayOrder: s.displayOrder })),
    })),
  };
}

async function cmdTicketPipelines() {
  const resp = await hubspotApi('GET', '/crm/v3/pipelines/tickets', null);
  if (resp.error) return resp;
  return {
    pipelines: resp.results?.map(p => ({
      id: p.id,
      label: p.label,
      stages: p.stages?.map(s => ({ id: s.id, label: s.label, displayOrder: s.displayOrder })),
    })),
  };
}

// ─── Owners ─────────────────────────────────────────────────────────────────

async function cmdOwners() {
  const resp = await hubspotApi('GET', '/crm/v3/owners/', null);
  if (resp.error) return resp;
  return {
    owners: resp.results?.map(o => ({
      id: o.id,
      email: o.email,
      firstName: o.firstName,
      lastName: o.lastName,
    })),
  };
}

// ─── Main ───────────────────────────────────────────────────────────────────

async function main() {
  const [,, command, ...args] = process.argv;

  if (!command) {
    console.log('Usage: node hubspot.cjs <command> [args...]');
    console.log('Commands: search-contacts, get-contact, create-contact, update-contact, list-contacts,');
    console.log('          search-companies, get-company, create-company, update-company,');
    console.log('          search-deals, get-deal, create-deal, update-deal, list-deals,');
    console.log('          create-ticket, update-ticket, search-tickets,');
    console.log('          add-note, associate, pipelines, ticket-pipelines, owners');
    process.exit(1);
  }

  let result;
  switch (command) {
    // Contacts
    case 'search-contacts': result = await cmdSearchContacts(args.join(' ')); break;
    case 'get-contact': result = await cmdGetContact(args[0]); break;
    case 'create-contact': result = await cmdCreateContact(args.join(' ')); break;
    case 'update-contact': result = await cmdUpdateContact(args[0], args.slice(1).join(' ')); break;
    case 'list-contacts': result = await cmdListContacts(parseInt(args[0] || '10', 10)); break;
    // Companies
    case 'search-companies': result = await cmdSearchCompanies(args.join(' ')); break;
    case 'get-company': result = await cmdGetCompany(args[0]); break;
    case 'create-company': result = await cmdCreateCompany(args.join(' ')); break;
    case 'update-company': result = await cmdUpdateCompany(args[0], args.slice(1).join(' ')); break;
    // Deals
    case 'search-deals': result = await cmdSearchDeals(args.join(' ')); break;
    case 'get-deal': result = await cmdGetDeal(args[0]); break;
    case 'create-deal': result = await cmdCreateDeal(args.join(' ')); break;
    case 'update-deal': result = await cmdUpdateDeal(args[0], args.slice(1).join(' ')); break;
    case 'list-deals': result = await cmdListDeals(parseInt(args[0] || '10', 10)); break;
    // Tickets
    case 'create-ticket': result = await cmdCreateTicket(args.join(' ')); break;
    case 'update-ticket': result = await cmdUpdateTicket(args[0], args.slice(1).join(' ')); break;
    case 'search-tickets': result = await cmdSearchTickets(args.join(' ')); break;
    // Notes
    case 'add-note': result = await cmdAddNote(args[0], args[1], args.slice(2).join(' ')); break;
    // Associations
    case 'associate': result = await cmdAssociate(args[0], args[1], args[2], args[3]); break;
    // Pipelines
    case 'pipelines': result = await cmdPipelines(); break;
    case 'ticket-pipelines': result = await cmdTicketPipelines(); break;
    // Owners
    case 'owners': result = await cmdOwners(); break;
    default:
      result = { error: `Unknown command: ${command}` };
  }

  console.log(JSON.stringify(result, null, 2));
}

main().catch(err => {
  console.error(JSON.stringify({ error: err.message }));
  process.exit(1);
});
