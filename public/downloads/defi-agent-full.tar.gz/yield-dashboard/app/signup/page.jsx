'use client';
import { useState } from 'react';

export default function SignupPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSignup(e) {
    e.preventDefault();
    setError('');

    if (password.length < 8) {
      setError('Password must be at least 8 characters');
      return;
    }
    if (password !== confirm) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (data.success) {
        window.location.href = '/dashboard';
      } else {
        setError(data.error || 'Signup failed');
      }
    } catch {
      setError('Network error — please try again');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{
      background: '#111214',
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    }}>
      <div style={{
        background: '#18191d',
        border: '1px solid #2a2b30',
        borderRadius: 16,
        padding: '40px 36px',
        width: '100%',
        maxWidth: 400,
      }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <img
            src="/passiveblocks_logo.png"
            alt="PassiveBlocks"
            style={{ height: 80, width: 'auto', objectFit: 'contain', filter: 'brightness(0) invert(1)', marginBottom: 16 }}
          />
          <h1 style={{ fontSize: 22, fontWeight: 800, color: '#edeef0', margin: '0 0 6px' }}>Create your account</h1>
          <p style={{ fontSize: 13, color: '#6b6c72', margin: 0 }}>Start tracking DeFi yields for free</p>
        </div>

        <form onSubmit={handleSignup}>
          <div style={{ marginBottom: 14 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#edeef0', marginBottom: 6 }}>Email address</label>
            <input
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              autoFocus
              style={{
                width: '100%',
                background: '#111214',
                border: '1px solid #2a2b30',
                borderRadius: 8,
                padding: '12px 14px',
                color: '#e2e8f0',
                fontSize: 15,
                outline: 'none',
                boxSizing: 'border-box',
              }}
              onFocus={e => e.target.style.borderColor = '#6789ed'}
              onBlur={e => e.target.style.borderColor = '#2a2b30'}
            />
          </div>

          <div style={{ marginBottom: 14 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#edeef0', marginBottom: 6 }}>Password</label>
            <input
              type="password"
              placeholder="Minimum 8 characters"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              style={{
                width: '100%',
                background: '#111214',
                border: '1px solid #2a2b30',
                borderRadius: 8,
                padding: '12px 14px',
                color: '#e2e8f0',
                fontSize: 15,
                outline: 'none',
                boxSizing: 'border-box',
              }}
              onFocus={e => e.target.style.borderColor = '#6789ed'}
              onBlur={e => e.target.style.borderColor = '#2a2b30'}
            />
          </div>

          <div style={{ marginBottom: 20 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#edeef0', marginBottom: 6 }}>Confirm password</label>
            <input
              type="password"
              placeholder="Repeat your password"
              value={confirm}
              onChange={e => setConfirm(e.target.value)}
              required
              style={{
                width: '100%',
                background: '#111214',
                border: '1px solid #2a2b30',
                borderRadius: 8,
                padding: '12px 14px',
                color: '#e2e8f0',
                fontSize: 15,
                outline: 'none',
                boxSizing: 'border-box',
              }}
              onFocus={e => e.target.style.borderColor = '#6789ed'}
              onBlur={e => e.target.style.borderColor = '#2a2b30'}
            />
          </div>

          {error && (
            <div style={{ color: '#ef4444', fontSize: 13, marginBottom: 14 }}>❌ {error}</div>
          )}

          <button
            type="submit"
            disabled={loading || !email || !password || !confirm}
            style={{
              width: '100%',
              background: !loading && email && password && confirm
                ? 'linear-gradient(135deg, #6789ed, #583fdd)'
                : '#2a2b30',
              color: !loading && email && password && confirm ? '#fff' : '#6b6c72',
              border: 'none',
              borderRadius: 8,
              padding: '13px',
              fontSize: 15,
              fontWeight: 700,
              cursor: !loading && email && password && confirm ? 'pointer' : 'not-allowed',
              transition: 'all 0.2s',
            }}
          >
            {loading ? '⏳ Creating account…' : 'Create Account'}
          </button>
        </form>

        <div style={{ textAlign: 'center', marginTop: 20, fontSize: 13, color: '#6b6c72' }}>
          Already have an account?{' '}
          <a href="/login" style={{ color: '#6789ed', textDecoration: 'none', fontWeight: 600 }}>
            Sign in →
          </a>
        </div>
      </div>
    </div>
  );
}
