# Wallet Sync Worker

VPS-side background service that pulls **complete transaction history** for all connected wallets, bypassing Vercel's 10s timeout and Alchemy's 1000-tx per-request pagination limit.

## Architecture

```
Vercel (Next.js)
  └─ /api/wallet/cached-transactions  ──proxy──▶  VPS :3002 (sync-server.cjs)
                                                      │
                                                      ├─ GET /sync/transactions  → reads cache/
                                                      ├─ POST /sync/trigger      → spawns wallet-sync.cjs
                                                      └─ GET /sync/status        → manifest.json
```

## Files

| File | Purpose |
|------|---------|
| `wallet-sync.cjs`   | Fetches all txs for all wallets, writes cache files |
| `sync-server.cjs`   | Express API server exposing cache to Vercel |
| `wallets.json`      | List of wallets to sync |
| `cache/`            | Raw JSON cache (gitignored) |
| `wallet-sync.service` | systemd unit for auto-start |

## Quick Start

### 1. Install dependencies

```bash
cd /home/node/.openclaw/workspace/yield-dashboard/sync-worker
npm install
```

### 2. Run a manual sync

```bash
node wallet-sync.cjs
```

Syncs all wallets in `wallets.json`. Progress logged to stdout with timestamps. Cache files written to `cache/`.

### 3. Start the API server

```bash
node sync-server.cjs
# Runs on port 3002
```

Or in background:

```bash
nohup node sync-server.cjs >> /var/log/wallet-sync.log 2>&1 &
```

### 4. Test the server

```bash
# Health (no auth)
curl http://localhost:3002/sync/health

# Status (auth required)
curl -H "X-Sync-Token: <DASHBOARD_SECRET>" http://localhost:3002/sync/status

# Transactions for a wallet
curl -H "X-Sync-Token: <DASHBOARD_SECRET>" \
  "http://localhost:3002/sync/transactions?address=0x0123caFe4c792D6255BB94357Bc98AFF2c916A4E&chain=ethereum"

# All chains merged
curl -H "X-Sync-Token: <DASHBOARD_SECRET>" \
  "http://localhost:3002/sync/transactions?address=0x0123caFe4c792D6255BB94357Bc98AFF2c916A4E"

# Trigger a fresh sync
curl -X POST -H "X-Sync-Token: <DASHBOARD_SECRET>" http://localhost:3002/sync/trigger
```

## Adding Wallets

Edit `wallets.json`:

```json
[
  {
    "address": "0xYourEVMAddress",
    "chains": ["ethereum", "base", "arbitrum", "optimism", "polygon"]
  },
  {
    "address": "YourSolanaAddress",
    "chains": ["solana"]
  }
]
```

Supported chains: `ethereum`, `base`, `arbitrum`, `optimism`, `polygon`, `solana`

Then trigger a fresh sync:
```bash
node wallet-sync.cjs
# or via API: POST /sync/trigger
```

## Cache Location

```
sync-worker/cache/
  ├─ 0x0123caFe...-ethereum.json
  ├─ 0x0123caFe...-base.json
  ├─ 0x0123caFe...-arbitrum.json
  ├─ 0x0123caFe...-optimism.json
  ├─ 0x0123caFe...-polygon.json
  ├─ HKtJbGPAHZH14b9...-solana.json
  └─ manifest.json
```

Each file contains:
```json
{
  "address": "0x...",
  "chain": "ethereum",
  "syncedAt": "2024-01-01T00:00:00.000Z",
  "count": 1234,
  "transfers": [ ... ]
}
```

## systemd Setup (auto-start on boot)

```bash
# Copy unit file
sudo cp wallet-sync.service /etc/systemd/system/

# Enable and start
sudo systemctl daemon-reload
sudo systemctl enable wallet-sync
sudo systemctl start wallet-sync

# Check status
sudo systemctl status wallet-sync

# View logs
sudo journalctl -u wallet-sync -f
```

## Vercel Environment Variables

Add these to your Vercel project settings:

| Variable | Value |
|----------|-------|
| `SYNC_SERVER_TOKEN` | Value of `DASHBOARD_SECRET` from `.env` |

## Scheduled Sync (cron)

To sync nightly at 2 AM:

```bash
crontab -e
# Add:
0 2 * * * /usr/bin/node /home/node/.openclaw/workspace/yield-dashboard/sync-worker/wallet-sync.cjs >> /var/log/wallet-sync-cron.log 2>&1
```

## Security Notes

- Port 3002 should be **firewall-restricted** — only accept from Vercel IP ranges or keep it internal
- The `X-Sync-Token` header matches `DASHBOARD_SECRET` from `.env`
- Cache files are gitignored — never committed to GitHub
- CORS is locked to `passiveblocks-dashboard.vercel.app` and localhost only
