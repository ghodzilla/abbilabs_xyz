import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

// ─── Rocket Pool contract addresses — fetched dynamically from RocketStorage ──
// RocketStorage (immutable): 0x1d8f8f00cfa6758d7bE78336684788Fb0ee0Fa46
// These were verified 2026-03-21 via web3_sha3 key lookup:
const ROCKETPOOL_CONTRACTS = {
  nodeManager:     '0xcf2d76a7499d3acb5a22ce83c027651e8d76e250', // rocketNodeManager
  minipoolManager: '0xe54b8c641fd96de5d6747f47c19964c6b824d62c', // rocketMinipoolManager
  nodeStaking:     '0xedfc7dcae43ff954577a2875a9d805874490ee3e', // rocketNodeStaking
  rETH:            '0xae78736Cd615f374D3085123A210448E74Fc6393',
  RPL:             '0xD33526068D116cE69F19A9ee46F0bd304F21A51f',
};

const ALCHEMY_BASE = 'https://eth-mainnet.g.alchemy.com/v2';

// ─── Low-level eth_call helper ────────────────────────────────────────────────
async function ethCall(alchemyUrl, to, data) {
  const res = await fetch(alchemyUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: '2.0',
      id: 1,
      method: 'eth_call',
      params: [{ to, data }, 'latest'],
    }),
    signal: AbortSignal.timeout(8000),
  });
  const d = await res.json();
  if (d.error) throw new Error(`eth_call error: ${d.error.message}`);
  return d.result || '0x';
}

// ─── RocketNodeManager.getNodeExists(address) → bool ────────────────────────
// selector: keccak256("getNodeExists(address)") = 0x65d4176f
async function isRocketPoolNode(address, alchemyUrl) {
  try {
    const paddedAddr = address.slice(2).padStart(64, '0');
    const result = await ethCall(alchemyUrl, ROCKETPOOL_CONTRACTS.nodeManager, '0x65d4176f' + paddedAddr);
    return result === '0x0000000000000000000000000000000000000000000000000000000000000001';
  } catch (err) {
    console.warn('[rocketpool] isRocketPoolNode failed:', err.message);
    return false;
  }
}

// ─── RocketMinipoolManager.getNodeMinipoolCount(address) → uint256 ───────────
// selector: keccak256("getNodeMinipoolCount(address)") = 0x1ce9ec33
async function getMinipoolCount(nodeAddress, alchemyUrl) {
  const paddedAddr = nodeAddress.slice(2).padStart(64, '0');
  const result = await ethCall(alchemyUrl, ROCKETPOOL_CONTRACTS.minipoolManager, '0x1ce9ec33' + paddedAddr);
  return parseInt(result || '0x0', 16);
}

// ─── RocketMinipoolManager.getNodeMinipoolAt(address, uint256) → address ─────
// selector: keccak256("getNodeMinipoolAt(address,uint256)") = 0x8b300029
async function getMinipoolAddress(nodeAddress, index, alchemyUrl) {
  try {
    const paddedAddr = nodeAddress.slice(2).padStart(64, '0');
    const paddedIdx  = index.toString(16).padStart(64, '0');
    const result = await ethCall(
      alchemyUrl,
      ROCKETPOOL_CONTRACTS.minipoolManager,
      '0x8b300029' + paddedAddr + paddedIdx,
    );
    if (!result || result === '0x' || result.length < 42) return null;
    return '0x' + result.slice(-40);
  } catch (err) {
    console.warn(`[rocketpool] getMinipoolAddress(${index}) failed:`, err.message);
    return null;
  }
}

// ─── eth_getBalance → ETH float ──────────────────────────────────────────────
async function getEthBalance(address, alchemyUrl) {
  const res = await fetch(alchemyUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: '2.0', id: 1,
      method: 'eth_getBalance',
      params: [address, 'latest'],
    }),
    signal: AbortSignal.timeout(8000),
  });
  const d = await res.json();
  const wei = BigInt(d.result || '0x0');
  const milliEth = Number(wei / BigInt(1e15));
  return milliEth / 1000;
}

// ─── alchemy_getAssetTransfers: from minipool → node (internal = rewards) ────
async function getMinipoolRewards(minipoolAddress, nodeAddress, alchemyUrl) {
  const res = await fetch(alchemyUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: '2.0', id: 1,
      method: 'alchemy_getAssetTransfers',
      params: [{
        fromAddress: minipoolAddress,
        toAddress: nodeAddress,
        category: ['internal'],
        withMetadata: true,
        order: 'asc',
      }],
    }),
    signal: AbortSignal.timeout(10000),
  });
  const d = await res.json();
  return d.result?.transfers || [];
}

// ─── RocketNodeStaking.getNodeStakedRPL(address) → uint256 (wei) → RPL ────────
// selector: keccak256("getNodeStakedRPL(address)") = 0x73897be8
async function getRPLStake(nodeAddress, alchemyUrl) {
  try {
    const paddedAddr = nodeAddress.slice(2).padStart(64, '0');
    const result = await ethCall(alchemyUrl, ROCKETPOOL_CONTRACTS.nodeStaking, '0x73897be8' + paddedAddr);
    const wei = BigInt(result || '0x0');
    // Divide via BigInt to stay in safe integer range, preserve 3 decimals
    const milliRpl = Number(wei / BigInt(1e15));
    return milliRpl / 1000;
  } catch (err) {
    console.warn('[rocketpool] getRPLStake failed:', err.message);
    return 0;
  }
}

// ─── Alchemy fallback: check rETH/RPL interactions for liquid stakers ─────────
async function checkAlchemyRpInteraction(address, alchemyUrl) {
  try {
    const res = await fetch(alchemyUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'alchemy_getAssetTransfers',
        params: [{
          toAddress: address,
          contractAddresses: [ROCKETPOOL_CONTRACTS.rETH, ROCKETPOOL_CONTRACTS.RPL],
          category: ['erc20', 'internal'],
          maxCount: '0x1',
          withMetadata: false,
        }],
      }),
      signal: AbortSignal.timeout(6000),
    });
    const data = await res.json();
    return (data.result?.transfers?.length || 0) > 0;
  } catch {
    return false;
  }
}

/**
 * GET /api/wallet/rocketpool?address=0x...
 *
 * Returns Rocket Pool node data using direct contract calls via Alchemy.
 * No dependency on api.rocketpool.net (404'd / dead).
 *
 * Node operators: returns minipools, balances, internal reward transfers, RPL stake.
 * Liquid stakers: returns hasRpInteraction flag for rETH/RPL transfers.
 */
export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const address = searchParams.get('address');

  if (!address || !/^0x[a-fA-F0-9]{40}$/.test(address)) {
    return NextResponse.json({ error: 'Invalid or missing address' }, { status: 400 });
  }

  const alchemyKey = process.env.ALCHEMY_API_KEY;
  if (!alchemyKey) {
    return NextResponse.json({ error: 'ALCHEMY_API_KEY not configured' }, { status: 500 });
  }

  const alchemyUrl = `${ALCHEMY_BASE}/${alchemyKey}`;

  try {
    // ── 1. Is this address a Rocket Pool node operator? ───────────────────────
    const isNode = await isRocketPoolNode(address, alchemyUrl);
    console.log(`[rocketpool] ${address} isNode=${isNode}`);

    if (!isNode) {
      // Liquid staker path: check for rETH/RPL token activity
      const hasRpInteraction = await checkAlchemyRpInteraction(address, alchemyUrl);
      return NextResponse.json({
        isNode: false,
        hasRpInteraction,
        fetchedAt: new Date().toISOString(),
      });
    }

    // ── 2. Get minipool count ─────────────────────────────────────────────────
    let minipoolCount = 0;
    try {
      minipoolCount = await getMinipoolCount(address, alchemyUrl);
    } catch (err) {
      console.warn('[rocketpool] getMinipoolCount failed:', err.message);
    }
    console.log(`[rocketpool] ${address} minipool count: ${minipoolCount}`);

    // ── 3. Fetch all minipool addresses ───────────────────────────────────────
    const minipoolAddresses = [];
    // Cap at 50 to avoid hammering Alchemy (real node operators rarely have >10)
    const fetchCount = Math.min(minipoolCount, 50);
    for (let i = 0; i < fetchCount; i++) {
      const mpAddr = await getMinipoolAddress(address, i, alchemyUrl);
      if (mpAddr && mpAddr !== '0x0000000000000000000000000000000000000000') {
        minipoolAddresses.push(mpAddr);
      }
    }
    console.log(`[rocketpool] ${address} minipool addresses:`, minipoolAddresses);

    // ── 4. Get balance + internal reward transfers for each minipool ──────────
    const minipools = [];
    let totalEthRewards = 0;
    const allRewardTransfers = [];

    await Promise.all(minipoolAddresses.map(async (mpAddr) => {
      const [balance, transfers] = await Promise.all([
        getEthBalance(mpAddr, alchemyUrl).catch(() => 0),
        getMinipoolRewards(mpAddr, address, alchemyUrl).catch(() => []),
      ]);

      const rewardEth = transfers.reduce((sum, t) => sum + (parseFloat(t.value) || 0), 0);

      minipools.push({
        address: mpAddr,
        stakedEth: parseFloat(balance.toFixed(6)),
        rewardTransferCount: transfers.length,
        rewardEth: parseFloat(rewardEth.toFixed(6)),
      });

      totalEthRewards += rewardEth;
      allRewardTransfers.push(...transfers.map(t => ({
        from: mpAddr,
        to: address,
        value: parseFloat(t.value) || 0,
        timestamp: t.metadata?.blockTimestamp
          ? Math.floor(new Date(t.metadata.blockTimestamp).getTime() / 1000)
          : null,
        blockNum: t.blockNum,
        hash: t.hash,
        stakingReward: true,
      })));
    }));

    // Sort minipools deterministically
    minipools.sort((a, b) => a.address.localeCompare(b.address));
    allRewardTransfers.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));

    // ── 5. Get RPL stake ──────────────────────────────────────────────────────
    const rplStaked = await getRPLStake(address, alchemyUrl);

    // ── 6. Smoothing pool opt-in status ───────────────────────────────────────
    let inSmoothingPool = false;
    try {
      const paddedAddr = address.slice(2).padStart(64, '0');
      // getSmoothingPoolRegistrationState(address) = 0xa4cef9dd
      const spRes = await fetch(alchemyUrl, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc:'2.0',id:1,method:'eth_call',params:[{ to: ROCKETPOOL_CONTRACTS.nodeManager, data:'0xa4cef9dd'+paddedAddr },'latest'] }),
        signal: AbortSignal.timeout(5000),
      });
      const spData = await spRes.json();
      inSmoothingPool = (spData.result || '').endsWith('1');
    } catch { /* ignore */ }

    // ── 7. Unclaimed reward periods ───────────────────────────────────────────
    // getRewardIndex() on rocketRewardsPool = 0x6e4d22c2
    // isClaimed(uint256,address) on rocketMerkleDistributor = 0xd2ef0795
    const REWARDS_POOL    = '0xcba5951fc706fc783b7c142dae8576ebe29c41fd';
    const MERKLE_DIST     = '0xe4e2612ee8d7fdc8518faea85770a3b9c886e2f5';
    let currentPeriod = 0;
    let unclaimedPeriods = [];
    let claimedPeriods = [];
    try {
      // getRewardIndex() selector — compute via keccak256 doesn't work inline, use known selector
      const idxRes = await fetch(alchemyUrl, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc:'2.0',id:1,method:'eth_call',params:[{ to:REWARDS_POOL, data:'0xf21c150c' },'latest'] }),
        signal: AbortSignal.timeout(5000),
      });
      const idxData = await idxRes.json();
      currentPeriod = parseInt(idxData.result || '0x0', 16);

      const paddedAddr = address.slice(2).padStart(64, '0');
      // Check all periods in parallel (cap at 50)
      const checkCount = Math.min(currentPeriod, 50);
      const results = await Promise.all(
        Array.from({ length: checkCount }, async (_, i) => {
          const paddedIdx = i.toString(16).padStart(64, '0');
          try {
            const r = await fetch(alchemyUrl, {
              method: 'POST', headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ jsonrpc:'2.0',id:1,method:'eth_call',params:[{ to:MERKLE_DIST, data:'0xd2ef0795'+paddedIdx+paddedAddr },'latest'] }),
              signal: AbortSignal.timeout(5000),
            });
            const d = await r.json();
            return { period: i, claimed: (d.result || '').endsWith('1') };
          } catch { return { period: i, claimed: false }; }
        })
      );
      unclaimedPeriods = results.filter(r => !r.claimed).map(r => r.period);
      claimedPeriods   = results.filter(r =>  r.claimed).map(r => r.period);
    } catch (err) {
      console.warn('[rocketpool] reward period check failed:', err.message);
    }

    return NextResponse.json({
      isNode: true,
      nodeAddress: address,
      minipoolCount,
      minipools,
      totalEthRewards: parseFloat(totalEthRewards.toFixed(6)),
      totalRplRewards: 0,
      rplStaked: parseFloat(rplStaked.toFixed(4)),
      rewardTransfers: allRewardTransfers,
      smoothingPool: {
        optedIn: inSmoothingPool,
      },
      rewards: {
        currentPeriod,
        claimedCount: claimedPeriods.length,
        unclaimedCount: unclaimedPeriods.length,
        unclaimedPeriods,
        claimedPeriods,
        note: claimedPeriods.length > 0 ? 'Claimed rewards were likely restaked (no RPL transfers detected)' : '',
      },
      fetchedAt: new Date().toISOString(),
      contractsUsed: {
        nodeManager:     ROCKETPOOL_CONTRACTS.nodeManager,
        minipoolManager: ROCKETPOOL_CONTRACTS.minipoolManager,
        nodeStaking:     ROCKETPOOL_CONTRACTS.nodeStaking,
      },
    });

  } catch (err) {
    console.error('[rocketpool] Unexpected error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
