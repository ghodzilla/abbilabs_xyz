import { NextResponse } from 'next/server';
import { readFileSync, writeFileSync, existsSync } from 'fs';

export const runtime = 'nodejs';

// ─── Alchemy network map ──────────────────────────────────────────────────────
const ALCHEMY_NETWORKS = {
  ethereum: 'eth-mainnet',
  base: 'base-mainnet',
  arbitrum: 'arb-mainnet',
  optimism: 'opt-mainnet',
  polygon: 'polygon-mainnet',
};

// DeFiLlama coin IDs for major tokens
const DEFI_LLAMA_IDS = {
  'ETH':    'coingecko:ethereum',
  'WETH':   'coingecko:weth',
  'USDC':   'coingecko:usd-coin',
  'USDT':   'coingecko:tether',
  'WBTC':   'coingecko:wrapped-bitcoin',
  'RPL':    'coingecko:rocket-pool',                // Rocket Pool governance token
  'rETH':   'coingecko:rocket-pool-eth',            // Rocket Pool liquid staking token
  'stETH':  'coingecko:staked-ether',               // Lido staked ETH
  'cbETH':  'coingecko:coinbase-wrapped-staked-eth',// Coinbase staked ETH
  'wstETH': 'coingecko:wrapped-steth',              // Wrapped stETH
};

// Known Rocket Pool contract addresses (lowercase) — internal ETH from these = staking income
const ROCKETPOOL_STATIC_CONTRACTS = new Set([
  '0xae78736cd615f374d3085123a210448e74fc6393', // rETH token
  '0xd33526068d116ce69f19a9ee46f0bd304f21a51f', // RPL token
  '0x1d8f8f00cfa6758d7be78336684788fb0ee0fa46', // rocketStorage
  '0x2fb37eb570b1ee258577b9b6c4e6109b083e4db',  // rocketNodeDistributor (common)
]);

// Rocket Pool node contracts for direct on-chain lookup
const RP_NODE_MANAGER     = '0xcf2d76a7499d3acb5a22ce83c027651e8d76e250';
const RP_MINIPOOL_MANAGER = '0xe54b8c641fd96de5d6747f47c19964c6b824d62c';

/**
 * Fetch Rocket Pool minipool addresses for a given node operator via Alchemy.
 * Returns { addresses: Set<string>, balances: Map<string,number>, isNode: boolean }
 */
async function getRocketPoolMinipoolAddresses(address, alchemyUrl) {
  const emptySet = new Set();
  if (!alchemyUrl) return { addresses: emptySet, balances: new Map() };

  try {
    // Check getNodeExists(address) — selector 0x65d4176f
    const paddedAddr = address.slice(2).padStart(64, '0');

    const nodeExistsRes = await fetch(alchemyUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0', id: 1,
        method: 'eth_call',
        params: [{ to: RP_NODE_MANAGER, data: '0x65d4176f' + paddedAddr }, 'latest'],
      }),
      signal: AbortSignal.timeout(6000),
    });
    const nodeExistsData = await nodeExistsRes.json();
    const isNode = nodeExistsData.result ===
      '0x0000000000000000000000000000000000000000000000000000000000000001';

    if (!isNode) return { addresses: emptySet, balances: new Map() };

    // Get minipool count — selector 0x1ce9ec33
    const countRes = await fetch(alchemyUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0', id: 1,
        method: 'eth_call',
        params: [{ to: RP_MINIPOOL_MANAGER, data: '0x1ce9ec33' + paddedAddr }, 'latest'],
      }),
      signal: AbortSignal.timeout(6000),
    });
    const countData = await countRes.json();
    const count = parseInt(countData.result || '0x0', 16);

    if (count === 0) return { addresses: emptySet, balances: new Map() };

    // Fetch up to 50 minipool addresses — selector 0x8b300029
    const addresses = new Set();
    const fetchCount = Math.min(count, 50);
    for (let i = 0; i < fetchCount; i++) {
      const paddedIdx = i.toString(16).padStart(64, '0');
      const mpRes = await fetch(alchemyUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0', id: 1,
          method: 'eth_call',
          params: [{ to: RP_MINIPOOL_MANAGER, data: '0x8b300029' + paddedAddr + paddedIdx }, 'latest'],
        }),
        signal: AbortSignal.timeout(6000),
      });
      const mpData = await mpRes.json();
      const result = mpData.result || '';
      if (result && result !== '0x' && result.length >= 42) {
        const mpAddr = ('0x' + result.slice(-40)).toLowerCase();
        if (mpAddr !== '0x0000000000000000000000000000000000000000') {
          addresses.add(mpAddr);
        }
      }
    }

    // Fetch ETH balance of each minipool (accrued rewards on execution layer)
    const balances = new Map();
    await Promise.all([...addresses].map(async (mpAddr) => {
      try {
        const balRes = await fetch(alchemyUrl, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_getBalance', params: [mpAddr, 'latest'] }),
          signal: AbortSignal.timeout(5000),
        });
        const balData = await balRes.json();
        const wei = BigInt(balData.result || '0x0');
        balances.set(mpAddr, Number(wei) / 1e18);
      } catch { balances.set(mpAddr, 0); }
    }));

    console.log(`[tax-summary] Rocket Pool node detected, found ${addresses.size} minipool(s) for ${address}`);
    return { addresses, balances };
  } catch (err) {
    console.warn('[tax-summary] getRocketPoolMinipoolAddresses failed:', err.message);
    return { addresses: emptySet, balances: new Map() };
  }
}

// ─── Module-level in-memory price cache (survives within serverless warm instances) ───
const priceCache = new Map(); // `${coinId}:${dayTimestamp}` -> { price, fetchedAt }
const CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24h

const PRICE_CACHE_FILE = '/tmp/eth-price-cache.json';

/** Load the file-based cache into the in-memory map on module init */
function loadFileCache() {
  try {
    if (existsSync(PRICE_CACHE_FILE)) {
      const raw = JSON.parse(readFileSync(PRICE_CACHE_FILE, 'utf8'));
      const now = Date.now();
      for (const [key, entry] of Object.entries(raw)) {
        if (now - entry.fetchedAt < CACHE_TTL_MS) {
          priceCache.set(key, entry);
        }
      }
    }
  } catch {
    // Ignore — corrupt or missing cache file
  }
}

/** Persist the in-memory cache to /tmp so it survives cold starts (within same instance) */
function saveFileCache() {
  try {
    const obj = {};
    for (const [key, entry] of priceCache.entries()) {
      obj[key] = entry;
    }
    writeFileSync(PRICE_CACHE_FILE, JSON.stringify(obj), 'utf8');
  } catch {
    // Non-fatal — in-memory cache still works
  }
}

loadFileCache();

/**
 * Batch-fetch historical prices from DeFiLlama for a given coin.
 * Rounds every timestamp to the start of its UTC day to maximise cache hits.
 */
async function fetchHistoricalPrices(timestamps, coinId = 'coingecko:ethereum') {
  const dayTimestamps = [
    ...new Set(timestamps.map(t => Math.floor(t / 86400) * 86400)),
  ];

  const toFetch = [];
  for (const dayTs of dayTimestamps) {
    const cacheKey = `${coinId}:${dayTs}`;
    const cached = priceCache.get(cacheKey);
    if (!cached || Date.now() - cached.fetchedAt >= CACHE_TTL_MS) {
      toFetch.push(dayTs);
    }
  }

  if (toFetch.length > 0) {
    for (let i = 0; i < toFetch.length; i += 100) {
      const batch = toFetch.slice(i, i + 100);
      try {
        const res = await fetch('https://coins.llama.fi/batchHistorical', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            coins: { [coinId]: { timestamps: batch } },
          }),
        });
        if (!res.ok) throw new Error(`DeFiLlama batch HTTP ${res.status}`);

        const data = await res.json();
        const prices = data?.coins?.[coinId]?.prices || [];
        const now = Date.now();

        for (const p of prices) {
          const dayKey = Math.floor(p.timestamp / 86400) * 86400;
          priceCache.set(`${coinId}:${dayKey}`, { price: p.price, fetchedAt: now });
        }
      } catch {
        // Fallback: individual GET requests
        for (const ts of batch) {
          try {
            const r = await fetch(
              `https://coins.llama.fi/prices/historical/${ts}/${coinId}`
            );
            const d = await r.json();
            const price = d?.coins?.[coinId]?.price;
            if (price) {
              const dayKey = Math.floor(ts / 86400) * 86400;
              priceCache.set(`${coinId}:${dayKey}`, { price, fetchedAt: Date.now() });
            }
          } catch {
            // Individual fallback also failed
          }
        }
      }
    }
    saveFileCache();
  }

  const result = {};
  for (const dayTs of dayTimestamps) {
    const entry = priceCache.get(`${coinId}:${dayTs}`);
    if (entry) result[dayTs] = entry.price;
  }
  return result;
}

/**
 * Look up the price for a given unix timestamp.
 * Tries exact day, then ±1 day, then falls back to fallbackPrice.
 */
function getPriceAtTimestamp(priceMap, timestamp, fallbackPrice) {
  const dayKey = Math.floor(timestamp / 86400) * 86400;
  return (
    priceMap[dayKey] ??
    priceMap[dayKey - 86400] ??
    priceMap[dayKey + 86400] ??
    fallbackPrice
  );
}

/**
 * Fetch all transfers for an address via Alchemy alchemy_getAssetTransfers.
 * Returns raw Alchemy transfer objects sorted asc by block.
 */
async function fetchAlchemyTransfers(address, alchemyUrl) {
  async function fetchPage(params) {
    const res = await fetch(alchemyUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'alchemy_getAssetTransfers',
        params: [params],
      }),
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.result;
  }

  // Paginate incoming transfers
  const inTransfers = [];
  let inPageKey;
  do {
    const params = {
      toAddress: address,
      category: ['external', 'internal', 'erc20', 'erc721', 'erc1155'],
      maxCount: '0x3e8', // 1000 per page
      order: 'asc',
      withMetadata: true,
      ...(inPageKey ? { pageKey: inPageKey } : {}),
    };
    const result = await fetchPage(params);
    inTransfers.push(...(result.transfers || []));
    inPageKey = result.pageKey;
  } while (inPageKey);

  // Paginate outgoing transfers
  const outTransfers = [];
  let outPageKey;
  do {
    const params = {
      fromAddress: address,
      category: ['external', 'internal', 'erc20', 'erc721', 'erc1155'],
      maxCount: '0x3e8',
      order: 'asc',
      withMetadata: true,
      ...(outPageKey ? { pageKey: outPageKey } : {}),
    };
    const result = await fetchPage(params);
    outTransfers.push(...(result.transfers || []));
    outPageKey = result.pageKey;
  } while (outPageKey);

  return { inTransfers, outTransfers };
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const address = searchParams.get('address');
  const network = searchParams.get('network') || 'ethereum';
  const startTs = parseInt(searchParams.get('startTs') || '0');
  const endTs = parseInt(searchParams.get('endTs') || String(Math.floor(Date.now() / 1000)));

  // chains param: comma-separated list of chains to scan (e.g. "ethereum,arbitrum,polygon")
  const chainsParam = searchParams.get('chains');
  // Cap at 3 chains max to avoid Vercel Hobby 10s timeout
  const chainsToScan = (chainsParam
    ? chainsParam.split(',').map(c => c.trim()).filter(c => ALCHEMY_NETWORKS[c])
    : [network]).slice(0, 3);

  if (!address) return NextResponse.json({ error: 'address required' }, { status: 400 });
  if (!/^0x[a-fA-F0-9]{40}$/.test(address)) {
    return NextResponse.json({ error: 'Invalid address' }, { status: 400 });
  }

  console.log('[tax-summary] Request — address:', address, '| chains:', chainsToScan, '| startTs:', startTs, '| endTs:', endTs);

  const alchemyKey = process.env.ALCHEMY_API_KEY;
  const addrLower = address.toLowerCase();

  try {
    // ── 0. Resolve Rocket Pool minipool addresses for this wallet ─────────────
    // These are unique per node operator — we fetch them dynamically so internal
    // ETH transfers FROM minipools TO this wallet are classified as staking income.
    let rocketpoolContracts = ROCKETPOOL_STATIC_CONTRACTS;
    let minipoolAddresses = new Set(); // declared in outer scope so 0b can reference it
    let minipoolBalances = new Map();  // mpAddr -> ETH balance (accrued rewards)
    let isRpNode = false;
    if (alchemyKey && chainsToScan.includes('ethereum')) {
      const mainnetAlchemyUrl = `https://eth-mainnet.g.alchemy.com/v2/${alchemyKey}`;
      const rpResult = await getRocketPoolMinipoolAddresses(address, mainnetAlchemyUrl);
      minipoolAddresses = rpResult.addresses;
      minipoolBalances = rpResult.balances;
      isRpNode = minipoolAddresses.size > 0;
      if (isRpNode) {
        // Merge static set + dynamic minipool addresses into one lookup set
        rocketpoolContracts = new Set([...ROCKETPOOL_STATIC_CONTRACTS, ...minipoolAddresses]);
      }
    }

    // ── 0b. Dedicated minipool reward sweep (parallel, separate from main fetch) ─
    // Fetches ETH transfers FROM each minipool → this wallet directly.
    // This catches rewards that alchemy_getAssetTransfers(toAddress) sometimes misses.
    async function fetchMinipoolRewards(mpAddresses, nodeAddr, alchemyUrl) {
      if (!mpAddresses || mpAddresses.size === 0) return [];
      const all = [];
      await Promise.allSettled([...mpAddresses].map(async mpAddr => {
        try {
          const res = await fetch(alchemyUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              jsonrpc: '2.0', id: 1,
              method: 'alchemy_getAssetTransfers',
              params: [{ fromAddress: mpAddr, toAddress: nodeAddr, category: ['internal', 'external'], withMetadata: true, maxCount: '0x3e8' }],
            }),
            signal: AbortSignal.timeout(8000),
          });
          const d = await res.json();
          for (const t of (d.result?.transfers || [])) {
            const ts = t.metadata?.blockTimestamp ? Math.floor(new Date(t.metadata.blockTimestamp).getTime() / 1000) : 0;
            all.push({ timestamp: ts, value: t.value || 0, from: mpAddr, to: nodeAddr, type: 'in', category: t.category, chain: 'ethereum', isStakingReward: true, hash: t.hash });
          }
        } catch (err) { console.warn('[tax-summary] minipool sweep failed for', mpAddr, err.message); }
      }));
      return all;
    }

    let minipoolRewardTxs = [];
    if (alchemyKey && minipoolAddresses && minipoolAddresses.size > 0) {
      const mainnetUrl = `https://eth-mainnet.g.alchemy.com/v2/${alchemyKey}`;
      minipoolRewardTxs = await fetchMinipoolRewards(minipoolAddresses, address, mainnetUrl);
      console.log(`[tax-summary] minipool sweep found ${minipoolRewardTxs.length} reward tx(s)`);
    }

    // ── 1. Fetch transfers from all specified chains in parallel ─────────────
    let txs = [];          // ETH transfers: { timestamp, value, from, to, type }
    let tokenTxs = [];     // ERC20 transfers: { timestamp, value, asset, from, to, type }
    const dataSources = [];
    const txsPerChain = {}; // chainName -> total tx count (for debug)

    // Helper to parse transfers from a single Alchemy chain
    async function fetchChainTransfers(chainName) {
      const alchemyNetwork = ALCHEMY_NETWORKS[chainName];
      if (!alchemyKey || !alchemyNetwork) return;

      const alchemyUrl = `https://${alchemyNetwork}.g.alchemy.com/v2/${alchemyKey}`;

      try {
        console.log(`[tax-summary] Fetching Alchemy transfers for chain: ${chainName} (${alchemyNetwork})`);
        const { inTransfers, outTransfers } = await fetchAlchemyTransfers(address, alchemyUrl);

        const alchemyTs = (transfer) =>
          transfer.metadata?.blockTimestamp
            ? Math.floor(new Date(transfer.metadata.blockTimestamp).getTime() / 1000)
            : 0;

        const chainTxs = [];
        const chainTokenTxs = [];

        for (const t of inTransfers) {
          const ts = alchemyTs(t);
          if (t.category === 'external' || t.category === 'internal') {
            chainTxs.push({
              timestamp: ts, value: t.value || 0, from: t.from, to: t.to, type: 'in', isError: 0,
              category: t.category, chain: chainName,
              isStakingReward: (t.category === 'internal' || t.category === 'external') && rocketpoolContracts.has((t.from || '').toLowerCase()),
            });
          } else if (t.category === 'erc20') {
            chainTokenTxs.push({ timestamp: ts, value: t.value || 0, asset: t.asset || '', from: t.from, to: t.to, type: 'in', chain: chainName });
          }
        }
        for (const t of outTransfers) {
          const ts = alchemyTs(t);
          if (t.category === 'external' || t.category === 'internal') {
            chainTxs.push({ timestamp: ts, value: t.value || 0, from: t.from, to: t.to, type: 'out', isError: 0, category: t.category, chain: chainName });
          } else if (t.category === 'erc20') {
            chainTokenTxs.push({ timestamp: ts, value: t.value || 0, asset: t.asset || '', from: t.from, to: t.to, type: 'out', chain: chainName });
          }
        }

        console.log(`[tax-summary] ${chainName}: ${chainTxs.length} ETH txs, ${chainTokenTxs.length} token txs`);
        return { chainTxs, chainTokenTxs, chainName, source: `alchemy:${alchemyNetwork}` };
      } catch (err) {
        console.error(`[tax-summary] Alchemy failed for ${chainName}:`, err.message);
        return null;
      }
    }

    // Fetch all chains in parallel
    console.log(`[tax-summary] Launching parallel fetch for ${chainsToScan.length} chain(s):`, chainsToScan);
    const chainResults = await Promise.allSettled(chainsToScan.map(c => fetchChainTransfers(c)));

    for (const result of chainResults) {
      if (result.status === 'fulfilled' && result.value) {
        const { chainTxs, chainTokenTxs, chainName, source } = result.value;
        txsPerChain[chainName] = chainTxs.length + chainTokenTxs.length;
        txs.push(...chainTxs);
        tokenTxs.push(...chainTokenTxs);
        dataSources.push(source);
      } else if (result.status === 'rejected') {
        console.error('[tax-summary] Chain fetch rejected:', result.reason);
      }
    }
    console.log('[tax-summary] txsPerChain:', txsPerChain);

    // ── 1b. Merge + sort by timestamp ascending ──────────────────────────────
    txs.sort((a, b) => a.timestamp - b.timestamp);
    tokenTxs.sort((a, b) => a.timestamp - b.timestamp);

    let dataSource = dataSources.length > 0 ? dataSources.join('+') : 'etherscan';

    // ── 2. Etherscan fallback (only if Alchemy failed or key missing; ethereum mainnet only) ──
    if (dataSources.length === 0 && (chainsToScan.includes('ethereum') || !alchemyKey)) {
      const apiKey = process.env.ETHERSCAN_API_KEY || '';
      const [txRes, tokenRes] = await Promise.all([
        fetch(
          `https://api.etherscan.io/api?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&sort=asc&apikey=${apiKey}`
        ),
        fetch(
          `https://api.etherscan.io/api?module=account&action=tokentx&address=${address}&startblock=0&endblock=99999999&sort=asc&apikey=${apiKey}`
        ),
      ]);
      const [txData, tokenData] = await Promise.all([txRes.json(), tokenRes.json()]);

      const rawTxs = Array.isArray(txData.result) ? txData.result : [];
      const rawToken = Array.isArray(tokenData.result) ? tokenData.result : [];

      txs = rawTxs
        .filter(tx => tx.isError !== '1')
        .map(tx => ({
          timestamp: parseInt(tx.timeStamp),
          value: parseFloat(tx.value) / 1e18,
          from: tx.from,
          to: tx.to,
          type: tx.to?.toLowerCase() === addrLower ? 'in' : 'out',
          isError: 0,
          chain: 'ethereum',
        }));

      tokenTxs = rawToken.map(t => ({
        timestamp: parseInt(t.timeStamp),
        value: parseFloat(t.value) / Math.pow(10, parseInt(t.tokenDecimal) || 18),
        asset: t.tokenSymbol || '',
        from: t.from,
        to: t.to,
        type: t.to?.toLowerCase() === addrLower ? 'in' : 'out',
        chain: 'ethereum',
      }));

      dataSource = 'etherscan';
    }

    // ── 2b. Filter transactions by tax year date range ──────────────────────
    if (startTs > 0 || endTs < Math.floor(Date.now() / 1000)) {
      txs = txs.filter(tx => tx.timestamp >= startTs && tx.timestamp <= endTs);
      tokenTxs = tokenTxs.filter(tx => tx.timestamp >= startTs && tx.timestamp <= endTs);
    }

    // Merge minipool reward txs (dedup by hash, respect date filter)
    if (minipoolRewardTxs.length > 0) {
      const existingHashes = new Set(txs.map(t => t.hash).filter(Boolean));
      const deduped = minipoolRewardTxs.filter(r =>
        r.timestamp >= startTs && r.timestamp <= endTs && !existingHashes.has(r.hash)
      );
      txs.push(...deduped);
      txs.sort((a, b) => a.timestamp - b.timestamp);
      console.log(`[tax-summary] merged ${deduped.length} minipool reward tx(s) after dedup+date filter`);
    }

    // ── 3. Get current ETH price ─────────────────────────────────────────────
    let currentEthPrice = 3000;
    try {
      const priceRes = await fetch(
        'https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd'
      );
      const priceData = await priceRes.json();
      if (priceData?.ethereum?.usd) currentEthPrice = priceData.ethereum.usd;
    } catch {
      // Use default fallback
    }

    // ── 4. Collect timestamps and batch-fetch ETH historical prices ───────────
    const ethTxsWithValue = txs.filter(tx => parseFloat(tx.value) > 0);
    const allTimestamps = ethTxsWithValue.map(tx => tx.timestamp);

    const priceMap = allTimestamps.length > 0
      ? await fetchHistoricalPrices(allTimestamps, 'coingecko:ethereum')
      : {};

    // ── 5. Batch-fetch token historical prices ───────────────────────────────
    // Group token timestamps by symbol for coins we track
    const tokenPriceMaps = {};
    for (const [symbol, llamaId] of Object.entries(DEFI_LLAMA_IDS)) {
      if (symbol === 'ETH') continue; // already handled above
      const relevantTxs = tokenTxs.filter(t => t.asset?.toUpperCase() === symbol && parseFloat(t.value) > 0);
      if (relevantTxs.length > 0) {
        const timestamps = relevantTxs.map(t => t.timestamp);
        try {
          tokenPriceMaps[symbol] = await fetchHistoricalPrices(timestamps, llamaId);
        } catch {
          tokenPriceMaps[symbol] = {};
        }
      }
    }

    // ── 6. ETH FIFO cost-basis calculation ───────────────────────────────────
    let totalEthReceived = 0;
    let totalEthSent = 0;
    let shortTermGains = 0;
    let longTermGains = 0;

    // Staking income tracking (Rocket Pool + internal ETH rewards)
    let stakingEthRewards = 0;   // ETH received as staking rewards (not capital gains)
    let stakingEthUsd = 0;       // USD value at time of receipt

    const costBasisQueue = []; // { ethAmount, costBasisUsd, pricePerEth, timestamp }
    let totalBuyCostUsd = 0;
    let totalBuyEth = 0;
    let totalSaleValueUsd = 0;
    let totalSellEth = 0;

    for (const tx of ethTxsWithValue) {
      const ethValue = parseFloat(tx.value);
      const txTimestamp = tx.timestamp;
      const historicalPrice = getPriceAtTimestamp(priceMap, txTimestamp, currentEthPrice);

      if (tx.to?.toLowerCase() === addrLower) {
        totalEthReceived += ethValue;
        const costBasisUsd = ethValue * historicalPrice;

        // Staking rewards are income at receipt price — exclude from cap gains cost basis tracking
        if (tx.isStakingReward) {
          stakingEthRewards += ethValue;
          stakingEthUsd += costBasisUsd;
          // Still add to cost basis queue (income received, basis = FMV at receipt)
          costBasisQueue.push({ ethAmount: ethValue, costBasisUsd, pricePerEth: historicalPrice, timestamp: txTimestamp });
        } else {
          totalBuyCostUsd += costBasisUsd;
          totalBuyEth += ethValue;
          costBasisQueue.push({ ethAmount: ethValue, costBasisUsd, pricePerEth: historicalPrice, timestamp: txTimestamp });
        }
      }

      if (tx.from?.toLowerCase() === addrLower) {
        totalEthSent += ethValue;
        const saleValueUsd = ethValue * historicalPrice;
        totalSaleValueUsd += saleValueUsd;
        totalSellEth += ethValue;

        let remaining = ethValue;

        while (remaining > 0 && costBasisQueue.length > 0) {
          const lot = costBasisQueue[0];
          const heldDays = (txTimestamp - lot.timestamp) / 86400;

          let lotCostUsed, lotEthUsed;

          if (lot.ethAmount <= remaining) {
            lotCostUsed = lot.costBasisUsd;
            lotEthUsed = lot.ethAmount;
            remaining -= lot.ethAmount;
            costBasisQueue.shift();
          } else {
            const fraction = remaining / lot.ethAmount;
            lotCostUsed = lot.costBasisUsd * fraction;
            lotEthUsed = remaining;
            lot.ethAmount -= remaining;
            lot.costBasisUsd *= (1 - fraction);
            remaining = 0;
          }

          const lotSaleValue = lotEthUsed * historicalPrice;
          const gain = lotSaleValue - lotCostUsed;

          if (heldDays >= 365) {
            longTermGains += gain;
          } else {
            shortTermGains += gain;
          }
        }
      }
    }

    // ── 7. Token gains (ERC20, FIFO per symbol) ──────────────────────────────
    let tokenShortTermGains = 0;
    let tokenLongTermGains = 0;
    let stakingRplRewards = 0;   // RPL received as staking rewards (income)
    let stakingRplUsd = 0;

    const tokenSymbols = [...new Set(tokenTxs.map(t => t.asset?.toUpperCase()).filter(Boolean))];

    for (const symbol of tokenSymbols) {
      const llamaId = DEFI_LLAMA_IDS[symbol];
      if (!llamaId) continue; // only tracked tokens

      const priceMapToken = tokenPriceMaps[symbol] || {};
      const symbolTxs = tokenTxs
        .filter(t => t.asset?.toUpperCase() === symbol && parseFloat(t.value) > 0)
        .sort((a, b) => a.timestamp - b.timestamp);

      const tokenQueue = []; // { amount, costBasisUsd, timestamp }

      for (const tx of symbolTxs) {
        const amount = parseFloat(tx.value);
        const ts = tx.timestamp;
        // Stablecoins (USDC, USDT) use price ~1.0 unless we have a real price
        const fallbackPrice = (symbol === 'USDC' || symbol === 'USDT') ? 1.0 : currentEthPrice;
        const historicalPrice = getPriceAtTimestamp(priceMapToken, ts, fallbackPrice);

        if (tx.to?.toLowerCase() === addrLower) {
          // Received token — record cost basis
          tokenQueue.push({ amount, costBasisUsd: amount * historicalPrice, timestamp: ts });
        }

        if (tx.from?.toLowerCase() === addrLower) {
          // Sent token — FIFO realised gain
          let remaining = amount;
          const saleValueUsd = amount * historicalPrice;

          while (remaining > 0 && tokenQueue.length > 0) {
            const lot = tokenQueue[0];
            const heldDays = (ts - lot.timestamp) / 86400;
            let lotCostUsed, lotAmountUsed;

            if (lot.amount <= remaining) {
              lotCostUsed = lot.costBasisUsd;
              lotAmountUsed = lot.amount;
              remaining -= lot.amount;
              tokenQueue.shift();
            } else {
              const fraction = remaining / lot.amount;
              lotCostUsed = lot.costBasisUsd * fraction;
              lotAmountUsed = remaining;
              lot.amount -= remaining;
              lot.costBasisUsd *= (1 - fraction);
              remaining = 0;
            }

            const lotSaleValue = lotAmountUsed * historicalPrice;
            const gain = lotSaleValue - lotCostUsed;

            if (heldDays >= 365) {
              tokenLongTermGains += gain;
            } else {
              tokenShortTermGains += gain;
            }
          }
        }
      }
    }

    // ── 8. Unrealised gain/loss on remaining ETH holdings ───────────────────
    const remainingCostBasis = costBasisQueue.reduce((sum, lot) => sum + lot.costBasisUsd, 0);
    const remainingEth = costBasisQueue.reduce((sum, lot) => sum + lot.ethAmount, 0);
    const currentHoldingsValue = remainingEth * currentEthPrice;
    const unrealisedGainLoss = currentHoldingsValue - remainingCostBasis;

    const avgBuyPrice = totalBuyEth > 0 ? totalBuyCostUsd / totalBuyEth : 0;
    const avgSellPrice = totalSellEth > 0 ? totalSaleValueUsd / totalSellEth : 0;

    const netEth = totalEthReceived - totalEthSent;
    const totalGains = shortTermGains + longTermGains + tokenShortTermGains + tokenLongTermGains;

    // ── 9. Staking income totals ─────────────────────────────────────────────
    const stakingIncomeTotalUsd = Math.round(stakingEthUsd + stakingRplUsd);

    return NextResponse.json({
      address,
      network,
      chains: chainsToScan,
      txCount: txs.length,
      tokenTxCount: tokenTxs.length,
      totalEthReceived: parseFloat(totalEthReceived.toFixed(4)),
      totalEthSent: parseFloat(totalEthSent.toFixed(4)),
      netEth: parseFloat(netEth.toFixed(4)),
      netEthUsd: Math.round(netEth * currentEthPrice),
      // ETH gains
      shortTermGains: Math.round(shortTermGains),
      longTermGains: Math.round(longTermGains),
      // Token gains (tracked ERC20s)
      tokenShortTermGains: Math.round(tokenShortTermGains),
      tokenLongTermGains: Math.round(tokenLongTermGains),
      // Combined
      totalGains: Math.round(totalGains),
      unrealisedGainLoss: Math.round(unrealisedGainLoss),
      avgBuyPrice: Math.round(avgBuyPrice * 100) / 100,
      avgSellPrice: Math.round(avgSellPrice * 100) / 100,
      ethPrice: currentEthPrice,
      // Staking income (taxed as ordinary income, not capital gains)
      stakingIncome: {
        ethRewards: parseFloat(stakingEthRewards.toFixed(6)),
        rplRewards: parseFloat(stakingRplRewards.toFixed(6)),
        totalUsd: stakingIncomeTotalUsd,
        // Accrued in minipool contracts (not yet distributed/claimed — not yet taxable in most jurisdictions)
        minipoolAccruedEth: isRpNode
          ? parseFloat([...minipoolBalances.values()].reduce((s, v) => s + v, 0).toFixed(6))
          : 0,
        minipoolAccruedUsd: isRpNode
          ? Math.round([...minipoolBalances.values()].reduce((s, v) => s + v, 0) * currentEthPrice)
          : 0,
        minipoolCount: minipoolAddresses.size,
      },
      // Transaction list for history table (capped at 200, sorted newest first)
      transactions: [...txs, ...tokenTxs]
        .filter(tx => tx.timestamp > 0)
        .sort((a, b) => b.timestamp - a.timestamp)
        .slice(0, 200)
        .map(tx => ({
          hash: tx.hash || tx.uniqueId || null,
          date: new Date(tx.timestamp * 1000).toISOString(),
          type: tx.isStakingReward ? 'Staking Reward'
              : tx.asset && tx.asset !== 'ETH' ? 'Token Transfer'
              : tx.type === 'in' ? 'ETH Received'
              : 'ETH Sent',
          asset: tx.asset || 'ETH',
          amount: parseFloat((tx.value || 0).toFixed(6)),
          from: tx.from || '',
          to: tx.to || '',
          isStakingReward: tx.isStakingReward || false,
          chain: tx.chain || 'ethereum',
        })),
      priceDataSource: 'DeFiLlama historical',
      dataSource,
      fetchedAt: new Date().toISOString(),
      debug: {
        chainsScanned: chainsToScan,
        txsPerChain,
        dataSource: dataSources.length > 0 ? 'alchemy' : 'etherscan',
      },
    });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
