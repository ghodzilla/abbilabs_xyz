'use strict';

require('dotenv').config({ path: '/home/node/.openclaw/workspace/.env' });

const fs = require('fs');
const path = require('path');
const https = require('https');

// ─── Config ──────────────────────────────────────────────────────────────────

const ALCHEMY_API_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_API_KEY) {
  console.error('[FATAL] ALCHEMY_API_KEY not found in .env');
  process.exit(1);
}

const WALLETS_FILE = path.join(__dirname, 'wallets.json');
const CACHE_DIR    = path.join(__dirname, 'cache');
const MANIFEST_FILE = path.join(CACHE_DIR, 'manifest.json');

const RATE_LIMIT_MS = 200;
const MAX_PAGES     = 50;

const NETWORK_MAP = {
  ethereum: 'eth-mainnet',
  base:     'base-mainnet',
  arbitrum: 'arb-mainnet',
  optimism: 'opt-mainnet',
  polygon:  'polygon-mainnet',
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

function log(msg) {
  console.log(`[${new Date().toISOString()}] ${msg}`);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function httpsPost(url, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const urlObj = new URL(url);
    const options = {
      hostname: urlObj.hostname,
      path:     urlObj.pathname + urlObj.search,
      method:   'POST',
      headers: {
        'Content-Type':   'application/json',
        'Content-Length': Buffer.byteLength(data),
      },
    };
    const req = https.request(options, res => {
      let raw = '';
      res.on('data', chunk => { raw += chunk; });
      res.on('end', () => {
        try { resolve(JSON.parse(raw)); }
        catch (e) { reject(new Error('Invalid JSON: ' + raw.slice(0, 200))); }
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

function httpsGet(url) {
  return new Promise((resolve, reject) => {
    https.get(url, res => {
      let raw = '';
      res.on('data', chunk => { raw += chunk; });
      res.on('end', () => {
        try { resolve(JSON.parse(raw)); }
        catch (e) { reject(new Error('Invalid JSON: ' + raw.slice(0, 200))); }
      });
    }).on('error', reject);
  });
}

function ensureCacheDir() {
  if (!fs.existsSync(CACHE_DIR)) {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
  }
}

function loadWallets() {
  if (!fs.existsSync(WALLETS_FILE)) {
    const defaults = [
      {
        address: '0x0123caFe4c792D6255BB94357Bc98AFF2c916A4E',
        chains: ['ethereum', 'base', 'arbitrum', 'optimism', 'polygon'],
      },
      {
        address: 'HKtJbGPAHZH14b9r1FWhzTe82nRApnPGoQ9G5KPRn3Uj',
        chains: ['solana'],
      },
    ];
    fs.writeFileSync(WALLETS_FILE, JSON.stringify(defaults, null, 2));
    log(`Created wallets.json with default wallets`);
    return defaults;
  }
  return JSON.parse(fs.readFileSync(WALLETS_FILE, 'utf8'));
}

// ─── EVM via Alchemy ──────────────────────────────────────────────────────────

async function fetchAlchemyTransactions(address, chain) {
  const network = NETWORK_MAP[chain];
  if (!network) throw new Error(`Unknown chain: ${chain}`);
  const url = `https://${network}.g.alchemy.com/v2/${ALCHEMY_API_KEY}`;

  const allTransfers = [];
  let pageKey = undefined;
  let page = 0;

  while (page < MAX_PAGES) {
    page++;
    const params = {
      fromAddress:      address,
      category:         ['external', 'internal', 'erc20', 'erc721', 'erc1155'],
      withMetadata:     true,
      excludeZeroValue: false,
      maxCount:         '0x3e8', // 1000
    };
    if (pageKey) params.pageKey = pageKey;

    const body = {
      id:      1,
      jsonrpc: '2.0',
      method:  'alchemy_getAssetTransfers',
      params:  [params],
    };

    log(`  [${chain}] Fetching page ${page} (from) for ${address.slice(0, 10)}...`);
    await sleep(RATE_LIMIT_MS);
    const respFrom = await httpsPost(url, body);
    const fromTxs = (respFrom.result && respFrom.result.transfers) ? respFrom.result.transfers : [];
    allTransfers.push(...fromTxs);
    const nextFrom = respFrom.result && respFrom.result.pageKey;

    // Also fetch toAddress transfers
    const paramsTo = { ...params, fromAddress: undefined, toAddress: address };
    if (pageKey) paramsTo.pageKey = pageKey;
    const bodyTo = {
      id:      2,
      jsonrpc: '2.0',
      method:  'alchemy_getAssetTransfers',
      params:  [paramsTo],
    };

    log(`  [${chain}] Fetching page ${page} (to) for ${address.slice(0, 10)}...`);
    await sleep(RATE_LIMIT_MS);
    const respTo = await httpsPost(url, bodyTo);
    const toTxs = (respTo.result && respTo.result.transfers) ? respTo.result.transfers : [];
    allTransfers.push(...toTxs);
    const nextTo = respTo.result && respTo.result.pageKey;

    // Advance page key — use from-direction as driver (if exhausted, try to)
    pageKey = nextFrom || nextTo;
    if (!pageKey) break;
  }

  if (page >= MAX_PAGES) {
    log(`  [${chain}] WARNING: Hit MAX_PAGES (${MAX_PAGES}) for ${address.slice(0, 10)} — may be incomplete`);
  }

  // Deduplicate by hash+asset
  const seen = new Set();
  const deduped = allTransfers.filter(tx => {
    const key = `${tx.hash}-${tx.asset}-${tx.from}-${tx.to}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  log(`  [${chain}] Total unique transfers: ${deduped.length} for ${address.slice(0, 10)}`);
  return deduped;
}

// ─── Solana via public RPC ────────────────────────────────────────────────────

async function fetchSolanaTransactions(address) {
  const RPC = 'https://api.mainnet-beta.solana.com';
  const allSignatures = [];
  let before = undefined;
  let page = 0;

  while (page < MAX_PAGES) {
    page++;
    const params = [address, { limit: 1000 }];
    if (before) params[1].before = before;

    const body = {
      jsonrpc: '2.0',
      id:      1,
      method:  'getSignaturesForAddress',
      params,
    };

    log(`  [solana] Fetching page ${page} for ${address.slice(0, 10)}...`);
    await sleep(RATE_LIMIT_MS);

    let resp;
    try {
      resp = await httpsPost(RPC, body);
    } catch (e) {
      log(`  [solana] RPC error on page ${page}: ${e.message}`);
      break;
    }

    const sigs = (resp.result && Array.isArray(resp.result)) ? resp.result : [];
    if (sigs.length === 0) break;

    allSignatures.push(...sigs);
    before = sigs[sigs.length - 1].signature;

    if (sigs.length < 1000) break; // last page
  }

  if (page >= MAX_PAGES) {
    log(`  [solana] WARNING: Hit MAX_PAGES (${MAX_PAGES}) for ${address.slice(0, 10)} — may be incomplete`);
  }

  log(`  [solana] Total signatures: ${allSignatures.length} for ${address.slice(0, 10)}`);
  return allSignatures;
}

// ─── Main sync ───────────────────────────────────────────────────────────────

async function syncWallet(wallet) {
  const { address, chains } = wallet;
  log(`\nSyncing wallet: ${address}`);

  for (const chain of chains) {
    const cacheFile = path.join(CACHE_DIR, `${address}-${chain}.json`);
    log(`  Chain: ${chain}`);

    try {
      let transfers;
      if (chain === 'solana') {
        transfers = await fetchSolanaTransactions(address);
      } else {
        transfers = await fetchAlchemyTransactions(address, chain);
      }

      const result = {
        address,
        chain,
        syncedAt: new Date().toISOString(),
        count:    transfers.length,
        transfers,
      };

      fs.writeFileSync(cacheFile, JSON.stringify(result, null, 2));
      log(`  [${chain}] Saved ${transfers.length} txs → ${path.basename(cacheFile)}`);
    } catch (err) {
      log(`  [${chain}] ERROR: ${err.message} — skipping`);
    }
  }
}

async function main() {
  log('=== Wallet Sync Worker starting ===');
  ensureCacheDir();

  const wallets = loadWallets();
  log(`Loaded ${wallets.length} wallets from wallets.json`);

  const manifest = {
    startedAt:  new Date().toISOString(),
    finishedAt: null,
    wallets:    [],
  };

  for (const wallet of wallets) {
    const before = Date.now();
    await syncWallet(wallet);
    const walletSummary = {
      address:  wallet.address,
      chains:   {},
      syncedAt: new Date().toISOString(),
      durationMs: Date.now() - before,
    };

    for (const chain of wallet.chains) {
      const cacheFile = path.join(CACHE_DIR, `${wallet.address}-${chain}.json`);
      if (fs.existsSync(cacheFile)) {
        try {
          const data = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
          walletSummary.chains[chain] = { count: data.count, syncedAt: data.syncedAt };
        } catch (_) {
          walletSummary.chains[chain] = { count: 0, error: 'read error' };
        }
      } else {
        walletSummary.chains[chain] = { count: 0, error: 'not synced' };
      }
    }

    manifest.wallets.push(walletSummary);
  }

  manifest.finishedAt = new Date().toISOString();
  fs.writeFileSync(MANIFEST_FILE, JSON.stringify(manifest, null, 2));
  log(`\n=== Sync complete. Manifest saved. ===`);
  log(`Total wallets: ${wallets.length}`);

  for (const w of manifest.wallets) {
    log(`  ${w.address.slice(0, 16)}... — ${Object.entries(w.chains).map(([c, v]) => `${c}:${v.count ?? 0}`).join(', ')}`);
  }
}

async function mainWithPush() {
  await main();
  await pushCacheToGitHub();
}

mainWithPush().catch(err => {
  console.error('[FATAL]', err);
  process.exit(1);
});

// ─── GitHub Data Branch Push ──────────────────────────────────────────────────

async function githubApiRequest(method, path, body) {
  const token = process.env.GITHUB_TOKEN;
  if (!token) { log('[github] No GITHUB_TOKEN — skipping push'); return null; }
  const url = `https://api.github.com${path}`;
  const res = await fetch(url, {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Accept': 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'User-Agent': 'passiveblocks-sync/1.0',
    },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(10000),
  });
  const text = await res.text();
  try { return JSON.parse(text); } catch { return { error: text }; }
}

async function getFileSha(filePath) {
  const result = await githubApiRequest('GET', `/repos/ghodzilla/yield-dashboard/contents/${filePath}?ref=data`);
  return result && result.sha ? result.sha : null;
}

async function pushFileToGitHub(filePath, content) {
  const sha = await getFileSha(filePath);
  const encoded = Buffer.from(JSON.stringify(content)).toString('base64');
  const body = {
    message: `sync: update ${filePath}`,
    content: encoded,
    branch: 'data',
  };
  if (sha) body.sha = sha;
  const result = await githubApiRequest('PUT', `/repos/ghodzilla/yield-dashboard/contents/${filePath}`, body);
  if (result && result.content) {
    log(`[github] ✅ Pushed ${filePath}`);
  } else {
    log(`[github] ⚠️  Failed to push ${filePath}: ${JSON.stringify(result).slice(0, 100)}`);
  }
}

async function pushCacheToGitHub() {
  log('\n[github] Pushing cache to data branch...');
  if (!fs.existsSync(CACHE_DIR)) { log('[github] No cache dir — skipping'); return; }

  const files = fs.readdirSync(CACHE_DIR).filter(f => f.endsWith('.json'));
  for (const file of files) {
    try {
      const content = JSON.parse(fs.readFileSync(path.join(CACHE_DIR, file), 'utf8'));
      await pushFileToGitHub(`cache/${file}`, content);
      await new Promise(r => setTimeout(r, 300)); // rate limit buffer
    } catch (e) {
      log(`[github] ❌ Error pushing ${file}: ${e.message}`);
    }
  }
  log('[github] Push complete.');
}
