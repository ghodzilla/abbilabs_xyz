---
name: google-sheets
description: "Read, write, update, and manage Google Sheets spreadsheets via the Sheets API v4. Use when: the agent needs to track data, build reports, manage inventories, log entries, or work with any tabular data in Google Sheets. Requires a Google service account JSON key."
homepage: https://developers.google.com/sheets/api
metadata:
  openclaw:
    emoji: "📊"
    requires:
      env:
        - GOOGLE_SERVICE_ACCOUNT_JSON
      node: true
    category: "Productivity"
    price: "$19"
    platforms: ["OpenClaw"]
    llm_compatible: ["Claude", "GPT", "Any"]
---

# Google Sheets Skill

Full read/write access to Google Sheets. Track revenue, manage inventories, build dashboards, log data — anything you'd do in a spreadsheet, your agent can now do autonomously.

## When to Use

✅ **USE this skill when:**
- Reading data from a spreadsheet (reports, lookups, dashboards)
- Writing or appending rows (logging, tracking, data entry)
- Creating new spreadsheets or tabs
- Updating specific cells or ranges
- Building automated reports from other data sources
- Managing inventories, contacts, or any structured data

## When NOT to Use

❌ **DON'T use this skill when:**
- Complex data analysis requiring pivot tables → use Python/pandas
- Real-time collaboration features → use Sheets UI directly
- Spreadsheet formatting (colors, fonts, borders) → limited support
- Files over 10 million cells → use a database instead

## Setup (One-Time)

### 1. Create a Google Cloud Project
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project (or use existing)
3. Enable the **Google Sheets API** and **Google Drive API**

### 2. Create a Service Account
1. Go to **IAM & Admin → Service Accounts**
2. Click **Create Service Account**
3. Name it (e.g., `openclaw-sheets`)
4. Click **Create and Continue** → **Done**
5. Click the service account → **Keys** tab → **Add Key** → **Create new key** → **JSON**
6. Download the JSON file

### 3. Configure the Skill
```bash
# Option A: Set the entire JSON as an environment variable
export GOOGLE_SERVICE_ACCOUNT_JSON='{"type":"service_account","project_id":"...","private_key":"...","client_email":"..."}'

# Option B: Set the path to the JSON file
export GOOGLE_SERVICE_ACCOUNT_KEY_FILE='/path/to/service-account.json'
```

### 4. Grant IAM Role
In **Google Cloud Console → IAM & Admin → IAM**, click **Grant Access**. Add the service account email as a principal with the **Editor** role.

### 5. Share Spreadsheets with the Service Account
Share any spreadsheet you want the agent to access with the service account email address (found in the JSON file as `client_email`). Give it **Editor** access.

> **Important:** Service accounts have 0 bytes of Google Drive storage. They **cannot create new spreadsheets** — only read/write spreadsheets that have been shared with them. Create your spreadsheet in Google Sheets first, then share it with the service account email.

## Commands

All commands use the script at `scripts/sheets.cjs`.

### Read Data

```bash
# Read entire sheet
node scripts/sheets.cjs read <spreadsheetId> [sheetName] [range]

# Read specific range
node scripts/sheets.cjs read "1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms" "Sheet1" "A1:D10"

# Read all data from first sheet
node scripts/sheets.cjs read "1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms"
```

**Output:** JSON array of rows. First row is treated as headers.

### Write Data (Overwrite)

```bash
# Write to a range (overwrites existing data)
node scripts/sheets.cjs write <spreadsheetId> <sheetName> <range> '<json_data>'

# Example: Write headers + data
node scripts/sheets.cjs write "SHEET_ID" "Sheet1" "A1:C3" '[["Name","Email","Status"],["Alice","alice@example.com","Active"],["Bob","bob@example.com","Pending"]]'
```

### Append Rows

```bash
# Append rows to the end of existing data
node scripts/sheets.cjs append <spreadsheetId> <sheetName> '<json_data>'

# Example: Add a new row
node scripts/sheets.cjs append "SHEET_ID" "Sheet1" '[["Charlie","charlie@example.com","Active"]]'

# Append multiple rows
node scripts/sheets.cjs append "SHEET_ID" "Sheet1" '[["Row1Col1","Row1Col2"],["Row2Col1","Row2Col2"]]'
```

### Update Cells

```bash
# Update specific cells
node scripts/sheets.cjs update <spreadsheetId> <sheetName> <range> '<json_data>'

# Example: Update a single cell
node scripts/sheets.cjs update "SHEET_ID" "Sheet1" "B2" '[["new-email@example.com"]]'
```

### Create Spreadsheet

```bash
# Create a new spreadsheet
node scripts/sheets.cjs create "<title>" '[{"name":"Sheet1"},{"name":"Sheet2"}]'

# Returns the new spreadsheet ID
```

### List Sheets (Tabs)

```bash
# List all sheets/tabs in a spreadsheet
node scripts/sheets.cjs list-sheets <spreadsheetId>
```

### Add Sheet (Tab)

```bash
# Add a new tab to an existing spreadsheet
node scripts/sheets.cjs add-sheet <spreadsheetId> "<sheetName>"
```

### Clear Range

```bash
# Clear data from a range
node scripts/sheets.cjs clear <spreadsheetId> <sheetName> <range>
```

### Search

```bash
# Find rows matching a value in a column
node scripts/sheets.cjs search <spreadsheetId> <sheetName> <column> "<value>"

# Example: Find all rows where column A contains "Active"
node scripts/sheets.cjs search "SHEET_ID" "Sheet1" "A" "Active"
```

## Common Patterns

### Revenue Tracking
```bash
# Append today's revenue
node scripts/sheets.cjs append "REVENUE_SHEET_ID" "2026" '[["2026-03-17","$142.00","Gumroad","5 sales"]]'

# Read this month's data
node scripts/sheets.cjs read "REVENUE_SHEET_ID" "2026" "A1:D31"
```

### Daily Log
```bash
# Append a log entry
node scripts/sheets.cjs append "LOG_SHEET_ID" "Logs" '[["2026-03-17T09:00:00Z","heartbeat","All systems healthy"]]'
```

### Contact Management
```bash
# Search for a contact
node scripts/sheets.cjs search "CONTACTS_ID" "Contacts" "B" "alice@example.com"

# Update their status
node scripts/sheets.cjs update "CONTACTS_ID" "Contacts" "C5" '[["Premium"]]'
```

## Error Handling

| Error | Cause | Fix |
|-------|-------|-----|
| `403 Forbidden` | Sheet not shared with service account | Share the sheet with the service account email |
| `404 Not Found` | Wrong spreadsheet ID | Check the ID from the sheet URL |
| `400 Bad Request` | Invalid range notation | Use A1 notation: `Sheet1!A1:C10` |
| `UNAUTHENTICATED` | Missing or invalid credentials | Check GOOGLE_SERVICE_ACCOUNT_JSON env var |

## Notes

- Google Sheets API has a quota of 300 requests per minute per project
- Maximum 10 million cells per spreadsheet
- The service account email must have Editor access to each sheet
- All times should be in ISO 8601 format for consistency
- The skill returns JSON — parse it in your agent logic
