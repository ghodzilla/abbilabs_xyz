#!/usr/bin/env node
// AI Sales Agent — Pipeline Report Generator v2
// Generates daily and weekly pipeline reports from HubSpot data
// v2: pipeline velocity metrics (avg days per stage, week-over-week trend)
//
// Usage:
//   node pipeline-report.cjs daily          → Daily pipeline summary
//   node pipeline-report.cjs weekly         → Weekly performance report (includes velocity)
//   node pipeline-report.cjs snapshot       → Current pipeline snapshot
//   node pipeline-report.cjs velocity       → Stage velocity metrics only

'use strict';

const https = require('https');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '..', 'config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

const HUBSPOT_TOKEN = process.env.HUBSPOT_ACCESS_TOKEN;
if (!HUBSPOT_TOKEN) { console.error('Error: HUBSPOT_ACCESS_TOKEN not set'); process.exit(1); }

// ─── Velocity History File ─────────────────────────────────────────────────
// Stores last week's stage velocity for comparison (avg days per stage)

const dataDir = path.join(__dirname, '..', 'data');
const velocityFile = path.join(dataDir, 'velocity-history.json');

function loadVelocityHistory() {
  try {
    if (!fs.existsSync(velocityFile)) return null;
    return JSON.parse(fs.readFileSync(velocityFile, 'utf8'));
  } catch (e) {
    return null;
  }
}

function saveVelocityHistory(data) {
  try {
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
    fs.writeFileSync(velocityFile, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error('Warning: could not save velocity history:', e.message);
  }
}

// ─── HTTP Helper ───────────────────────────────────────────────────────────

function hubspotRequest(method, endpoint, body) {
  return new Promise((resolve, reject) => {
    const url = `https://api.hubapi.com${endpoint}`;
    const payload = body ? JSON.stringify(body) : null;
    const opts = {
      method,
      headers: {
        'Authorization': `Bearer ${HUBSPOT_TOKEN}`,
        'Content-Type': 'application/json',
      },
    };
    const req = https.request(url, opts, res => {
      let d = ''; res.on('data', c => d += c);
      res.on('end', () => res.statusCode >= 400 ? reject(new Error(`${res.statusCode}: ${d}`)) : resolve(JSON.parse(d)));
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// ─── HubSpot Data Fetching ─────────────────────────────────────────────────

async function getAllDeals() {
  // Base properties
  const baseProperties = [
    'dealname', 'amount', 'dealstage', 'closedate', 'createdate',
    'hs_lastmodifieddate', 'pipeline', 'hubspot_owner_id', 'hs_deal_stage_probability'
  ];

  // Stage entry date properties — HubSpot tracks when a deal entered each stage
  // e.g. hs_date_entered_appointmentscheduled, hs_date_entered_qualifiedtobuy, etc.
  const stagesToTrack = config.hubspot.deal_stages_to_track || [];
  const stageDateProps = stagesToTrack.map(s => `hs_date_entered_${s}`);

  const properties = [...baseProperties, ...stageDateProps];

  let all = [];
  let after;

  do {
    let url = `/crm/v3/objects/deals?limit=100&properties=${properties.join(',')}`;
    if (after) url += `&after=${after}`;
    const res = await hubspotRequest('GET', url);
    all = all.concat(res.results || []);
    after = res.paging && res.paging.next && res.paging.next.after;
  } while (after);

  return all;
}

async function getNewContacts(since) {
  return hubspotRequest('POST', '/crm/v3/objects/contacts/search', {
    filterGroups: [{
      filters: [{
        propertyName: 'createdate',
        operator: 'GTE',
        value: new Date(since).getTime()
      }]
    }],
    properties: ['firstname', 'lastname', 'email', 'company', 'createdate'],
    limit: 100,
  });
}

// ─── Deal Categorisation ───────────────────────────────────────────────────

function categoriseDeals(deals) {
  const open = [];
  const closedWon = [];
  const closedLost = [];

  for (const deal of deals) {
    const stage = deal.properties.dealstage;
    const amount = parseFloat(deal.properties.amount) || 0;
    const entry = {
      name: deal.properties.dealname,
      amount,
      stage,
      created: deal.properties.createdate,
      modified: deal.properties.hs_lastmodifieddate,
      closeDate: deal.properties.closedate,
      properties: deal.properties,
    };

    if (stage === 'closedwon') closedWon.push(entry);
    else if (stage === 'closedlost') closedLost.push(entry);
    else open.push(entry);
  }

  return { open, closedWon, closedLost };
}

// ─── Velocity Calculation ──────────────────────────────────────────────────

/**
 * Calculate average days spent in current stage for all open deals.
 * Uses hs_date_entered_{stage} if available, falls back to hs_lastmodifieddate.
 *
 * Returns: { stageName: { avg_days: number, count: number }, ... }
 */
function calcVelocity(openDeals) {
  const stageGroups = {};

  for (const deal of openDeals) {
    const stage = deal.stage;
    if (!stage) continue;

    // Try the precise stage entry date first
    const enteredKey = `hs_date_entered_${stage}`;
    const enteredDate = deal.properties[enteredKey] || deal.properties.hs_lastmodifieddate;
    if (!enteredDate) continue;

    const daysInStage = (Date.now() - new Date(enteredDate).getTime()) / (24 * 60 * 60 * 1000);
    if (!stageGroups[stage]) stageGroups[stage] = [];
    stageGroups[stage].push(Math.max(0, daysInStage));
  }

  const result = {};
  for (const [stage, days] of Object.entries(stageGroups)) {
    const avg = days.reduce((s, d) => s + d, 0) / days.length;
    result[stage] = {
      avg_days: Math.round(avg * 10) / 10,
      count: days.length
    };
  }

  return result;
}

/**
 * Format stage name for display.
 */
function formatStageName(stage) {
  const names = {
    appointmentscheduled: 'Discovery',
    qualifiedtobuy: 'Qualified',
    presentationscheduled: 'Proposal',
    decisionmakerboughtin: 'Decision Maker',
    contractsent: 'Contract Sent',
    closedwon: 'Closed Won',
    closedlost: 'Closed Lost',
  };
  return names[stage] || stage.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

/**
 * Format velocity section for weekly report.
 * Compares to last week's data if available.
 */
function formatVelocitySection(currentVelocity, previousVelocity) {
  const stages = Object.keys(currentVelocity);
  if (stages.length === 0) return '  No open deals to measure velocity.';

  // Sort by a logical pipeline order
  const order = ['appointmentscheduled', 'qualifiedtobuy', 'presentationscheduled', 'decisionmakerboughtin', 'contractsent'];
  stages.sort((a, b) => {
    const ai = order.indexOf(a);
    const bi = order.indexOf(b);
    if (ai === -1 && bi === -1) return a.localeCompare(b);
    if (ai === -1) return 1;
    if (bi === -1) return -1;
    return ai - bi;
  });

  const lines = stages.map(stage => {
    const curr = currentVelocity[stage];
    const prev = previousVelocity && previousVelocity.stages && previousVelocity.stages[stage];

    let trend = '';
    if (prev) {
      const diff = curr.avg_days - prev.avg_days;
      if (Math.abs(diff) >= 0.5) {
        const arrow = diff > 0 ? '↑' : '↓';
        trend = ` (${arrow} from ${prev.avg_days}d last week)`;
      } else {
        trend = ' (→ steady)';
      }
    }

    return `  ${formatStageName(stage)}: avg ${curr.avg_days} days in stage — ${curr.count} deal${curr.count !== 1 ? 's' : ''}${trend}`;
  });

  return lines.join('\n');
}

// ─── Formatters ────────────────────────────────────────────────────────────

function formatCurrency(amount) {
  return '$' + amount.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

// ─── Reports ───────────────────────────────────────────────────────────────

async function dailyReport() {
  const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  const deals = await getAllDeals();
  const { open, closedWon, closedLost } = categoriseDeals(deals);
  const newContacts = await getNewContacts(yesterday);

  const totalPipeline = open.reduce((sum, d) => sum + d.amount, 0);
  const revenueToday = closedWon
    .filter(d => new Date(d.modified) > new Date(yesterday))
    .reduce((sum, d) => sum + d.amount, 0);
  const lostToday = closedLost
    .filter(d => new Date(d.modified) > new Date(yesterday))
    .reduce((sum, d) => sum + d.amount, 0);

  const topDeals = open.slice().sort((a, b) => b.amount - a.amount).slice(0, 5);

  const report = `📊 DAILY PIPELINE REPORT
${new Date().toISOString().split('T')[0]}

💰 Pipeline Value: ${formatCurrency(totalPipeline)}
📈 Open Deals: ${open.length}
🆕 New Leads (24h): ${newContacts.total || 0}
✅ Closed Won (24h): ${formatCurrency(revenueToday)}
❌ Closed Lost (24h): ${formatCurrency(lostToday)}

🏆 Top 5 Deals by Value:
${topDeals.map((d, i) => `${i + 1}. ${d.name} — ${formatCurrency(d.amount)} (${d.stage})`).join('\n') || '  (none)'}

${closedWon.length > 0 ? `\n🎉 Recent Wins:\n${closedWon.slice(0, 3).map(d => `• ${d.name} — ${formatCurrency(d.amount)}`).join('\n')}` : ''}
${revenueToday === 0 && lostToday === 0 ? '\n📝 No deals closed in the last 24 hours.' : ''}`.trim();

  return report;
}

async function weeklyReport() {
  const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
  const deals = await getAllDeals();
  const { open, closedWon, closedLost } = categoriseDeals(deals);
  const newContacts = await getNewContacts(weekAgo);

  const totalPipeline = open.reduce((sum, d) => sum + d.amount, 0);
  const weekRevenue = closedWon
    .filter(d => new Date(d.modified) > new Date(weekAgo))
    .reduce((sum, d) => sum + d.amount, 0);
  const weekLost = closedLost
    .filter(d => new Date(d.modified) > new Date(weekAgo))
    .reduce((sum, d) => sum + d.amount, 0);
  const weekClosedWon = closedWon.filter(d => new Date(d.modified) > new Date(weekAgo));
  const weekClosedLost = closedLost.filter(d => new Date(d.modified) > new Date(weekAgo));
  const totalClosed = weekClosedWon.length + weekClosedLost.length;
  const winRate = totalClosed > 0
    ? Math.round(weekClosedWon.length / totalClosed * 100)
    : 0;

  // ── Velocity ──
  const currentVelocity = calcVelocity(open);
  const previousVelocity = loadVelocityHistory();
  const velocitySection = formatVelocitySection(currentVelocity, previousVelocity);

  // Save current velocity as next week's "previous"
  saveVelocityHistory({
    week: new Date().toISOString().split('T')[0],
    stages: currentVelocity,
  });

  const report = `📊 WEEKLY PERFORMANCE REPORT
Week of ${new Date(weekAgo).toISOString().split('T')[0]} → ${new Date().toISOString().split('T')[0]}

💰 PIPELINE
Total Value: ${formatCurrency(totalPipeline)}
Open Deals: ${open.length}

📈 THIS WEEK
New Leads: ${newContacts.total || 0}
Revenue Closed: ${formatCurrency(weekRevenue)}
Deals Lost: ${formatCurrency(weekLost)}
Win Rate: ${winRate}%

🏆 BIGGEST WINS
${weekClosedWon.sort((a, b) => b.amount - a.amount).slice(0, 3).map(d => `• ${d.name} — ${formatCurrency(d.amount)}`).join('\n') || '• No deals closed this week'}

📋 TOP OPEN DEALS
${open.slice().sort((a, b) => b.amount - a.amount).slice(0, 5).map((d, i) => `${i + 1}. ${d.name} — ${formatCurrency(d.amount)} (${formatStageName(d.stage)})`).join('\n') || '• No open deals'}

⚡ PIPELINE VELOCITY (avg days in current stage)
${velocitySection}

💡 RECOMMENDATION
${weekRevenue > 0 ? `Strong week with ${formatCurrency(weekRevenue)} closed. Focus on moving the top open deals forward.` : 'No revenue this week. Prioritise follow-ups on stale deals and new lead generation.'}`;

  return report;
}

async function snapshot() {
  const deals = await getAllDeals();
  const { open, closedWon, closedLost } = categoriseDeals(deals);

  const byStage = {};
  for (const deal of open) {
    byStage[deal.stage] = byStage[deal.stage] || { count: 0, value: 0 };
    byStage[deal.stage].count++;
    byStage[deal.stage].value += deal.amount;
  }

  const report = `📸 PIPELINE SNAPSHOT
${new Date().toISOString()}

Total Open: ${open.length} deals — ${formatCurrency(open.reduce((s, d) => s + d.amount, 0))}
Total Won: ${closedWon.length} deals — ${formatCurrency(closedWon.reduce((s, d) => s + d.amount, 0))}
Total Lost: ${closedLost.length} deals — ${formatCurrency(closedLost.reduce((s, d) => s + d.amount, 0))}

BY STAGE:
${Object.entries(byStage).map(([stage, data]) => `• ${formatStageName(stage)}: ${data.count} deals — ${formatCurrency(data.value)}`).join('\n') || '• No open deals'}`;

  return report;
}

async function velocityReport() {
  const deals = await getAllDeals();
  const { open } = categoriseDeals(deals);
  const currentVelocity = calcVelocity(open);
  const previousVelocity = loadVelocityHistory();

  const report = `⚡ PIPELINE VELOCITY REPORT
${new Date().toISOString().split('T')[0]}

Average days deals spend in each current stage:
${formatVelocitySection(currentVelocity, previousVelocity)}

${previousVelocity ? `Compared to: ${previousVelocity.week}` : 'No previous week data yet — run weekly report to establish baseline.'}`;

  return report;
}

// ─── CLI ───────────────────────────────────────────────────────────────────

const cmd = process.argv[2];
const commands = { daily: dailyReport, weekly: weeklyReport, snapshot, velocity: velocityReport };

if (commands[cmd]) {
  commands[cmd]().then(r => console.log(r)).catch(e => console.error('Error:', e.message));
} else {
  console.log(`AI Sales Agent — Pipeline Report v2

Usage:
  node pipeline-report.cjs daily      Daily pipeline summary
  node pipeline-report.cjs weekly     Weekly report (includes velocity metrics)
  node pipeline-report.cjs snapshot   Current pipeline snapshot
  node pipeline-report.cjs velocity   Stage velocity metrics only

v2 features:
  - Pipeline velocity: avg days per stage, week-over-week trend (↑/↓)
  - Velocity history stored in data/velocity-history.json
  - Stage names humanised (e.g. "presentationscheduled" → "Proposal")`);
}
