---
name: notion-agent
description: "Read, create, update, and search pages, databases, and blocks in Notion via the API. Use when: the agent needs to manage project wikis, task databases, meeting notes, knowledge bases, or any structured content in Notion. Requires a Notion Integration Token."
homepage: https://developers.notion.com
metadata:
  openclaw:
    emoji: "📝"
    requires:
      env:
        - NOTION_API_KEY
      node: true
    category: "Productivity"
    price: "$29"
    platforms: ["OpenClaw"]
    llm_compatible: ["Claude", "GPT", "Any"]
---

# Notion Agent Skill

Full Notion integration for AI agents. Create pages, query databases, update content, search across your workspace — your agent becomes a Notion power user.

## When to Use

✅ **USE this skill when:**
- Creating or updating Notion pages (meeting notes, docs, wikis)
- Querying Notion databases (tasks, CRM, inventory, content calendar)
- Adding items to databases (new tasks, contacts, entries)
- Searching across your Notion workspace
- Building automated workflows that read/write Notion content
- Syncing data between Notion and other tools

## When NOT to Use

❌ **DON'T use this skill when:**
- Real-time collaborative editing → use Notion UI
- Complex page layouts with embeds/toggles → limited block support
- Workspace admin functions (billing, members) → use Notion admin panel
- Notion formulas or rollups → those compute server-side, just read the results

## Setup (One-Time)

### 1. Create a Notion Integration
1. Go to [notion.so/my-integrations](https://www.notion.so/my-integrations)
2. Click **New integration**
3. Name it (e.g., `AI Agent`)
4. Select the workspace
5. Set capabilities: **Read content**, **Update content**, **Insert content**
6. Click **Submit** → Copy the **Internal Integration Token**

### 2. Configure the Skill
```bash
export NOTION_API_KEY="ntn_your_token_here"
```

### 3. Share Pages/Databases with the Integration
For each page or database the agent needs to access:
1. Open the page in Notion
2. Click **⋯** (three dots) → **Connections** → **Connect to** → Select your integration

**Important:** The integration can only access pages explicitly shared with it.

## Commands

All commands use the script at `scripts/notion.cjs`.

### Search

```bash
# Search across entire workspace
node scripts/notion.cjs search "<query>"

# Search for pages only
node scripts/notion.cjs search "<query>" page

# Search for databases only
node scripts/notion.cjs search "<query>" database
```

### Read Page

```bash
# Get page properties and content
node scripts/notion.cjs get-page <pageId>

# Get page content blocks
node scripts/notion.cjs get-blocks <pageId>
```

### Create Page

```bash
# Create a page in a parent page
node scripts/notion.cjs create-page <parentPageId> "<title>" "<markdown_content>"

# Create a page in a database
node scripts/notion.cjs create-db-entry <databaseId> '<properties_json>'
```

### Update Page

```bash
# Update page properties
node scripts/notion.cjs update-page <pageId> '<properties_json>'

# Append content blocks to a page
node scripts/notion.cjs append-blocks <pageId> "<markdown_content>"
```

### Query Database

```bash
# Get all items from a database
node scripts/notion.cjs query-db <databaseId>

# Query with filter
node scripts/notion.cjs query-db <databaseId> '<filter_json>'

# Example: Get all tasks with status "In Progress"
node scripts/notion.cjs query-db "DB_ID" '{"property":"Status","status":{"equals":"In Progress"}}'

# Example: Get items created this week
node scripts/notion.cjs query-db "DB_ID" '{"property":"Created","date":{"on_or_after":"2026-03-10"}}'
```

### Get Database Schema

```bash
# View database properties/columns
node scripts/notion.cjs get-db <databaseId>
```

### Delete (Archive) Page

```bash
# Archive a page (Notion doesn't truly delete via API)
node scripts/notion.cjs archive <pageId>
```

## Common Patterns

### Task Management
```bash
# Add a new task
node scripts/notion.cjs create-db-entry "TASKS_DB_ID" '{"Name":{"title":"Fix login bug"},"Status":{"status":"To Do"},"Priority":{"select":"High"},"Assignee":{"people":["USER_ID"]}}'

# Query open tasks
node scripts/notion.cjs query-db "TASKS_DB_ID" '{"property":"Status","status":{"does_not_equal":"Done"}}'

# Mark task complete
node scripts/notion.cjs update-page "PAGE_ID" '{"Status":{"status":"Done"}}'
```

### Meeting Notes
```bash
# Create meeting notes page
node scripts/notion.cjs create-page "MEETINGS_PAGE_ID" "Team Standup 2026-03-17" "## Attendees\n- Alice\n- Bob\n\n## Discussion\n- Sprint progress on track\n- Need to resolve API timeout issue\n\n## Action Items\n- [ ] Alice: Deploy hotfix by EOD\n- [ ] Bob: Update docs"
```

### Content Calendar
```bash
# Add content idea
node scripts/notion.cjs create-db-entry "CONTENT_DB_ID" '{"Title":{"title":"AI Agent for HubSpot - Blog Post"},"Status":{"status":"Draft"},"Publish Date":{"date":"2026-03-20"},"Platform":{"select":"Blog"}}'

# Query upcoming content
node scripts/notion.cjs query-db "CONTENT_DB_ID" '{"property":"Publish Date","date":{"on_or_after":"2026-03-17"}}'
```

### Knowledge Base
```bash
# Search for existing documentation
node scripts/notion.cjs search "deployment guide" page

# Append to existing page
node scripts/notion.cjs append-blocks "PAGE_ID" "## Update 2026-03-17\nAdded rate limiting to the API gateway. New limit: 100 req/min per user."
```

### CRM / Contact Management
```bash
# Add new contact
node scripts/notion.cjs create-db-entry "CONTACTS_DB_ID" '{"Name":{"title":"Alice Smith"},"Email":{"email":"alice@company.com"},"Company":{"rich_text":"Acme Corp"},"Stage":{"select":"Lead"}}'

# Find contacts at a company
node scripts/notion.cjs query-db "CONTACTS_DB_ID" '{"property":"Company","rich_text":{"contains":"Acme"}}'
```

## Property Types Reference

When creating or updating database entries, use the correct property format:

| Type | Format | Example |
|------|--------|---------|
| Title | `{"title":"text"}` | `{"Name":{"title":"My Page"}}` |
| Rich Text | `{"rich_text":"text"}` | `{"Notes":{"rich_text":"Some notes"}}` |
| Number | `{"number":42}` | `{"Revenue":{"number":142.50}}` |
| Select | `{"select":"option"}` | `{"Status":{"select":"Active"}}` |
| Multi-select | `{"multi_select":["a","b"]}` | `{"Tags":{"multi_select":["AI","SaaS"]}}` |
| Date | `{"date":"YYYY-MM-DD"}` | `{"Due":{"date":"2026-03-20"}}` |
| Checkbox | `{"checkbox":true}` | `{"Done":{"checkbox":true}}` |
| Email | `{"email":"a@b.com"}` | `{"Email":{"email":"alice@co.com"}}` |
| URL | `{"url":"https://..."}` | `{"Website":{"url":"https://example.com"}}` |
| Status | `{"status":"option"}` | `{"Status":{"status":"In Progress"}}` |

## Error Handling

| Error | Cause | Fix |
|-------|-------|-----|
| `object_not_found` | Page/DB not shared with integration | Share it via Connections menu |
| `unauthorized` | Invalid or expired token | Regenerate at notion.so/my-integrations |
| `validation_error` | Wrong property format | Check property types with `get-db` |
| `rate_limited` | Too many requests | Script auto-retries with backoff |
| `conflict_error` | Concurrent edit conflict | Retry the request |

## Rate Limits

- Notion API: 3 requests per second per integration
- The skill handles rate limiting automatically
- For bulk operations, the script batches requests with delays

## Notes

- Page IDs are 32-char hex strings (dashes optional)
- The Notion API version used is `2022-06-28` (latest stable)
- Markdown in content is converted to Notion blocks automatically
- Database queries support sorting: add `_sort` param
- Archived pages can be restored in Notion UI
