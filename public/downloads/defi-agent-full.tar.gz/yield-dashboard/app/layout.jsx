export const metadata = {
  title: 'PassiveBlocks — Build Wealth Block by Block',
  description: 'AI-powered DeFi yield intelligence with 10-country crypto tax reporting.',
  icons: { icon: '/favicon.svg' },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0, background: '#111214' }}>{children}</body>
    </html>
  );
}
