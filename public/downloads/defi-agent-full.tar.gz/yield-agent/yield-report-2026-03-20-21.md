# Yield Intelligence Report — 2026-03-20 21:03 UTC

## Simulation Status
- **Started:** 2026-03-19
- **Running for:** 1.4 days (20 cycles)
- **Days remaining:** 5.6 of 7
- **Total rotations:** Strategy A: 19 | Strategy B: 20

---

## Strategy Standings

### Strategy A — Max APY 🏆 (LEADING)
| Metric | Value |
|--------|-------|
| Starting Capital | $2,500.00 |
| Current Balance | $2,504.85 |
| Total Earned | $4.85 |
| Return | +0.19% |
| Projected APY | 49.5% |
| Daily Earnings | $1.17 |
| Active Positions | 5/5 |

**Positions:**
1. Base | aerodrome-slipstream | USDZ-SUSDZ | 32.3% APY | $1.3M TVL
2. Arbitrum | uniswap-v3 | WBTC-WETH | 15.8% APY | $53.8M TVL
3. Arbitrum | pancakeswap-amm-v3 | WBTC-WETH | 18.1% APY | $1.4M TVL
4. Ethereum | uniswap-v3 | WBTC-WETH | 6.4% APY | $47.5M TVL
5. Ethereum | supernova-cl | USDC-USDT | 12.5% APY | $1.6M TVL

---

### Strategy B — Risk-Adjusted
| Metric | Value |
|--------|-------|
| Starting Capital | $2,500.00 |
| Current Balance | $2,503.49 |
| Total Earned | $3.49 |
| Return | +0.14% |
| Projected APY | 35.6% |
| Daily Earnings | $2.78 |
| Active Positions | 5/5 |

**Positions:**
1. Solana | jupiter-lend | USDS | 5.1% APY | $28.3M TVL ✅ Single-asset lending
2. Ethereum | fluid-lending | USDT | 4.2% APY | $142.2M TVL ✅ Single-asset lending
3. Solana | orca-dex | SOL-USDC | 61.4% APY | $29.5M TVL 🔴 CORRELATION BREACH
4. Base | pancakeswap-amm-v3 | WETH-USDC | 72.3% APY | $2.1M TVL 🔴 CORRELATION BREACH
5. Base | pancakeswap-amm-v3 | WETH-USDC | 59.9% APY | $4.6M TVL 🔴 CORRELATION BREACH

**Combined Portfolio:** $5,008.34 | Strategy A leads by **$1.36**

---

## Correlation Check Results

| Position | Strategy | Correlation | Status |
|----------|----------|-------------|--------|
| USDZ-SUSDZ (Base/aerodrome-slipstream) | A | Unknown token IDs | ⚪ Watchlist |
| WBTC-WETH (Arbitrum/uniswap-v3) | A | 89.03% | ✅ PASS (>70%) |
| WBTC-WETH (Arbitrum/pancakeswap) | A | 89.03% | ✅ PASS (>70%) |
| WBTC-WETH (Ethereum/uniswap-v3) | A | 89.03% | ✅ PASS (>70%) |
| USDC-USDT (Ethereum/supernova-cl) | A | Peg stable (max 0.046% deviation) | ✅ PASS |
| USDS (Solana/jupiter-lend) | B | Single-asset | ✅ N/A |
| USDT (Ethereum/fluid-lending) | B | Single-asset | ✅ N/A |
| SOL-USDC (Solana/orca-dex) | B | **-22.41%** | 🔴 FAIL — BELOW THRESHOLD |
| WETH-USDC (Base/pancakeswap #1) | B | **-27.15%** | 🔴 FAIL — BELOW THRESHOLD |
| WETH-USDC (Base/pancakeswap #2) | B | **-27.15%** | 🔴 FAIL — BELOW THRESHOLD |

### 🚨 Correlation Alerts (3 breaches):
- **SOL-USDC** on Solana/orca-dex: -22.41% (threshold: 70%) → Recommend EXIT
- **WETH-USDC** on Base/pancakeswap-amm-v3 (#1): -27.15% → Recommend EXIT
- **WETH-USDC** on Base/pancakeswap-amm-v3 (#2): -27.15% → Recommend EXIT

---

## Market Context (24h Price Movement)

| Asset | Price | 24h Change | IL Risk Flag |
|-------|-------|------------|--------------|
| Bitcoin (BTC) | $70,007 | -0.77% | ✅ None |
| Ethereum (ETH) | $2,132.13 | -0.75% | ✅ None |
| Solana (SOL) | $88.97 | -0.08% | ✅ None |

**Assessment:** No major price moves (all <5% in 24h). No IL risk escalation from market conditions today. However, the negative correlations on SOL-USDC and WETH-USDC pairs in Strategy B indicate structural IL exposure independent of price action.

---

## Recent Rotation History (Strategy B)
| # | Pair | Reason | Earned |
|---|------|---------|--------|
| 1 | WETH-USDC | correlation_breach (corr: -27.7%) | $0.00 |
| 2 | USDC-WETH | correlation_breach (corr: -41.4%) | $0.00 |
| 3 | USDC-WETH | correlation_breach (corr: -28.9%) | $0.13 |
| 4 | USDC-WETH | correlation_breach (corr: -28.3%) | $0.07 |
| 5 | WETH-USDC | apy_collapse | $0.14 |

Strategy B's rotation history shows repeated exits from WETH-USDC and USDC-WETH pairs due to correlation breaches — a pattern of instability in these positions.

---

## APY Changes
- No APY drops >10% detected this cycle. Sim confirmed: "✅ APY check: all positions within normal range."
- Strategy B positions with negative correlation are still generating high nominal APY (59–72%) but carry elevated IL risk.

---

## 🔴 Active Alerts

| Alert Type | Detail | Severity |
|------------|--------|----------|
| Correlation Breach | SOL-USDC corr: -22.41% (threshold 70%) | 🔴 HIGH |
| Correlation Breach | WETH-USDC corr: -27.15% (threshold 70%) | 🔴 HIGH |
| Correlation Breach | WETH-USDC corr: -27.15% (threshold 70%) | 🔴 HIGH |
| Stablecoin Peg | USDC max 0.019%, USDT max 0.046% deviation | ✅ CLEAR |
| Price Drop >10% | No assets down >10% in 24h | ✅ CLEAR |
| Simulation Day 7 | Day 1.4 of 7 — 5.6 days remaining | ⏳ Ongoing |

---

## Recommendation

**Strategy A — HOLD all positions**
- WBTC-WETH correlation at 89% (well above threshold)
- USDC-USDT peg stable
- Projected 49.5% APY healthy and sustainable for sim window

**Strategy B — FLAG for review**
- 3 of 5 positions in correlation breach (WETH-USDC and SOL-USDC vs stablecoins = decoupled)
- Sim continues rotating out of these pairs — 20 rotations in 1.4 days = high churn
- Despite high nominal APY (59–72%), impermanent loss exposure is unacceptable per Strategy B's risk-adjusted mandate
- If this were live capital: EXIT SOL-USDC and WETH-USDC positions, reallocate to stablecoin lending (e.g., expand USDS + USDT positions or add USDC lending)

**Overall:** Strategy A outperforming by $1.36 at day 1.4. Lead expected to grow if Strategy B continues churning correlated pair exits. **Strategy A appears structurally more stable for the sim window.**

---

*Report generated: 2026-03-20 21:03 UTC | Next report: 2026-03-21 03:03 UTC*
