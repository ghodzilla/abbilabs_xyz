'use client';
import { useEffect, useState } from 'react';

const TAX_YEAR_CONFIG = {
  AU: { startMonth: 7,  startDay: 1, format: 'FY{start}-{end}' },
  NZ: { startMonth: 4,  startDay: 1, format: 'FY{start}-{end}' },
  IN: { startMonth: 4,  startDay: 1, format: 'FY{start}-{end}' },
  JP: { startMonth: 4,  startDay: 1, format: 'FY{start}-{end}' },
  GB: { startMonth: 4,  startDay: 6, format: 'FY{start}/{end}' },
  US: { startMonth: 1,  startDay: 1, format: '{end}' },
  CA: { startMonth: 1,  startDay: 1, format: '{end}' },
  DE: { startMonth: 1,  startDay: 1, format: '{end}' },
  SG: { startMonth: 1,  startDay: 1, format: '{end}' },
  AE: { startMonth: 1,  startDay: 1, format: '{end}' },
};

function getTaxYears(countryCode) {
  const config = TAX_YEAR_CONFIG[countryCode] || TAX_YEAR_CONFIG.US;
  const { startMonth, startDay } = config;
  const now = new Date();
  const curYear = now.getUTCFullYear();
  const curMonth = now.getUTCMonth() + 1;
  const curDay = now.getUTCDate();
  const fyStartedThisYear = curMonth > startMonth || (curMonth === startMonth && curDay >= startDay);
  const currentFyStartYear = fyStartedThisYear ? curYear : curYear - 1;
  const calendarYear = startMonth === 1;
  const years = [];
  for (let i = 0; i < 5; i++) {
    const fyStartYear = currentFyStartYear - i;
    const startTs = Math.floor(Date.UTC(fyStartYear, startMonth - 1, startDay) / 1000);
    const endTs = Math.floor(Date.UTC(fyStartYear + 1, startMonth - 1, startDay) / 1000) - 1;
    const endYearFull = fyStartYear + (calendarYear ? 0 : 1);
    const endToken = calendarYear ? String(endYearFull) : String(endYearFull).slice(-2);
    const label = config.format.replace('{start}', fyStartYear).replace('{end}', endToken);
    years.push({ label, startTs, endTs });
  }
  return years;
}

function formatDateShort(ts) {
  return new Date(ts * 1000).toLocaleDateString('en-GB', {
    day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC',
  });
}

const NAV_LINKS = [
  { label: 'Features', href: '/#features' },
  { label: 'Pricing', href: '/pricing' },
  { label: 'Tax', href: '/tax' },
  { label: 'Dashboard', href: '/dashboard' },
  { label: 'Wallets', href: '/wallets' },
];

const TAX_COUNTRIES = [
  { code: 'AU', flag: '🇦🇺', name: 'Australia', note: '50% CGT discount >12mo', year: 'FY 2024-25 (Jul-Jun)', rate: 0.32, discount: 0.50, currency: 'AUD' },
  { code: 'US', flag: '🇺🇸', name: 'United States', note: 'Short-term = ordinary income', year: 'FY 2024 (Jan-Dec)', rate: 0.24, discount: 0, currency: 'USD' },
  { code: 'GB', flag: '🇬🇧', name: 'United Kingdom', note: '3k CGT allowance', year: 'FY 2024-25 (Apr-Mar)', rate: 0.20, discount: 0, currency: 'GBP' },
  { code: 'CA', flag: '🇨🇦', name: 'Canada', note: '50% CGT inclusion rate', year: 'FY 2024 (Jan-Dec)', rate: 0.26, discount: 0.50, currency: 'CAD' },
  { code: 'DE', flag: '🇩🇪', name: 'Germany', note: 'Tax-free after 12 months', year: 'FY 2024 (Jan-Dec)', rate: 0.42, discount: 0, currency: 'EUR' },
  { code: 'JP', flag: '🇯🇵', name: 'Japan', note: 'Misc. income up to 55%', year: 'FY 2024 (Jan-Dec)', rate: 0.45, discount: 0, currency: 'JPY' },
  { code: 'SG', flag: '🇸🇬', name: 'Singapore', note: 'No CGT for individuals', year: 'FY 2024 (Jan-Dec)', rate: 0, discount: 0, currency: 'SGD', taxFree: true },
  { code: 'AE', flag: '🇦🇪', name: 'UAE', note: 'No personal income/CGT tax', year: 'FY 2024 (Jan-Dec)', rate: 0, discount: 0, currency: 'AED', taxFree: true },
  { code: 'IN', flag: '🇮🇳', name: 'India', note: 'Flat 30% on all gains', year: 'FY 2024-25 (Apr-Mar)', rate: 0.30, discount: 0, currency: 'INR' },
  { code: 'NZ', flag: '🇳🇿', name: 'New Zealand', note: 'No CGT generally', year: 'FY 2024 (Apr-Mar)', rate: 0, discount: 0, currency: 'NZD', taxFree: true },
];

const DEMO = {
  shortTermGains: 1850,
  longTermGains: 2430,
  yieldIncome: 1920,
  gasDeductions: 180,
  capitalGains: 4280,
};

const TX_HEADERS = ['Date', 'Type', 'Asset', 'Amount', 'Value (AUD)', 'Gain / Loss', 'Classification'];

const HARVEST_OPPORTUNITIES = [
  { asset: 'ETH/USDC LP', unrealisedLoss: -340, position: '$4,200', recommendation: 'Consider harvesting to offset gains' },
  { asset: 'ARB', unrealisedLoss: -210, position: '$1,850', recommendation: 'Short-term loss available' },
  { asset: 'MATIC', unrealisedLoss: -155, position: '$920', recommendation: 'Small loss - harvest if near year-end' },
  { asset: 'UNI', unrealisedLoss: -88, position: '$650', recommendation: 'Minor - consider transaction costs' },
];

const HOLDING_PERIODS = [
  { asset: 'wstETH', acquiredDate: '2024-05-03', daysHeld: 322, daysToThreshold: 43, value: '$8,400', potentialSaving: '$1,260' },
  { asset: 'USDC/ETH LP', acquiredDate: '2024-04-18', daysHeld: 337, daysToThreshold: 28, value: '$5,200', potentialSaving: '$780' },
  { asset: 'cbETH', acquiredDate: '2024-03-10', daysHeld: 376, daysToThreshold: 0, value: '$3,100', potentialSaving: '$465', qualified: true },
];

function calcTax(taxData, country) {
  if (!taxData || country.taxFree) return 0;
  const longTermTaxable = (taxData.longTermGains || 0) * (1 - (country.discount || 0));
  const netTaxable = (taxData.shortTermGains || 0) + longTermTaxable + (taxData.stakingIncome?.totalUsd || 0);
  return Math.max(0, Math.round(netTaxable * country.rate));
}

function LoadingDots() {
  const [dots, setDots] = useState('');
  useEffect(() => {
    const id = setInterval(() => setDots(d => d.length >= 3 ? '' : d + '.'), 500);
    return () => clearInterval(id);
  }, []);
  return <span style={{ display: 'inline-block', minWidth: 20 }}>{dots}</span>;
}

function DisabledButton({ label, tooltip }) {
  const [show, setShow] = useState(false);
  return (
    <div style={{ position: 'relative', display: 'inline-block' }}
      onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}>
      <button disabled style={{ background: '#2a2b30', color: '#6b6c72', border: 'none', borderRadius: 8, padding: '10px 20px', fontSize: 13, fontWeight: 600, cursor: 'not-allowed' }}>{label}</button>
      {show && tooltip && (
        <div style={{ position: 'absolute', bottom: '110%', left: '50%', transform: 'translateX(-50%)', background: '#18191d', border: '1px solid #2a2b30', borderRadius: 8, padding: '7px 12px', fontSize: 12, color: '#6b6c72', whiteSpace: 'nowrap', zIndex: 10, boxShadow: '0 4px 16px #0006' }}>{tooltip}</div>
      )}
    </div>
  );
}

function LockedPanel({ upgradeLabel, href, children, blurred }) {
  return (
    <div style={{ position: 'relative', overflow: 'hidden', borderRadius: 12 }}>
      {blurred && <div style={{ filter: 'blur(4px)', pointerEvents: 'none', userSelect: 'none', opacity: 0.4 }}>{children}</div>}
      <div style={{ position: blurred ? 'absolute' : 'static', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: blurred ? 'rgba(17,18,20,0.7)' : 'transparent', padding: blurred ? 0 : '20px 0 4px', gap: 10 }}>
        <span style={{ fontSize: 28 }}>🔒</span>
        <a href={href || '/pricing'} style={{ background: 'linear-gradient(135deg, #6789ed, #583fdd)', color: '#fff', textDecoration: 'none', borderRadius: 8, padding: '10px 22px', fontSize: 13, fontWeight: 700 }}>{upgradeLabel}</a>
      </div>
    </div>
  );
}

export default function TaxDashboard() {
  const [country, setCountry] = useState('AU');
  const [showPicker, setShowPicker] = useState(false);
  const [userInfo, setUserInfo] = useState({ email: '', tier: 'explorer', isAdmin: false });
  const [connectedWallets, setConnectedWallets] = useState([]);
  const [selectedWalletIdx, setSelectedWalletIdx] = useState(0);
  const [realTaxData, setRealTaxData] = useState(null);
  const [loadingTax, setLoadingTax] = useState(false);
  const [taxError, setTaxError] = useState(null);

  // All-wallets state
  const [allWalletsTax, setAllWalletsTax] = useState([]);
  const [combinedTax, setCombinedTax] = useState(null);
  const [loadingAll, setLoadingAll] = useState(false);
  const [expandedWalletIdxs, setExpandedWalletIdxs] = useState(new Set([0]));

  // Tax year state
  const [taxYears, setTaxYears] = useState(() => getTaxYears('AU'));
  const [taxYearIdx, setTaxYearIdx] = useState(0);

  // Yield dashboard income
  const [yieldIncome, setYieldIncome] = useState(null);

  // Transaction history — all-time toggle
  const [showAllTime, setShowAllTime] = useState(false);

  async function fetchAllWalletsTax(wallets, yearEntry) {
    const evmWallets = wallets.filter(w => w.network !== 'solana');
    if (evmWallets.length === 0) return;
    setLoadingAll(true);
    const results = await Promise.allSettled(
      evmWallets.map(wallet => {
        // Limit to chains with actual activity; default ethereum only for speed
        const activeChains = (wallet.chains?.activeChains || [wallet.network || 'ethereum']).slice(0, 2);
        const qs = new URLSearchParams({
          address: wallet.address,
          chains: activeChains.join(','),
          startTs: yearEntry.startTs,
          endTs: yearEntry.endTs,
        });
        return fetch('/api/wallet/tax-summary?' + qs, { signal: AbortSignal.timeout(15000) }).then(r => r.json());
      })
    );
    const walletResults = evmWallets.map((wallet, i) => ({
      wallet,
      taxData: results[i].status === 'fulfilled' && !results[i].value.error ? results[i].value : null,
      taxError: results[i].status === 'rejected' ? results[i].reason?.message : (results[i].value?.error || null),
    }));
    setAllWalletsTax(walletResults);
    const combined = walletResults.reduce((acc, { taxData }) => {
      if (!taxData) return acc;
      return {
        shortTermGains: acc.shortTermGains + (taxData.shortTermGains || 0),
        longTermGains: acc.longTermGains + (taxData.longTermGains || 0),
        totalGains: acc.totalGains + (taxData.totalGains || 0),
        stakingIncomeUsd: acc.stakingIncomeUsd + (taxData.stakingIncome?.totalUsd || 0),
        minipoolAccruedUsd: acc.minipoolAccruedUsd + (taxData.stakingIncome?.minipoolAccruedUsd || 0),
        minipoolAccruedEth: acc.minipoolAccruedEth + (taxData.stakingIncome?.minipoolAccruedEth || 0),
        totalTxCount: acc.totalTxCount + (taxData.txCount || 0),
        walletsIncluded: acc.walletsIncluded + 1,
      };
    }, { shortTermGains: 0, longTermGains: 0, totalGains: 0, stakingIncomeUsd: 0, minipoolAccruedUsd: 0, minipoolAccruedEth: 0, totalTxCount: 0, walletsIncluded: 0 });
    setCombinedTax(combined);
    setLoadingAll(false);
  }

  function fetchTaxSummary(wallet, yearEntry, allTime = false) {
    if (!wallet || wallet.network === 'solana') return;
    const year = yearEntry || taxYears[taxYearIdx];
    setLoadingTax(true);
    setRealTaxData(null);
    setTaxError(null);
    const activeChains = wallet?.chains?.activeChains?.length
      ? wallet.chains.activeChains
      : [wallet.network || 'ethereum'];
    const params = {
      address: wallet.address,
      network: wallet.network || 'ethereum',
      chains: activeChains.join(','),
    };
    if (!allTime) {
      params.startTs = year.startTs;
      params.endTs = year.endTs;
    }
    const qs = new URLSearchParams(params);
    fetch('/api/wallet/tax-summary?' + qs)
      .then(r => r.json())
      .then(data => {
        if (data.error) { setTaxError(data.error); } else { setRealTaxData(data); }
        setLoadingTax(false);
      })
      .catch(err => { setTaxError(err.message); setLoadingTax(false); });
  }

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const hasCookie = document.cookie.split(';').some(c => c.trim().startsWith('pb_token='));
      if (!hasCookie) { window.location.href = '/login'; return; }
      const stored = localStorage.getItem('pb_wallets');
      let walletList = [];
      if (stored) { try { walletList = JSON.parse(stored); } catch {} }
      setConnectedWallets(walletList);
      const saved = localStorage.getItem('tax_country');
      const activeCountry = saved || 'AU';
      if (saved) setCountry(saved);
      const initYears = getTaxYears(activeCountry);
      setTaxYears(initYears);
      setTaxYearIdx(0);
      if (walletList.length > 0) {
        const evmWallet = walletList.find(w => w.network !== 'solana') || walletList[0];
        const evmIdx = walletList.indexOf(evmWallet);
        setSelectedWalletIdx(evmIdx >= 0 ? evmIdx : 0);
        fetchTaxSummary(evmWallet, initYears[0]);
        fetchAllWalletsTax(walletList, initYears[0]);
      }
    }
    fetch('/api/auth/me').then(r => r.json()).then(d => { if (d.email) setUserInfo(d); }).catch(() => {});
    fetch('/api/yield/income').then(r => r.json()).then(d => { if (!d.error) setYieldIncome(d); }).catch(() => {});
  }, []);

  function handleWalletChange(idx) {
    setSelectedWalletIdx(idx);
    fetchTaxSummary(connectedWallets[idx], taxYears[taxYearIdx]);
  }

  function selectCountry(code) {
    setCountry(code);
    localStorage.setItem('tax_country', code);
    setShowPicker(false);
    const newYears = getTaxYears(code);
    setTaxYears(newYears);
    setTaxYearIdx(0);
    const wallet = connectedWallets[selectedWalletIdx];
    if (wallet && wallet.network !== 'solana') fetchTaxSummary(wallet, newYears[0]);
    fetchAllWalletsTax(connectedWallets, newYears[0]);
  }

  function handleTaxYearChange(idx) {
    setTaxYearIdx(idx);
    const wallet = connectedWallets[selectedWalletIdx];
    if (wallet && wallet.network !== 'solana') fetchTaxSummary(wallet, taxYears[idx]);
    fetchAllWalletsTax(connectedWallets, taxYears[idx]);
  }

  function toggleWalletRow(evmIdx) {
    setExpandedWalletIdxs(prev => {
      const next = new Set(prev);
      if (next.has(evmIdx)) { next.delete(evmIdx); } else { next.add(evmIdx); }
      return next;
    });
    const evmWallets = connectedWallets.filter(w => w.network !== 'solana');
    if (evmWallets[evmIdx]) {
      const globalIdx = connectedWallets.indexOf(evmWallets[evmIdx]);
      if (globalIdx !== selectedWalletIdx) handleWalletChange(globalIdx);
    }
  }

  const c = TAX_COUNTRIES.find(x => x.code === country) || TAX_COUNTRIES[0];
  const isElite = userInfo.isAdmin || userInfo.tier === 'elite' || userInfo.tier === 'pro';

  const capitalGains   = realTaxData ? realTaxData.totalGains : DEMO.capitalGains;
  const shortTermGains = realTaxData ? realTaxData.shortTermGains : DEMO.shortTermGains;
  const longTermGains  = realTaxData ? realTaxData.longTermGains : DEMO.longTermGains;
  const totalIncome    = realTaxData ? realTaxData.netEthUsd : DEMO.yieldIncome;
  const longTermTaxable = longTermGains * (1 - c.discount);
  const netTaxable = shortTermGains + longTermTaxable + totalIncome - DEMO.gasDeductions;
  const estTax = c.taxFree ? 0 : Math.round(netTaxable * c.rate);

  const selectedWallet = connectedWallets[selectedWalletIdx];
  const evmWallets = connectedWallets.filter(w => w.network !== 'solana');

  const yieldIncomeUsd = yieldIncome?.totalEarnedUsd || 0;
  const combinedLongTermTaxable = (combinedTax?.longTermGains || 0) * (1 - (c.discount || 0));
  const combinedNetTaxable = (combinedTax?.shortTermGains || 0) + combinedLongTermTaxable + (combinedTax?.stakingIncomeUsd || 0) + yieldIncomeUsd;
  const combinedEstTax = c.taxFree ? 0 : Math.max(0, Math.round(combinedNetTaxable * c.rate));

  // Combined display values — use combinedTax when available, fallback to single wallet, then demo
  const displayShortTerm = combinedTax ? combinedTax.shortTermGains : (realTaxData ? realTaxData.shortTermGains : DEMO.shortTermGains);
  const displayLongTerm  = combinedTax ? combinedTax.longTermGains  : (realTaxData ? realTaxData.longTermGains  : DEMO.longTermGains);
  const displayStaking   = combinedTax ? combinedTax.stakingIncomeUsd : (realTaxData?.stakingIncome?.totalUsd || 0);
  const displayLongTermTaxable = displayLongTerm * (1 - (c.discount || 0));
  const displayNetTaxable = displayShortTerm + displayLongTermTaxable + displayStaking + yieldIncomeUsd;
  const displayEstTax = c.taxFree ? 0 : Math.max(0, Math.round(displayNetTaxable * c.rate));

  const allChainSet = new Set();
  connectedWallets.forEach(w => {
    (w.chains?.activeChains || [w.network || 'ethereum']).forEach(ch => allChainSet.add(ch));
  });
  const allChains = Array.from(allChainSet);

  const S = {
    bg: '#111214',
    card: { background: '#18191d', border: '1px solid #2a2b30', borderRadius: 16, padding: 24 },
  };

  return (
    <div style={{ background: S.bg, minHeight: '100vh', color: '#edeef0', fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" }}>
      {/* NAVBAR */}
      <nav style={{ position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100, backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', background: 'rgba(17,18,20,0.85)', borderBottom: '1px solid #2a2b30' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
          <a href="/" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
            <img src="/passiveblocks_logo.png" alt="PassiveBlocks" style={{ height: 44, width: 'auto', objectFit: 'contain', filter: 'brightness(0) invert(1)' }} />
          </a>
          <div style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
            {NAV_LINKS.map(l => (
              <a key={l.label} href={l.href} style={{ color: l.label === 'Tax' ? '#edeef0' : '#6b6c72', textDecoration: 'none', fontSize: 14, fontWeight: 500 }}>{l.label}</a>
            ))}
            <button onClick={async () => { await fetch('/api/auth/logout', { method: 'POST' }); window.location.href = '/login'; }}
              style={{ background: '#ef4444', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
              🔒 Logout
            </button>
          </div>
        </div>
      </nav>

      {/* PAGE HEADER */}
      <div style={{ background: '#18191d', borderBottom: '1px solid #2a2b30', padding: '0 28px', marginTop: 64, display: 'flex', justifyContent: 'space-between', alignItems: 'center', height: 72, boxSizing: 'border-box' }}>
        <div>
          <div style={{ fontSize: 18, fontWeight: 800, display: 'flex', alignItems: 'center', gap: 10 }}>
            🏛️ Tax Dashboard
            {combinedTax?.walletsIncluded > 0
              ? <span style={{ background: '#8aad8a22', color: '#8aad8a', border: '1px solid #8aad8a44', borderRadius: 20, padding: '2px 10px', fontSize: 11, fontWeight: 700 }}>LIVE</span>
              : <span style={{ background: '#ff931722', color: '#ff9317', border: '1px solid #ff931744', borderRadius: 20, padding: '2px 10px', fontSize: 11, fontWeight: 700 }}>DEMO</span>
            }
          </div>
          <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 3 }}>{c.year} · {c.note}</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          {userInfo.isAdmin
            ? <div style={{ background: '#ff931722', border: '1px solid #ff931744', borderRadius: 8, padding: '6px 14px', fontSize: 12, fontWeight: 700, color: '#ff9317' }}>👑 ADMIN</div>
            : userInfo.tier === 'elite'
            ? <div style={{ background: '#8aad8a22', border: '1px solid #8aad8a44', borderRadius: 8, padding: '6px 14px', fontSize: 12, fontWeight: 700, color: '#8aad8a' }}>⚡ ELITE</div>
            : userInfo.tier === 'pro'
            ? <div style={{ background: '#6789ed22', border: '1px solid #6789ed44', borderRadius: 8, padding: '6px 14px', fontSize: 12, fontWeight: 700, color: '#6789ed' }}>🔹 PRO</div>
            : <div style={{ background: '#2a2b30', border: '1px solid #2a2b30', borderRadius: 8, padding: '6px 14px', fontSize: 12, fontWeight: 700, color: '#6b6c72' }}>Explorer — Free</div>
          }
          <div style={{ position: 'relative' }}>
            <button onClick={() => setShowPicker(v => !v)}
              style={{ background: '#1e3a5f', color: '#93c5fd', border: '1px solid #6789ed44', borderRadius: 6, padding: '7px 14px', fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
              {c.flag} {c.code} <span style={{ fontSize: 10 }}>▼</span>
            </button>
            {showPicker && (
              <div style={{ position: 'absolute', right: 0, top: '110%', background: '#18191d', border: '1px solid #2a2b30', borderRadius: 10, zIndex: 200, minWidth: 280, boxShadow: '0 8px 32px #0008', overflow: 'hidden' }}>
                <div style={{ padding: '8px 14px', fontSize: 11, color: '#6b6c72', borderBottom: '1px solid #2a2b30', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Tax Jurisdiction</div>
                {TAX_COUNTRIES.map(tc => (
                  <div key={tc.code} onClick={() => selectCountry(tc.code)}
                    style={{ padding: '10px 14px', cursor: 'pointer', background: tc.code === country ? '#6789ed22' : 'transparent', borderLeft: tc.code === country ? '3px solid #6789ed' : '3px solid transparent', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontWeight: 600 }}>{tc.flag} {tc.name}</span>
                    <span style={{ fontSize: 11, color: '#6b6c72' }}>{tc.note}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1300, margin: '0 auto', padding: '28px 28px 64px' }}>

        {/* TAX YEAR SELECTOR */}
        {connectedWallets.length > 0 && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
            <label style={{ fontSize: 12, color: '#6b6c72', whiteSpace: 'nowrap' }}>Tax Year:</label>
            <select value={taxYearIdx} onChange={e => handleTaxYearChange(Number(e.target.value))}
              style={{ background: '#111214', color: '#edeef0', border: '1px solid #2a2b30', borderRadius: 8, padding: '8px 12px', fontSize: 13, cursor: 'pointer', minWidth: 160 }}>
              {taxYears.map((y, i) => (
                <option key={i} value={i}>{y.label}{i === 0 ? ' (current)' : ''}</option>
              ))}
            </select>
            {taxYears[taxYearIdx] && (
              <span style={{ fontSize: 12, color: '#6b6c72' }}>
                {formatDateShort(taxYears[taxYearIdx].startTs)} – {formatDateShort(taxYears[taxYearIdx].endTs)}
              </span>
            )}
          </div>
        )}

        {/* DEBUG / STATUS BAR */}
        {connectedWallets.length > 0 && (
          <div style={{ marginBottom: 16, padding: '8px 14px', background: taxError ? '#ef444411' : loadingTax || loadingAll ? '#6789ed11' : '#8aad8a11', border: `1px solid ${taxError ? '#ef444433' : loadingTax || loadingAll ? '#6789ed33' : '#8aad8a33'}`, borderRadius: 8, fontSize: 12, display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            {taxError && !loadingTax ? (
              <>
                <span style={{ color: '#ef4444' }}>⚠️ Error: {taxError}</span>
                <button onClick={() => fetchTaxSummary(selectedWallet, taxYears[taxYearIdx])}
                  style={{ background: '#ef444422', color: '#ef4444', border: '1px solid #ef444444', borderRadius: 6, padding: '2px 10px', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}>
                  Retry
                </button>
              </>
            ) : (loadingTax || loadingAll) ? (
              <span style={{ color: '#6789ed' }}>⏳ Fetching on-chain data…</span>
            ) : realTaxData ? (
              <span style={{ color: '#8aad8a' }}>
                📡 Data source: <strong>{realTaxData.dataSource || 'Alchemy'}</strong>
                {' '}|{' '}Last fetched: <strong>{new Date(realTaxData.fetchedAt).toLocaleTimeString()}</strong>
                {' '}|{' '}<strong>{combinedTax?.walletsIncluded ?? 1}</strong> wallet{(combinedTax?.walletsIncluded ?? 1) !== 1 ? 's' : ''}
                {' '}·{' '}<strong>{(combinedTax?.totalTxCount ?? realTaxData.txCount ?? 0).toLocaleString()}</strong> txns
              </span>
            ) : (
              <span style={{ color: '#ff9317' }}>⚠️ Demo mode — connect a wallet to see real data</span>
            )}
          </div>
        )}

        {/* SECTION 1: COMBINED TAX SUMMARY */}
        {connectedWallets.length > 0 && (
          <div style={{ marginBottom: 24, borderRadius: 18, overflow: 'hidden', border: '1px solid #6789ed33' }}>
            <div style={{ background: 'linear-gradient(135deg, #1a2744 0%, #221540 100%)', padding: '16px 24px', borderBottom: '1px solid #6789ed22', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 15, fontWeight: 800, color: '#edeef0', display: 'flex', alignItems: 'center', gap: 10 }}>
                  💼 Combined Tax Summary
                  {loadingAll
                    ? <span style={{ background: '#6789ed22', color: '#6789ed', border: '1px solid #6789ed44', borderRadius: 20, padding: '2px 10px', fontSize: 11, fontWeight: 700 }}>LOADING</span>
                    : combinedTax?.walletsIncluded > 0
                      ? <span style={{ background: '#8aad8a22', color: '#8aad8a', border: '1px solid #8aad8a44', borderRadius: 20, padding: '2px 10px', fontSize: 11, fontWeight: 700 }}>LIVE</span>
                      : null}
                </div>
                <div style={{ fontSize: 12, color: '#93c5fd', marginTop: 2 }}>
                  All wallets · All chains · {taxYears[taxYearIdx]?.label}
                </div>
              </div>
              <div style={{ fontSize: 12, color: '#6b6c72', textAlign: 'right' }}>
                {combinedTax && (
                  <>
                    <div>{combinedTax.walletsIncluded} wallet{combinedTax.walletsIncluded !== 1 ? 's' : ''} · {combinedTax.totalTxCount.toLocaleString()} transactions</div>
                    {allChains.length > 0 && <div style={{ color: '#6789ed', marginTop: 2 }}>{allChains.map(ch => ch.charAt(0).toUpperCase() + ch.slice(1)).join(', ')}</div>}
                  </>
                )}
              </div>
            </div>
            <div style={{ background: '#16171b', padding: 24 }}>
              {loadingAll ? (
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, color: '#6789ed', padding: '20px 0' }}>
                  <span style={{ display: 'inline-block', width: 16, height: 16, border: '2px solid #6789ed44', borderTopColor: '#6789ed', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
                  Fetching all wallets<LoadingDots />
                </div>
              ) : combinedTax ? (
                <>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 14 }}>
                    <div style={{ background: '#18191d', border: '1px solid #2a2b30', borderRadius: 14, padding: '20px 22px' }}>
                      <div style={{ fontSize: 11, color: '#6b6c72', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>📈 Total Capital Gains</div>
                      <div style={{ fontSize: 28, fontWeight: 900, color: combinedTax.totalGains >= 0 ? '#8aad8a' : '#ef4444', lineHeight: 1 }}>${Math.abs(combinedTax.totalGains).toLocaleString()}</div>
                      <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 8 }}>Short: <strong style={{ color: '#edeef0' }}>${combinedTax.shortTermGains.toLocaleString()}</strong></div>
                      <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 2 }}>
                        Long: <strong style={{ color: '#edeef0' }}>${combinedTax.longTermGains.toLocaleString()}</strong>
                        {c.discount > 0 && <span style={{ color: '#8aad8a', marginLeft: 6 }}>({(c.discount * 100).toFixed(0)}% disc.)</span>}
                      </div>
                    </div>
                    <div style={{ background: '#18191d', border: '1px solid #2a2b30', borderRadius: 14, padding: '20px 22px' }}>
                      <div style={{ fontSize: 11, color: '#6b6c72', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>💰 Total Income</div>
                      <div style={{ fontSize: 28, fontWeight: 900, color: '#6789ed', lineHeight: 1 }}>${((combinedTax.stakingIncomeUsd || 0) + yieldIncomeUsd).toLocaleString()}</div>
                      <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 8 }}>🏊 Staking (claimed): <strong style={{ color: '#edeef0' }}>${(combinedTax.stakingIncomeUsd || 0).toLocaleString()}</strong></div>
                      <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 2 }}>📊 Yield sim: <strong style={{ color: '#edeef0' }}>${yieldIncomeUsd.toLocaleString()}</strong></div>
                      {taxYearIdx === 0 && combinedTax.minipoolAccruedEth > 0 && (
                        <div style={{ fontSize: 12, color: '#ff9317', marginTop: 4 }}>⏳ Unclaimed today: <strong>${(combinedTax.minipoolAccruedUsd || 0).toLocaleString()}</strong> ({combinedTax.minipoolAccruedEth.toFixed(4)} ETH)</div>
                      )}
                    </div>
                    <div style={{ background: '#18191d', border: '1px solid #2a2b30', borderRadius: 14, padding: '20px 22px' }}>
                      <div style={{ fontSize: 11, color: '#6b6c72', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>🏛️ Est. Tax Due</div>
                      <div style={{ fontSize: 28, fontWeight: 900, color: c.taxFree ? '#8aad8a' : '#ef4444', lineHeight: 1 }}>
                        {c.taxFree ? 'Tax-free' : `$${combinedEstTax.toLocaleString()} ${c.currency}`}
                      </div>
                      <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 8 }}>
                        {c.taxFree ? c.note : `@ ${(c.rate * 100).toFixed(0)}% effective rate`}
                      </div>
                    </div>
                  </div>
                  <div style={{ fontSize: 12, color: '#6b6c72' }}>
                    {combinedTax.walletsIncluded} wallet{combinedTax.walletsIncluded !== 1 ? 's' : ''} · {combinedTax.totalTxCount.toLocaleString()} transactions across {allChains.length} chain{allChains.length !== 1 ? 's' : ''}
                  </div>
                </>
              ) : (
                <div style={{ color: '#6b6c72', fontSize: 13, padding: '20px 0' }}>No wallet data loaded yet.</div>
              )}
            </div>
          </div>
        )}

        {/* SECTION 2: PER-WALLET ACCORDION */}
        {evmWallets.length > 0 && (
          <div style={{ ...S.card, marginBottom: 24, padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '16px 24px', borderBottom: '1px solid #2a2b30', display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 15, fontWeight: 800 }}>📊 Per-Wallet Breakdown</span>
              <span style={{ fontSize: 12, color: '#6b6c72' }}>{evmWallets.length} wallet{evmWallets.length !== 1 ? 's' : ''}</span>
            </div>
            {(allWalletsTax.length > 0 ? allWalletsTax : evmWallets.map(w => ({ wallet: w, taxData: null }))).map(({ wallet, taxData }, evmIdx) => {
              const isExpanded = expandedWalletIdxs.has(evmIdx);
              const globalIdx = connectedWallets.indexOf(wallet);
              const isSelected = globalIdx === selectedWalletIdx;
              const walletChains = wallet.chains?.activeChains || [wallet.network || 'ethereum'];
              const walletEstTax = calcTax(taxData, c);
              return (
                <div key={evmIdx} style={{ borderBottom: evmIdx < evmWallets.length - 1 ? '1px solid #1e1f23' : 'none' }}>
                  <div onClick={() => toggleWalletRow(evmIdx)}
                    style={{ padding: '14px 24px', cursor: 'pointer', background: isSelected ? '#6789ed0a' : 'transparent', display: 'flex', alignItems: 'center', gap: 12, userSelect: 'none' }}>
                    <span style={{ fontSize: 14, color: '#6789ed', width: 16, flexShrink: 0 }}>{isExpanded ? '▼' : '▶'}</span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                        <span style={{ fontSize: 13, fontWeight: 700, fontFamily: 'monospace', color: '#edeef0' }}>
                          {wallet.address.slice(0, 10)}...{wallet.address.slice(-8)}
                        </span>
                        {wallet.label && <span style={{ fontSize: 12, color: '#6b6c72' }}>({wallet.label})</span>}
                        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                          {walletChains.map(ch => (
                            <span key={ch} style={{ background: '#6789ed22', color: '#6789ed', border: '1px solid #6789ed33', borderRadius: 4, padding: '1px 6px', fontSize: 10, fontWeight: 600 }}>
                              {ch.charAt(0).toUpperCase() + ch.slice(1)}
                            </span>
                          ))}
                        </div>
                      </div>
                      {!isExpanded && (
                        <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 4, display: 'flex', gap: 16, flexWrap: 'wrap' }}>
                          {loadingAll
                            ? <span style={{ color: '#6789ed' }}>⏳ Fetching...</span>
                            : taxData ? (
                              <>
                                <span>Short: <strong style={{ color: '#8aad8a' }}>${(taxData.shortTermGains || 0).toLocaleString()}</strong></span>
                                <span>Long: <strong style={{ color: '#8aad8a' }}>${(taxData.longTermGains || 0).toLocaleString()}</strong></span>
                                <span>Est. tax: <strong style={{ color: c.taxFree ? '#8aad8a' : '#ef4444' }}>{c.taxFree ? 'Free' : `$${walletEstTax.toLocaleString()}`}</strong></span>
                                <span style={{ color: '#6b6c72' }}>{(taxData.txCount || 0).toLocaleString()} txns</span>
                              </>
                            ) : <span style={{ color: '#ef444488' }} title={allWalletsTax.find(r=>r.wallet?.address===wallet.address)?.taxError || 'Unknown error'}>⚠️ Failed to load — {allWalletsTax.find(r=>r.wallet?.address===wallet.address)?.taxError || 'timeout/error'}</span>}
                        </div>
                      )}
                    </div>
                    {isSelected && (
                      <span style={{ background: '#6789ed22', color: '#6789ed', border: '1px solid #6789ed33', borderRadius: 6, padding: '2px 8px', fontSize: 10, fontWeight: 700, flexShrink: 0 }}>SELECTED</span>
                    )}
                  </div>
                  {isExpanded && (
                    <div style={{ padding: '0 24px 20px', background: '#111214' }}>
                      {loadingAll ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#6789ed', fontSize: 13, padding: '16px 0' }}>
                          <span style={{ display: 'inline-block', width: 14, height: 14, border: '2px solid #6789ed44', borderTopColor: '#6789ed', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
                          Fetching wallet data<LoadingDots />
                        </div>
                      ) : !taxData && allWalletsTax.find(r=>r.wallet?.address===wallet.address)?.taxError ? (
                        <div style={{ color: '#ef4444', fontSize: 13, padding: '12px 0' }}>
                          ⚠️ Error: {allWalletsTax.find(r=>r.wallet?.address===wallet.address).taxError}
                          <br/><span style={{ color: '#6b6c72', fontSize: 12, marginTop: 4, display: 'block' }}>This may be a Vercel timeout (10s limit on Hobby plan). Try selecting a specific wallet above instead.</span>
                        </div>
                      ) : taxData ? (
                        <div>
                          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginTop: 16 }}>
                            <div style={{ background: '#18191d', border: '1px solid #2a2b30', borderRadius: 12, padding: 16 }}>
                              <div style={{ fontSize: 11, color: '#6b6c72', textTransform: 'uppercase', marginBottom: 6 }}>Capital Gains</div>
                              <div style={{ fontSize: 22, fontWeight: 900, color: '#8aad8a' }}>${(taxData.totalGains || 0).toLocaleString()}</div>
                              <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 6 }}>Short: ${(taxData.shortTermGains || 0).toLocaleString()}</div>
                              <div style={{ fontSize: 12, color: '#6b6c72' }}>Long: ${(taxData.longTermGains || 0).toLocaleString()}</div>
                            </div>
                            <div style={{ background: '#18191d', border: '1px solid #2a2b30', borderRadius: 12, padding: 16 }}>
                              <div style={{ fontSize: 11, color: '#6b6c72', textTransform: 'uppercase', marginBottom: 6 }}>Staking Income</div>
                              <div style={{ fontSize: 22, fontWeight: 900, color: '#6789ed' }}>${(taxData.stakingIncome?.totalUsd || 0).toLocaleString()}</div>
                              <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 6 }}>{(taxData.txCount || 0).toLocaleString()} txns</div>
                              {taxData.tokenTxCount > 0 && <div style={{ fontSize: 12, color: '#6b6c72' }}>{taxData.tokenTxCount.toLocaleString()} token txns</div>}
                              {taxYearIdx === 0 && taxData.stakingIncome?.minipoolAccruedEth > 0 && (
                                <div style={{ marginTop: 8, padding: '6px 8px', background: '#ff931711', border: '1px solid #ff931733', borderRadius: 6, fontSize: 11 }}>
                                  <div style={{ color: '#ff9317', fontWeight: 700 }}>⏳ Unclaimed today (live balance)</div>
                                  <div style={{ color: '#6b6c72', marginTop: 2 }}>{taxData.stakingIncome.minipoolAccruedEth} ETH ≈ ${taxData.stakingIncome.minipoolAccruedUsd?.toLocaleString()}</div>
                                  <div style={{ color: '#6b6c72', marginTop: 1, fontSize: 10 }}>Not yet taxable — distribute to realise</div>
                                </div>
                              )}
                            </div>
                            <div style={{ background: '#18191d', border: '1px solid #2a2b30', borderRadius: 12, padding: 16 }}>
                              <div style={{ fontSize: 11, color: '#6b6c72', textTransform: 'uppercase', marginBottom: 6 }}>Est. Tax Due</div>
                              <div style={{ fontSize: 22, fontWeight: 900, color: c.taxFree ? '#8aad8a' : '#ef4444' }}>
                                {c.taxFree ? 'Tax-free' : `$${walletEstTax.toLocaleString()} ${c.currency}`}
                              </div>
                              <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 6 }}>{c.taxFree ? c.note : `@ ${(c.rate * 100).toFixed(0)}% rate`}</div>
                            </div>
                          </div>
                          {taxData.fetchedAt && (
                            <div style={{ fontSize: 11, color: '#6b6c72', marginTop: 10 }}>Last updated: {new Date(taxData.fetchedAt).toLocaleString()}</div>
                          )}
                        </div>
                      ) : (
                        <div style={{ color: '#ef4444', fontSize: 13, padding: '16px 0' }}>⚠️ Failed to load tax data for this wallet.</div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* DETAIL VIEW — selected wallet */}
        {connectedWallets.length > 0 && (
          <div style={{ ...S.card, marginBottom: 24, borderColor: realTaxData ? '#8aad8a44' : loadingTax ? '#6789ed44' : '#2a2b30' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12 }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#edeef0', marginBottom: 10 }}>
                  🔍 Detailed Analysis
                  {selectedWallet && <span style={{ fontSize: 12, color: '#6789ed', fontWeight: 400, marginLeft: 8, textTransform: 'none' }}>— {selectedWallet.address.slice(0, 10)}...{selectedWallet.address.slice(-8)}</span>}
                </div>
                {selectedWallet && selectedWallet.network !== 'solana' && (() => {
                  const activeChains = selectedWallet?.chains?.activeChains;
                  if (!activeChains?.length) return null;
                  return (
                    <div style={{ fontSize: 12, color: '#6789ed', marginBottom: 4 }}>
                      🔗 {activeChains.length} chain{activeChains.length !== 1 ? 's' : ''}: <span style={{ color: '#edeef0', fontWeight: 600 }}>{activeChains.map(ch => ch.charAt(0).toUpperCase() + ch.slice(1)).join(', ')}</span>
                    </div>
                  );
                })()}
                {loadingTax && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#6789ed', fontSize: 13 }}>
                    <span style={{ display: 'inline-block', width: 14, height: 14, border: '2px solid #6789ed44', borderTopColor: '#6789ed', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
                    📊 Fetching your transaction history<LoadingDots />
                  </div>
                )}
                {taxError && !loadingTax && <div style={{ color: '#ef4444', fontSize: 13 }}>⚠️ Failed to fetch: {taxError}. Showing demo data.</div>}
                {realTaxData && !loadingTax && (
                  <>
                    <div style={{ fontSize: 12, color: '#8aad8a', marginTop: 2 }}>
                      Based on <strong>{realTaxData.txCount.toLocaleString()}</strong> transactions
                      {realTaxData.tokenTxCount > 0 && <> + <strong>{realTaxData.tokenTxCount.toLocaleString()}</strong> token transfers</>}
                    </div>
                    {realTaxData.debug && (
                      <div style={{ fontSize: 11, color: '#6789ed', marginTop: 4, background: '#6789ed11', borderRadius: 6, padding: '4px 10px', display: 'inline-block' }}>
                        ✅ {realTaxData.debug.dataSource || realTaxData.dataSource || 'Alchemy'}
                        {' | '}
                        {realTaxData.debug.chainsScanned?.map(ch => (
                          <span key={ch}>
                            {ch.charAt(0).toUpperCase() + ch.slice(1)}: {(realTaxData.debug.txsPerChain?.[ch] ?? 0)} txns
                          </span>
                        )).reduce((acc, el, i) => i === 0 ? [el] : [...acc, ', ', el], [])}
                        {' | '}{taxYears[taxYearIdx]?.label}
                      </div>
                    )}
                  </>
                )}
              </div>
              {selectedWallet && selectedWallet.network !== 'solana' && (
                <button onClick={() => fetchTaxSummary(selectedWallet, taxYears[taxYearIdx])} disabled={loadingTax}
                  style={{ background: loadingTax ? '#2a2b30' : '#6789ed22', color: loadingTax ? '#6b6c72' : '#6789ed', border: '1px solid #6789ed33', borderRadius: 8, padding: '8px 16px', fontSize: 13, fontWeight: 600, cursor: loadingTax ? 'not-allowed' : 'pointer' }}>
                  🔄 Refresh
                </button>
              )}
            </div>
            <div style={{ marginTop: 12, fontSize: 11, background: realTaxData ? '#8aad8a11' : '#ff931711', border: `1px solid ${realTaxData ? '#8aad8a22' : '#ff931722'}`, borderRadius: 8, padding: '8px 12px', color: realTaxData ? '#8aad8a' : '#ff9317' }}>
              {realTaxData
                ? `✅ Live data from your connected wallet via Etherscan. Last updated: ${new Date(realTaxData.fetchedAt).toLocaleString()}.`
                : '⚠️ Demo figures only — connect a wallet to see your real tax data.'}
            </div>
          </div>
        )}

        {/* TOP STATS */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
          {[
            { label: 'Total Capital Gains', value: loadingTax ? '⏳ Loading…' : `$${capitalGains.toLocaleString()} ${c.currency}`, sub: realTaxData ? `Short + long term · ${realTaxData.txCount} txns` : 'Short + long term combined', color: '#8aad8a', icon: '📈' },
            { label: 'Total Crypto Income', value: loadingTax ? '⏳ Loading…' : `$${totalIncome.toLocaleString()} ${c.currency}`, sub: realTaxData ? `Net ETH value (${realTaxData.netEth} ETH @ $${realTaxData.ethPrice?.toLocaleString()})` : 'Yield farming & staking rewards', color: '#6789ed', icon: '💰' },
            { label: 'Estimated Tax Due', value: loadingTax ? '⏳ Loading…' : c.taxFree ? `$0 ${c.currency}` : `$${estTax.toLocaleString()} ${c.currency}`, sub: c.taxFree ? 'Tax-free jurisdiction ✅' : `@ ${(c.rate * 100).toFixed(0)}% effective rate`, color: c.taxFree ? '#8aad8a' : '#ef4444', icon: '🏛️' },
          ].map((stat, i) => (
            <div key={i} style={{ ...S.card, display: 'flex', alignItems: 'center', gap: 18 }}>
              <div style={{ fontSize: 32 }}>{stat.icon}</div>
              <div>
                <div style={{ fontSize: 11, color: '#6b6c72', marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{stat.label}</div>
                <div style={{ fontSize: 26, fontWeight: 900, color: stat.color, lineHeight: 1 }}>{stat.value}</div>
                <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 5 }}>{stat.sub}</div>
              </div>
              <div style={{ marginLeft: 'auto' }}>
                {realTaxData
                  ? <span style={{ background: '#8aad8a22', color: '#8aad8a', border: '1px solid #8aad8a44', borderRadius: 20, padding: '2px 8px', fontSize: 10, fontWeight: 700 }}>LIVE</span>
                  : <span style={{ background: '#ff931722', color: '#ff9317', border: '1px solid #ff931744', borderRadius: 20, padding: '2px 8px', fontSize: 10, fontWeight: 700 }}>DEMO</span>}
              </div>
            </div>
          ))}
        </div>

        {/* CONNECTED ACCOUNTS */}
        <div style={{ ...S.card, marginBottom: 24 }}>
          <div style={{ fontSize: 13, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#edeef0', marginBottom: 16 }}>🔗 Connected Accounts</div>
          <div style={{ background: '#111214', borderRadius: 10, border: '1px dashed #2a2b30', padding: '28px', textAlign: 'center', marginBottom: 18 }}>
            <div style={{ fontSize: 32, marginBottom: 10 }}>📭</div>
            <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6 }}>No exchange accounts connected yet</div>
            <div style={{ fontSize: 13, color: '#6b6c72', marginBottom: 20 }}>Connect a wallet or exchange to import your transaction history and generate real tax reports.</div>
            <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
              <div style={{ position: 'relative', display: 'inline-block' }}
                onMouseEnter={e => { const t = e.currentTarget.querySelector('.tooltip'); if (t) t.style.display = 'block'; }}
                onMouseLeave={e => { const t = e.currentTarget.querySelector('.tooltip'); if (t) t.style.display = 'none'; }}>
                <button disabled style={{ background: '#2a2b30', color: '#6b6c72', border: 'none', borderRadius: 8, padding: '10px 20px', fontSize: 13, fontWeight: 600, cursor: 'not-allowed', display: 'flex', alignItems: 'center', gap: 8 }}>
                  🔌 Connect Exchange API
                </button>
                <div className="tooltip" style={{ display: 'none', position: 'absolute', bottom: '110%', left: '50%', transform: 'translateX(-50%)', background: '#18191d', border: '1px solid #2a2b30', borderRadius: 8, padding: '7px 12px', fontSize: 12, color: '#6b6c72', whiteSpace: 'nowrap', zIndex: 10, boxShadow: '0 4px 16px #0006' }}>
                  Exchange connections available in Pro tier
                </div>
              </div>
              <a href="/wallets" style={{ background: 'linear-gradient(135deg, #6789ed, #583fdd)', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 20px', fontSize: 13, fontWeight: 600, cursor: 'pointer', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 8 }}>
                👛 Connect Wallets →
              </a>
              <div style={{ position: 'relative', display: 'inline-block' }}
                onMouseEnter={e => { const t = e.currentTarget.querySelector('.tooltip'); if (t) t.style.display = 'block'; }}
                onMouseLeave={e => { const t = e.currentTarget.querySelector('.tooltip'); if (t) t.style.display = 'none'; }}>
                <button disabled style={{ background: '#2a2b30', color: '#6b6c72', border: 'none', borderRadius: 8, padding: '10px 20px', fontSize: 13, fontWeight: 600, cursor: 'not-allowed', display: 'flex', alignItems: 'center', gap: 8 }}>
                  📤 Upload CSV
                </button>
                <div className="tooltip" style={{ display: 'none', position: 'absolute', bottom: '110%', left: '50%', transform: 'translateX(-50%)', background: '#18191d', border: '1px solid #2a2b30', borderRadius: 8, padding: '7px 12px', fontSize: 12, color: '#6b6c72', whiteSpace: 'nowrap', zIndex: 10, boxShadow: '0 4px 16px #0006' }}>
                  CSV import available in Pro tier
                </div>
              </div>
            </div>
          </div>
          <div style={{ fontSize: 12, color: '#6b6c72', background: '#6789ed11', border: '1px solid #6789ed22', borderRadius: 8, padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ color: '#6789ed' }}>ℹ️</span>
            Exchange API connections are coming in Pro tier. Supports Binance, Coinbase, Kraken, and more.
            <a href="/pricing" style={{ color: '#6789ed', marginLeft: 'auto', fontWeight: 700, textDecoration: 'none', flexShrink: 0 }}>Upgrade to Pro →</a>
          </div>
        </div>

        {/* TRANSACTION TABLE */}
        <div style={{ ...S.card, marginBottom: 24, overflowX: 'auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div>
              <span style={{ fontSize: 13, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#edeef0' }}>📋 Transaction History</span>
              {realTaxData?.transactions?.length > 0 && (
                <span style={{ marginLeft: 10, fontSize: 11, fontWeight: 400, color: '#6b6c72' }}>
                  {showAllTime ? 'All time' : taxYears[taxYearIdx]?.label} · {realTaxData.transactions.length} transactions
                </span>
              )}
            </div>
            <button
              onClick={() => {
                const next = !showAllTime;
                setShowAllTime(next);
                const wallet = connectedWallets[selectedWalletIdx];
                if (wallet) fetchTaxSummary(wallet, taxYears[taxYearIdx], next);
              }}
              style={{ background: showAllTime ? '#6789ed22' : '#2a2b30', color: showAllTime ? '#6789ed' : '#6b6c72', border: `1px solid ${showAllTime ? '#6789ed55' : '#2a2b30'}`, borderRadius: 7, padding: '5px 12px', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}
            >
              {showAllTime ? '📅 Showing all time' : '🔍 Show all time'}
            </button>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
            <thead>
              <tr>
                {['Date', 'Type', 'Asset', 'Amount', 'From', 'To', 'Chain'].map(h => (
                  <th key={h} style={{ textAlign: 'left', color: '#6b6c72', padding: '8px 10px', borderBottom: '1px solid #2a2b30', fontWeight: 600, fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.05em', whiteSpace: 'nowrap' }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loadingTax ? (
                <tr>
                  <td colSpan={7} style={{ textAlign: 'center', padding: '32px 20px', color: '#6789ed' }}>
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ display: 'inline-block', width: 14, height: 14, border: '2px solid #6789ed44', borderTopColor: '#6789ed', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
                      Loading transactions<LoadingDots />
                    </div>
                  </td>
                </tr>
              ) : realTaxData?.transactions?.length > 0 ? (
                realTaxData.transactions.map((tx, i) => (
                  <tr key={i} style={{ background: tx.isStakingReward ? '#8aad8a08' : 'transparent', borderLeft: tx.isStakingReward ? '3px solid #8aad8a' : '3px solid transparent' }}>
                    <td style={{ padding: '7px 10px', color: '#edeef0', whiteSpace: 'nowrap' }}>
                      {tx.date ? new Date(tx.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                    </td>
                    <td style={{ padding: '7px 10px' }}>
                      <span style={{ background: tx.isStakingReward ? '#8aad8a22' : tx.type === 'ETH Received' ? '#6789ed22' : '#2a2b30', color: tx.isStakingReward ? '#8aad8a' : tx.type === 'ETH Received' ? '#6789ed' : '#6b6c72', borderRadius: 5, padding: '2px 7px', fontSize: 11, fontWeight: 600, whiteSpace: 'nowrap' }}>
                        {tx.type}
                      </span>
                    </td>
                    <td style={{ padding: '7px 10px', color: '#edeef0', fontWeight: 600 }}>{tx.asset}</td>
                    <td style={{ padding: '7px 10px', color: '#edeef0', fontFamily: 'monospace' }}>{tx.amount}</td>
                    <td style={{ padding: '7px 10px', color: '#6b6c72', fontFamily: 'monospace', fontSize: 11 }}>
                      {tx.from ? tx.from.slice(0, 6) + '…' + tx.from.slice(-4) : '—'}
                    </td>
                    <td style={{ padding: '7px 10px', color: '#6b6c72', fontFamily: 'monospace', fontSize: 11 }}>
                      {tx.to ? tx.to.slice(0, 6) + '…' + tx.to.slice(-4) : '—'}
                    </td>
                    <td style={{ padding: '7px 10px', color: '#6b6c72', fontSize: 11 }}>
                      {tx.chain || 'eth'}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} style={{ textAlign: 'center', padding: '48px 20px', color: '#6b6c72' }}>
                    <div style={{ fontSize: 32, marginBottom: 12 }}>🔗</div>
                    {realTaxData ? (
                      <>
                        <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 8, color: '#edeef0' }}>No transactions for {taxYears[taxYearIdx]?.label}</div>
                        <div style={{ fontSize: 13, marginBottom: 12 }}>Try a different tax year, or show your full history</div>
                        <button onClick={() => { setShowAllTime(true); const w = connectedWallets[selectedWalletIdx]; if (w) fetchTaxSummary(w, taxYears[taxYearIdx], true); }} style={{ background: '#6789ed22', color: '#6789ed', border: '1px solid #6789ed44', borderRadius: 8, padding: '8px 16px', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
                          🔍 Show all-time history
                        </button>
                      </>
                    ) : (
                      <>
                        <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 8, color: '#edeef0' }}>No wallet connected</div>
                        <div style={{ fontSize: 13 }}>Connect a wallet on the <a href="/wallets" style={{ color: '#6789ed' }}>Wallets page</a> to see your transactions</div>
                      </>
                    )}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* TAX BREAKDOWN + HARVESTING */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 24 }}>
          <div style={{ ...S.card }}>
            <div style={{ fontSize: 13, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#edeef0', marginBottom: 4 }}>📊 Tax Breakdown</div>
            {combinedTax && <div style={{ fontSize: 11, color: '#6b6c72', marginBottom: 16 }}>Combined across all wallets & chains</div>}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2, marginBottom: 20 }}>
              {[
                { label: 'Short-term gains', val: `+$${displayShortTerm.toLocaleString()}`, color: '#8aad8a' },
                { label: `Long-term gains (${c.discount > 0 ? (c.discount * 100).toFixed(0) + '% discount applied' : 'full rate'})`, val: `+$${displayLongTerm.toLocaleString()}`, sub: c.discount > 0 ? `→ $${Math.round(displayLongTermTaxable).toLocaleString()} taxable` : null, color: '#8aad8a' },
                { label: 'Staking income (Rocket Pool)', val: `+$${displayStaking.toLocaleString()}`, color: '#6789ed' },
                { label: 'Yield dashboard income', val: `+$${yieldIncomeUsd.toLocaleString()}`, color: '#6789ed' },
              ].map((row, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 14px', background: '#111214', borderRadius: 8, marginBottom: 4 }}>
                  <div>
                    <div style={{ fontSize: 13, color: '#edeef0' }}>{row.label}</div>
                    {row.sub && <div style={{ fontSize: 11, color: '#6b6c72', marginTop: 2 }}>{row.sub}</div>}
                  </div>
                  <span style={{ fontWeight: 700, color: row.color, fontSize: 14 }}>{row.val}</span>
                </div>
              ))}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 14px', background: '#6789ed11', border: '1px solid #6789ed33', borderRadius: 8, marginTop: 4 }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: '#edeef0' }}>Net Taxable Amount</div>
                  {combinedTax && <div style={{ fontSize: 11, color: '#6b6c72', marginTop: 2 }}>All wallets combined</div>}
                </div>
                <span style={{ fontSize: 18, fontWeight: 900, color: c.taxFree ? '#8aad8a' : '#6789ed' }}>
                  {c.taxFree ? `$0 (tax-free ✅)` : `$${Math.round(displayNetTaxable).toLocaleString()} ${c.currency}`}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 14px', background: '#ef444411', border: '1px solid #ef444433', borderRadius: 8, marginTop: 2 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: '#edeef0' }}>Estimated Tax Due</div>
                <span style={{ fontSize: 18, fontWeight: 900, color: c.taxFree ? '#8aad8a' : '#ef4444' }}>
                  {c.taxFree ? 'Tax-free ✅' : `$${displayEstTax.toLocaleString()} ${c.currency}`}
                </span>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              <DisabledButton label="📥 Download CSV" tooltip="Available in Pro tier" />
              {isElite ? (
                <button onClick={() => window.print()}
                  style={{ background: 'linear-gradient(135deg, #8aad8a, #5a8a5a)', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 20px', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
                  📄 Download Tax Report
                </button>
              ) : (
                <DisabledButton label="📄 Download PDF" tooltip="Available in Elite tier" />
              )}
            </div>
            <div style={{ marginTop: 12, fontSize: 11, color: realTaxData ? '#8aad8a99' : '#ff931766' }}>
              {realTaxData
                ? `✅ Live data from your connected wallet via Etherscan. Last updated: ${new Date(realTaxData.fetchedAt).toLocaleString()}.`
                : '⚠️ Demo figures only — not financial or tax advice. Consult a qualified tax professional.'}
            </div>
          </div>

          <div style={{ ...S.card, position: 'relative' }}>
            <div style={{ fontSize: 13, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#edeef0', marginBottom: 16 }}>🌿 Tax-Loss Harvesting</div>
            <div style={{ background: '#8aad8a22', border: '1px solid #8aad8a33', borderRadius: 8, padding: '10px 14px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 18 }}>🔍</span>
              <span style={{ fontSize: 13, color: '#8aad8a', fontWeight: 600 }}>{HARVEST_OPPORTUNITIES.length} opportunities found</span>
            </div>
            {isElite ? (
              <div>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                  <thead>
                    <tr>
                      {['Asset', 'Position Value', 'Unrealised Loss', 'Recommendation'].map(h => (
                        <th key={h} style={{ textAlign: 'left', color: '#6b6c72', padding: '8px 10px', borderBottom: '1px solid #2a2b30', fontWeight: 600, fontSize: 11, textTransform: 'uppercase' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {HARVEST_OPPORTUNITIES.map((opp, i) => (
                      <tr key={i} style={{ borderBottom: '1px solid #18191d' }}>
                        <td style={{ padding: '10px', fontWeight: 700 }}>{opp.asset}</td>
                        <td style={{ padding: '10px', color: '#edeef0' }}>{opp.position}</td>
                        <td style={{ padding: '10px', color: '#ef4444', fontWeight: 700 }}>${opp.unrealisedLoss}</td>
                        <td style={{ padding: '10px', color: '#6b6c72', fontSize: 11 }}>{opp.recommendation}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div style={{ marginTop: 12, background: '#8aad8a11', border: '1px solid #8aad8a22', borderRadius: 8, padding: '10px 14px', fontSize: 12, color: '#8aad8a' }}>
                  💡 Total potential tax savings: <strong>${HARVEST_OPPORTUNITIES.reduce((s, o) => s + Math.abs(o.unrealisedLoss), 0)}</strong> (estimated, demo data)
                </div>
              </div>
            ) : (
              <>
                <div style={{ filter: 'blur(5px)', pointerEvents: 'none', userSelect: 'none', marginBottom: 16 }}>
                  {['ETH/USDC — Save est. $340', 'ARB — Save est. $210', 'MATIC — Save est. $155'].map((item, i) => (
                    <div key={i} style={{ background: '#111214', borderRadius: 8, padding: '12px 14px', marginBottom: 6, display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ fontSize: 13 }}>{item}</span>
                      <span style={{ fontSize: 12, color: '#8aad8a', fontWeight: 700 }}>Harvest →</span>
                    </div>
                  ))}
                </div>
                <LockedPanel upgradeLabel="🔒 Unlock with Elite tier" href="/pricing" blurred={false} />
              </>
            )}
          </div>
        </div>

        {/* HOLDING PERIOD TRACKER */}
        <div style={{ ...S.card }}>
          <div style={{ fontSize: 13, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#edeef0', marginBottom: 16 }}>⏰ Holding Period Tracker</div>
          <div style={{ background: '#ff931722', border: '1px solid #ff931733', borderRadius: 8, padding: '10px 14px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 18 }}>⚠️</span>
            <span style={{ fontSize: 13, color: '#ff9317', fontWeight: 600 }}>
              {HOLDING_PERIODS.filter(p => !p.qualified && p.daysToThreshold <= 60).length} positions approaching 12-month CGT threshold
            </span>
          </div>
          {isElite ? (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
              {HOLDING_PERIODS.map((p, i) => (
                <div key={i} style={{ background: '#111214', borderRadius: 10, padding: '14px 16px', border: p.qualified ? '1px solid #8aad8a44' : p.daysToThreshold <= 30 ? '1px solid #ef444444' : '1px solid #ff931744' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                    <div style={{ fontSize: 14, fontWeight: 700 }}>{p.asset}</div>
                    {p.qualified
                      ? <span style={{ background: '#8aad8a22', color: '#8aad8a', borderRadius: 6, padding: '2px 8px', fontSize: 11, fontWeight: 700 }}>✅ Qualified</span>
                      : p.daysToThreshold <= 30
                      ? <span style={{ background: '#ef444422', color: '#ef4444', borderRadius: 6, padding: '2px 8px', fontSize: 11, fontWeight: 700 }}>🔥 {p.daysToThreshold}d left</span>
                      : <span style={{ background: '#ff931722', color: '#ff9317', borderRadius: 6, padding: '2px 8px', fontSize: 11, fontWeight: 700 }}>⚠️ {p.daysToThreshold}d left</span>}
                  </div>
                  <div style={{ fontSize: 12, color: '#6b6c72', marginBottom: 4 }}>Acquired: {p.acquiredDate} · {p.daysHeld} days held</div>
                  <div style={{ fontSize: 12, color: '#6b6c72', marginBottom: 8 }}>Position value: <span style={{ color: '#edeef0', fontWeight: 600 }}>{p.value}</span></div>
                  {!p.qualified && (
                    <div style={{ fontSize: 11, color: '#8aad8a', background: '#8aad8a11', borderRadius: 6, padding: '6px 10px' }}>
                      💰 Hold to qualify → est. CGT saving: <strong>{p.potentialSaving}</strong>
                    </div>
                  )}
                  {p.qualified && (
                    <div style={{ fontSize: 11, color: '#8aad8a' }}>✅ CGT discount applies — {c.discount > 0 ? `${(c.discount * 100).toFixed(0)}% discount` : 'full rate — check jurisdiction'}</div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
                {['wstETH — 10 months 18 days held', 'USDC/ETH LP — 11 months 3 days held'].map((item, i) => (
                  <div key={i} style={{ filter: 'blur(4px)', pointerEvents: 'none', userSelect: 'none', background: '#111214', borderRadius: 8, padding: '14px 16px' }}>
                    <div style={{ fontSize: 13, color: '#edeef0', fontWeight: 600 }}>{item}</div>
                    <div style={{ fontSize: 11, color: '#ff9317', marginTop: 4 }}>Hold {i === 0 ? '42' : '27'} more days for CGT discount</div>
                  </div>
                ))}
              </div>
              <LockedPanel upgradeLabel="🔒 Unlock with Elite tier" href="/pricing" blurred={false} />
            </>
          )}
        </div>

        <style>{`
          @keyframes spin { to { transform: rotate(360deg); } }
          @media print {
            nav, button, .no-print { display: none !important; }
            body { background: #fff !important; color: #000 !important; }
          }
        `}</style>

      </div>
    </div>
  );
}
