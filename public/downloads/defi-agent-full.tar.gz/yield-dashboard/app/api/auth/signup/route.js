import { createHmac } from 'crypto';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

function sign(payload) {
  const data = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = createHmac('sha256', process.env.DASHBOARD_SECRET).update(data).digest('base64url');
  return `${data}.${sig}`;
}

export async function POST(request) {
  const body = await request.json();
  const { email, password } = body;

  // Validate email
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return NextResponse.json({ error: 'Invalid email address' }, { status: 400 });
  }

  // Validate password
  if (!password || password.length < 8) {
    return NextResponse.json({ error: 'Password must be at least 8 characters' }, { status: 400 });
  }

  // Hash password with HMAC-SHA256 keyed by secret
  const ph = createHmac('sha256', process.env.DASHBOARD_SECRET).update(password).digest('hex');

  // Determine tier and admin status
  const isAdmin = email.toLowerCase() === process.env.ADMIN_EMAIL?.toLowerCase();
  const tier = isAdmin ? 'elite' : 'explorer';

  // Create signed session token containing email + password hash + tier
  const now = Math.floor(Date.now() / 1000);
  const token = sign({ email, ph, tier, isAdmin, iat: now, exp: now + 86400 * 7 });

  const res = NextResponse.json({ success: true, email });
  res.cookies.set('pb_token', token, {
    httpOnly: false, // must be readable by document.cookie on client
    maxAge: 86400 * 7,
    sameSite: 'strict',
    path: '/',
  });
  return res;
}
