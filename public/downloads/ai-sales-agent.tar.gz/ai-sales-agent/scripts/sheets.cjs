#!/usr/bin/env node
/**
 * Google Sheets Skill — Core Script
 * Full CRUD operations on Google Sheets via Sheets API v4.
 * Auth: Google Service Account (JSON key via env or file).
 *
 * Usage:
 *   node sheets.cjs read <spreadsheetId> [sheetName] [range]
 *   node sheets.cjs write <spreadsheetId> <sheetName> <range> '<jsonData>'
 *   node sheets.cjs append <spreadsheetId> <sheetName> '<jsonData>'
 *   node sheets.cjs update <spreadsheetId> <sheetName> <range> '<jsonData>'
 *   node sheets.cjs create "<title>" '[{"name":"Sheet1"}]'
 *   node sheets.cjs list-sheets <spreadsheetId>
 *   node sheets.cjs add-sheet <spreadsheetId> "<sheetName>"
 *   node sheets.cjs clear <spreadsheetId> <sheetName> <range>
 *   node sheets.cjs search <spreadsheetId> <sheetName> <column> "<value>"
 */
'use strict';

const https = require('https');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// ─── Auth ───────────────────────────────────────────────────────────────────

function getServiceAccountCredentials() {
  // Option 1: JSON string in env
  if (process.env.GOOGLE_SERVICE_ACCOUNT_JSON) {
    try {
      return JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_JSON);
    } catch (e) {
      throw new Error('GOOGLE_SERVICE_ACCOUNT_JSON is not valid JSON');
    }
  }
  // Option 2: File path in env
  if (process.env.GOOGLE_SERVICE_ACCOUNT_KEY_FILE) {
    const raw = fs.readFileSync(process.env.GOOGLE_SERVICE_ACCOUNT_KEY_FILE, 'utf8');
    return JSON.parse(raw);
  }
  // Option 3: Default location
  const defaultPath = path.join(process.env.HOME || '/home/node', '.openclaw/google-service-account.json');
  if (fs.existsSync(defaultPath)) {
    return JSON.parse(fs.readFileSync(defaultPath, 'utf8'));
  }
  throw new Error(
    'No Google Service Account credentials found.\n' +
    'Set GOOGLE_SERVICE_ACCOUNT_JSON (JSON string) or\n' +
    'GOOGLE_SERVICE_ACCOUNT_KEY_FILE (path to JSON file) or\n' +
    'Place the key at ~/.openclaw/google-service-account.json'
  );
}

function base64url(buf) {
  return Buffer.from(buf).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

async function getAccessToken(creds) {
  const now = Math.floor(Date.now() / 1000);
  const header = base64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const payload = base64url(JSON.stringify({
    iss: creds.client_email,
    scope: 'https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive',
    aud: 'https://oauth2.googleapis.com/token',
    iat: now,
    exp: now + 3600,
  }));

  const signInput = `${header}.${payload}`;
  const sign = crypto.createSign('RSA-SHA256');
  sign.update(signInput);
  const signature = base64url(sign.sign(creds.private_key));
  const jwt = `${signInput}.${signature}`;

  const body = `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}`;
  const resp = await httpRequest('POST', 'oauth2.googleapis.com', '/token', {
    'Content-Type': 'application/x-www-form-urlencoded',
    'Content-Length': Buffer.byteLength(body),
  }, body);

  if (!resp.access_token) throw new Error('Auth failed: ' + JSON.stringify(resp));
  return resp.access_token;
}

// ─── HTTP Helper ────────────────────────────────────────────────────────────

function httpRequest(method, host, path, headers, body) {
  return new Promise((resolve, reject) => {
    const opts = { method, hostname: host, path, headers: headers || {} };
    const req = https.request(opts, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString();
        try { resolve(JSON.parse(raw)); } catch { resolve({ _raw: raw, _status: res.statusCode }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function sheetsApi(token, method, endpoint, body) {
  const headers = {
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
  };
  if (body) headers['Content-Length'] = Buffer.byteLength(JSON.stringify(body));
  return httpRequest(method, 'sheets.googleapis.com', `/v4/spreadsheets/${endpoint}`, headers, body ? JSON.stringify(body) : null);
}

async function driveApi(token, method, endpoint, body) {
  const headers = {
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
  };
  if (body) headers['Content-Length'] = Buffer.byteLength(JSON.stringify(body));
  return httpRequest(method, 'www.googleapis.com', `/drive/v3/${endpoint}`, headers, body ? JSON.stringify(body) : null);
}

// ─── Commands ───────────────────────────────────────────────────────────────

async function cmdRead(token, spreadsheetId, sheetName, range) {
  const fullRange = range ? `${sheetName || 'Sheet1'}!${range}` : (sheetName || 'Sheet1');
  const encodedRange = encodeURIComponent(fullRange);
  const resp = await sheetsApi(token, 'GET', `${spreadsheetId}/values/${encodedRange}`, null);

  if (resp.error) return { error: resp.error.message, code: resp.error.code };

  const rows = resp.values || [];
  if (rows.length === 0) return { data: [], message: 'No data found' };

  // Convert to objects using first row as headers
  const headers = rows[0];
  const data = rows.slice(1).map(row => {
    const obj = {};
    headers.forEach((h, i) => { obj[h] = row[i] || ''; });
    return obj;
  });

  return { data, rowCount: data.length, headers };
}

async function cmdWrite(token, spreadsheetId, sheetName, range, jsonData) {
  const fullRange = `${sheetName}!${range}`;
  const values = JSON.parse(jsonData);
  const resp = await sheetsApi(token, 'PUT',
    `${spreadsheetId}/values/${encodeURIComponent(fullRange)}?valueInputOption=USER_ENTERED`,
    { range: fullRange, majorDimension: 'ROWS', values }
  );
  if (resp.error) return { error: resp.error.message, code: resp.error.code };
  return { success: true, updatedCells: resp.updatedCells, updatedRange: resp.updatedRange };
}

async function cmdAppend(token, spreadsheetId, sheetName, jsonData) {
  const fullRange = `${sheetName}!A:ZZ`;
  const values = JSON.parse(jsonData);
  const resp = await sheetsApi(token, 'POST',
    `${spreadsheetId}/values/${encodeURIComponent(fullRange)}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,
    { range: fullRange, majorDimension: 'ROWS', values }
  );
  if (resp.error) return { error: resp.error.message, code: resp.error.code };
  return { success: true, updatedRange: resp.updates?.updatedRange, updatedRows: resp.updates?.updatedRows };
}

async function cmdUpdate(token, spreadsheetId, sheetName, range, jsonData) {
  return cmdWrite(token, spreadsheetId, sheetName, range, jsonData);
}

async function cmdCreate(token, title, sheetsJson) {
  const sheets = sheetsJson ? JSON.parse(sheetsJson).map(s => ({ properties: { title: s.name } })) : [{ properties: { title: 'Sheet1' } }];
  const resp = await sheetsApi(token, 'POST', '', {
    properties: { title },
    sheets,
  });
  if (resp.error) {
    // Service accounts have 0 Drive storage quota — can't create spreadsheets directly
    if (resp.error.code === 403 && resp.error.message?.includes('permission')) {
      return {
        error: 'Cannot create spreadsheets with a service account (0 Drive storage quota). ' +
          'Create the spreadsheet manually in Google Sheets, then share it with the service account email as Editor. ' +
          'Use "list-sheets" or "read" commands to interact with shared spreadsheets.',
        code: 403,
        hint: 'Share your spreadsheet with the service account email address as Editor.',
      };
    }
    return { error: resp.error.message, code: resp.error.code };
  }
  return {
    success: true,
    spreadsheetId: resp.spreadsheetId,
    url: resp.spreadsheetUrl,
    sheets: resp.sheets?.map(s => s.properties.title),
  };
}

async function cmdListSheets(token, spreadsheetId) {
  const resp = await sheetsApi(token, 'GET', spreadsheetId, null);
  if (resp.error) return { error: resp.error.message, code: resp.error.code };
  return {
    title: resp.properties?.title,
    sheets: resp.sheets?.map(s => ({
      name: s.properties.title,
      index: s.properties.index,
      rowCount: s.properties.gridProperties?.rowCount,
      colCount: s.properties.gridProperties?.columnCount,
    })),
  };
}

async function cmdAddSheet(token, spreadsheetId, sheetName) {
  const resp = await sheetsApi(token, 'POST', `${spreadsheetId}:batchUpdate`, {
    requests: [{ addSheet: { properties: { title: sheetName } } }],
  });
  if (resp.error) return { error: resp.error.message, code: resp.error.code };
  return { success: true, sheetId: resp.replies?.[0]?.addSheet?.properties?.sheetId };
}

async function cmdClear(token, spreadsheetId, sheetName, range) {
  const fullRange = range ? `${sheetName}!${range}` : sheetName;
  const resp = await sheetsApi(token, 'POST',
    `${spreadsheetId}/values/${encodeURIComponent(fullRange)}:clear`, {});
  if (resp.error) return { error: resp.error.message, code: resp.error.code };
  return { success: true, clearedRange: resp.clearedRange };
}

async function cmdSearch(token, spreadsheetId, sheetName, column, value) {
  const resp = await sheetsApi(token, 'GET',
    `${spreadsheetId}/values/${encodeURIComponent(sheetName)}`, null);
  if (resp.error) return { error: resp.error.message, code: resp.error.code };

  const rows = resp.values || [];
  if (rows.length === 0) return { data: [], message: 'No data found' };

  const headers = rows[0];
  const colIndex = column.length === 1
    ? column.toUpperCase().charCodeAt(0) - 65 // A=0, B=1, etc.
    : headers.findIndex(h => h.toLowerCase() === column.toLowerCase());

  if (colIndex < 0 || colIndex >= headers.length) {
    return { error: `Column "${column}" not found. Available: ${headers.join(', ')}` };
  }

  const matches = rows.slice(1)
    .map((row, i) => ({ row: i + 2, data: row }))
    .filter(r => r.data[colIndex] && r.data[colIndex].toString().toLowerCase().includes(value.toLowerCase()))
    .map(r => {
      const obj = { _row: r.row };
      headers.forEach((h, i) => { obj[h] = r.data[i] || ''; });
      return obj;
    });

  return { matches, count: matches.length, searchColumn: headers[colIndex], searchValue: value };
}

// ─── Main ───────────────────────────────────────────────────────────────────

async function main() {
  const [,, command, ...args] = process.argv;

  if (!command) {
    console.log('Usage: node sheets.cjs <command> [args...]');
    console.log('Commands: read, write, append, update, create, list-sheets, add-sheet, clear, search');
    process.exit(1);
  }

  const creds = getServiceAccountCredentials();
  const token = await getAccessToken(creds);

  let result;
  switch (command) {
    case 'read':
      result = await cmdRead(token, args[0], args[1], args[2]);
      break;
    case 'write':
      result = await cmdWrite(token, args[0], args[1], args[2], args[3]);
      break;
    case 'append':
      result = await cmdAppend(token, args[0], args[1], args[2]);
      break;
    case 'update':
      result = await cmdUpdate(token, args[0], args[1], args[2], args[3]);
      break;
    case 'create':
      result = await cmdCreate(token, args[0], args[1]);
      break;
    case 'list-sheets':
      result = await cmdListSheets(token, args[0]);
      break;
    case 'add-sheet':
      result = await cmdAddSheet(token, args[0], args[1]);
      break;
    case 'clear':
      result = await cmdClear(token, args[0], args[1], args[2]);
      break;
    case 'search':
      result = await cmdSearch(token, args[0], args[1], args[2], args[3]);
      break;
    default:
      result = { error: `Unknown command: ${command}` };
  }

  console.log(JSON.stringify(result, null, 2));
}

main().catch(err => {
  console.error(JSON.stringify({ error: err.message }));
  process.exit(1);
});
