# Sample End-to-End Workflow

## Scenario: New Lead → Qualified → Deal → Closed

### 1. New lead enters HubSpot
A new contact is created: Sarah Chen, VP Engineering at DataCorp (250 employees, Technology industry).

### 2. Agent scores the lead
```
Score: 90/100 — HOT
+30 — title contains "VP"
+20 — employees in range 50-500
+15 — industry contains "Technology"
+10 — company not empty
+10 — email opened 3 times
+5  — has notes
```

### 3. Agent sends Slack alert
```
🔥 HOT LEAD — Score: 90/100

Sarah Chen — VP Engineering
DataCorp (Technology, 250 employees)

Why hot:
+30 VP title, +20 mid-market, +15 tech industry

HubSpot: https://app.hubspot.com/contacts/xxx/contact/12345
Action: Review and contact within 2 hours.
```

### 4. Agent logs to Google Sheets
| Date | Name | Email | Company | Title | Score | Source | Status |
|------|------|-------|---------|-------|-------|--------|--------|
| 2026-03-17 | Sarah Chen | sarah@datacorp.com | DataCorp | VP Engineering | 90 | Website | Hot |

### 5. Human follows up, creates deal
Sales rep contacts Sarah, creates a deal in HubSpot: "DataCorp — AI Integration" — $15,000.

### 6. Agent detects new deal
```
📊 New deal created: DataCorp — AI Integration — $15,000
Stage: Appointment Scheduled
Contact: Sarah Chen (Score: 90)
```

### 7. Days pass — agent checks for follow-up
3 days later, no notes added to the deal.

```
📋 Follow-up needed (1 deal):
• Sarah Chen — DataCorp — AI Integration — $15,000
  Last contact: 3 days ago
  Stage: Appointment Scheduled
  Suggested action: Follow up on meeting outcome
```

### 8. Deal progresses
Rep updates deal to "Proposal Sent". Agent logs the stage change.

### 9. Deal closes
```
🎉 DEAL CLOSED!

DataCorp — AI Integration — $15,000
Company: DataCorp
Stage: Closed Won
Close date: 2026-04-01

Pipeline: $45,000 remaining across 8 open deals
```

### 10. Weekly report includes the win
The Monday report shows DataCorp as the biggest win of the week, with conversion metrics and pipeline health.

---

This entire flow happens autonomously. The human only needs to:
1. Make the actual sales calls
2. Update deal stages in HubSpot
3. Review the daily/weekly reports

The agent handles everything else.
