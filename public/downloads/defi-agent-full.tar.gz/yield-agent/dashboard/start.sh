#!/bin/bash
# Start dashboard server — binds to 0.0.0.0 for direct access
# Protected by HTTP Basic Auth (see .env DASHBOARD_PASS)
cd /home/node/.openclaw/workspace
export $(grep -v '^#' .env | xargs)
nohup node dashboard/server-public.cjs > /tmp/dashboard.log 2>&1 &
echo "Dashboard PID: $!"
