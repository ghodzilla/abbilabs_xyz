---
name: hubspot-agent
description: "Manage contacts, companies, deals, and tickets in HubSpot CRM via the API. Use when: the agent needs to handle sales pipelines, manage customer relationships, track deals, automate follow-ups, or integrate HubSpot data into workflows. Requires a HubSpot Private App Token."
homepage: https://developers.hubspot.com
metadata:
  openclaw:
    emoji: "🧲"
    requires:
      env:
        - HUBSPOT_ACCESS_TOKEN
      node: true
    category: "Sales & CRM"
    price: "$49"
    platforms: ["OpenClaw"]
    llm_compatible: ["Claude", "GPT", "Any"]
---

# HubSpot Agent Skill

Full HubSpot CRM integration for AI agents. Manage contacts, companies, deals, tickets, and notes — your agent becomes a CRM operator that never forgets a follow-up.

## When to Use

✅ **USE this skill when:**
- Managing contacts (create, update, search, associate)
- Tracking deals through pipeline stages
- Creating and managing support tickets
- Logging notes, calls, and activities on records
- Searching the CRM for contacts, companies, or deals
- Building automated sales or support workflows
- Generating CRM reports and summaries

## When NOT to Use

❌ **DON'T use this skill when:**
- Marketing automation (email sequences, ads) → use HubSpot Marketing Hub
- Website CMS management → use HubSpot CMS API
- Complex workflow builder logic → use HubSpot Workflows UI
- OAuth flows for customer-facing apps → this skill uses private app tokens

## Setup (One-Time)

### 1. Create a HubSpot Private App
1. Go to **Settings** → **Integrations** → **Private Apps**
2. Click **Create a private app**
3. Name it (e.g., `AI Agent`)
4. Under **Scopes**, add:
   - `crm.objects.contacts.read` / `.write`
   - `crm.objects.companies.read` / `.write`
   - `crm.objects.deals.read` / `.write`
   - `crm.objects.custom.read` / `.write`
   - `tickets` (read/write)
   - `crm.objects.owners.read`
   - `sales-email-read`
5. Click **Create app** → Copy the **Access Token**

### 2. Configure the Skill
```bash
export HUBSPOT_ACCESS_TOKEN="pat-na1-your-token-here"
```

## Commands

All commands use the script at `scripts/hubspot.cjs`.

### Contacts

```bash
# Search contacts
node scripts/hubspot.cjs search-contacts "<query>"
# Example: Find by name or email
node scripts/hubspot.cjs search-contacts "alice@company.com"

# Get contact by ID
node scripts/hubspot.cjs get-contact <contactId>

# Create contact
node scripts/hubspot.cjs create-contact '<properties_json>'
# Example:
node scripts/hubspot.cjs create-contact '{"firstname":"Alice","lastname":"Smith","email":"alice@company.com","phone":"555-0100","company":"Acme Corp","jobtitle":"CTO"}'

# Update contact
node scripts/hubspot.cjs update-contact <contactId> '<properties_json>'
# Example: Update lifecycle stage
node scripts/hubspot.cjs update-contact "123" '{"lifecyclestage":"customer"}'

# List recent contacts
node scripts/hubspot.cjs list-contacts [limit]
```

### Companies

```bash
# Search companies
node scripts/hubspot.cjs search-companies "<query>"

# Get company
node scripts/hubspot.cjs get-company <companyId>

# Create company
node scripts/hubspot.cjs create-company '{"name":"Acme Corp","domain":"acme.com","industry":"Technology","numberofemployees":"50"}'

# Update company
node scripts/hubspot.cjs update-company <companyId> '<properties_json>'
```

### Deals

```bash
# Search deals
node scripts/hubspot.cjs search-deals "<query>"

# Get deal
node scripts/hubspot.cjs get-deal <dealId>

# Create deal
node scripts/hubspot.cjs create-deal '{"dealname":"Acme Enterprise License","amount":"15000","pipeline":"default","dealstage":"appointmentscheduled"}'

# Update deal stage
node scripts/hubspot.cjs update-deal <dealId> '{"dealstage":"closedwon","amount":"15000"}'

# List deals in pipeline
node scripts/hubspot.cjs list-deals [limit]
```

### Tickets

```bash
# Create ticket
node scripts/hubspot.cjs create-ticket '{"subject":"Login issue","content":"Customer reports 500 error on login page","hs_pipeline":"0","hs_pipeline_stage":"1"}'

# Update ticket
node scripts/hubspot.cjs update-ticket <ticketId> '{"hs_pipeline_stage":"3"}'

# Search tickets
node scripts/hubspot.cjs search-tickets "<query>"
```

### Notes & Activities

```bash
# Add note to a contact
node scripts/hubspot.cjs add-note contact <contactId> "<note_text>"

# Add note to a deal
node scripts/hubspot.cjs add-note deal <dealId> "<note_text>"

# Example
node scripts/hubspot.cjs add-note contact "123" "Called Alice — interested in enterprise plan. Follow up next Tuesday."
```

### Associations

```bash
# Associate contact with company
node scripts/hubspot.cjs associate contact <contactId> company <companyId>

# Associate deal with contact
node scripts/hubspot.cjs associate deal <dealId> contact <contactId>

# Associate deal with company
node scripts/hubspot.cjs associate deal <dealId> company <companyId>
```

### Pipelines

```bash
# List deal pipelines and stages
node scripts/hubspot.cjs pipelines

# List ticket pipelines
node scripts/hubspot.cjs ticket-pipelines
```

### Owners

```bash
# List CRM owners (sales team)
node scripts/hubspot.cjs owners
```

## Common Patterns

### Sales Pipeline Management
```bash
# Create deal + associate with contact
node scripts/hubspot.cjs create-deal '{"dealname":"Acme Corp - Pro Plan","amount":"5000","pipeline":"default","dealstage":"appointmentscheduled"}'
node scripts/hubspot.cjs associate deal "DEAL_ID" contact "CONTACT_ID"
node scripts/hubspot.cjs add-note deal "DEAL_ID" "Initial demo scheduled for 2026-03-20. Decision maker: Alice (CTO). Budget: $5K-10K."

# Move deal forward
node scripts/hubspot.cjs update-deal "DEAL_ID" '{"dealstage":"qualifiedtobuy"}'
```

### Customer Onboarding
```bash
# Update contact lifecycle
node scripts/hubspot.cjs update-contact "CONTACT_ID" '{"lifecyclestage":"customer"}'

# Create onboarding ticket
node scripts/hubspot.cjs create-ticket '{"subject":"Onboarding: Acme Corp","content":"New customer. Plan: Pro. Start date: 2026-03-20."}'

# Log onboarding note
node scripts/hubspot.cjs add-note contact "CONTACT_ID" "Onboarding started. Sent welcome email + access credentials."
```

### Lead Qualification
```bash
# Search for new leads
node scripts/hubspot.cjs search-contacts "lifecyclestage:lead"

# Enrich and qualify
node scripts/hubspot.cjs update-contact "CONTACT_ID" '{"hs_lead_status":"OPEN","notes":"Inbound from website. Company: 50+ employees. Budget confirmed."}'
```

## Property Reference

### Contact Properties
| Property | Description |
|----------|-------------|
| `firstname` | First name |
| `lastname` | Last name |
| `email` | Email address |
| `phone` | Phone number |
| `company` | Company name |
| `jobtitle` | Job title |
| `lifecyclestage` | subscriber, lead, marketingqualifiedlead, salesqualifiedlead, opportunity, customer, evangelist |
| `hs_lead_status` | NEW, OPEN, IN_PROGRESS, OPEN_DEAL, UNQUALIFIED, ATTEMPTED_TO_CONTACT, CONNECTED, BAD_TIMING |

### Deal Properties
| Property | Description |
|----------|-------------|
| `dealname` | Deal name |
| `amount` | Deal value |
| `pipeline` | Pipeline ID (use `pipelines` to list) |
| `dealstage` | Stage ID (use `pipelines` to list) |
| `closedate` | Expected close date (YYYY-MM-DD) |
| `hubspot_owner_id` | Assigned owner ID |

## Error Handling

| Error | Cause | Fix |
|-------|-------|-----|
| `401 Unauthorized` | Invalid token | Regenerate in Private Apps settings |
| `403 Forbidden` | Missing scope | Add required scope to Private App |
| `404 Not Found` | Wrong object ID | Verify the ID exists |
| `409 Conflict` | Duplicate contact (email) | Search first, update existing |
| `429 Rate Limited` | Too many requests | Script auto-retries |

## Rate Limits

- HubSpot API: 100 requests per 10 seconds (private apps)
- Search API: 4 requests per second
- The skill handles rate limiting with automatic backoff
- Batch operations available for bulk updates (up to 100 per request)

## Notes

- HubSpot Free CRM works with this skill (no paid plan required)
- Contact emails must be unique — creating a duplicate returns an error
- Deal stages are pipeline-specific — use `pipelines` to list valid stages
- All dates should be in ISO 8601 or YYYY-MM-DD format
- The skill uses HubSpot API v3 (latest)
