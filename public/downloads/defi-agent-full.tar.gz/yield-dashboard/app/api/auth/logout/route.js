import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

export async function POST() {
  const res = NextResponse.json({ success: true });
  res.cookies.set('pb_token', '', {
    httpOnly: false,
    maxAge: 0,
    sameSite: 'strict',
    path: '/',
  });
  return res;
}
