# AI Sales Agent — Workflows

These are the step-by-step workflows your agent follows. Each workflow is a sequence of actions triggered by an event or schedule.

---

## Workflow 1: New Lead Processing

**Trigger:** New contact created in HubSpot (checked every 30 minutes)

```
1. FETCH new contacts from HubSpot created since last check
   → hubspot.cjs list-contacts --since {last_check_timestamp}

2. For each new contact:
   a. SCORE the lead using config.json scoring rules
      → lead-scorer.cjs score --contact {contact_id}
   
   b. LOG to Google Sheets "Leads" tab
      → sheets.cjs append {spreadsheet_id} Leads!A:H
        [date, name, email, company, title, score, source, status]
   
   c. ADD NOTE to HubSpot contact
      → hubspot.cjs add-note contact {contact_id}
        "AI Agent: Lead scored {score}/100. Classification: {hot/warm/cold}."
   
   d. IF score >= hot_threshold:
      → slack.cjs send {hot_lead_channel}
        "🔥 Hot lead: {name}, {title} at {company}. Score: {score}. {hubspot_link}"
   
   e. IF score >= warm_threshold AND < hot_threshold:
      → slack.cjs send {daily_report_channel}
        "📊 New warm lead: {name}, {title} at {company}. Score: {score}."
   
   f. IF score < warm_threshold:
      → No alert. Logged to Sheets only.
```

---

## Workflow 2: Deal Stage Changes

**Trigger:** Deal stage changes in HubSpot (checked every 30 minutes)

```
1. FETCH deals modified since last check
   → hubspot.cjs list-deals --since {last_check_timestamp}

2. For each deal with a stage change:
   a. LOG to Google Sheets "Deals" tab
      → sheets.cjs append {spreadsheet_id} Deals!A:G
        [date, deal_name, company, old_stage, new_stage, amount, owner]
   
   b. IF new_stage == "closedwon":
      → slack.cjs send {daily_report_channel}
        "🎉 DEAL CLOSED: {deal_name} — ${amount}! 🎉"
   
   c. IF new_stage == "closedlost":
      → slack.cjs send {daily_report_channel}
        "❌ Deal lost: {deal_name} — ${amount}. Reason: {close_reason}"
   
   d. IF deal amount >= high_value_deal_threshold AND stage moved forward:
      → slack.cjs send {hot_lead_channel}
        "💰 High-value deal progressed: {deal_name} — ${amount} → {new_stage}"
```

---

## Workflow 3: Follow-up Checker

**Trigger:** Daily (runs once per day at configured time)

```
1. FETCH all open deals from HubSpot
   → hubspot.cjs list-deals --stage not:closedwon,closedlost

2. For each deal:
   a. CHECK last activity date
   b. IF last_activity > follow_up_days ago:
      → Flag as needing follow-up
   
3. FETCH all contacts with open deals but no recent notes
   → hubspot.cjs search-contacts --no-notes-since {note_stale_days}

4. COMPILE follow-up list

5. LOG to Google Sheets "Follow-ups" tab
   → sheets.cjs append {spreadsheet_id} Follow-ups!A:F
     [date, contact_name, deal_name, days_since_contact, deal_value, recommended_action]

6. POST to Slack
   → slack.cjs send {follow_up_channel}
     "📋 Follow-up needed ({count} leads):
      • {name} — {deal} — ${amount} — last contact {days} days ago
      • ..."

7. ADD NOTES to each flagged HubSpot contact
   → hubspot.cjs add-note contact {contact_id}
     "AI Agent: Flagged for follow-up. No activity in {days} days."
```

---

## Workflow 4: Daily Pipeline Report

**Trigger:** Daily at configured time (default 09:00 UTC)

```
1. FETCH pipeline summary from HubSpot
   → hubspot.cjs list-deals (all open deals)
   → hubspot.cjs list-contacts --created-since yesterday

2. CALCULATE metrics:
   - Total pipeline value (sum of all open deals)
   - New leads today
   - Deals moved forward
   - Deals closed (won + lost)
   - Average deal size
   - Conversion rate (closed-won / total closed)

3. GENERATE report using templates/daily-report.md

4. LOG to Google Sheets "Reports" tab
   → sheets.cjs append {spreadsheet_id} Reports!A:H
     [date, pipeline_value, new_leads, deals_progressed, closed_won, closed_lost, revenue_today, conversion_rate]

5. POST to Slack
   → slack.cjs send {daily_report_channel}
     [formatted daily report]
```

---

## Workflow 5: Weekly Performance Report

**Trigger:** Every Monday at configured time

```
1. FETCH weekly data from Google Sheets "Reports" tab
   → sheets.cjs read {spreadsheet_id} Reports!A:H (last 7 rows)

2. CALCULATE week-over-week metrics:
   - Total revenue this week vs last week
   - New leads this week vs last week
   - Pipeline growth
   - Top deals by value
   - Leads by source
   - Conversion funnel

3. GENERATE comprehensive report

4. POST to Slack
   → slack.cjs send {daily_report_channel}
     [formatted weekly report with trends and recommendations]
```

---

## How to Customise

- **Add a workflow:** Copy the format above, define trigger and steps
- **Modify thresholds:** Edit config.json
- **Change alert channels:** Update config.json alerts section
- **Adjust scoring:** Add/remove/modify rules in config.json scoring section
- **Change templates:** Edit files in templates/ directory

Each workflow references the scripts in scripts/ — the same scripts work regardless of your agent framework.
