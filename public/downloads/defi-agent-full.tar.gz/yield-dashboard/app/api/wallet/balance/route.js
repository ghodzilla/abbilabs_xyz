import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

const ALCHEMY_NETWORKS = {
  ethereum: 'eth-mainnet',
  base: 'base-mainnet',
  arbitrum: 'arb-mainnet',
  optimism: 'opt-mainnet',
  polygon: 'polygon-mainnet',
};

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const address = searchParams.get('address');
  const network = searchParams.get('network') || 'ethereum';

  const isSolana = network === 'solana' || /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address) && !address.startsWith('0x');
  if (!address || (!isSolana && !/^0x[a-fA-F0-9]{40}$/.test(address))) {
    return NextResponse.json({ error: 'Invalid address' }, { status: 400 });
  }

  // ── Solana balance via public RPC ─────────────────────────────────────────
  if (isSolana) {
    try {
      const solRpc = 'https://api.mainnet-beta.solana.com';
      const [balRes, priceRes] = await Promise.all([
        fetch(solRpc, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'getBalance', params: [address] }),
        }),
        fetch('https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd'),
      ]);
      const balData = await balRes.json();
      const priceData = await priceRes.json();
      const lamports = balData.result?.value || 0;
      const balanceSol = lamports / 1e9;
      const solUsd = priceData?.solana?.usd || 0;
      return NextResponse.json({
        address, network: 'solana',
        balanceEth: parseFloat(balanceSol.toFixed(6)), // reusing field for SOL amount
        balanceUsd: parseFloat((balanceSol * solUsd).toFixed(2)),
        nativeTokenUsd: solUsd,
        nativeToken: 'SOL',
        dataSource: 'solana-rpc',
        fetchedAt: new Date().toISOString(),
      });
    } catch (err) {
      return NextResponse.json({ error: err.message }, { status: 500 });
    }
  }

  // Resolve Alchemy network up front — undefined means unsupported chain
  const alchemyNetwork = ALCHEMY_NETWORKS[network];
  const alchemyKey = process.env.ALCHEMY_API_KEY;

  try {
    let balanceEth = 0;
    let balanceSource = 'none';

    // ── 1. Try Alchemy first for ALL supported networks ───────────────────────
    if (alchemyKey && alchemyNetwork) {
      const alchemyUrl = `https://${alchemyNetwork}.g.alchemy.com/v2/${alchemyKey}`;

      try {
        const balRes = await fetch(alchemyUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            jsonrpc: '2.0',
            id: 1,
            method: 'eth_getBalance',
            params: [address, 'latest'],
          }),
        });
        const balData = await balRes.json();

        if (balData.result) {
          const balanceWei = BigInt(balData.result || '0x0');
          balanceEth = Number(balanceWei) / 1e18;
          balanceSource = `alchemy:${alchemyNetwork}`;
        } else {
          throw new Error(balData.error?.message || 'No result from Alchemy');
        }
      } catch (alchemyErr) {
        console.warn('[balance] Alchemy failed, falling back to Etherscan:', alchemyErr.message);
        balanceSource = 'etherscan-fallback';
      }
    } else if (!alchemyNetwork) {
      // Network not in Alchemy map (e.g. solana) — return zero gracefully
      console.warn(`[balance] Network '${network}' not in Alchemy map — returning zero balance`);
    } else {
      // No Alchemy key — will try Etherscan below
      balanceSource = 'etherscan-fallback';
    }

    // ── 2. Etherscan fallback (Ethereum mainnet only) ────────────────────────
    if (balanceSource === 'etherscan-fallback' && network === 'ethereum') {
      const etherscanKey = process.env.ETHERSCAN_API_KEY || 'YourApiKeyToken';
      try {
        const balanceRes = await fetch(
          `https://api.etherscan.io/api?module=account&action=balance&address=${address}&tag=latest&apikey=${etherscanKey}`
        );
        const balanceData = await balanceRes.json();

        if (balanceData.status === '1') {
          balanceEth = parseInt(balanceData.result, 10) / 1e18;
          balanceSource = 'etherscan';
        }
      } catch (etherscanErr) {
        console.warn('[balance] Etherscan fallback also failed:', etherscanErr.message);
      }
    }

    // ── 3. Fetch native token USD price from CoinGecko ───────────────────────
    const NATIVE_TOKEN_IDS = {
      ethereum: 'ethereum',
      base: 'ethereum',      // ETH on Base
      arbitrum: 'ethereum',  // ETH on Arbitrum
      optimism: 'ethereum',  // ETH on Optimism
      polygon: 'matic-network',
    };

    const coinId = NATIVE_TOKEN_IDS[network] || 'ethereum';
    let nativeUsd = 0;
    try {
      const priceRes = await fetch(
        `https://api.coingecko.com/api/v3/simple/price?ids=${coinId}&vs_currencies=usd`,
        { headers: { 'Accept': 'application/json' } }
      );
      const priceData = await priceRes.json();
      nativeUsd = priceData?.[coinId]?.usd || 0;
    } catch {
      // Price fetch failed — continue with 0
    }

    const balanceUsd = balanceEth * nativeUsd;

    // Derive simplified dataSource for consumers
    const dataSource = balanceSource.startsWith('alchemy') ? 'alchemy'
      : balanceSource === 'etherscan' ? 'etherscan'
      : 'none';

    return NextResponse.json({
      address,
      network,
      balanceEth: parseFloat(balanceEth.toFixed(6)),
      balanceUsd: parseFloat(balanceUsd.toFixed(2)),
      nativeTokenUsd: nativeUsd,
      dataSource,
      balanceSource,
      fetchedAt: new Date().toISOString(),
    });
  } catch (err) {
    return NextResponse.json({ error: err.message || 'Failed to fetch balance' }, { status: 500 });
  }
}
