# Yield Intelligence Report — 2026-03-20 09:03 UTC

**Simulation Day:** 0.9 / 7 (Day 1 of 7)
**Days Remaining:** ~6.1
**Report Time:** 2026-03-20 09:03 UTC

---

## Strategy Standings

| Metric | Strategy A (Max APY) | Strategy B (Risk-Adjusted) |
|---|---|---|
| Starting Capital | $2,500.00 | $2,500.00 |
| Current Balance | **$2,504.17** | $2,502.50 |
| Total Earned | **$4.17** | $2.50 |
| Return (so far) | **+0.17%** | +0.10% |
| Projected APY | **65.4%** | 39.2% |
| Daily Earnings | **$4.41/day** | $2.55/day |

**🏆 Current Leader: Strategy A** — leads by $1.67 with $1.86/day earnings edge.

Combined portfolio: **$5,006.67** (+$6.67 total across both)

---

## Strategy A — Top Positions

1. Base | PancakeSwap AMM v3 | WETH-USDC | **66.5% APY** | $2.1M TVL
2. Base | Aerodrome Slipstream | WETH-USDC | **66.3% APY** | $14.6M TVL
3. Solana | Orca DEX | SOL-USDC | **66.0% APY** | $29.5M TVL
4. Base | Uniswap v4 | ETH-USDC | **65.1% APY** | $1.6M TVL
5. Base | PancakeSwap AMM v3 | WETH-USDC | **58.3% APY** | $4.7M TVL

## Strategy B — Top Positions

1. Solana | Jupiter Lend | USDS | 5.1% APY | $28.3M TVL (lending — no IL)
2. Ethereum | Fluid Lending | USDT | 4.3% APY | $142.2M TVL (lending — no IL)
3. Solana | Orca DEX | SOL-USDC | **66.0% APY** | $29.5M TVL
4. Base | Aerodrome Slipstream | WETH-USDC | **66.3% APY** | $14.6M TVL
5. Ethereum | Uniswap v3 | USDC-WETH | **44.5% APY** | $93.5M TVL

---

## APY Change Since Last Report

No prior report on file — baseline set this run. APY range:
- Strategy A: 58–66.5% across all positions ✅ No alerts
- Strategy B: 4–66.3% (blended by design) ✅ No alerts

No position showed >10% APY change (first run — no prior baseline to compare).

---

## Correlation Check

**Status: ⚠️ DEGRADED — CoinGecko rate limited**

The correlation checker was unable to fetch price history data for most LP pairs due to CoinGecko API rate limits and a script bug (`THRESHOLDS is not defined`). Actual correlation scores could not be computed.

| Pair | Strategy | Type | Status |
|---|---|---|---|
| WETH-USDC | A | LP | ⚪ API error (THRESHOLDS bug) |
| SOL-USDC | A | LP | ⚪ API rate limited |
| ETH-USDC | A | LP | ⚪ API rate limited |
| WETH-USDC | A | LP (x2) | ⚪ API rate limited |
| USDS | B | Lending | ✅ Single-asset, no IL |
| USDT | B | Lending | ✅ Single-asset, no IL |
| SOL-USDC | B | LP | ⚪ API rate limited |
| WETH-USDC | B | LP | ⚪ API rate limited |
| USDC-WETH | B | LP | ⚪ API rate limited |

**Action Required:** Fix `correlation-checker.cjs` — `THRESHOLDS` variable not defined. Also implement CoinGecko retry/fallback (CryptoCompare worked this run).

**No confirmed correlation threshold breaches** — but LP pair checks could not execute.

---

## Market Context (via CryptoCompare)

| Asset | Price (USD) | 24h Change | IL Risk Flag |
|---|---|---|---|
| ETH | $2,158.26 | **-1.43%** | ✅ No alert (<5%) |
| BTC | $70,985.26 | **+0.68%** | ✅ No alert (<5%) |
| SOL | $89.60 | **-0.66%** | ✅ No alert (<5%) |

All assets within normal range. No IL risk flags triggered. ETH slightly down but well within threshold.

---

## Alert Status

| Alert Condition | Status |
|---|---|
| Correlation below threshold | ⚪ Could not verify (API issues) |
| Pool APY dropped >50% | ✅ No — all APYs stable |
| Stablecoin peg deviation >0.2% | ✅ No — stables are lending-only |
| Any asset down >10% in 24h | ✅ No — max move was ETH -1.43% |
| Simulation Day 7 reached | ✅ No — Day 0.9 of 7 |

**No alerts triggered this cycle.** No Telegram message required.

---

## Recommendation

**HOLD — all positions.** Day 1 of 7. Too early to draw statistical conclusions.

Observations so far:
- Strategy A's pure high-APY approach has a $1.67 earnings lead on Day 1
- Strategy B's stablecoin lending cushion (USDS/USDT) provides downside protection but drags projected APY to 39.2% vs 65.4%
- All underlying assets are flat-to-slightly-down — good environment for LP strategies (low IL risk)
- TVL on top positions is healthy ($14–142M) — liquidity depth not a concern

**⚠️ Maintenance Flag:** `correlation-checker.cjs` needs a bug fix before it can validate LP pair health. This is a tool issue, not a position risk.

---

## Next Report

Scheduled in ~8 hours. By Day 3, trend should be clearer for a preliminary A vs B recommendation.
