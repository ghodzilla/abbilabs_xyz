#!/usr/bin/env node
/**
 * Slack Agent Skill — Core Script
 * Full Slack integration via Web API.
 * Auth: Bot User OAuth Token (xoxb-...)
 *
 * Usage:
 *   node slack.cjs send <channel> "<message>"
 *   node slack.cjs reply <channel> <thread_ts> "<message>"
 *   node slack.cjs history <channel> [limit]
 *   node slack.cjs search "<query>"
 *   node slack.cjs channels
 *   node slack.cjs user <user_id>
 *   node slack.cjs react <channel> <timestamp> <emoji>
 *   node slack.cjs pin <channel> <timestamp>
 *   node slack.cjs unpin <channel> <timestamp>
 *   node slack.cjs topic <channel> "<topic>"
 *   node slack.cjs snippet <channel> "<title>" "<content>"
 */
'use strict';

const https = require('https');

const TOKEN = process.env.SLACK_BOT_TOKEN;
if (!TOKEN) {
  console.error(JSON.stringify({ error: 'SLACK_BOT_TOKEN environment variable not set' }));
  process.exit(1);
}

// ─── HTTP Helper ────────────────────────────────────────────────────────────

function slackApi(method, endpoint, body) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null;
    const opts = {
      method: method,
      hostname: 'slack.com',
      path: `/api/${endpoint}`,
      headers: {
        Authorization: `Bearer ${TOKEN}`,
        'Content-Type': 'application/json; charset=utf-8',
      },
    };
    if (payload) opts.headers['Content-Length'] = Buffer.byteLength(payload);

    const req = https.request(opts, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString();
        try {
          const data = JSON.parse(raw);
          if (res.statusCode === 429) {
            const retryAfter = parseInt(res.headers['retry-after'] || '5', 10);
            console.error(`Rate limited. Retrying in ${retryAfter}s...`);
            setTimeout(() => slackApi(method, endpoint, body).then(resolve).catch(reject), retryAfter * 1000);
            return;
          }
          resolve(data);
        } catch {
          resolve({ ok: false, error: 'parse_error', _raw: raw.substring(0, 200) });
        }
      });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// ─── Channel Resolution ────────────────────────────────────────────────────

async function resolveChannel(channelRef) {
  // Already an ID
  if (channelRef.startsWith('C') || channelRef.startsWith('D') || channelRef.startsWith('G')) {
    return channelRef;
  }

  // Strip # prefix
  const name = channelRef.replace(/^#/, '');

  // If it starts with @, it's a DM — find user and open DM
  if (channelRef.startsWith('@')) {
    const username = channelRef.replace(/^@/, '');
    const users = await slackApi('GET', `users.list?limit=200`, null);
    if (!users.ok) throw new Error('Failed to list users: ' + users.error);
    const user = users.members?.find(u =>
      u.name === username || u.real_name?.toLowerCase() === username.toLowerCase()
    );
    if (!user) throw new Error(`User not found: ${username}`);
    const dm = await slackApi('POST', 'conversations.open', { users: user.id });
    if (!dm.ok) throw new Error('Failed to open DM: ' + dm.error);
    return dm.channel.id;
  }

  // It's a channel name — look it up
  let cursor = '';
  do {
    const resp = await slackApi('GET', `conversations.list?limit=200&types=public_channel,private_channel${cursor ? '&cursor=' + cursor : ''}`, null);
    if (!resp.ok) throw new Error('Failed to list channels: ' + resp.error);
    const ch = resp.channels?.find(c => c.name === name);
    if (ch) return ch.id;
    cursor = resp.response_metadata?.next_cursor || '';
  } while (cursor);

  throw new Error(`Channel not found: ${channelRef}`);
}

// ─── Commands ───────────────────────────────────────────────────────────────

async function cmdSend(channelRef, text) {
  const channel = await resolveChannel(channelRef);
  const resp = await slackApi('POST', 'chat.postMessage', { channel, text, unfurl_links: false });
  if (!resp.ok) return { error: resp.error };
  return { success: true, ts: resp.ts, channel: resp.channel };
}

async function cmdReply(channelRef, threadTs, text) {
  const channel = await resolveChannel(channelRef);
  const resp = await slackApi('POST', 'chat.postMessage', { channel, text, thread_ts: threadTs, unfurl_links: false });
  if (!resp.ok) return { error: resp.error };
  return { success: true, ts: resp.ts, thread_ts: threadTs };
}

async function cmdHistory(channelRef, limit = 10) {
  const channel = await resolveChannel(channelRef);
  const resp = await slackApi('GET', `conversations.history?channel=${channel}&limit=${limit}`, null);
  if (!resp.ok) return { error: resp.error };
  return {
    messages: resp.messages?.map(m => ({
      user: m.user,
      text: m.text,
      ts: m.ts,
      thread_ts: m.thread_ts,
      reply_count: m.reply_count,
      reactions: m.reactions?.map(r => ({ emoji: r.name, count: r.count })),
    })),
    count: resp.messages?.length,
  };
}

async function cmdSearch(query) {
  const resp = await slackApi('GET', `search.messages?query=${encodeURIComponent(query)}&count=20`, null);
  if (!resp.ok) return { error: resp.error };
  return {
    messages: resp.messages?.matches?.map(m => ({
      text: m.text,
      user: m.username,
      channel: m.channel?.name,
      ts: m.ts,
      permalink: m.permalink,
    })),
    total: resp.messages?.total,
  };
}

async function cmdChannels() {
  const channels = [];
  let cursor = '';
  do {
    const resp = await slackApi('GET', `conversations.list?limit=200&types=public_channel${cursor ? '&cursor=' + cursor : ''}`, null);
    if (!resp.ok) return { error: resp.error };
    channels.push(...(resp.channels || []).map(c => ({
      id: c.id,
      name: c.name,
      members: c.num_members,
      topic: c.topic?.value,
      purpose: c.purpose?.value,
      archived: c.is_archived,
    })));
    cursor = resp.response_metadata?.next_cursor || '';
  } while (cursor);
  return { channels, count: channels.length };
}

async function cmdUser(userId) {
  const resp = await slackApi('GET', `users.info?user=${userId}`, null);
  if (!resp.ok) return { error: resp.error };
  const u = resp.user;
  return {
    id: u.id,
    name: u.name,
    real_name: u.real_name,
    display_name: u.profile?.display_name,
    email: u.profile?.email,
    title: u.profile?.title,
    status: u.profile?.status_text,
    timezone: u.tz,
    is_admin: u.is_admin,
    is_bot: u.is_bot,
  };
}

async function cmdReact(channelRef, timestamp, emoji) {
  const channel = await resolveChannel(channelRef);
  const resp = await slackApi('POST', 'reactions.add', { channel, timestamp, name: emoji });
  if (!resp.ok) return { error: resp.error };
  return { success: true };
}

async function cmdPin(channelRef, timestamp) {
  const channel = await resolveChannel(channelRef);
  const resp = await slackApi('POST', 'pins.add', { channel, timestamp });
  if (!resp.ok) return { error: resp.error };
  return { success: true };
}

async function cmdUnpin(channelRef, timestamp) {
  const channel = await resolveChannel(channelRef);
  const resp = await slackApi('POST', 'pins.remove', { channel, timestamp });
  if (!resp.ok) return { error: resp.error };
  return { success: true };
}

async function cmdTopic(channelRef, topic) {
  const channel = await resolveChannel(channelRef);
  const resp = await slackApi('POST', 'conversations.setTopic', { channel, topic });
  if (!resp.ok) return { error: resp.error };
  return { success: true, topic };
}

async function cmdSnippet(channelRef, title, content) {
  const channel = await resolveChannel(channelRef);
  const resp = await slackApi('POST', 'files.upload', {
    channels: channel,
    title,
    content,
    filetype: 'text',
  });
  if (!resp.ok) return { error: resp.error };
  return { success: true, fileId: resp.file?.id, permalink: resp.file?.permalink };
}

// ─── Main ───────────────────────────────────────────────────────────────────

async function main() {
  const [,, command, ...args] = process.argv;

  if (!command) {
    console.log('Usage: node slack.cjs <command> [args...]');
    console.log('Commands: send, reply, history, search, channels, user, react, pin, unpin, topic, snippet');
    process.exit(1);
  }

  let result;
  switch (command) {
    case 'send':
      result = await cmdSend(args[0], args.slice(1).join(' '));
      break;
    case 'reply':
      result = await cmdReply(args[0], args[1], args.slice(2).join(' '));
      break;
    case 'history':
      result = await cmdHistory(args[0], parseInt(args[1] || '10', 10));
      break;
    case 'search':
      result = await cmdSearch(args.join(' '));
      break;
    case 'channels':
      result = await cmdChannels();
      break;
    case 'user':
      result = await cmdUser(args[0]);
      break;
    case 'react':
      result = await cmdReact(args[0], args[1], args[2]);
      break;
    case 'pin':
      result = await cmdPin(args[0], args[1]);
      break;
    case 'unpin':
      result = await cmdUnpin(args[0], args[1]);
      break;
    case 'topic':
      result = await cmdTopic(args[0], args.slice(1).join(' '));
      break;
    case 'snippet':
      result = await cmdSnippet(args[0], args[1], args.slice(2).join(' '));
      break;
    default:
      result = { error: `Unknown command: ${command}` };
  }

  console.log(JSON.stringify(result, null, 2));
}

main().catch(err => {
  console.error(JSON.stringify({ error: err.message }));
  process.exit(1);
});
