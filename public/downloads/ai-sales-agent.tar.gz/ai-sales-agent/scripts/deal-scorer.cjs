#!/usr/bin/env node
// AI Sales Agent — Deal Priority Scorer
// Scores open deals by combining: inactivity × deal size × engagement signals
// Produces a ranked "needs attention" digest for Slack
//
// Usage:
//   node deal-scorer.cjs score              → Score all open deals, output ranked list
//   node deal-scorer.cjs score --slack      → Score and post to Slack
//   node deal-scorer.cjs score --json       → Output raw JSON scores
//   node deal-scorer.cjs --test             → Run with sample data (no API needed)

'use strict';

const https = require('https');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '..', 'config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

const HUBSPOT_TOKEN = process.env.HUBSPOT_ACCESS_TOKEN;
const SLACK_WEBHOOK = process.env.SLACK_WEBHOOK_URL;

// ─── HubSpot API ───────────────────────────────────────────────────────────

function hubspotGet(endpoint) {
  return new Promise((resolve, reject) => {
    if (!HUBSPOT_TOKEN) return reject(new Error('HUBSPOT_ACCESS_TOKEN not set'));
    const url = `https://api.hubapi.com${endpoint}`;
    const req = https.get(url, {
      headers: { 'Authorization': `Bearer ${HUBSPOT_TOKEN}` }
    }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        if (res.statusCode === 429) {
          // Rate limited — wait and retry
          const retryAfter = parseInt(res.headers['retry-after'] || '2', 10) * 1000;
          setTimeout(() => hubspotGet(endpoint).then(resolve).catch(reject), retryAfter);
          return;
        }
        if (res.statusCode >= 400) return reject(new Error(`HubSpot ${res.statusCode}: ${d.substring(0, 200)}`));
        try { resolve(JSON.parse(d)); } catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
  });
}

async function fetchAllDeals() {
  const properties = [
    'dealname', 'amount', 'dealstage', 'pipeline',
    'hs_lastmodifieddate', 'notes_last_updated', 'createdate',
    'num_associated_contacts', 'hs_next_step',
    'hs_deal_stage_probability', 'hubspot_owner_id'
  ];

  const allDeals = [];
  let after = undefined;

  do {
    let url = `/crm/v3/objects/deals?limit=100&properties=${properties.join(',')}`;
    if (after) url += `&after=${after}`;
    const res = await hubspotGet(url);
    allDeals.push(...(res.results || []));
    after = res.paging?.next?.after;
  } while (after);

  return allDeals;
}

async function fetchEngagementCounts(dealIds) {
  // Fetch recent engagements for deals (emails, calls, meetings)
  const counts = {};
  for (const id of dealIds) {
    try {
      const res = await hubspotGet(`/crm/v4/objects/deals/${id}/associations/engagements`);
      counts[id] = (res.results || []).length;
    } catch (e) {
      counts[id] = 0; // If no engagements or error, default to 0
    }
  }
  return counts;
}

// ─── Scoring Engine ────────────────────────────────────────────────────────

function daysSince(dateStr) {
  if (!dateStr) return Infinity;
  const ms = Date.now() - new Date(dateStr).getTime();
  return Math.max(0, Math.floor(ms / (1000 * 60 * 60 * 24)));
}

function scoreDeal(deal, engagementCount) {
  const props = deal.properties;
  const amount = parseFloat(props.amount) || 0;
  const daysInactive = daysSince(props.hs_lastmodifieddate);
  const daysSinceNote = daysSince(props.notes_last_updated);
  const daysSinceCreated = daysSince(props.createdate);
  const stage = props.dealstage || 'unknown';

  // Skip closed deals
  if (stage === 'closedwon' || stage === 'closedlost') return null;

  const thresholds = config.deal_scoring || {
    inactivity_weight: 3,
    amount_weight: 2,
    engagement_weight: 1.5,
    stage_multipliers: {
      contractsent: 2.0,
      decisionmakerboughtin: 1.8,
      presentationscheduled: 1.5,
      qualifiedtobuy: 1.2,
      appointmentscheduled: 1.0
    },
    urgency_thresholds: {
      critical: 80,  // 🔴
      warning: 40,   // 🟡
      watch: 20      // 🟢
    }
  };

  // ─── Inactivity Score (0-100) ───
  // Exponential growth: 7 days = 20, 14 days = 50, 21 days = 80, 30+ days = 100
  const inactivityScore = Math.min(100, Math.pow(daysInactive / 7, 1.5) * 20);

  // ─── Amount Score (0-100) ───
  // Logarithmic: $1K = 20, $5K = 40, $10K = 55, $25K = 70, $50K = 80, $100K+ = 100
  const amountScore = amount > 0 ? Math.min(100, Math.log10(amount / 100) * 30) : 5;

  // ─── Engagement Score (0-100) ───
  // Inverse: fewer engagements = higher urgency
  // 0 engagements = 100 (dead silence), 1 = 70, 3 = 40, 5+ = 10
  const engagementScore = Math.max(0, 100 - (engagementCount * 20));

  // ─── Stage Multiplier ───
  // Later stages are more urgent when inactive (a stale contract is worse than a stale discovery)
  const stageMultiplier = (thresholds.stage_multipliers || {})[stage] || 1.0;

  // ─── Combined Priority Score ───
  const weights = {
    inactivity: thresholds.inactivity_weight || 3,
    amount: thresholds.amount_weight || 2,
    engagement: thresholds.engagement_weight || 1.5
  };
  const totalWeight = weights.inactivity + weights.amount + weights.engagement;

  const rawScore = (
    (inactivityScore * weights.inactivity) +
    (amountScore * weights.amount) +
    (engagementScore * weights.engagement)
  ) / totalWeight;

  const priorityScore = Math.round(rawScore * stageMultiplier);

  // ─── Urgency Level ───
  const urgencyThresholds = thresholds.urgency_thresholds || { critical: 80, warning: 40, watch: 20 };
  let urgency, emoji;
  if (priorityScore >= urgencyThresholds.critical) {
    urgency = 'CRITICAL';
    emoji = '🔴';
  } else if (priorityScore >= urgencyThresholds.warning) {
    urgency = 'WARNING';
    emoji = '🟡';
  } else if (priorityScore >= urgencyThresholds.watch) {
    urgency = 'WATCH';
    emoji = '🟢';
  } else {
    urgency = 'HEALTHY';
    emoji = '✅';
  }

  return {
    deal_id: deal.id,
    name: props.dealname || 'Unnamed Deal',
    amount,
    stage,
    days_inactive: daysInactive,
    days_since_note: daysSinceNote,
    engagement_count: engagementCount,
    priority_score: priorityScore,
    urgency,
    emoji,
    breakdown: {
      inactivity: Math.round(inactivityScore),
      amount: Math.round(amountScore),
      engagement: Math.round(engagementScore),
      stage_multiplier: stageMultiplier
    }
  };
}

// ─── Output Formatting ─────────────────────────────────────────────────────

function formatCurrency(amount) {
  if (amount >= 1000) return '$' + (amount / 1000).toFixed(amount % 1000 === 0 ? 0 : 1) + 'K';
  return '$' + amount.toLocaleString('en-US', { minimumFractionDigits: 0 });
}

function formatStageName(stage) {
  const names = {
    appointmentscheduled: 'Discovery',
    qualifiedtobuy: 'Qualified',
    presentationscheduled: 'Presentation',
    decisionmakerboughtin: 'Decision Maker',
    contractsent: 'Contract Sent',
    closedwon: 'Closed Won',
    closedlost: 'Closed Lost'
  };
  return names[stage] || stage;
}

function formatLastTouch(daysInactive) {
  if (daysInactive === 0) return 'today';
  if (daysInactive === 1) return 'yesterday';
  if (daysInactive <= 7) return `${daysInactive} days ago`;
  const weeks = Math.floor(daysInactive / 7);
  return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
}

function buildSlackDigest(scoredDeals) {
  const now = new Date().toISOString().split('T')[0];
  const critical = scoredDeals.filter(d => d.urgency === 'CRITICAL');
  const warning = scoredDeals.filter(d => d.urgency === 'WARNING');
  const watch = scoredDeals.filter(d => d.urgency === 'WATCH');
  const totalAtRisk = [...critical, ...warning].reduce((s, d) => s + d.amount, 0);

  let msg = `📊 *Pipeline Priority Digest — ${now}*\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `Scored ${scoredDeals.length} open deals · ${formatCurrency(totalAtRisk)} needs attention\n\n`;

  function formatDeal(d) {
    return `${d.emoji} *${d.name}* (${formatCurrency(d.amount)}) — ${formatLastTouch(d.days_inactive)}, ${formatStageName(d.stage)}\n` +
           `   Score: ${d.priority_score} · Inactivity: ${d.breakdown.inactivity} · Value: ${d.breakdown.amount} · Engagement: ${d.breakdown.engagement}\n`;
  }

  if (critical.length > 0) {
    msg += `🔴 *CRITICAL — Act today* (${critical.length})\n`;
    critical.forEach(d => { msg += formatDeal(d); });
    msg += '\n';
  }

  if (warning.length > 0) {
    msg += `🟡 *WARNING — Review this week* (${warning.length})\n`;
    warning.forEach(d => { msg += formatDeal(d); });
    msg += '\n';
  }

  if (watch.length > 0) {
    msg += `🟢 *WATCH — Monitor* (${watch.length})\n`;
    watch.forEach(d => { msg += formatDeal(d); });
    msg += '\n';
  }

  const healthy = scoredDeals.filter(d => d.urgency === 'HEALTHY');
  if (healthy.length > 0) {
    msg += `✅ *Healthy* — ${healthy.length} deals on track\n`;
  }

  msg += `\n💡 _Scores combine: deal size × days inactive × engagement signals × stage urgency_`;

  return msg;
}

// ─── Slack Posting ──────────────────────────────────────────────────────────

function postToSlack(text) {
  return new Promise((resolve, reject) => {
    if (!SLACK_WEBHOOK) return reject(new Error('SLACK_WEBHOOK_URL not set'));
    const url = new URL(SLACK_WEBHOOK);
    const body = JSON.stringify({ text });
    const req = https.request({
      hostname: url.hostname,
      path: url.pathname,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => res.statusCode >= 400 ? reject(new Error(`Slack ${res.statusCode}: ${d}`)) : resolve(d));
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ─── Test Mode ──────────────────────────────────────────────────────────────

function runTestMode() {
  const sampleDeals = [
    { id: '1', properties: { dealname: 'Acme Corp', amount: '24000', dealstage: 'presentationscheduled', hs_lastmodifieddate: new Date(Date.now() - 21 * 86400000).toISOString(), notes_last_updated: new Date(Date.now() - 25 * 86400000).toISOString(), createdate: '2025-01-15T00:00:00Z' } },
    { id: '2', properties: { dealname: 'GlobalTech', amount: '8000', dealstage: 'contractsent', hs_lastmodifieddate: new Date(Date.now() - 14 * 86400000).toISOString(), notes_last_updated: new Date(Date.now() - 14 * 86400000).toISOString(), createdate: '2025-02-01T00:00:00Z' } },
    { id: '3', properties: { dealname: 'StartupXYZ', amount: '3000', dealstage: 'qualifiedtobuy', hs_lastmodifieddate: new Date(Date.now() - 8 * 86400000).toISOString(), notes_last_updated: new Date(Date.now() - 5 * 86400000).toISOString(), createdate: '2025-03-01T00:00:00Z' } },
    { id: '4', properties: { dealname: 'MegaCorp', amount: '50000', dealstage: 'decisionmakerboughtin', hs_lastmodifieddate: new Date(Date.now() - 3 * 86400000).toISOString(), notes_last_updated: new Date(Date.now() - 2 * 86400000).toISOString(), createdate: '2025-02-15T00:00:00Z' } },
    { id: '5', properties: { dealname: 'DeadDeal Inc', amount: '15000', dealstage: 'presentationscheduled', hs_lastmodifieddate: new Date(Date.now() - 35 * 86400000).toISOString(), notes_last_updated: null, createdate: '2025-01-01T00:00:00Z' } },
    { id: '6', properties: { dealname: 'NewLead Co', amount: '5000', dealstage: 'appointmentscheduled', hs_lastmodifieddate: new Date(Date.now() - 1 * 86400000).toISOString(), notes_last_updated: new Date(Date.now() - 1 * 86400000).toISOString(), createdate: '2025-03-15T00:00:00Z' } },
  ];

  const sampleEngagements = { '1': 1, '2': 0, '3': 3, '4': 5, '5': 0, '6': 2 };

  const scored = sampleDeals
    .map(d => scoreDeal(d, sampleEngagements[d.id] || 0))
    .filter(Boolean)
    .sort((a, b) => b.priority_score - a.priority_score);

  const digest = buildSlackDigest(scored);
  console.log(digest);
  console.log('\n--- Raw Scores ---');
  scored.forEach(d => {
    console.log(`${d.emoji} ${d.name}: score=${d.priority_score} (inactivity=${d.breakdown.inactivity}, amount=${d.breakdown.amount}, engagement=${d.breakdown.engagement}, stage=${d.breakdown.stage_multiplier}x)`);
  });
}

// ─── Main ───────────────────────────────────────────────────────────────────

async function main() {
  const args = process.argv.slice(2);

  if (args.includes('--test')) {
    runTestMode();
    return;
  }

  if (args[0] !== 'score') {
    console.log(`AI Sales Agent — Deal Priority Scorer

Usage:
  node deal-scorer.cjs score          Score all open deals, print ranked digest
  node deal-scorer.cjs score --slack  Score and post digest to Slack
  node deal-scorer.cjs score --json   Score and output raw JSON
  node deal-scorer.cjs --test         Run with sample data (no API needed)

Scoring formula:
  Priority = (inactivity × ${config.deal_scoring?.inactivity_weight || 3} + amount × ${config.deal_scoring?.amount_weight || 2} + engagement × ${config.deal_scoring?.engagement_weight || 1.5}) × stage_multiplier

  Inactivity: exponential — 7d=20, 14d=50, 21d=80, 30d+=100
  Amount: logarithmic — $1K=20, $10K=55, $50K=80, $100K+=100
  Engagement: inverse — 0 engagements=100, 5+=10
  Stage: later stages (contract sent) score higher than early (discovery)`);
    return;
  }

  console.log('Fetching deals from HubSpot...');
  const deals = await fetchAllDeals();
  console.log(`Found ${deals.length} deals. Filtering open deals...`);

  const openDeals = deals.filter(d => {
    const stage = d.properties.dealstage;
    return stage !== 'closedwon' && stage !== 'closedlost';
  });
  console.log(`${openDeals.length} open deals. Fetching engagement data...`);

  // Fetch engagements (batched to avoid rate limits)
  const engagements = {};
  for (let i = 0; i < openDeals.length; i++) {
    try {
      const res = await hubspotGet(`/crm/v4/objects/deals/${openDeals[i].id}/associations/engagements`);
      engagements[openDeals[i].id] = (res.results || []).length;
    } catch (e) {
      engagements[openDeals[i].id] = 0;
    }
    // Rate limit: max 10 requests per second
    if (i % 10 === 9) await new Promise(r => setTimeout(r, 1100));
  }

  // Score all deals
  const scored = openDeals
    .map(d => scoreDeal(d, engagements[d.id] || 0))
    .filter(Boolean)
    .sort((a, b) => b.priority_score - a.priority_score);

  if (args.includes('--json')) {
    console.log(JSON.stringify(scored, null, 2));
    return;
  }

  const digest = buildSlackDigest(scored);

  if (args.includes('--slack')) {
    console.log('Posting to Slack...');
    await postToSlack(digest);
    console.log('✅ Posted to Slack');
  }

  console.log(digest);
}

main().catch(e => {
  console.error('Error:', e.message);
  process.exit(1);
});
