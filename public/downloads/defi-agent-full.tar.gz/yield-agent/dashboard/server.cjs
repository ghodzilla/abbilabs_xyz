#!/usr/bin/env node
/**
 * Yield Dashboard API Server
 * Password protected — access via SSH tunnel only
 * 
 * Access:
 *   ssh -L 3001:localhost:3001 root@209.38.93.29
 *   Then open: http://localhost:3001
 * 
 * Port 3001 is NOT open in the firewall — SSH tunnel is the only way in.
 */
const express = require('express');
const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });

const app = express();
const PORT = 3001;
const STATE_FILE = path.join(__dirname, '../yield-sim-state.json');
const PASS = process.env.DASHBOARD_PASS;

// Basic auth middleware
function auth(req, res, next) {
  const header = req.headers['authorization'];
  if (!header) return challenge(res);
  const b64 = header.replace('Basic ', '');
  const [, pass] = Buffer.from(b64, 'base64').toString().split(':');
  if (pass === PASS) return next();
  return challenge(res);
}

function challenge(res) {
  res.set('WWW-Authenticate', 'Basic realm="Yield Dashboard"');
  res.status(401).send('Unauthorised');
}

// Serve dashboard HTML
app.get('/', auth, (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// API: yield sim state
app.get('/api/yield', auth, (req, res) => {
  try {
    const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    res.json({ ok: true, data: state, updatedAt: new Date().toISOString() });
  } catch (e) {
    res.status(404).json({ ok: false, error: 'No simulation data yet. Run yield-sim.cjs first.' });
  }
});

// Bind to localhost only — not 0.0.0.0
// Logout — returns 401 to clear browser's cached Basic Auth credentials
app.get('/logout', (req, res) => {
  res.set('WWW-Authenticate', 'Basic realm="Yield Dashboard"');
  res.status(401).send('Logged out — <a href="/">Login again</a>');
});

app.listen(PORT, '127.0.0.1', () => {
  console.log(`✅ Dashboard running at http://localhost:${PORT} (localhost only)`);
  console.log(`🔒 Access via SSH tunnel: ssh -L 3001:localhost:3001 root@209.38.93.29`);
  console.log(`🔑 Password required (check .env DASHBOARD_PASS)`);
});
