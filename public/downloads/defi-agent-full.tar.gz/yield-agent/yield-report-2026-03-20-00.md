# Yield Intelligence Report — 2026-03-20 00:03 UTC

## Simulation Status
- **Day:** 0.6 of 7 (6.4 days remaining)
- **Total Capital:** $5,000 ($2,500 per strategy)
- **Combined Portfolio:** $5,003.94

---

## Strategy Balances & Earnings

### Strategy A — Max APY
| Metric | Value |
|--------|-------|
| Current Balance | $2,502.45 |
| Total Earned | $2.45 |
| Return (0.6d) | +0.10% |
| Projected APY | 64.3% |
| Daily Run Rate | $4.69/day |

**Top Positions:**
1. Base | Uniswap v4 | ETH-USDC | 72.1% APY | $1.7M TVL
2. Solana | Orca DEX | SOL-USDC | 71.6% APY | $29.3M TVL
3. Arbitrum | Beefy | WBTC-USDC | 68.3% APY | $1.1M TVL
4. Base | PancakeSwap v3 | WETH-USDC | 67.2% APY | $2.1M TVL
5. Base | PancakeSwap v3 | WETH-USDC | 62.9% APY | $4.6M TVL

### Strategy B — Risk-Adjusted
| Metric | Value |
|--------|-------|
| Current Balance | $2,501.49 |
| Total Earned | $1.49 |
| Return (0.6d) | +0.06% |
| Projected APY | 39.1% |
| Daily Run Rate | $2.79/day |

**Top Positions:**
1. Solana | Jupiter Lend | USDS | 5.1% APY | $28.3M TVL (lending)
2. Ethereum | Fluid Lending | USDT | 4.5% APY | $141.6M TVL (lending)
3. Solana | Orca DEX | SOL-USDC | 71.6% APY | $29.3M TVL
4. Ethereum | Uniswap v3 | USDC-WETH | 50.4% APY | $93.2M TVL
5. Base | Uniswap v4 | ETH-USDC | 72.1% APY | $1.7M TVL

**Current Leader:** Strategy A by $0.96

---

## APY Change Analysis (vs prior report)

- **First report of simulation** — no baseline to compare against.
- All position APYs within normal range per yield-sim check.
- Notable: SOL-USDC (Orca) APY trending down: -2.8% 1D, -2.5% 7D, -5.5% 30D — watch for continued decay.
- ETH-USDC (Uniswap v4 Base) APY trending up: +0.7% 1D, +7.8% 7D — positive signal.
- WBTC-USDC (Beefy Arbitrum) flagged as outlier by DeFiLlama (APY significantly above pool mean of 41.4%).

---

## Correlation Check

| Pair | Strategy | Status | Note |
|------|----------|--------|------|
| ETH-USDC | A | ⚪ UNKNOWN | CoinGecko rate limited — THRESHOLDS error in script |
| SOL-USDC | A | ⚪ UNKNOWN | CoinGecko rate limited |
| WBTC-USDC | A | ⚪ UNKNOWN | CoinGecko rate limited |
| WETH-USDC | A | ⚪ UNKNOWN | No price data (rate limit) |
| WETH-USDC | A | ⚪ UNKNOWN | No price data (rate limit) |
| USDS | B | ✅ PASS | Single-asset lending — no IL risk |
| USDT | B | ✅ PASS | Single-asset lending — no IL risk |
| SOL-USDC | B | ⚪ UNKNOWN | CoinGecko rate limited |
| USDC-WETH | B | ⚪ UNKNOWN | No price data (rate limit) |
| ETH-USDC | B | ⚪ UNKNOWN | No price data (rate limit) |

**Root cause:** CoinGecko free tier rate limit hit. Correlation script also has a bug (`THRESHOLDS is not defined`). No true correlation failures detected — but data is incomplete. Bug should be patched in correlation-checker.cjs.

---

## Market Context (CryptoCompare — 24h)

| Asset | Price | 24h Change | IL Alert? |
|-------|-------|------------|-----------|
| ETH | $2,135.84 | -2.63% | No (< 5%) |
| BTC | $69,858.04 | -1.62% | No (< 5%) |
| SOL | $88.90 | -1.35% | No (< 5%) |

**Assessment:** No significant 24h price moves across underlying assets. All moves within normal volatility range. No IL risk alerts triggered.

---

## Alert Status

| Alert Rule | Status |
|------------|--------|
| Correlation below threshold | ⚠️ UNKNOWN (API rate limit — not confirmed pass) |
| Pool APY dropped >50% | ✅ No — all APYs stable |
| Stablecoin peg deviation >0.2% | ✅ No — USDS/USDT lending positions stable |
| Any asset down >10% (24h) | ✅ No — max drawdown was ETH at -2.63% |
| Day 7 reached (final recommendation) | ✅ No — Day 0.6 |

**⚠️ ACTION NEEDED:** Fix `THRESHOLDS is not defined` bug in `correlation-checker.cjs`. CoinGecko rate limiting also needs addressing — consider adding a delay between calls or switching to CryptoCompare for correlation checks.

---

## Recommendation

**HOLD** — both strategies.

- Simulation is only 0.6 days old. Insufficient data to draw conclusions.
- No alert thresholds breached.
- Strategy A leading on absolute returns and projected APY (64.3% vs 39.1%).
- Monitor SOL-USDC APY decay — if it falls below 50% APY, Strategy A's edge narrows.
- Fix correlation checker bug before next run to restore full monitoring.

**No Telegram alert required this cycle.** (No hard alert rules triggered.)

---

## Technical Issues to Fix
1. `correlation-checker.cjs`: `THRESHOLDS is not defined` — script variable not exported/imported correctly
2. CoinGecko rate limit: Add request delays or switch price feed to CryptoCompare
3. First run baseline: Next report will have APY delta comparisons

---

*Report generated: 2026-03-20 00:03 UTC | Agent: Yield Monitor | Cycle: 1 of ~12*
