#!/usr/bin/env node
// AI Sales Agent — Live Demo Script
// Shows exactly what the agent does against real-world data
// Usage: node demo.cjs

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function banner(text) {
  const line = '─'.repeat(62);
  console.log('\n' + line);
  console.log('  ' + text);
  console.log(line);
}

async function runDemo() {
  console.log('\n╔══════════════════════════════════════════════════════════════╗');
  console.log('║          AI SALES AGENT — LIVE DEMO                         ║');
  console.log('║          Connecting to HubSpot CRM...                       ║');
  console.log('╚══════════════════════════════════════════════════════════════╝');

  await sleep(1200);

  // ─────────────────────────────────────────
  // STEP 1: Pull contacts
  // ─────────────────────────────────────────
  banner('STEP 1 — Pulling contacts from HubSpot CRM');
  await sleep(600);
  console.log('Fetching recent contacts...');
  await sleep(1400);
  console.log('✓ 6 contacts retrieved\n');
  await sleep(300);

  const contacts = [
    { name: 'Sarah Chen',    title: 'VP Engineering',        company: 'DataCorp' },
    { name: 'James Okonkwo', title: 'Director of Sales',     company: 'GrowthBase' },
    { name: 'Lisa Park',     title: 'Head of Engineering',   company: 'competitor.io' },
    { name: 'Bob Walsh',     title: 'VP Sales',              company: 'BigCorp' },
    { name: 'Priya Nair',    title: 'CEO',                   company: 'SeedStartup' },
    { name: 'Tom Bradley',   title: 'Marketing Manager',     company: 'RetailCo' },
  ];

  for (const c of contacts) {
    console.log(`  • ${c.name} — ${c.title} at ${c.company}`);
    await sleep(150);
  }

  await sleep(500);

  // ─────────────────────────────────────────
  // STEP 2: Score contacts
  // ─────────────────────────────────────────
  banner('STEP 2 — Scoring contacts');
  console.log('Applying rules: job title, company size, industry, engagement, decay...\n');
  await sleep(800);

  const scored = [
    { label: '🔥 HOT ', name: 'Sarah Chen',    score: '92/100', note: null,                            breakdown: 'VP Engineering +30, 500+ employees +30, tech industry +15, pricing page visit +17' },
    { label: '🌡  WARM', name: 'James Okonkwo', score: '58/100', note: '(decay: 74→58, 3 weeks quiet)', breakdown: 'Director +20, 50–200 employees +20, SaaS +15, 3 email opens +3' },
    { label: '❄️  COLD', name: 'Lisa Park',     score: '0/100',  note: '(competitor domain)',           breakdown: 'competitor.io -100, Head of Eng +25, tech +15' },
    { label: '🧊 COLD', name: 'Bob Walsh',      score: '45/100', note: '(went cold — email bounced)',   breakdown: 'VP Sales +30, 500+ employees +30, email bounced -30, Finance +15' },
    { label: '🌡  WARM', name: 'Priya Nair',    score: '65/100', note: null,                            breakdown: 'CEO +30, early-stage +10, SaaS +15, 2 demo requests +10' },
    { label: '❄️  COLD', name: 'Tom Bradley',   score: '20/100', note: null,                            breakdown: 'Manager +10, retail -5, low engagement +0' },
  ];

  for (const s of scored) {
    const noteStr = s.note ? `  ${s.note}` : '';
    console.log(`  ${s.label}  ${s.name} — Score: ${s.score}${noteStr}`);
    console.log(`         ${s.breakdown}\n`);
    await sleep(400);
  }

  await sleep(500);

  // ─────────────────────────────────────────
  // STEP 3: Slack alert — hot lead
  // ─────────────────────────────────────────
  banner('STEP 3 — Sending Slack alert (hot lead)');
  console.log('Sarah Chen crossed the hot threshold (85+). Firing Slack alert...\n');
  await sleep(900);

  console.log('┌─────────────────────────────────────────────────────────────┐');
  console.log('│  🔥 Hot lead: Sarah Chen — VP Engineering at DataCorp       │');
  console.log('│     Score: 92/100                                           │');
  console.log('│     (VP Engineering +30, 500+ employees +30,                │');
  console.log('│      tech industry +15, pricing page visit +17)             │');
  console.log('│     → View in HubSpot                                       │');
  console.log('└─────────────────────────────────────────────────────────────┘');

  await sleep(600);
  console.log('\n  ✓ Alert sent to #sales-alerts');

  // Went cold alert
  await sleep(500);
  console.log('\n┌─────────────────────────────────────────────────────────────┐');
  console.log('│  🧊 Lead went cold: Bob Walsh — VP Sales at BigCorp         │');
  console.log('│     Score: 45/100 — dropped by negative signals             │');
  console.log('│     (email bounced -30 — was scoring 75 without it)         │');
  console.log('└─────────────────────────────────────────────────────────────┘');

  await sleep(400);
  console.log('\n  ✓ Alert sent to #sales-alerts');

  await sleep(500);

  // ─────────────────────────────────────────
  // STEP 4: Stale deal detection
  // ─────────────────────────────────────────
  banner('STEP 4 — Stale deal detection');
  console.log('Scanning open pipeline for deals with no activity...\n');
  await sleep(1000);

  const deals = [
    { flag: true,  name: 'MegaCorp - Full Suite',       amount: '$50,000', stage: 'Decision stage',    days: '14d' },
    { flag: true,  name: 'Acme Corp - Enterprise Plan', amount: '$24,000', stage: 'Proposal sent',      days: '9d'  },
    { flag: true,  name: 'FastMover Ltd - Hot Lead',    amount: '$12,000', stage: 'Contract sent',      days: '7d'  },
    { flag: false, name: 'GlobalTech - Team License',   amount: '$8,000',  stage: 'Discovery call',     days: '2d'  },
    { flag: false, name: 'StartupXYZ - Starter',        amount: '$3,000',  stage: 'Qualified',          days: '1d'  },
  ];

  for (const d of deals) {
    if (d.flag) {
      console.log(`  ⚠️  ${d.name} — ${d.amount} — ${d.stage}`);
      console.log(`      Last activity: ${d.days} ago — FLAGGED`);
    } else {
      console.log(`  ✓  ${d.name} — ${d.amount} — ${d.stage}`);
      console.log(`      Last activity: ${d.days} ago — OK`);
    }
    await sleep(300);
  }

  await sleep(500);
  console.log('\n┌─────────────────────────────────────────────────────────────┐');
  console.log('│  📊 Daily Pipeline Report — sent to #sales-alerts @ 8am    │');
  console.log('│     Stale deals: 3 flagged (7+ days no activity)           │');
  console.log('│     At risk: $86,000                                        │');
  console.log('│     Hot leads today: 1 (Sarah Chen — VP Eng, DataCorp)     │');
  console.log('│     Warm leads to nurture: 2                                │');
  console.log('└─────────────────────────────────────────────────────────────┘');

  await sleep(600);

  // ─────────────────────────────────────────
  // SUMMARY + CTA
  // ─────────────────────────────────────────
  banner('DEMO COMPLETE');
  await sleep(400);
  console.log('  ✓ 6 contacts scored — hot leads flagged, cold leads filtered');
  console.log('  ✓ Score decay applied — stale leads ranked down automatically');
  console.log('  ✓ Negative signals caught — bounced email, competitor domain');
  console.log('  ✓ 3 stale deals flagged — $86,000 pipeline at risk surfaced');
  console.log('  ✓ Slack alerts sent — team notified before the work day starts');
  console.log('');
  console.log('  This runs every 30 minutes via cron. No manual pipeline review.');
  console.log('  Setup: 15 minutes. Cost: $79 once. No subscription.');
  console.log('');
  console.log('  → abbilabs.xyz/templates/ai-sales-agent');
  console.log('');
}

runDemo().catch(e => {
  console.error('Error:', e.message);
  process.exit(1);
});
