import { createHmac } from 'crypto';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

function sign(payload) {
  const data = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = createHmac('sha256', process.env.DASHBOARD_SECRET).update(data).digest('base64url');
  return `${data}.${sig}`;
}

function verify(token) {
  try {
    const [data, sig] = token.split('.');
    const expected = createHmac('sha256', process.env.DASHBOARD_SECRET).update(data).digest('base64url');
    if (sig !== expected) return null;
    return JSON.parse(Buffer.from(data, 'base64url').toString());
  } catch {
    return null;
  }
}

export async function POST(request) {
  const body = await request.json();
  const { email, password } = body;

  if (!email || !password) {
    return NextResponse.json({ error: 'Email and password required' }, { status: 400 });
  }

  // Check if admin credentials
  const isAdmin = email.toLowerCase() === process.env.ADMIN_EMAIL?.toLowerCase();
  if (isAdmin) {
    if (password !== process.env.ADMIN_PASSWORD) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
    }
  }

  // Hash the submitted password using the same formula as signup
  const ph = createHmac('sha256', process.env.DASHBOARD_SECRET).update(password).digest('hex');

  // Determine tier
  const tier = isAdmin ? 'elite' : 'explorer';

  // Build token with tier-aware payload
  const now = Math.floor(Date.now() / 1000);
  const token = sign({ email, ph, tier, isAdmin, iat: now, exp: now + 86400 * 7 });

  // Verify the token we just created is well-formed (sanity check)
  const payload = verify(token);
  if (!payload) {
    return NextResponse.json({ error: 'Authentication failed' }, { status: 401 });
  }

  const res = NextResponse.json({ success: true, redirect: '/dashboard' });
  res.cookies.set('pb_token', token, {
    httpOnly: false, // must be readable by document.cookie on client
    maxAge: 86400 * 7,
    sameSite: 'strict',
    path: '/',
  });
  return res;
}
