#!/usr/bin/env node
/**
 * Yield Scanner — finds best correlated pair pools across Base, Arbitrum, Solana
 * Uses DeFiLlama API (no API key needed)
 * Filters: correlated pairs, high liquidity (TVL > $500K), high APY, low IL risk
 */

const https = require('https');

// Target chains
const TARGET_CHAINS = ['Base', 'Arbitrum', 'Solana', 'Ethereum'];

// Minimum TVL for "highly liquid" ($500K USD)
const MIN_TVL = 500_000;

// Minimum monthly APY (annualised)
const MIN_APY = 6;

// Maximum APY (filter out suspicious/unsustainable yields)
const MAX_APY = 200;

// Minimum correlation to even consider a pool (Pritesh mandate: close to 1)
// Pools below this are excluded entirely regardless of APY
const MIN_CORR = {
  lst:    0.98,   // ETH LST pairs, SOL LST pairs
  btc:    0.97,   // BTC wrapped variants
  stable: 0.995,  // Stablecoin pairs
  default:0.95,   // any other
};

/**
 * TRUE CORRELATION: both tokens must track the SAME underlying asset.
 * ✅ ETH/stETH, SOL/mSOL, USDC/USDT, wBTC/cbBTC → same underlying
 * ❌ USDC/cbBTC, WETH/cbBTC, ETH/USDC → different assets → HIGH IL risk
 */
const ETH_BASE     = new Set(['eth','weth']);
const ETH_LSTS     = new Set(['steth','wsteth','cbeth','reth','weeth','ezeth','frxeth','sweth','oseth']);
const SOL_BASE     = new Set(['sol','wsol']);
const SOL_LSTS     = new Set(['msol','jitosol','bsol','bbsol']);
const BTC_VARIANTS = new Set(['wbtc','cbbtc','tbtc','sbtc','lbtc','btcb','btc']);
const USD_STABLES  = new Set(['usdc','usdt','dai','usde','crvusd','frax','usds','lusd','susd','usdz','susdz','gho','pyusd','busd','tusd']);

// Tier 2: conviction pairs — Pritesh holds both assets, accepts IL
const CONVICTION_PAIRS = [
  ['eth','btc'],['weth','wbtc'],['eth','sol'],['sol','usdc'],
  ['sol','usdt'],['eth','usdc'],['eth','usdt'],['weth','usdc'],
  ['btc','usdc'],['wbtc','usdc'],['wbtc','usdt'],['sol','btc'],
];

function tokenize(sym) {
  return (sym||'').toLowerCase().split(/[^a-z0-9]+/).filter(t => t.length > 0);
}

function pairTier(symbol) {
  const tokens = tokenize(symbol);
  if (tokens.length < 2) return null;
  const isEthFamily = t => ETH_BASE.has(t) || ETH_LSTS.has(t);
  const isSolFamily = t => SOL_BASE.has(t) || SOL_LSTS.has(t);
  const isBtcFamily = t => BTC_VARIANTS.has(t);
  const isStable    = t => USD_STABLES.has(t);
  if (tokens.every(isEthFamily) && tokens.some(t => ETH_LSTS.has(t))) return 1;
  if (tokens.every(isSolFamily) && tokens.some(t => SOL_LSTS.has(t))) return 1;
  if (tokens.every(isBtcFamily) && tokens.length >= 2) return 1;
  if (tokens.every(isStable)    && tokens.length >= 2) return 1;
  const sorted = [...tokens].sort();
  if (CONVICTION_PAIRS.some(p => { const sp=[...p].sort(); return sp[0]===sorted[0]&&sp[1]===sorted[1]; })) return 2;
  return null;
}

function isCorrelated(symbol) { return pairTier(symbol) !== null; }

function fetch(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'AbbiLabs-YieldScanner/1.0' } }, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch(e) { reject(new Error('JSON parse error: ' + data.substring(0, 200))); }
      });
    }).on('error', reject);
  });
}

function formatUSD(n) {
  if (n >= 1_000_000_000) return `$${(n/1_000_000_000).toFixed(1)}B`;
  if (n >= 1_000_000) return `$${(n/1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `$${(n/1_000).toFixed(0)}K`;
  return `$${n.toFixed(0)}`;
}

async function scan() {
  console.log('🔍 Fetching all yield pools from DeFiLlama...\n');
  
  const data = await fetch('https://yields.llama.fi/pools');
  const allPools = data.data || [];
  
  console.log(`📊 Total pools indexed: ${allPools.length.toLocaleString()}`);
  
  // Filter step by step
  const chainFiltered = allPools.filter(p => TARGET_CHAINS.includes(p.chain));
  console.log(`🔗 On target chains (${TARGET_CHAINS.join(', ')}): ${chainFiltered.length}`);
  
  const liquidFiltered = chainFiltered.filter(p => (p.tvlUsd || 0) >= MIN_TVL);
  console.log(`💧 TVL > ${formatUSD(MIN_TVL)}: ${liquidFiltered.length}`);
  
  const apyFiltered = liquidFiltered.filter(p => {
    const apy = p.apy || 0;
    return apy >= MIN_APY && apy <= MAX_APY;
  });
  console.log(`📈 APY ${MIN_APY}%–${MAX_APY}%: ${apyFiltered.length}`);
  
  const correlatedPools = apyFiltered.filter(p => isCorrelated(p.symbol || ''));
  console.log(`🔗 Correlated pairs: ${correlatedPools.length}`);
  
  // Sort by APY descending, then TVL
  const sorted = correlatedPools.sort((a, b) => {
    // Weight: 70% APY, 30% TVL score (log scale)
    const apyScore = (b.apy || 0) - (a.apy || 0);
    return apyScore;
  });
  
  // Top 20
  const top = sorted.slice(0, 20);
  
  console.log('\n' + '═'.repeat(90));
  console.log('🏆  TOP CORRELATED PAIR OPPORTUNITIES');
  console.log('═'.repeat(90));
  console.log(
    'Rank'.padEnd(5) +
    'Chain'.padEnd(12) +
    'Protocol'.padEnd(18) +
    'Pool'.padEnd(25) +
    'APY'.padEnd(10) +
    'TVL'.padEnd(12) +
    'IL Risk'
  );
  console.log('─'.repeat(90));
  
  top.forEach((p, i) => {
    const apy = (p.apy || 0).toFixed(1) + '%';
    const tvl = formatUSD(p.tvlUsd || 0);
    const il = p.ilRisk || 'unknown';
    const ilLabel = il === 'no' ? '✅ None' : il === 'low' ? '🟡 Low' : il === 'medium' ? '🟠 Med' : '⚪ ' + il;
    
    console.log(
      `${(i+1)+'.'}`.padEnd(5) +
      (p.chain || '').padEnd(12) +
      (p.project || '').substring(0,17).padEnd(18) +
      (p.symbol || '').substring(0,24).padEnd(25) +
      apy.padEnd(10) +
      tvl.padEnd(12) +
      ilLabel
    );
  });
  
  console.log('\n' + '═'.repeat(90));
  
  // Summary by chain
  console.log('\n📊 BREAKDOWN BY CHAIN:');
  const byChain = {};
  correlatedPools.forEach(p => {
    byChain[p.chain] = byChain[p.chain] || [];
    byChain[p.chain].push(p);
  });
  Object.entries(byChain).sort((a,b) => b[1].length - a[1].length).forEach(([chain, pools]) => {
    const avgApy = (pools.reduce((s,p) => s + (p.apy||0), 0) / pools.length).toFixed(1);
    const bestApy = Math.max(...pools.map(p => p.apy||0)).toFixed(1);
    console.log(`  ${chain}: ${pools.length} pools | avg APY: ${avgApy}% | best: ${bestApy}%`);
  });
  
  // Top pick per chain
  console.log('\n⭐ RECOMMENDED ENTRY POINTS (best liquidity + APY per chain):');
  TARGET_CHAINS.forEach(chain => {
    const chainPools = correlatedPools
      .filter(p => p.chain === chain)
      .sort((a,b) => (b.apy||0) - (a.apy||0))
      .slice(0, 3);
    if (chainPools.length === 0) return;
    console.log(`\n  ${chain}:`);
    chainPools.forEach(p => {
      console.log(`    • ${p.project} — ${p.symbol} | ${(p.apy||0).toFixed(1)}% APY | TVL: ${formatUSD(p.tvlUsd||0)}`);
    });
  });
  
  console.log('\n✅ Scan complete. Use these pools for the yield agent configuration.\n');
  
  // Return top pools for agent config
  return top.map(p => ({
    chain: p.chain,
    protocol: p.project,
    pool: p.symbol,
    apy: p.apy,
    tvl: p.tvlUsd,
    ilRisk: p.ilRisk,
    poolId: p.pool,
  }));
}

scan().catch(console.error);
