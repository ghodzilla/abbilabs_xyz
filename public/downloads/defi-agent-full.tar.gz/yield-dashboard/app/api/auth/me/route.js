import { createHmac } from 'crypto';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

function verify(token) {
  try {
    const [data, sig] = token.split('.');
    const expected = createHmac('sha256', process.env.DASHBOARD_SECRET).update(data).digest('base64url');
    if (sig !== expected) return null;
    const payload = JSON.parse(Buffer.from(data, 'base64url').toString());
    // Check expiry if present
    if (payload.exp && Math.floor(Date.now() / 1000) > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

export async function GET(request) {
  // Read pb_token from cookies
  const cookieHeader = request.headers.get('cookie') || '';
  const match = cookieHeader.match(/(?:^|;\s*)pb_token=([^;]+)/);
  const token = match ? match[1] : null;

  if (!token) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const payload = verify(token);
  if (!payload) {
    return NextResponse.json({ error: 'Invalid or expired token' }, { status: 401 });
  }

  // Determine tier — legacy tokens without tier field default to explorer
  const tier = payload.tier || 'explorer';
  const isAdmin = payload.isAdmin || false;

  return NextResponse.json({ email: payload.email, tier, isAdmin });
}
