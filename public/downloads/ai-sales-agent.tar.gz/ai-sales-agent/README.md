# AI Sales Agent

> A production-ready AI agent that manages your HubSpot sales pipeline autonomously. Scores leads, flags stale deals, sends daily pipeline reports to Slack. Works with any LLM — Claude, GPT, Gemini — or as a standalone cron job with no LLM at all.

## What It Does

- **Scores every new lead** in HubSpot — job title, company size, industry, engagement, time decay
- **Fires instant Slack alerts** when a lead hits your hot threshold — with exactly why they scored high
- **Flags stale deals** — any deal with no activity past your threshold (7/14/30 days, your choice)
- **Sends a daily pipeline report** to Slack every morning — hot leads, stale deals, pipeline value, deals closing this week
- **Creates HubSpot tasks** automatically for stale deals (enable in config.json)
- **Logs everything** to Google Sheets — every score, every alert, full audit trail

## What's Included

```
ai-sales-agent/
├── README.md                  ← You're reading this
├── AGENT.md                   ← Agent personality, role, and decision rules
├── WORKFLOWS.md               ← Step-by-step workflows the agent follows
├── SETUP.md                   ← Complete setup guide (15 minutes)
├── config.json                ← All settings — scoring rules, thresholds, channels
├── scripts/
│   ├── hubspot.cjs            ← HubSpot CRM integration
│   ├── sheets.cjs             ← Google Sheets integration
│   ├── slack.cjs              ← Slack alerts and reports
│   ├── lead-scorer.cjs        ← Lead scoring engine (v2: decay + negative signals)
│   ├── deal-scorer.cjs        ← Deal urgency scoring
│   ├── pipeline-report.cjs    ← Daily pipeline report generator
│   └── follow-up-checker.cjs  ← Stale deal detection + HubSpot task creation
├── templates/
│   └── slack-alert.md         ← Slack message templates
└── examples/
    ├── scoring-rules.json     ← Example lead scoring configs (B2B SaaS, agency, consulting)
    └── sample-workflow.md     ← Example end-to-end workflow
```

## Quick Start

```bash
# 1. Set your API keys
export HUBSPOT_ACCESS_TOKEN="pat-xx-..."
export SLACK_BOT_TOKEN="xoxb-..."
export GOOGLE_SERVICE_ACCOUNT_KEY_FILE="/path/to/key.json"

# 2. Update config.json with your spreadsheet ID and Slack channels

# 3. Run
node scripts/lead-scorer.cjs score-all
node scripts/follow-up-checker.cjs check
node scripts/pipeline-report.cjs generate
```

Full setup guide: [SETUP.md](./SETUP.md)

## Framework Compatibility

| Framework | How to Use |
|-----------|-----------|
| **OpenClaw** | Drop the folder into your skills directory. Done. |
| **Claude API** | Load AGENT.md as system prompt, call scripts as tools |
| **GPT API** | Load AGENT.md as system message, use function calling |
| **LangChain** | Scripts become tools, WORKFLOWS.md defines the chain |
| **CrewAI** | AGENT.md → agent config, WORKFLOWS.md → task definitions |
| **Standalone** | Scripts are pure Node.js cron jobs — no LLM required |

## Requirements

- Node.js 18+
- HubSpot account (free tier works — no Marketing Hub Pro needed)
- Slack workspace (free)
- Google account + service account (free, optional — for Sheets logging)

## Zero Dependencies

No `npm install`. No `node_modules`. Every script is pure Node.js using only built-in modules. Copy and run.

## Guarantee

Try it for 30 days. If it doesn't save you at least 2 hours a week on pipeline management, email support@abbilabs.xyz for an immediate refund — no forms, no questions.

Built by [Abbi Labs](https://abbilabs.xyz)
