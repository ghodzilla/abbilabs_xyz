import { createHmac } from 'crypto';
import { NextResponse } from 'next/server';

// Backward-compatible login endpoint — delegates to new auth system logic
export const runtime = 'nodejs';

function sign(payload) {
  const data = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = createHmac('sha256', process.env.DASHBOARD_SECRET).update(data).digest('base64url');
  return `${data}.${sig}`;
}

export async function POST(request) {
  const body = await request.json();

  // Legacy password-only support
  if (body.password && !body.email) {
    const SECRET = process.env.DASHBOARD_SECRET || '6b86523c96074acda4a9b1afe02837bc';
    if (body.password === SECRET) {
      const res = NextResponse.json({ ok: true, redirect: '/dashboard' });
      res.cookies.set('dash_auth', SECRET, {
        httpOnly: true,
        maxAge: 86400 * 30,
        sameSite: 'strict',
        path: '/',
      });
      return res;
    }
    return NextResponse.json({ ok: false, error: 'Invalid password' }, { status: 401 });
  }

  // New email + password login
  const { email, password } = body;
  if (!email || !password) {
    return NextResponse.json({ ok: false, error: 'Email and password required' }, { status: 400 });
  }

  const ph = createHmac('sha256', process.env.DASHBOARD_SECRET).update(password).digest('hex');
  const token = sign({ email, ph });

  const res = NextResponse.json({ ok: true, success: true, redirect: '/dashboard' });
  res.cookies.set('pb_token', token, {
    httpOnly: false,
    maxAge: 86400 * 7,
    sameSite: 'strict',
    path: '/',
  });
  return res;
}
