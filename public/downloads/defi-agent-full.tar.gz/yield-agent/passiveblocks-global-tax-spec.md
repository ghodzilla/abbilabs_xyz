# PassiveBlocks — Global Tax Module Specification

> **Purpose:** This document specifies how to make the Yield Agent's tax tracking work for any country, not just Australia. Users select their tax jurisdiction and the agent automatically applies the correct rules for CGT, income tax, holding period discounts, and reporting.
>
> **Prerequisite:** The v2.1 Australian tax logic (Change 13) should already be implemented. This spec generalises that module into a pluggable country system.

---

## 1. ARCHITECTURE: HOW IT WORKS

### The Core Idea

Instead of hardcoding Australian tax rules, the agent loads a **tax profile** based on the user's selected country. Each profile defines:
- Income tax brackets and rates
- Capital gains tax rules (short-term vs long-term rates, holding period thresholds)
- Whether LP entry/exit is a CGT event
- Whether yield is ordinary income or capital gains
- Whether gas fees are deductible
- Local currency code and exchange rate source
- Tax year dates (not all countries use July–June)
- Available cost basis methods (FIFO, LIFO, HIFO, specific ID)
- Reporting format for export

The agent's core logic stays the same — the tax profile just changes how earnings and rotations are classified and calculated.

### User Configuration

In the .env (self-hosted) or user settings (SaaS dashboard):
```bash
# Select your tax jurisdiction
TAX_COUNTRY=AU

# Override marginal rate if you know your bracket
TAX_MARGINAL_RATE=0.32

# Cost basis method (fifo, lifo, hifo, specific_id)
TAX_COST_BASIS_METHOD=fifo
```

On the SaaS dashboard, this is a dropdown with country flags. When selected, the system auto-fills the default tax profile and lets the user override their marginal rate.

---

## 2. TAX PROFILE DATA STRUCTURE

Each country profile is a JSON object. Store these in a `/config/tax-profiles/` directory, one file per country.

### 2.1: Profile Schema

```json
{
  "countryCode": "AU",
  "countryName": "Australia",
  "localCurrency": "AUD",
  "taxYearStart": "07-01",
  "taxYearEnd": "06-30",
  "filingDeadline": "10-31",

  "exchangeRateSource": "USD_TO_AUD",
  "defaultExchangeRate": 1.55,

  "incomeTax": {
    "type": "progressive",
    "brackets": [
      { "min": 0,      "max": 18200,  "rate": 0.00 },
      { "min": 18201,  "max": 45000,  "rate": 0.16 },
      { "min": 45001,  "max": 135000, "rate": 0.30 },
      { "min": 135001, "max": 190000, "rate": 0.37 },
      { "min": 190001, "max": null,   "rate": 0.45 }
    ],
    "additionalLevies": [
      { "name": "Medicare Levy", "rate": 0.02, "applies": "all_income" }
    ],
    "defaultMarginalRate": 0.32,
    "yieldTaxedAs": "ordinary_income"
  },

  "capitalGains": {
    "shortTermRate": "marginal_rate",
    "longTermRate": "marginal_rate",
    "longTermDiscount": 0.50,
    "longTermThresholdMonths": 12,
    "lpEntryIsCGTEvent": true,
    "lpExitIsCGTEvent": true,
    "wrappingIsCGTEvent": true,
    "lendingEntryIsCGTEvent": false,
    "lendingExitIsCGTEvent": false,
    "allowedCostBasisMethods": ["fifo", "lifo", "hifo", "specific_id"],
    "defaultCostBasisMethod": "fifo",
    "washSaleRule": false,
    "taxFreeAllowance": 0
  },

  "deductions": {
    "gasFees": true,
    "softwareCosts": true,
    "interestOnBorrowing": false
  },

  "reporting": {
    "exportFormats": ["csv", "myTax"],
    "requiredFields": [
      "date", "event_type", "asset", "quantity", "cost_basis_local",
      "proceeds_local", "gain_loss_local", "income_local", "gas_deductible_local"
    ],
    "notes": "ATO requires records of every disposal. Data matching program active through 2026."
  }
}
```

### 2.2: Country Profiles to Implement

Launch with these 10 countries (covers ~85% of global crypto users by volume):

| Priority | Country | Code | Key Differentiator |
|----------|---------|------|-------------------|
| 1 | Australia | AU | 50% CGT discount >12mo, yield = income, LP entry = CGT event |
| 2 | United States | US | Short-term = ordinary income rates (10–37%), long-term = 0/15/20%, per-wallet basis tracking |
| 3 | United Kingdom | GB | £3,000 CGT allowance, 10%/20% CGT rates, yield = income |
| 4 | Canada | CA | 50% inclusion rate on capital gains, yield = income or business income |
| 5 | Germany | DE | Tax-free after 1 year hold, yield taxed as income, €1,000 exemption |
| 6 | Japan | JP | Miscellaneous income up to 55%, no CGT discount |
| 7 | Singapore | SG | No CGT for individuals, income tax on trading if business activity |
| 8 | UAE | AE | No personal income tax, no CGT — simplest profile |
| 9 | India | IN | Flat 30% on all crypto gains, 1% TDS, no loss offset |
| 10 | New Zealand | NZ | No CGT (generally), income tax if acquired for resale |

---

## 3. COUNTRY PROFILES — DETAILED

### 3.1: United States (US)

```json
{
  "countryCode": "US",
  "countryName": "United States",
  "localCurrency": "USD",
  "taxYearStart": "01-01",
  "taxYearEnd": "12-31",
  "filingDeadline": "04-15",

  "exchangeRateSource": "native",
  "defaultExchangeRate": 1.00,

  "incomeTax": {
    "type": "progressive",
    "brackets": [
      { "min": 0,      "max": 11925,  "rate": 0.10 },
      { "min": 11926,  "max": 48475,  "rate": 0.12 },
      { "min": 48476,  "max": 103350, "rate": 0.22 },
      { "min": 103351, "max": 197300, "rate": 0.24 },
      { "min": 197301, "max": 250525, "rate": 0.32 },
      { "min": 250526, "max": 626350, "rate": 0.35 },
      { "min": 626351, "max": null,   "rate": 0.37 }
    ],
    "additionalLevies": [
      { "name": "NIIT", "rate": 0.038, "applies": "investment_income_above_200000" }
    ],
    "defaultMarginalRate": 0.24,
    "yieldTaxedAs": "ordinary_income"
  },

  "capitalGains": {
    "shortTermRate": "marginal_rate",
    "longTermRate": "tiered",
    "longTermTiers": [
      { "min": 0,      "max": 48350,  "rate": 0.00 },
      { "min": 48351,  "max": 533400, "rate": 0.15 },
      { "min": 533401, "max": null,   "rate": 0.20 }
    ],
    "longTermDiscount": 0,
    "longTermThresholdMonths": 12,
    "lpEntryIsCGTEvent": true,
    "lpExitIsCGTEvent": true,
    "wrappingIsCGTEvent": true,
    "lendingEntryIsCGTEvent": true,
    "lendingExitIsCGTEvent": true,
    "allowedCostBasisMethods": ["fifo", "lifo", "hifo", "specific_id"],
    "defaultCostBasisMethod": "fifo",
    "washSaleRule": false,
    "taxFreeAllowance": 0,
    "perWalletBasisTracking": true
  },

  "deductions": {
    "gasFees": true,
    "softwareCosts": true,
    "interestOnBorrowing": true
  },

  "reporting": {
    "exportFormats": ["csv", "form_8949", "schedule_d", "turbotax"],
    "requiredFields": [
      "date_acquired", "date_sold", "asset", "quantity",
      "cost_basis_usd", "proceeds_usd", "gain_loss_usd",
      "holding_period", "income_usd"
    ],
    "notes": "Form 1099-DA from exchanges covers centralized activity only. DeFi must be self-reported. Per-wallet basis tracking required from 2025."
  }
}
```

### 3.2: United Kingdom (GB)

```json
{
  "countryCode": "GB",
  "countryName": "United Kingdom",
  "localCurrency": "GBP",
  "taxYearStart": "04-06",
  "taxYearEnd": "04-05",
  "filingDeadline": "01-31",

  "exchangeRateSource": "USD_TO_GBP",
  "defaultExchangeRate": 0.79,

  "incomeTax": {
    "type": "progressive",
    "brackets": [
      { "min": 0,      "max": 12570, "rate": 0.00 },
      { "min": 12571,  "max": 50270, "rate": 0.20 },
      { "min": 50271,  "max": 125140, "rate": 0.40 },
      { "min": 125141, "max": null,   "rate": 0.45 }
    ],
    "additionalLevies": [
      { "name": "National Insurance", "rate": 0.08, "applies": "employment_income_only" }
    ],
    "defaultMarginalRate": 0.20,
    "yieldTaxedAs": "ordinary_income"
  },

  "capitalGains": {
    "shortTermRate": "tiered",
    "shortTermTiers": [
      { "bracket": "basic_rate", "rate": 0.10 },
      { "bracket": "higher_rate", "rate": 0.20 }
    ],
    "longTermRate": "same_as_short_term",
    "longTermDiscount": 0,
    "longTermThresholdMonths": null,
    "lpEntryIsCGTEvent": true,
    "lpExitIsCGTEvent": true,
    "wrappingIsCGTEvent": false,
    "lendingEntryIsCGTEvent": true,
    "lendingExitIsCGTEvent": true,
    "allowedCostBasisMethods": ["share_pooling"],
    "defaultCostBasisMethod": "share_pooling",
    "washSaleRule": true,
    "washSaleDays": 30,
    "taxFreeAllowance": 3000
  },

  "deductions": {
    "gasFees": true,
    "softwareCosts": false,
    "interestOnBorrowing": false
  },

  "reporting": {
    "exportFormats": ["csv", "hmrc_self_assessment"],
    "requiredFields": [
      "date", "event_type", "asset", "quantity",
      "cost_basis_gbp", "proceeds_gbp", "gain_loss_gbp", "income_gbp"
    ],
    "notes": "HMRC uses share pooling for cost basis (not FIFO). Bed and breakfasting rule applies (30-day wash sale). CGT allowance is £3,000 for 2025/26."
  }
}
```

### 3.3: Germany (DE)

```json
{
  "countryCode": "DE",
  "countryName": "Germany",
  "localCurrency": "EUR",
  "taxYearStart": "01-01",
  "taxYearEnd": "12-31",
  "filingDeadline": "07-31",

  "exchangeRateSource": "USD_TO_EUR",
  "defaultExchangeRate": 0.92,

  "incomeTax": {
    "type": "progressive",
    "brackets": [
      { "min": 0,      "max": 11784, "rate": 0.00 },
      { "min": 11785,  "max": 66760, "rate": 0.14, "note": "progressive formula, not flat" },
      { "min": 66761,  "max": 277826, "rate": 0.42 },
      { "min": 277827, "max": null,   "rate": 0.45 }
    ],
    "additionalLevies": [
      { "name": "Solidarity Surcharge", "rate": 0.055, "applies": "on_tax_above_threshold" }
    ],
    "defaultMarginalRate": 0.42,
    "yieldTaxedAs": "ordinary_income"
  },

  "capitalGains": {
    "shortTermRate": "marginal_rate",
    "longTermRate": 0.00,
    "longTermDiscount": 1.00,
    "longTermThresholdMonths": 12,
    "lpEntryIsCGTEvent": true,
    "lpExitIsCGTEvent": true,
    "wrappingIsCGTEvent": true,
    "lendingEntryIsCGTEvent": false,
    "lendingExitIsCGTEvent": false,
    "allowedCostBasisMethods": ["fifo"],
    "defaultCostBasisMethod": "fifo",
    "washSaleRule": false,
    "taxFreeAllowance": 1000,
    "taxFreeNote": "Private sales (including crypto) under EUR 1,000/year are exempt if held >1 year"
  },

  "deductions": {
    "gasFees": true,
    "softwareCosts": true,
    "interestOnBorrowing": false
  },

  "reporting": {
    "exportFormats": ["csv", "elster"],
    "requiredFields": [
      "date", "event_type", "asset", "quantity",
      "cost_basis_eur", "proceeds_eur", "gain_loss_eur",
      "holding_period_days", "income_eur"
    ],
    "notes": "Germany is uniquely favourable: crypto held >12 months is completely tax-free. This changes the agent's optimal strategy significantly — longer holds are always better for German users."
  }
}
```

### 3.4: Singapore (SG)

```json
{
  "countryCode": "SG",
  "countryName": "Singapore",
  "localCurrency": "SGD",
  "taxYearStart": "01-01",
  "taxYearEnd": "12-31",
  "filingDeadline": "04-18",

  "exchangeRateSource": "USD_TO_SGD",
  "defaultExchangeRate": 1.34,

  "incomeTax": {
    "type": "progressive",
    "brackets": [
      { "min": 0,      "max": 20000,  "rate": 0.00 },
      { "min": 20001,  "max": 30000,  "rate": 0.02 },
      { "min": 30001,  "max": 40000,  "rate": 0.035 },
      { "min": 40001,  "max": 80000,  "rate": 0.07 },
      { "min": 80001,  "max": 120000, "rate": 0.115 },
      { "min": 120001, "max": 160000, "rate": 0.15 },
      { "min": 160001, "max": 200000, "rate": 0.18 },
      { "min": 200001, "max": 240000, "rate": 0.19 },
      { "min": 240001, "max": 280000, "rate": 0.195 },
      { "min": 280001, "max": 320000, "rate": 0.20 },
      { "min": 320001, "max": 500000, "rate": 0.22 },
      { "min": 500001, "max": 1000000, "rate": 0.23 },
      { "min": 1000001, "max": null,  "rate": 0.24 }
    ],
    "additionalLevies": [],
    "defaultMarginalRate": 0.07,
    "yieldTaxedAs": "not_taxed_unless_business"
  },

  "capitalGains": {
    "shortTermRate": 0.00,
    "longTermRate": 0.00,
    "longTermDiscount": 0,
    "longTermThresholdMonths": null,
    "lpEntryIsCGTEvent": false,
    "lpExitIsCGTEvent": false,
    "wrappingIsCGTEvent": false,
    "lendingEntryIsCGTEvent": false,
    "lendingExitIsCGTEvent": false,
    "allowedCostBasisMethods": ["fifo"],
    "defaultCostBasisMethod": "fifo",
    "washSaleRule": false,
    "taxFreeAllowance": null,
    "note": "Singapore has no CGT for individuals. Gains only taxable if IRAS considers it trading/business activity."
  },

  "deductions": {
    "gasFees": false,
    "softwareCosts": false,
    "interestOnBorrowing": false
  },

  "reporting": {
    "exportFormats": ["csv"],
    "requiredFields": ["date", "event_type", "asset", "quantity", "value_sgd"],
    "notes": "No CGT for individuals. Only taxable if deemed business income by IRAS. Keep records in case of audit."
  }
}
```

### 3.5: UAE (AE)

```json
{
  "countryCode": "AE",
  "countryName": "United Arab Emirates",
  "localCurrency": "AED",
  "taxYearStart": "01-01",
  "taxYearEnd": "12-31",
  "filingDeadline": null,

  "exchangeRateSource": "USD_TO_AED",
  "defaultExchangeRate": 3.67,

  "incomeTax": {
    "type": "flat",
    "rate": 0.00,
    "defaultMarginalRate": 0.00,
    "yieldTaxedAs": "not_taxed"
  },

  "capitalGains": {
    "shortTermRate": 0.00,
    "longTermRate": 0.00,
    "lpEntryIsCGTEvent": false,
    "lpExitIsCGTEvent": false,
    "wrappingIsCGTEvent": false,
    "lendingEntryIsCGTEvent": false,
    "lendingExitIsCGTEvent": false,
    "taxFreeAllowance": null,
    "note": "No personal income tax or CGT in UAE. Corporate tax (9%) applies only to businesses above AED 375,000 profit."
  },

  "deductions": {
    "gasFees": false,
    "softwareCosts": false
  },

  "reporting": {
    "exportFormats": ["csv"],
    "notes": "No personal tax filing required. Keep records for potential corporate tax if operating as a business."
  }
}
```

### 3.6: Remaining Profiles (Canada, India, Japan, New Zealand)

Follow the same schema. Key differentiators:

**Canada (CA):** 50% capital gains inclusion rate (only half the gain is taxable), yield = income, tax year Jan–Dec, filing deadline April 30.

**India (IN):** Flat 30% tax on all crypto gains (no distinction short/long-term), 1% TDS (tax deducted at source) on transfers above INR 50,000, no loss offset allowed against other income, no deductions except cost of acquisition.

**Japan (JP):** Crypto classified as "miscellaneous income" taxed at progressive rates up to 55%, no CGT discount, extremely high tax burden for active DeFi users.

**New Zealand (NZ):** Generally no CGT, but crypto acquired with intent to sell is taxable as income. Yield farming rewards are likely income. Tax year April–March.

---

## 4. TAX ENGINE IMPLEMENTATION

### 4.1: Tax Engine Module

```javascript
// tax-engine.js

const taxProfiles = {};

function loadTaxProfile(countryCode) {
  if (!taxProfiles[countryCode]) {
    const profile = require(`./config/tax-profiles/${countryCode}.json`);
    taxProfiles[countryCode] = profile;
  }
  return taxProfiles[countryCode];
}

function calculateIncomeTax(grossIncome, profile, userMarginalRate = null) {
  const rate = userMarginalRate || profile.incomeTax.defaultMarginalRate;

  if (profile.incomeTax.yieldTaxedAs === "not_taxed" ||
      profile.incomeTax.yieldTaxedAs === "not_taxed_unless_business") {
    return 0;
  }

  let tax = grossIncome * rate;

  // Add levies
  for (const levy of (profile.incomeTax.additionalLevies || [])) {
    if (levy.applies === "all_income") {
      tax += grossIncome * levy.rate;
    }
  }

  return tax;
}

function calculateCGT(gain, holdingDays, profile, userMarginalRate = null) {
  if (gain <= 0) return 0;

  const rate = userMarginalRate || profile.incomeTax.defaultMarginalRate;
  const isLongTerm = profile.capitalGains.longTermThresholdMonths &&
    holdingDays >= profile.capitalGains.longTermThresholdMonths * 30;

  // Apply tax-free allowance
  let taxableGain = gain;
  if (profile.capitalGains.taxFreeAllowance) {
    taxableGain = Math.max(0, gain - profile.capitalGains.taxFreeAllowance);
  }

  if (isLongTerm) {
    // Long-term treatment
    if (profile.capitalGains.longTermRate === 0) {
      return 0;  // Germany: completely tax-free after holding period
    }
    if (profile.capitalGains.longTermDiscount > 0) {
      taxableGain *= (1 - profile.capitalGains.longTermDiscount);  // Australia: 50% discount
    }
    if (profile.capitalGains.longTermRate === "tiered") {
      return calculateTieredCGT(taxableGain, profile.capitalGains.longTermTiers);
    }
    if (profile.capitalGains.longTermRate === "marginal_rate") {
      return taxableGain * rate;
    }
    return taxableGain * profile.capitalGains.longTermRate;
  } else {
    // Short-term treatment
    if (profile.capitalGains.shortTermRate === "marginal_rate") {
      return taxableGain * rate;
    }
    if (profile.capitalGains.shortTermRate === 0) {
      return 0;  // Singapore, UAE: no CGT
    }
    return taxableGain * profile.capitalGains.shortTermRate;
  }
}

function isRotationCGTEvent(position, profile) {
  if (position.isLending) {
    return profile.capitalGains.lendingExitIsCGTEvent;
  }
  return profile.capitalGains.lpExitIsCGTEvent;
}

function shouldRotate(currentPosition, newPool, profile, gasCost) {
  // Tax-aware rotation: only rotate if after-tax benefit exceeds cost
  if (!isRotationCGTEvent(currentPosition, profile)) {
    // No CGT on exit — just check gas
    const benefit = (newPool.apy - currentPosition.currentApy) / 100 * 500 / 365 * 7;
    return benefit > gasCost;
  }

  const unrealisedGain = currentPosition.currentValueLocal - currentPosition.costBasisLocal;
  const estimatedTax = calculateCGT(
    unrealisedGain,
    currentPosition.holdingDays,
    profile,
    currentPosition.userMarginalRate
  );

  const benefit = (newPool.apy - currentPosition.currentApy) / 100 * 500 / 365 * 7;
  return benefit > estimatedTax + gasCost;
}

// Special handling for Germany: longer holds are better
function getOptimalHoldDuration(profile) {
  if (profile.capitalGains.longTermRate === 0 &&
      profile.capitalGains.longTermThresholdMonths) {
    // Country has tax-free treatment after holding period
    // Signal to the agent that holding longer is tax-optimal
    return {
      minHoldForTaxBenefit: profile.capitalGains.longTermThresholdMonths * 30,
      taxBenefit: "complete_exemption"
    };
  }
  if (profile.capitalGains.longTermDiscount > 0) {
    return {
      minHoldForTaxBenefit: profile.capitalGains.longTermThresholdMonths * 30,
      taxBenefit: `${profile.capitalGains.longTermDiscount * 100}%_discount`
    };
  }
  return { minHoldForTaxBenefit: 0, taxBenefit: "none" };
}

module.exports = {
  loadTaxProfile,
  calculateIncomeTax,
  calculateCGT,
  isRotationCGTEvent,
  shouldRotate,
  getOptimalHoldDuration
};
```

### 4.2: How the Tax Engine Plugs Into the Agent

Replace all hardcoded Australian tax references in the v2.1 code with calls to the tax engine:

```javascript
// In the main agent cycle:
const taxProfile = loadTaxProfile(config.TAX_COUNTRY);

// On position entry:
position.costBasisLocal = positionValueUSD * getExchangeRate(taxProfile);

// On yield accrual each cycle:
const yieldLocal = yieldUSD * getExchangeRate(taxProfile);
position.yieldIncomeLocal += yieldLocal;
const incomeTax = calculateIncomeTax(yieldLocal, taxProfile, config.TAX_MARGINAL_RATE);

// On position exit:
position.proceedsLocal = positionValueUSD * getExchangeRate(taxProfile);
const gain = position.proceedsLocal - position.costBasisLocal;
const cgt = calculateCGT(gain, position.holdingDays, taxProfile, config.TAX_MARGINAL_RATE);

// On rotation decision:
const shouldDoRotation = shouldRotate(currentPosition, newPool, taxProfile, gasCost);

// For German users: the agent should prefer longer holds
const holdAdvice = getOptimalHoldDuration(taxProfile);
if (holdAdvice.taxBenefit !== "none") {
  // Adjust the 7-day review window to account for tax-optimal holding
  // For Germany: if position is profitable and approaching 12 months,
  // strongly prefer holding to capture tax-free treatment
}
```

### 4.3: Exchange Rate Handling

```javascript
// exchange-rates.js

const RATE_CACHE_HOURS = 6;
let rateCache = {};

async function getExchangeRate(taxProfile) {
  if (taxProfile.exchangeRateSource === "native") {
    return 1.0;  // USD profile, no conversion needed
  }

  const cacheKey = taxProfile.exchangeRateSource;
  const cached = rateCache[cacheKey];

  if (cached && (Date.now() - cached.timestamp) < RATE_CACHE_HOURS * 3600000) {
    return cached.rate;
  }

  try {
    // Use a free exchange rate API
    const pair = taxProfile.exchangeRateSource;  // e.g. "USD_TO_AUD"
    const [from, to] = pair.replace("_TO_", ",").split(",");
    const response = await fetch(
      `https://api.exchangerate-api.com/v4/latest/${from}`
    );
    const data = await response.json();
    const rate = data.rates[to];

    rateCache[cacheKey] = { rate, timestamp: Date.now() };
    return rate;
  } catch (error) {
    // Fallback to default rate from profile
    log(`Exchange rate fetch failed, using default: ${taxProfile.defaultExchangeRate}`);
    return taxProfile.defaultExchangeRate;
  }
}
```

---

## 5. COUNTRY-SPECIFIC STRATEGY ADJUSTMENTS

The tax profile doesn't just affect reporting — it should influence the agent's actual strategy decisions.

### 5.1: Germany — Hold Longer

For German users, the agent should:
- Extend the 7-day review window to strongly prefer holding positions approaching 12 months
- Only rotate if the yield benefit massively outweighs the tax cost of resetting the holding clock
- The profit-take exit trigger should be suppressed for positions approaching the 12-month mark
- Display a "days to tax-free" countdown on the dashboard

### 5.2: Singapore/UAE — Pure Yield Optimisation

For users in zero-CGT jurisdictions:
- The tax-aware rotation threshold becomes irrelevant — rotate freely
- The agent can be more aggressive with rotations since there's no tax drag
- Strategy A becomes relatively more attractive (no CGT penalty for frequent LP rotations)
- Lending tax efficiency bonus in Strategy B scoring should be disabled

### 5.3: India — Minimise Transactions

For Indian users:
- 30% flat rate with no loss offset makes every losing trade permanently painful
- The agent should be extremely conservative about entering positions
- Favour lending over LP (fewer taxable events)
- Circuit breaker should be more sensitive (losses can't offset gains)

### 5.4: United States — Track Per-Wallet Basis

For US users:
- Cost basis must be tracked per-wallet (IRS rule from 2025)
- If the simulation models multiple wallets, each has independent basis
- NIIT (3.8% surtax) applies to investment income above $200K
- Form 8949 export is essential for tax filing

### 5.5: Implementation in the Agent

```javascript
function getCountryStrategyAdjustments(taxProfile) {
  const adjustments = {
    rotationFrequency: "normal",    // normal, aggressive, conservative
    holdPeriodPreference: "none",   // none, extend_to_12mo, extend_to_24mo
    profitTakeOverride: false,      // suppress profit-take near tax threshold?
    lendingPreference: "neutral",   // neutral, strong_prefer, no_preference
    lossOffsetAllowed: true
  };

  // Zero-CGT countries: rotate freely
  if (taxProfile.capitalGains.shortTermRate === 0 &&
      taxProfile.capitalGains.longTermRate === 0) {
    adjustments.rotationFrequency = "aggressive";
    adjustments.lendingPreference = "no_preference";
  }

  // Tax-free after holding period (Germany)
  if (taxProfile.capitalGains.longTermRate === 0 &&
      taxProfile.capitalGains.longTermThresholdMonths) {
    adjustments.holdPeriodPreference = "extend_to_12mo";
    adjustments.profitTakeOverride = true;
    adjustments.rotationFrequency = "conservative";
  }

  // No loss offset (India)
  if (taxProfile.countryCode === "IN") {
    adjustments.lossOffsetAllowed = false;
    adjustments.rotationFrequency = "conservative";
    adjustments.lendingPreference = "strong_prefer";
  }

  return adjustments;
}
```

---

## 6. TAX REPORT EXPORT

### 6.1: Universal CSV Format

All countries get a base CSV export with these columns:

```
date, event_type, pool, chain, pair, protocol, strategy,
cost_basis_usd, proceeds_usd, gain_loss_usd,
cost_basis_local, proceeds_local, gain_loss_local,
yield_income_usd, yield_income_local,
gas_cost_usd, gas_cost_local, gas_deductible,
holding_period_days, is_long_term, is_lending,
tax_year, local_currency
```

### 6.2: Country-Specific Formats

| Country | Format | Import Compatible With |
|---------|--------|----------------------|
| AU | CSV + myTax format | Koinly, CryptoTaxCalculator, accountant |
| US | CSV + Form 8949 format | TurboTax, TaxBit, CoinTracker, TokenTax |
| GB | CSV + HMRC SA format | Koinly, Recap, accountant |
| CA | CSV + Schedule 3 format | Koinly, CoinTracker, Wealthsimple Tax |
| DE | CSV + Elster format | CoinTracking, Blockpit, accountant |
| All others | Universal CSV | Any crypto tax software or accountant |

### 6.3: Export Function

```javascript
function exportTaxReport(startDate, endDate, countryCode, format = "csv") {
  const profile = loadTaxProfile(countryCode);
  const positions = getPositionsInRange(startDate, endDate);

  // Filter to the correct tax year
  const taxYearPositions = positions.filter(p =>
    isInTaxYear(p.exitDate || p.entryDate, profile)
  );

  if (format === "csv") {
    return generateUniversalCSV(taxYearPositions, profile);
  }

  if (format === "form_8949" && countryCode === "US") {
    return generateForm8949(taxYearPositions, profile);
  }

  if (format === "hmrc_self_assessment" && countryCode === "GB") {
    return generateHMRCSA(taxYearPositions, profile);
  }

  // Fallback to universal CSV
  return generateUniversalCSV(taxYearPositions, profile);
}
```

---

## 7. DASHBOARD CHANGES

### 7.1: Country Selector
- Dropdown with flag icons at onboarding and in settings
- Auto-detects country from browser locale as default suggestion
- Changing country recalculates all historical tax estimates retroactively

### 7.2: Tax Summary Panel (Country-Aware)
- Shows after-tax returns in local currency
- Highlights country-specific advantages (e.g. "🇩🇪 3 positions approaching tax-free status")
- Tax year progress bar (how far through the current tax year)
- Estimated tax liability for current tax year

### 7.3: Strategy Recommendations (Country-Aware)
- For DE users: "Strategy B is recommended — longer holding periods align with Germany's 12-month tax-free rule"
- For SG/AE users: "Strategy A is recommended — no CGT means frequent rotations carry no tax penalty"
- For IN users: "Strategy B (lending-heavy) is recommended — fewer taxable events with India's flat 30% rate"

---

## 8. IMPLEMENTATION ORDER

1. **Tax profile schema** — define the JSON structure, create AU profile (already done in v2.1, just extract to JSON)
2. **Tax engine module** — extract hardcoded AU logic into the pluggable engine
3. **US and UK profiles** — highest priority markets after AU
4. **Exchange rate service** — with caching and fallback
5. **Country-specific strategy adjustments** — Germany hold extension, Singapore/UAE aggressive mode, India conservative mode
6. **Export formats** — universal CSV first, then country-specific formats
7. **Dashboard country selector** — UI changes, retroactive recalculation
8. **Remaining country profiles** — CA, DE, JP, SG, AE, IN, NZ
9. **Testing** — verify tax calculations against known examples for each country
10. **Documentation** — per-country tax guide on the PassiveBlocks education hub

> **Important:** Tax laws change. Build a process to review and update profiles annually. Each profile should have a `lastVerified` date field so stale profiles can be flagged. Consider adding a disclaimer: "Tax rules verified as of [date]. Consult a tax professional for your specific situation."
