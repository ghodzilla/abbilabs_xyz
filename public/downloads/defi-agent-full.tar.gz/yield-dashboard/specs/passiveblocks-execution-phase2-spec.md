# PassiveBlocks — Phase 2: One-Click Execution Engine

> **Goal:** Agent prepares unsigned transactions, user approves with one click.  
> **Principle:** Agent has intelligence, human has signing authority. Never the reverse.  
> **Timeline:** 3–4 weeks  
> **Prerequisite:** Phase 1 (advisory dashboard) complete ✅

---

## 1. WHAT THIS BUILDS

The agent scans protocols, finds the best yield opportunity, and prepares a complete transaction bundle:
- Token approvals
- Deposit/swap calldata
- Gas estimates
- Slippage protection

User sees a single "Deploy" button. They click it, MetaMask pops up, they confirm. Done.

No manual navigation to Aave/Curve/Compound. No copying addresses. No calculating amounts.

---

## 2. ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│  PASSIVEBLOCKS AGENT (VPS)                                   │
│                                                              │
│  1. Scan DeFiLlama → find best APY                          │
│  2. Fetch protocol ABI + contract address                    │
│  3. Encode calldata (ethers.js / viem)                       │
│  4. Estimate gas (eth_estimateGas)                           │
│  5. Store unsigned tx bundle → Vercel API                    │
└──────────────────────┬──────────────────────────────────────┘
                       │  HTTPS (push tx bundle)
┌──────────────────────▼──────────────────────────────────────┐
│  PASSIVEBLOCKS DASHBOARD (Vercel)                            │
│                                                              │
│  "💡 Agent found 8.4% APY on Aave USDC"                    │
│  "Deploy $500 USDC → Aave v3 on Base"                       │
│                                                              │
│  [Review tx] [Deploy →]                                      │
│                                                              │
│  On click: wagmi/viem sends tx bundle to browser wallet     │
│  User signs in MetaMask/Coinbase Wallet/WalletConnect        │
└──────────────────────────────────────────────────────────────┘
```

---

## 3. TRANSACTION BUNDLE FORMAT

The agent produces a structured bundle stored server-side:

```json
{
  "bundleId": "bundle_abc123",
  "createdAt": "2026-03-21T10:00:00Z",
  "expiresAt": "2026-03-21T10:30:00Z",
  "status": "pending",

  "strategy": {
    "protocol": "aave-v3",
    "action": "deposit",
    "asset": "USDC",
    "assetAddress": "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48",
    "amount": "500000000",
    "amountHuman": "500",
    "chain": "base",
    "expectedApy": 8.42,
    "poolId": "0x..."
  },

  "transactions": [
    {
      "step": 1,
      "description": "Approve USDC spend",
      "to": "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48",
      "data": "0x095ea7b3...",
      "value": "0x0",
      "gasEstimate": "46000",
      "required": true
    },
    {
      "step": 2,
      "description": "Deposit 500 USDC into Aave v3",
      "to": "0x...",
      "data": "0x617ba037...",
      "value": "0x0",
      "gasEstimate": "180000",
      "required": true
    }
  ],

  "safetyChecks": {
    "contractVerified": true,
    "protocolAuditLink": "https://github.com/aave/aave-v3-core/tree/master/audits",
    "tvlUsd": 4200000000,
    "slippageBps": 50,
    "priceImpactPct": 0.01,
    "withinUserLimits": true
  },

  "userAddress": "0x...",
  "chainId": 8453
}
```

---

## 4. SAFETY RAILS (NON-NEGOTIABLE)

Every transaction bundle must pass ALL checks before being presented to the user:

### 4.1 Protocol Whitelist
Only these protocols can ever be in a bundle:
```javascript
const WHITELISTED_PROTOCOLS = [
  'aave-v3',
  'compound-v3',
  'curve-finance',
  'convex-finance',
  'lido',
  'rocket-pool',
  'uniswap-v3',
  '1inch',         // only for routing, not yield
  'pendle',
];
// Adding a new protocol requires a manual code change + Pritesh approval
// NEVER dynamically whitelist protocols based on APY data
```

### 4.2 Contract Verification
- Contract must be verified on Etherscan/Basescan/etc.
- If unverified → reject bundle, log reason, do not present to user

### 4.3 User-Defined Limits (stored in DB per user)
```json
{
  "limits": {
    "maxSingleTxUsd": 1000,
    "maxDailyTxUsd": 2000,
    "maxProtocolExposureUsd": 5000,
    "allowedChains": ["ethereum", "base", "arbitrum"],
    "allowedAssets": ["USDC", "USDT", "ETH", "WETH", "wstETH"],
    "requireApprovalAboveUsd": 500
  }
}
```
Any bundle that exceeds these limits is rejected before it reaches the UI.

### 4.4 Slippage Protection
- Max slippage: 0.5% for stablecoins, 1% for ETH/LSTs
- If price impact > 1% → warn user prominently
- If price impact > 3% → reject bundle entirely

### 4.5 Bundle Expiry
- Bundles expire after 30 minutes
- Expired bundle shows "Market conditions changed — agent is preparing a fresh bundle"
- Stale gas estimates are dangerous — always re-estimate on execution

### 4.6 Simulation Before Signing
- Before presenting to user, simulate the tx with `eth_call`
- If simulation reverts → do not show "Deploy" button
- Show specific revert reason to user

---

## 5. SUPPORTED ACTIONS (LAUNCH SCOPE)

### 5.1 Deposit / Lend
- Deposit ERC-20 tokens into lending protocols (Aave v3, Compound v3)
- Approve + deposit in a 2-step bundle (or use permit2 for 1-step where available)

### 5.2 Withdraw
- Withdraw from lending positions
- Show current position + pending interest before withdraw

### 5.3 Swap (routing only)
- Swap asset A → asset B to rebalance (e.g. ETH → USDC before deploying to lending)
- Route via 1inch API for best execution
- Show price + price impact before signing

### 5.4 LP Deposit / Withdraw (Phase 2.1 — slightly later)
- LP operations are more complex (impermanent loss, tick ranges)
- Uniswap v3 position management
- Curve LP deposit/withdraw
- Build after lending is stable

---

## 6. UI COMPONENTS

### 6.1 Opportunity Card
```
┌──────────────────────────────────────────────────────────┐
│  💡 New Opportunity Found                                 │
│                                                          │
│  Aave v3 — USDC Lending                   8.42% APY     │
│  Base Network · TVL $4.2B · Audited ✅                   │
│                                                          │
│  Deploy amount: [    500    ] USDC   (max: 2,340 USDC)  │
│                                                          │
│  Estimated weekly earnings: $0.81                        │
│  Estimated annual earnings: $42.10                       │
│                                                          │
│  [Review transaction]         [Deploy now →]             │
└──────────────────────────────────────────────────────────┘
```

### 6.2 Transaction Review Modal
```
┌──────────────────────────────────────────────────────────┐
│  Transaction Review                              [Close] │
│                                                          │
│  Step 1 of 2 — Approve USDC spend                       │
│  Contract: 0xa0b8...eb48 (USDC — verified ✅)            │
│  Gas estimate: $0.08                                     │
│                                                          │
│  Step 2 of 2 — Deposit into Aave v3                     │
│  Contract: 0x794a...b49e (Aave Pool — verified ✅)       │
│  Amount: 500 USDC                                        │
│  Gas estimate: $0.31                                     │
│                                                          │
│  Total gas: ~$0.39 · Slippage: 0.01% · Expires: 29min  │
│                                                          │
│  Safety checks:                                          │
│  ✅ Contract verified  ✅ Protocol whitelisted            │
│  ✅ Within your limits  ✅ Simulation passed              │
│                                                          │
│  [Cancel]                          [Sign & Deploy →]     │
└──────────────────────────────────────────────────────────┘
```

### 6.3 Active Positions Dashboard
```
┌──────────────────────────────────────────────────────────┐
│  Active Positions                                        │
│                                                          │
│  Aave v3 USDC — Base                                     │
│  Deposited: 500 USDC · Current: 500.41 USDC             │
│  APY: 8.42% · Earned: $0.41 · Since: 3 days ago         │
│  [Withdraw]                                              │
│                                                          │
│  Rocket Pool — Ethereum                                  │
│  Deposited: 0.5 ETH · Current: 0.514 ETH                │
│  APY: 3.8% · Earned: 0.014 ETH · Since: 47 days ago     │
│  [Withdraw]                                              │
└──────────────────────────────────────────────────────────┘
```

---

## 7. WALLET INTEGRATION

Use **wagmi v2 + viem** for wallet connections. Already has:
- MetaMask
- Coinbase Wallet
- WalletConnect (needs project ID)
- Injected providers (Rabby, Frame, etc.)

### Transaction execution flow:
```javascript
import { useWriteContract, useWaitForTransactionReceipt } from 'wagmi';

function DeployButton({ bundle }) {
  const { writeContract, isPending } = useWriteContract();

  async function execute() {
    // Execute each step in sequence
    for (const tx of bundle.transactions) {
      await writeContract({
        address: tx.to,
        abi: parseAbi([...]),  // minimal ABI from bundle
        functionName: tx.functionName,
        args: tx.args,
        chainId: bundle.chainId,
      });
    }
  }

  return <button onClick={execute} disabled={isPending}>
    {isPending ? 'Confirming...' : 'Deploy →'}
  </button>;
}
```

---

## 8. AGENT-SIDE BUNDLE BUILDER (VPS)

New script: `yield-agent/bundle-builder.cjs`

```javascript
// Called after yield-sim identifies a position change opportunity
async function buildBundle(opportunity, userAddress, userLimits) {

  // 1. Validate against whitelist
  if (!WHITELISTED_PROTOCOLS.includes(opportunity.protocol)) {
    throw new Error(`Protocol ${opportunity.protocol} not whitelisted`);
  }

  // 2. Fetch protocol contract addresses
  const contracts = await getProtocolContracts(opportunity.protocol, opportunity.chain);

  // 3. Encode calldata
  const txSteps = await encodeDepositTransaction({
    protocol: opportunity.protocol,
    asset: opportunity.asset,
    amount: opportunity.amountWei,
    userAddress,
    contracts,
  });

  // 4. Estimate gas for each step
  for (const step of txSteps) {
    step.gasEstimate = await estimateGas(step, opportunity.chain);
  }

  // 5. Simulate entire bundle
  const simResult = await simulateBundle(txSteps, userAddress, opportunity.chain);
  if (!simResult.success) {
    throw new Error(`Simulation failed: ${simResult.revertReason}`);
  }

  // 6. Run safety checks
  const safetyChecks = await runSafetyChecks(opportunity, txSteps, userLimits);
  if (!safetyChecks.passed) {
    throw new Error(`Safety check failed: ${safetyChecks.reason}`);
  }

  // 7. Store bundle (30min TTL)
  const bundle = await storeBundle({ opportunity, txSteps, safetyChecks, userAddress });

  return bundle;
}
```

---

## 9. DATA STORE FOR BUNDLES

Bundles are short-lived (30min TTL). Options ranked by simplicity:

1. **Upstash Redis** (free tier, REST API) — best fit. TTL built-in, no infra.
2. **Vercel KV** — same thing, slightly more integrated with Vercel.
3. **In-memory on VPS + sync server** — simpler but loses bundles on restart.

Recommendation: **Upstash Redis** for bundles + active positions.

---

## 10. ACTIVE POSITIONS TRACKING

When a user executes a bundle, record the position:
```json
{
  "positionId": "pos_xyz789",
  "userId": "user_abc",
  "protocol": "aave-v3",
  "asset": "USDC",
  "chain": "base",
  "amountDeposited": "500000000",
  "txHash": "0x...",
  "deployedAt": "2026-03-21T10:05:00Z",
  "entryApyPct": 8.42,
  "status": "active"
}
```

Sync actual on-chain balances via Alchemy every hour to show current value + earnings.

---

## 11. PROTOCOL INTEGRATIONS (LAUNCH)

### Aave v3
- Chains: Ethereum, Base, Arbitrum, Optimism, Polygon
- Action: `supply(asset, amount, onBehalfOf, referralCode)`
- Pool contract: fetched from AddressesProvider
- Docs: https://docs.aave.com/developers/core-contracts/pool

### Compound v3
- Chains: Ethereum, Base, Arbitrum
- Action: `supply(asset, amount)`
- Market contracts: USDC market on each chain
- Docs: https://docs.compound.finance

### Rocket Pool
- Chain: Ethereum only
- Action: `deposit()` on rETH contract (payable — sends ETH, gets rETH)
- Contract: `0xae78736Cd615f374D3085123A210448E74Fc6393` (rETH token)
- Docs: https://docs.rocketpool.net/developers/usage/contracts/contracts.html

---

## 12. PHASE 2.1 ADDITIONS (POST-LAUNCH)

After Phase 2 is stable and users have deployed real capital:

- **Auto-rebalance:** Agent detects a better yield, prepares a withdraw + re-deposit bundle automatically. User gets a notification and one-click to execute.
- **Position monitoring alerts:** "Your Aave position APY dropped from 8.4% to 4.1% — agent found a better option at Compound (5.9%)"
- **Batch transactions:** Use EIP-4337 (account abstraction) to execute approve + deposit in a single signature
- **Safe wallet integration:** For users who want full automation — agent queues transactions to a Safe multisig, user approves via Safe app

---

## 13. WHAT THIS IS NOT

- ❌ Not a trading bot — no speculative positions, no leveraged trades
- ❌ Not custodial — private keys never leave user's device
- ❌ Not automated — user always signs every transaction
- ❌ Not financial advice — "this is what the agent found; you decide"

---

## 14. IMPLEMENTATION ORDER

| Week | Task |
|------|------|
| 1 | Bundle builder (VPS) — encode Aave v3 deposit tx |
| 1 | Safety checks engine — whitelist, simulation, slippage |
| 1 | Upstash Redis setup — bundle storage with TTL |
| 2 | Vercel API routes — store + retrieve bundles |
| 2 | Transaction review UI — opportunity card + modal |
| 2 | wagmi integration — connect wallet + send tx |
| 3 | Active positions tracker — on-chain sync via Alchemy |
| 3 | Compound v3 support |
| 3 | Rocket Pool ETH deposit support |
| 4 | End-to-end test on Base testnet |
| 4 | Security review — check every contract address, every ABI call |
| 4 | Launch to Pritesh as beta user #1 |

---

## 15. OPEN QUESTIONS (for Pritesh to answer)

1. **Wallet setup:** Do you want to use MetaMask (existing) or set up a Safe multisig for extra protection?
2. **Starting capital:** What's the max USD amount you'd be comfortable with the agent deploying in Phase 2? (Suggests the `maxSingleTxUsd` limit)
3. **Chains:** Start with Base only (cheapest gas) or all supported chains from day one?
4. **Notification method:** Push notification to Telegram when agent finds a new bundle? Or just shows in dashboard?
5. **Upstash Redis:** Free tier requires account creation at upstash.com — can you set that up when we're ready to build?
