# CLAUDE.md — Yield Dashboard

> This file is the authoritative context guide for AI coding assistants working on the Yield Dashboard project. Read this before touching any file.

---

## What This Is

A real-time DeFi yield monitoring dashboard for Abbi Labs. Tracks a **7-day virtual A/B test** with $5,000 simulated capital split across two yield strategies. No real money moves — this is a simulation using live DeFiLlama data to evaluate which strategy performs better before committing real capital.

**Live URL:** https://yield-dashboard-9sk54tpcl-priteshghodge-gmailcoms-projects.vercel.app  
**Access:** Password protected (see DASHBOARD_PASS in .env)  
**Local access:** SSH tunnel only — `ssh -L 3001:localhost:3001 root@209.38.93.29` → http://localhost:3001  
**Port 3001 is NOT open in the firewall.** SSH tunnel is the only access method.

---

## Repository Structure

```
workspace/
├── dashboard/
│   ├── CLAUDE.md           ← you are here
│   ├── server.cjs          ← Express API server (localhost:3001)
│   ├── server-public.cjs   ← Vercel-deployed public dashboard
│   ├── index.html          ← Dashboard frontend (vanilla HTML/JS/CSS)
│   └── start.sh            ← Start script for local server
│
├── scripts/
│   ├── yield-sim.cjs       ← Core simulation engine (run every 3h via cron)
│   ├── yield-scanner.cjs   ← DeFiLlama pool scanner + pair filter
│   └── correlation-checker.cjs ← CoinGecko 7-day correlation calculator
│
└── memory/
    ├── yield-sim-state.json      ← Live simulation state (source of truth)
    ├── correlation-state.json    ← Last correlation check results
    └── yield-report-YYYY-MM-DD-HH.md ← Per-cycle reports (written by cron)
```

---

## Architecture

### Data Flow
```
DeFiLlama API → yield-scanner.cjs → pool candidates
CoinGecko API → correlation-checker.cjs → pair safety check
                     ↓
              yield-sim.cjs (every 3h)
                     ↓
         memory/yield-sim-state.json
                     ↓
         dashboard/server.cjs → /api/yield
                     ↓
         dashboard/index.html (frontend)
```

### Cron Schedule
- **yield-monitor-agent** runs every 3 hours (00:00, 03:00, 06:00, 09:00, 12:00, 15:00, 18:00, 21:00 UTC)
- Runs: yield-sim.cjs → correlation-checker.cjs → price check → saves report
- Alerts Pritesh via Telegram on exit signals

---

## Strategy Definitions

### Strategy A — Max APY
Targets highest-yield correlated pools on Base, Arbitrum, Solana, Ethereum.
- $2,500 allocated
- Filters: APY 5–80%, TVL > $1M, correlated pairs only
- Top 5 positions by APY score
- Higher volatility, higher upside

### Strategy B — Risk-Adjusted
Balances yield and safety (TVL × APY composite score).
- $2,500 allocated  
- Filters: same as A + higher TVL preference
- Top 5 positions by safety-weighted score
- More stable, lower drawdown expected

---

## Pair Classification (TWO-TIER SYSTEM)

### Tier 1 — Strictly Correlated (near-zero IL risk)
Both tokens track the SAME underlying asset. Correlation threshold ≥ 0.98.

| Family | Examples |
|--------|---------|
| ETH LSTs | ETH/stETH, ETH/wstETH, ETH/cbETH, ETH/rETH, ETH/weETH |
| SOL LSTs | SOL/mSOL, SOL/jitoSOL, SOL/bSOL |
| BTC variants | wBTC/cbBTC, wBTC/tBTC |
| Stablecoins | USDC/USDT, USDC/DAI, USDC/USDS |

### Tier 2 — Conviction Holds (Pritesh holds both assets, accepts some IL)
Different assets but both are conviction holds. Correlation threshold ≥ 0.70.

ETH/BTC, ETH/SOL, SOL/USDC, ETH/USDC, BTC/USDC, wBTC/USDC, SOL/BTC

### Exit Triggers (any of these = exit signal)
- Tier 1 pair correlation drops below 0.98 (LST/BTC) or 0.995 (stable)
- Tier 2 conviction pair correlation drops below 0.70
- Pool APY collapses >50% in one cycle
- TVL drops >20% in 24h
- Stablecoin deviates >0.2% from peg
- Underlying asset (ETH/BTC/SOL) drops >10% in 24h

---

## State File Schema (`memory/yield-sim-state.json`)

```json
{
  "startedAt": "ISO timestamp",
  "lastUpdatedAt": "ISO timestamp",
  "capital": 5000,
  "day": 1,
  "strategyA": {
    "name": "Max APY",
    "balance": 2500.00,
    "totalEarned": 0.00,
    "positions": [
      {
        "chain": "Base",
        "project": "uniswap-v4",
        "symbol": "ETH-USDC",
        "apy": 70.19,
        "tvlUsd": 1640306,
        "pool": "pool-uuid",
        "tier": "T2",
        "ilRisk": "yes"
      }
    ]
  },
  "strategyB": {
    "name": "Risk-Adjusted",
    "balance": 2500.00,
    "totalEarned": 0.00,
    "positions": [...]
  }
}
```

---

## API Endpoints (server.cjs)

| Method | Path | Auth | Response |
|--------|------|------|---------|
| GET | `/` | Basic auth | Dashboard HTML |
| GET | `/api/yield` | Basic auth | Full sim state JSON |

All endpoints require HTTP Basic Auth. Username: `admin`. Password: `DASHBOARD_PASS` from `.env`.

---

## Environment Variables

All in `/home/node/.openclaw/workspace/.env`:

| Variable | Used By | Notes |
|----------|---------|-------|
| `DASHBOARD_PASS` | server.cjs | HTTP Basic Auth password |
| `TELEGRAM_BOT_TOKEN` | yield-monitor-agent | Alert delivery |
| `TELEGRAM_CHAT_ID` | yield-monitor-agent | Pritesh's Telegram ID |

No DeFiLlama API key needed — public API.  
No CoinGecko API key needed — free tier, rate-limited (1 req/sec enforced in code).

---

## External APIs

### DeFiLlama (yield data)
- **Endpoint:** `https://yields.llama.fi/pools`
- **No auth required**
- **Rate limit:** generous, no enforced delay needed
- **Returns:** array of pool objects with APY, TVL, chain, project, symbol

### CoinGecko (price history for correlation)
- **Endpoint:** `https://api.coingecko.com/api/v3/coins/{id}/market_chart`
- **No auth required (free tier)**
- **Rate limit:** ~10-30 req/min — code enforces 1200ms delay between calls
- **Used for:** 7-day price history → Pearson correlation coefficient

---

## Key Rules & Constraints

1. **Capital preservation is rule #1.** Never recommend real capital deployment without passing all exit trigger checks. Make money, never lose money.

2. **Simulation only.** No real transactions are made. All balances are virtual. yield-sim.cjs computes P&L mathematically from APY rates.

3. **Cron is every 3 hours.** Do not manually run yield-sim.cjs more than once per cycle — it updates the running P&L cumulatively.

4. **Pair classification is strict.** A pair must pass Tier 1 OR Tier 2 checks to be included. Any pool with uncorrelated assets (e.g., ETH/USDC at Tier 1 threshold) is excluded.

5. **Dashboard is localhost-only.** server.cjs binds to `127.0.0.1` only. Port 3001 is not in the firewall. Use SSH tunnel.

6. **Never commit credentials.** `.env` is in `.gitignore`. `credentials/` is in `.gitignore`.

7. **Correlation check runs separately.** correlation-checker.cjs is its own script — don't merge it into yield-sim.cjs. They can run independently.

---

## Running Locally

```bash
# Start dashboard server
node /home/node/.openclaw/workspace/dashboard/server.cjs &

# Run a manual sim cycle (use sparingly)
node /home/node/.openclaw/workspace/scripts/yield-sim.cjs

# Run correlation check
node /home/node/.openclaw/workspace/scripts/correlation-checker.cjs

# Scan for new pools
node /home/node/.openclaw/workspace/scripts/yield-scanner.cjs

# Reset simulation (loses all history)
node /home/node/.openclaw/workspace/scripts/yield-sim.cjs --reset
```

---

## Common Tasks

### Add a new API endpoint to the dashboard
1. Edit `dashboard/server.cjs`
2. Add route with `auth` middleware
3. Test via SSH tunnel before deploying

### Change correlation thresholds
- Edit `THRESHOLDS_T1` / `THRESHOLDS_T2` in `scripts/correlation-checker.cjs`
- Also update matching constants in `scripts/yield-sim.cjs`
- Update this CLAUDE.md

### Add a new chain
- Add to `TARGET_CHAINS` array in both `yield-sim.cjs` and `yield-scanner.cjs`
- DeFiLlama chain names are case-sensitive (e.g., `"Base"` not `"base"`)

### Debug missing data
- Check `memory/yield-sim-state.json` exists and is valid JSON
- Check last cron run time via `openclaw cron list`
- Run `yield-sim.cjs` manually and check stderr

---

## Day 14 Protocol

On simulation day 14, the yield-monitor-agent produces a final recommendation:
- Which strategy won (higher total earned)
- Which pools were most stable (correlation held throughout)
- Whether real capital deployment is recommended and at what allocation
- Send full report to Pritesh via Telegram

Real capital deployment requires Pritesh's explicit approval — this is a Level 3 decision.

---

## Owner
Pritesh Ghodge (owner) · Abbi (AI CEO, Abbi Labs) · Built March 2026
