#!/usr/bin/env node
// AI Sales Agent — Follow-up Checker v2
// Identifies stale leads and deals that need follow-up
// v2: auto-creates HubSpot tasks for stale deals when auto_create_tasks is enabled
//
// Usage:
//   node follow-up-checker.cjs check              → Find all stale leads/deals
//   node follow-up-checker.cjs check --days 5      → Custom stale threshold
//   node follow-up-checker.cjs check --no-tasks    → Skip task creation even if enabled in config

'use strict';

const https = require('https');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '..', 'config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

const HUBSPOT_TOKEN = process.env.HUBSPOT_ACCESS_TOKEN;
if (!HUBSPOT_TOKEN) { console.error('Error: HUBSPOT_ACCESS_TOKEN not set'); process.exit(1); }

// ─── HTTP Helpers ──────────────────────────────────────────────────────────

function hubspotRequest(method, endpoint, body) {
  return new Promise((resolve, reject) => {
    const url = `https://api.hubapi.com${endpoint}`;
    const payload = body ? JSON.stringify(body) : null;
    const opts = {
      method,
      headers: {
        'Authorization': `Bearer ${HUBSPOT_TOKEN}`,
        'Content-Type': 'application/json',
      },
    };
    const req = https.request(url, opts, res => {
      let d = ''; res.on('data', c => d += c);
      res.on('end', () => {
        if (res.statusCode >= 400) return reject(new Error(`${res.statusCode}: ${d.substring(0, 300)}`));
        // 204 No Content — return empty object
        if (res.statusCode === 204 || !d.trim()) return resolve({});
        try { resolve(JSON.parse(d)); } catch (e) { resolve({}); }
      });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// ─── HubSpot Task Creator ──────────────────────────────────────────────────

/**
 * Create a HubSpot task associated with a deal (and optionally a contact).
 * Uses HubSpot Tasks API: POST /crm/v3/objects/tasks
 *
 * @param {object} opts
 * @param {string} opts.dealId
 * @param {string} opts.dealName
 * @param {string} [opts.contactId]
 * @param {string} [opts.contactName]
 * @param {number} opts.daysSinceActivity
 * @param {string} [opts.lastActivity]  — human-readable description of last activity
 */
async function createHubSpotTask(opts) {
  const { dealId, dealName, contactId, contactName, daysSinceActivity, lastActivity } = opts;

  const dueDateMs = Date.now() + 24 * 60 * 60 * 1000; // today + 1 day

  const contactPart = contactName ? ` with ${contactName}` : '';
  const subject = `Follow up${contactPart} — ${dealName} stale for ${daysSinceActivity} days`;
  const taskBody = [
    `Deal "${dealName}" has been inactive for ${daysSinceActivity} days.`,
    contactName ? `Contact: ${contactName}.` : '',
    lastActivity ? `Last activity: ${lastActivity}.` : '',
    'Flagged automatically by AI Sales Agent.',
  ].filter(Boolean).join(' ');

  // Build associations array — always associate with deal; add contact if available
  const associations = [
    {
      to: { id: dealId },
      types: [{ associationCategory: 'HUBSPOT_DEFINED', associationTypeId: 216 }] // TASK_TO_DEAL
    }
  ];

  if (contactId) {
    associations.push({
      to: { id: contactId },
      types: [{ associationCategory: 'HUBSPOT_DEFINED', associationTypeId: 204 }] // TASK_TO_CONTACT
    });
  }

  const payload = {
    properties: {
      hs_task_subject: subject,
      hs_task_body: taskBody,
      hs_due_date: dueDateMs.toString(),
      hs_task_status: 'NOT_STARTED',
      hs_task_type: 'TODO',
    },
    associations,
  };

  const result = await hubspotRequest('POST', '/crm/v3/objects/tasks', payload);
  return result;
}

/**
 * Fetch the first associated contact for a deal.
 * Returns { id, name } or null if no contact found.
 */
async function getDealContact(dealId) {
  try {
    const res = await hubspotRequest('GET', `/crm/v4/objects/deals/${dealId}/associations/contacts`);
    const contacts = res.results || [];
    if (contacts.length === 0) return null;

    const contactId = contacts[0].toObjectId || contacts[0].id;
    const contact = await hubspotRequest('GET', `/crm/v3/objects/contacts/${contactId}?properties=firstname,lastname,email`);
    const p = contact.properties || {};
    const name = [p.firstname, p.lastname].filter(Boolean).join(' ') || p.email || null;
    return { id: String(contactId), name };
  } catch (e) {
    // Non-fatal — proceed without contact association
    return null;
  }
}

// ─── Helpers ───────────────────────────────────────────────────────────────

function daysSince(dateStr) {
  if (!dateStr) return Infinity;
  return Math.floor((Date.now() - new Date(dateStr).getTime()) / (1000 * 60 * 60 * 24));
}

function formatCurrency(amount) {
  return '$' + amount.toLocaleString('en-US', { minimumFractionDigits: 0 });
}

function formatDate(dateStr) {
  if (!dateStr) return 'unknown';
  return new Date(dateStr).toISOString().split('T')[0];
}

// ─── Main Follow-up Check ─────────────────────────────────────────────────

async function checkFollowUps(staleDays, skipTaskCreation) {
  const followUpDays = staleDays || config.follow_up.follow_up_days;
  const staleDealDays = config.follow_up.stale_deal_days;
  const autoCreateTasks = !skipTaskCreation && (config.follow_up.auto_create_tasks === true);

  // Get all open deals
  const properties = ['dealname', 'amount', 'dealstage', 'hs_lastmodifieddate',
    'notes_last_updated', 'hs_next_step', 'createdate'];
  const dealsRes = await hubspotRequest('GET',
    `/crm/v3/objects/deals?limit=100&properties=${properties.join(',')}&associations=contacts`);
  const deals = dealsRes.results || [];

  const staleDeals = [];
  const needsFollowUp = [];

  for (const deal of deals) {
    const stage = deal.properties.dealstage;
    if (stage === 'closedwon' || stage === 'closedlost') continue;

    const amount = parseFloat(deal.properties.amount) || 0;
    const lastModified = deal.properties.hs_lastmodifieddate;
    const daysSinceModified = daysSince(lastModified);
    const notesLastUpdated = deal.properties.notes_last_updated;
    const daysSinceNote = daysSince(notesLastUpdated);

    const entry = {
      deal_id: deal.id,
      name: deal.properties.dealname,
      amount,
      stage,
      days_since_activity: daysSinceModified,
      days_since_note: daysSinceNote,
      last_activity_date: lastModified,
      created: deal.properties.createdate,
    };

    if (daysSinceModified >= staleDealDays) {
      staleDeals.push({ ...entry, reason: `No activity in ${daysSinceModified} days` });
    }

    if (daysSinceNote >= followUpDays) {
      const noteLabel = isFinite(daysSinceNote) ? `No notes in ${daysSinceNote} days` : 'No notes on record';
      needsFollowUp.push({ ...entry, reason: noteLabel });
    }
  }

  // Deduplicate — a deal can be both stale and needing follow-up
  const allFlagged = new Map();
  for (const d of [...staleDeals, ...needsFollowUp]) {
    if (!allFlagged.has(d.deal_id)) {
      allFlagged.set(d.deal_id, { ...d, reasons: [d.reason] });
    } else {
      allFlagged.get(d.deal_id).reasons.push(d.reason);
    }
  }

  const flagged = Array.from(allFlagged.values()).sort((a, b) => b.amount - a.amount);

  // ── Auto-create HubSpot tasks for stale deals ──
  const tasksCreated = [];
  const taskErrors = [];

  if (autoCreateTasks && flagged.length > 0) {
    console.log(`Creating HubSpot tasks for ${flagged.length} stale deal(s)...`);

    for (const deal of flagged) {
      try {
        const contact = await getDealContact(deal.deal_id);
        const task = await createHubSpotTask({
          dealId: deal.deal_id,
          dealName: deal.name,
          contactId: contact ? contact.id : null,
          contactName: contact ? contact.name : null,
          daysSinceActivity: deal.days_since_activity,
          lastActivity: deal.last_activity_date ? `last modified ${formatDate(deal.last_activity_date)}` : null,
        });
        tasksCreated.push({ deal: deal.name, task_id: task.id });
        console.log(`  ✅ Task created for "${deal.name}" (task ID: ${task.id})`);
      } catch (e) {
        taskErrors.push({ deal: deal.name, error: e.message });
        console.error(`  ⚠️  Task creation failed for "${deal.name}": ${e.message}`);
      }
    }
  }

  // ── Format report ──
  if (flagged.length === 0) {
    return '✅ No stale deals or follow-ups needed. Pipeline is healthy!';
  }

  const totalValue = flagged.reduce((sum, d) => sum + d.amount, 0);

  let report = `📋 FOLLOW-UP NEEDED — ${flagged.length} deals (${formatCurrency(totalValue)} at risk)\n\n`;

  const urgent = flagged.filter(d => d.days_since_activity >= staleDealDays * 2);
  const standard = flagged.filter(d => d.days_since_activity < staleDealDays * 2);

  if (urgent.length > 0) {
    report += `🚨 URGENT (${urgent.length}):\n`;
    for (const d of urgent) {
      report += `• ${d.name} — ${formatCurrency(d.amount)} — ${d.stage}\n`;
      report += `  ${d.reasons.join(' | ')}\n`;
    }
    report += '\n';
  }

  if (standard.length > 0) {
    report += `⚠️ NEEDS ATTENTION (${standard.length}):\n`;
    for (const d of standard) {
      report += `• ${d.name} — ${formatCurrency(d.amount)} — ${d.stage}\n`;
      report += `  ${d.reasons.join(' | ')}\n`;
    }
  }

  if (autoCreateTasks) {
    report += `\n📌 HubSpot Tasks: ${tasksCreated.length} created`;
    if (taskErrors.length > 0) report += `, ${taskErrors.length} failed`;
    report += '\n';
  }

  report += `\n💡 Recommended: Review these deals and either follow up or update their status.`;

  return report;
}

// ─── CLI ───────────────────────────────────────────────────────────────────

const args = process.argv.slice(2);
const cmd = args[0];

if (cmd === 'check') {
  const daysIdx = args.indexOf('--days');
  const days = daysIdx !== -1 ? parseInt(args[daysIdx + 1], 10) : undefined;
  const skipTasks = args.includes('--no-tasks');

  checkFollowUps(days, skipTasks)
    .then(r => console.log(r))
    .catch(e => console.error('Error:', e.message));
} else {
  const autoTasks = config.follow_up.auto_create_tasks ? 'ON' : 'OFF';
  console.log(`AI Sales Agent — Follow-up Checker v2

Usage:
  node follow-up-checker.cjs check               Find stale leads/deals
  node follow-up-checker.cjs check --days 5      Custom stale threshold (default: ${config.follow_up.follow_up_days} days)
  node follow-up-checker.cjs check --no-tasks    Skip HubSpot task creation

Config:
  auto_create_tasks: ${autoTasks} — set follow_up.auto_create_tasks in config.json to enable/disable

v2 features:
  - Auto-creates HubSpot tasks for stale deals (configurable)
  - Task associated with both deal and contact
  - Due date set to tomorrow`);
}
