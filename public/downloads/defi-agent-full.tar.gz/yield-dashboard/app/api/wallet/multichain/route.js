import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

// GET /api/wallet/multichain?address=0x...
// Scans all 5 chains in parallel, returns per-chain balance + tx count + active flag

const CHAINS = ['ethereum', 'base', 'arbitrum', 'optimism', 'polygon'];

const ALCHEMY_NETWORKS = {
  ethereum: 'eth-mainnet',
  base:     'base-mainnet',
  arbitrum: 'arb-mainnet',
  optimism: 'opt-mainnet',
  polygon:  'polygon-mainnet',
};

const CHAIN_TICKER = {
  ethereum: 'ETH',
  base:     'ETH',
  arbitrum: 'ETH',
  optimism: 'ETH',
  polygon:  'POL',
};

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const address = searchParams.get('address');

  if (!address) {
    return NextResponse.json({ error: 'address required' }, { status: 400 });
  }
  if (!/^0x[a-fA-F0-9]{40}$/.test(address)) {
    return NextResponse.json({ error: 'Invalid EVM address' }, { status: 400 });
  }

  const alchemyKey = process.env.ALCHEMY_API_KEY;
  if (!alchemyKey) {
    return NextResponse.json({ error: 'ALCHEMY_API_KEY not configured' }, { status: 500 });
  }

  // ── 1. Fetch ETH + POL prices from CoinGecko (single request) ─────────────
  let ethUsd = 3000;
  let polUsd = 0.4;
  try {
    const priceRes = await fetch(
      'https://api.coingecko.com/api/v3/simple/price?ids=ethereum,matic-network&vs_currencies=usd',
      { headers: { Accept: 'application/json' } }
    );
    if (priceRes.ok) {
      const priceData = await priceRes.json();
      if (priceData?.ethereum?.usd)     ethUsd = priceData.ethereum.usd;
      if (priceData?.['matic-network']?.usd) polUsd = priceData['matic-network'].usd;
    }
  } catch {
    // Use fallback prices
  }

  // ── 2. Scan all chains in parallel via Alchemy JSON-RPC ───────────────────
  async function scanChain(chain) {
    const network = ALCHEMY_NETWORKS[chain];
    const url = `https://${network}.g.alchemy.com/v2/${alchemyKey}`;

    const [balRes, txRes] = await Promise.all([
      fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0', id: 1,
          method: 'eth_getBalance',
          params: [address, 'latest'],
        }),
      }),
      fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0', id: 2,
          method: 'eth_getTransactionCount',
          params: [address, 'latest'],
        }),
      }),
    ]);

    const [balData, txData] = await Promise.all([balRes.json(), txRes.json()]);

    const balanceWei = BigInt(balData.result || '0x0');
    const balance    = Number(balanceWei) / 1e18;
    const txCount    = parseInt(txData.result || '0x0', 16);

    const ticker     = CHAIN_TICKER[chain];
    const priceUsd   = ticker === 'POL' ? polUsd : ethUsd;
    const balanceUsd = parseFloat((balance * priceUsd).toFixed(2));
    const hasActivity = balance > 0 || txCount > 0;

    return {
      chain,
      balance:    parseFloat(balance.toFixed(6)),
      balanceUsd,
      ticker,
      txCount,
      hasActivity,
    };
  }

  const results = await Promise.allSettled(CHAINS.map(chain => scanChain(chain)));

  // ── 3. Build response ──────────────────────────────────────────────────────
  const chains = {};
  let totalBalanceUsd = 0;
  const activeChains = [];

  for (let i = 0; i < CHAINS.length; i++) {
    const chain  = CHAINS[i];
    const result = results[i];

    if (result.status === 'fulfilled') {
      const { balance, balanceUsd, ticker, txCount, hasActivity } = result.value;
      chains[chain] = { balance, balanceUsd, ticker, txCount, hasActivity };
      if (hasActivity) {
        activeChains.push(chain);
        totalBalanceUsd += balanceUsd;
      }
    } else {
      // Chain scan failed — return safe zero values
      chains[chain] = {
        balance:    0,
        balanceUsd: 0,
        ticker:     CHAIN_TICKER[chain],
        txCount:    0,
        hasActivity: false,
        error:      result.reason?.message || 'scan failed',
      };
    }
  }

  return NextResponse.json({
    address,
    chains,
    activeChains,
    totalBalanceUsd: parseFloat(totalBalanceUsd.toFixed(2)),
    fetchedAt: new Date().toISOString(),
  });
}
