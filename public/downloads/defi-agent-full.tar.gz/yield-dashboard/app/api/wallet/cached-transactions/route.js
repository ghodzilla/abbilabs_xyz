export const runtime = 'nodejs';

const REPO    = 'ghodzilla/yield-dashboard';
const BRANCH  = 'data';
const GH_RAW  = `https://raw.githubusercontent.com/${REPO}/${BRANCH}`;

const TAX_YEARS = {
  '2024-25': { start: new Date('2024-07-01T00:00:00Z'), end: new Date('2025-06-30T23:59:59Z') },
  '2023-24': { start: new Date('2023-07-01T00:00:00Z'), end: new Date('2024-06-30T23:59:59Z') },
  '2022-23': { start: new Date('2022-07-01T00:00:00Z'), end: new Date('2023-06-30T23:59:59Z') },
  '2021-22': { start: new Date('2021-07-01T00:00:00Z'), end: new Date('2022-06-30T23:59:59Z') },
};

async function fetchFromGitHub(filePath) {
  const url = `${GH_RAW}/${filePath}`;
  const res = await fetch(url, {
    headers: {
      'Authorization': `Bearer ${process.env.GITHUB_TOKEN}`,
      'Accept': 'application/json',
    },
    signal: AbortSignal.timeout(8000),
  });
  if (!res.ok) return null;
  return await res.json();
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const address  = searchParams.get('address');
  const chain    = searchParams.get('chain');
  const taxYear  = searchParams.get('taxYear'); // e.g. "2023-24"

  if (!address) {
    return Response.json({ error: 'address required' }, { status: 400 });
  }

  try {
    let transactions = [];

    if (chain) {
      // Fetch single chain
      const data = await fetchFromGitHub(`cache/${address}-${chain}.json`);
      if (!data) return Response.json({ error: 'not_found', address, chain }, { status: 404 });
      transactions = data.transfers || [];
    } else {
      // Fetch all chains for this address — try common chains
      const chains = ['ethereum', 'base', 'arbitrum', 'optimism', 'polygon', 'solana'];
      const results = await Promise.all(
        chains.map(c => fetchFromGitHub(`cache/${address}-${c}.json`).catch(() => null))
      );
      for (const data of results) {
        if (data && data.transfers) transactions.push(...data.transfers);
      }
    }

    // Filter by tax year if requested
    if (taxYear && TAX_YEARS[taxYear]) {
      const { start, end } = TAX_YEARS[taxYear];
      transactions = transactions.filter(tx => {
        const ts = tx.metadata?.blockTimestamp || tx.timestamp;
        if (!ts) return false;
        const d = new Date(ts);
        return d >= start && d <= end;
      });
    }

    // Sort newest first
    transactions.sort((a, b) => {
      const ta = new Date(a.metadata?.blockTimestamp || a.timestamp || 0);
      const tb = new Date(b.metadata?.blockTimestamp || b.timestamp || 0);
      return tb - ta;
    });

    return Response.json({
      address,
      chain: chain || 'all',
      taxYear: taxYear || 'all',
      count: transactions.length,
      transactions,
    });

  } catch (err) {
    console.error('[cached-transactions] error:', err.message);
    return Response.json({ error: 'fetch_failed', detail: err.message }, { status: 500 });
  }
}
