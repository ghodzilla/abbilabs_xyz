#!/usr/bin/env node
/**
 * PassiveBlocks Global Tax Engine
 * Pluggable tax calculation module supporting 10 country profiles.
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

// ── Profile cache ────────────────────────────────────────────────────────────
const taxProfiles = {};

function loadTaxProfile(countryCode) {
  if (!taxProfiles[countryCode]) {
    const filePath = path.join(__dirname, 'tax-profiles', `${countryCode}.json`);
    taxProfiles[countryCode] = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  }
  return taxProfiles[countryCode];
}

// ── Income Tax ───────────────────────────────────────────────────────────────

function calculateIncomeTax(grossIncomeUSD, profile, userMarginalRate) {
  const rate = userMarginalRate != null ? userMarginalRate : profile.incomeTax.defaultMarginalRate;

  if (profile.incomeTax.yieldTaxedAs === 'not_taxed' ||
      profile.incomeTax.yieldTaxedAs === 'not_taxed_unless_business') {
    return 0;
  }

  let tax = grossIncomeUSD * rate;

  for (const levy of (profile.incomeTax.additionalLevies || [])) {
    if (levy.applies === 'all_income') {
      tax += grossIncomeUSD * levy.rate;
    }
  }

  return tax;
}

// ── Tiered CGT helper ────────────────────────────────────────────────────────

function calculateTieredCGT(gain, tiers) {
  if (!tiers || tiers.length === 0) return 0;
  let tax = 0;
  let remaining = gain;
  for (const tier of tiers) {
    const max = tier.max != null ? tier.max : Infinity;
    const min = tier.min || 0;
    const width = max - min;
    const taxable = Math.min(remaining, width);
    if (taxable <= 0) break;
    tax += taxable * tier.rate;
    remaining -= taxable;
  }
  return tax;
}

// ── Capital Gains Tax ────────────────────────────────────────────────────────

function calculateCGT(gainUSD, holdingDays, profile, userMarginalRate) {
  if (gainUSD <= 0) return 0;

  const rate = userMarginalRate != null ? userMarginalRate : profile.incomeTax.defaultMarginalRate;
  const cg = profile.capitalGains;

  const isLongTerm = cg.longTermThresholdMonths != null &&
    holdingDays >= cg.longTermThresholdMonths * 30;

  // Apply tax-free allowance
  let taxableGain = gainUSD;
  if (cg.taxFreeAllowance != null && cg.taxFreeAllowance > 0) {
    taxableGain = Math.max(0, gainUSD - cg.taxFreeAllowance);
  }

  if (isLongTerm) {
    // Long-term treatment
    if (cg.longTermRate === 0 || cg.longTermRate === 0.00) {
      return 0; // Germany: completely tax-free after holding period
    }
    if (cg.longTermDiscount > 0 && cg.longTermRate !== 0) {
      taxableGain *= (1 - cg.longTermDiscount); // Australia: 50% discount, Canada: 50% inclusion
    }
    if (cg.longTermRate === 'tiered') {
      return calculateTieredCGT(taxableGain, cg.longTermTiers);
    }
    if (cg.longTermRate === 'marginal_rate') {
      return taxableGain * rate;
    }
    if (cg.longTermRate === 'same_as_short_term') {
      // UK: same rate regardless of holding period
      if (cg.shortTermRate === 'marginal_rate') return taxableGain * rate;
      if (cg.shortTermRate === 'tiered') return calculateTieredCGT(taxableGain, cg.shortTermTiers || []);
      if (typeof cg.shortTermRate === 'number') return taxableGain * cg.shortTermRate;
      return taxableGain * rate;
    }
    if (typeof cg.longTermRate === 'number') return taxableGain * cg.longTermRate;
    return taxableGain * rate;
  } else {
    // Short-term treatment
    if (cg.shortTermRate === 'marginal_rate') {
      return taxableGain * rate;
    }
    if (typeof cg.shortTermRate === 'number') {
      if (cg.shortTermRate === 0) return 0; // Singapore, UAE, NZ: no CGT
      return taxableGain * cg.shortTermRate;
    }
    if (cg.shortTermRate === 'tiered') {
      return calculateTieredCGT(taxableGain, cg.shortTermTiers || []);
    }
    return taxableGain * rate;
  }
}

// ── CGT Event Checks ─────────────────────────────────────────────────────────

function isRotationCGTEvent(position, profile) {
  const isLending = position.isLending || position.type === 'lending';
  if (isLending) {
    return profile.capitalGains.lendingExitIsCGTEvent === true;
  }
  return profile.capitalGains.lpExitIsCGTEvent === true;
}

// ── Tax-Aware Rotation Decision ──────────────────────────────────────────────

function shouldRotate(currentPosition, newPool, profile, gasCostUSD) {
  const currentApy = currentPosition.apy || currentPosition.currentApy || 0;
  const newApy = newPool.apy || 0;
  const positionValue = currentPosition.atRiskCapital || 500;

  // Expected 7-day benefit from switching
  const benefit = (newApy - currentApy) / 100 * positionValue / 365 * 7;

  if (!isRotationCGTEvent(currentPosition, profile)) {
    // No CGT on exit — just check gas
    return benefit > gasCostUSD;
  }

  // Estimate unrealised gain
  const costBasis = currentPosition.costBasisUSD || positionValue;
  const unrealisedGain = Math.max(0, positionValue - costBasis);
  const holdDays = currentPosition.holdingDays || 0;
  const marginalRate = currentPosition.userMarginalRate || profile.incomeTax.defaultMarginalRate;
  const estimatedTax = calculateCGT(unrealisedGain, holdDays, profile, marginalRate);

  return benefit > estimatedTax + gasCostUSD;
}

// ── Optimal Hold Duration ────────────────────────────────────────────────────

function getOptimalHoldDuration(profile) {
  const cg = profile.capitalGains;

  if ((cg.longTermRate === 0 || cg.longTermRate === 0.00) && cg.longTermThresholdMonths) {
    return {
      minHoldForTaxBenefit: cg.longTermThresholdMonths * 30,
      taxBenefit: 'complete_exemption'
    };
  }
  if (cg.longTermDiscount > 0 && cg.longTermThresholdMonths) {
    return {
      minHoldForTaxBenefit: cg.longTermThresholdMonths * 30,
      taxBenefit: `${cg.longTermDiscount * 100}%_discount`
    };
  }
  return { minHoldForTaxBenefit: 0, taxBenefit: 'none' };
}

// ── Country Strategy Adjustments ─────────────────────────────────────────────

function getCountryStrategyAdjustments(profile) {
  const cg = profile.capitalGains;
  const adjustments = {
    rotationFrequency: 'normal',
    holdPeriodPreference: 'none',
    profitTakeOverride: false,
    lendingPreference: 'neutral',
    lossOffsetAllowed: true
  };

  // Zero-CGT countries: rotate freely (SG, AE, NZ)
  if ((cg.shortTermRate === 0 || cg.shortTermRate === 0.00) &&
      (cg.longTermRate === 0 || cg.longTermRate === 0.00)) {
    adjustments.rotationFrequency = 'aggressive';
    adjustments.lendingPreference = 'no_preference';
  }

  // Tax-free after holding period (Germany)
  if ((cg.longTermRate === 0 || cg.longTermRate === 0.00) && cg.longTermThresholdMonths) {
    adjustments.holdPeriodPreference = 'extend_to_12mo';
    adjustments.profitTakeOverride = true;
    adjustments.rotationFrequency = 'conservative';
  }

  // No loss offset (India)
  if (cg.lossOffsetAllowed === false || profile.countryCode === 'IN') {
    adjustments.lossOffsetAllowed = false;
    adjustments.rotationFrequency = 'conservative';
    adjustments.lendingPreference = 'strong_prefer';
  }

  return adjustments;
}

// ── Exchange Rate with Cache ─────────────────────────────────────────────────

const rateCache = {};
const RATE_CACHE_MS = 6 * 3600 * 1000; // 6 hours

async function getExchangeRate(profile) {
  if (profile.exchangeRateSource === 'native') return 1.0;

  const cacheKey = profile.exchangeRateSource;
  const cached = rateCache[cacheKey];
  if (cached && (Date.now() - cached.timestamp) < RATE_CACHE_MS) {
    return cached.rate;
  }

  try {
    const parts = cacheKey.replace('USD_TO_', '');
    const targetCurrency = parts;
    const rate = await new Promise((resolve, reject) => {
      https.get(`https://api.exchangerate-api.com/v4/latest/USD`, {
        headers: { 'User-Agent': 'PassiveBlocks-TaxEngine/1.0' }
      }, res => {
        let d = '';
        res.on('data', c => d += c);
        res.on('end', () => {
          try {
            const data = JSON.parse(d);
            const r = data.rates?.[targetCurrency];
            resolve(r || profile.defaultExchangeRate);
          } catch { resolve(profile.defaultExchangeRate); }
        });
      }).on('error', () => resolve(profile.defaultExchangeRate));
    });

    rateCache[cacheKey] = { rate, timestamp: Date.now() };
    return rate;
  } catch {
    return profile.defaultExchangeRate;
  }
}

// ── Tax CSV Export ───────────────────────────────────────────────────────────

function exportTaxCSV(positions, profile) {
  const headers = [
    'date', 'event_type', 'pool', 'chain', 'pair', 'protocol', 'strategy',
    'cost_basis_usd', 'proceeds_usd', 'gain_loss_usd',
    'cost_basis_local', 'proceeds_local', 'gain_loss_local',
    'yield_income_usd', 'yield_income_local',
    'gas_cost_usd', 'gas_cost_local', 'gas_deductible',
    'holding_period_days', 'is_long_term', 'is_lending',
    'tax_year', 'local_currency'
  ];

  const rows = [headers.join(',')];
  const xr = profile.defaultExchangeRate;

  for (const pos of positions) {
    const costUSD = pos.costBasisUSD || 0;
    const proceedsUSD = pos.proceedsUSD || 0;
    const gainUSD = proceedsUSD - costUSD;
    const yieldUSD = pos.yieldIncomeUSD || 0;
    const gasUSD = pos.gasCostUSD || 0;
    const holdDays = pos.holdingDays || 0;
    const isLongTerm = profile.capitalGains.longTermThresholdMonths != null &&
      holdDays >= profile.capitalGains.longTermThresholdMonths * 30;
    const isLending = pos.isLending || pos.type === 'lending';
    const gasDeductible = profile.deductions.gasFees ? 'yes' : 'no';

    rows.push([
      pos.date || pos.exitDate || pos.entryDate || '',
      pos.eventType || pos.exitReason || 'unknown',
      pos.pool || '',
      pos.chain || '',
      pos.symbol || '',
      pos.project || pos.protocol || '',
      pos.strategy || '',
      costUSD.toFixed(2),
      proceedsUSD.toFixed(2),
      gainUSD.toFixed(2),
      (costUSD * xr).toFixed(2),
      (proceedsUSD * xr).toFixed(2),
      (gainUSD * xr).toFixed(2),
      yieldUSD.toFixed(2),
      (yieldUSD * xr).toFixed(2),
      gasUSD.toFixed(2),
      (gasUSD * xr).toFixed(2),
      gasDeductible,
      holdDays.toString(),
      isLongTerm ? 'yes' : 'no',
      isLending ? 'yes' : 'no',
      pos.taxYear || '',
      profile.localCurrency
    ].join(','));
  }

  return rows.join('\n');
}

// ── Module Exports ───────────────────────────────────────────────────────────

module.exports = {
  loadTaxProfile,
  calculateIncomeTax,
  calculateCGT,
  isRotationCGTEvent,
  shouldRotate,
  getOptimalHoldDuration,
  getCountryStrategyAdjustments,
  getExchangeRate,
  exportTaxCSV,
};
