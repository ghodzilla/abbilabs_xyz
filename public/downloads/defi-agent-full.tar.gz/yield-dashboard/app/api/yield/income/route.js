import { NextResponse } from 'next/server';
import { readFileSync } from 'fs';

export const runtime = 'nodejs';

const STATE_PATHS = [
  '/home/node/.openclaw/workspace/yield-agent/yield-sim-state.json',
  process.cwd() + '/../yield-agent/yield-sim-state.json',
  process.cwd() + '/../../yield-agent/yield-sim-state.json',
];

export async function GET() {
  try {
    let state = null;
    for (const p of STATE_PATHS) {
      try {
        state = JSON.parse(readFileSync(p, 'utf8'));
        break;
      } catch { /* try next */ }
    }

    if (!state) {
      return NextResponse.json({
        totalEarnedUsd: 0,
        yieldEvents: [],
        error: 'Yield state file not found — simulation may not have run yet',
      });
    }

    const stratA = state.strategyA || {};
    const stratB = state.strategyB || {};

    const stratAEarned = stratA.totalEarningsUsd || stratA.realizedPnl || 0;
    const stratBEarned = stratB.totalEarningsUsd || stratB.realizedPnl || 0;
    const totalEarnedUsd = Math.round((stratAEarned + stratBEarned) * 100) / 100;

    // Extract individual yield events from history
    const history = state.history || [];
    const yieldEvents = history
      .map(h => ({
        date: h.date || h.timestamp || null,
        earnedUsd: h.earnedUsd || h.earnings || h.pnl || 0,
        pool: h.pool || h.strategy || 'Unknown',
        apy: h.apy || null,
        chain: h.chain || null,
      }))
      .filter(h => h.earnedUsd > 0)
      .sort((a, b) => (b.date || '') > (a.date || '') ? 1 : -1);

    return NextResponse.json({
      totalEarnedUsd,
      stratAEarned: Math.round(stratAEarned * 100) / 100,
      stratBEarned: Math.round(stratBEarned * 100) / 100,
      yieldEvents: yieldEvents.slice(0, 100),
      simulationStart: state.startedAt,
      lastUpdated: state.lastUpdatedAt,
      capital: state.capital,
      cycles: state.cycles || 0,
    });
  } catch (err) {
    console.error('[yield/income]', err.message);
    return NextResponse.json({ error: err.message, totalEarnedUsd: 0, yieldEvents: [] });
  }
}
