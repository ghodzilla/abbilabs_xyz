# Yield Agent — v2.1 Implementation Spec for Code Changes

> **Purpose:** This document tells you exactly what to change in the Yield Agent codebase to upgrade from v1.0 (current `logic.txt`) to v2.1. Each section describes the CURRENT behaviour, the NEW behaviour, and the exact implementation details. Work through each change in order.

---

## CHANGE 1: Correlation Engine — Switch from Raw Prices to Log-Returns

### Current behaviour
Fetches 7 days of hourly prices from `coins.llama.fi/chart/`, runs Pearson correlation directly on the two raw price arrays.

### New behaviour
Convert raw prices to **log-returns** before running Pearson correlation.

### Implementation
```
For each token's price series [P_0, P_1, P_2, ... P_167]:
  returns[i] = ln(P_i / P_{i-1})   // for i = 1 to 167
  // This gives you 167 return values from 168 prices

correlation = pearson(returns_tokenA, returns_tokenB)
```

### Why
Raw-price Pearson inflates during trending markets. Two tokens both rising 10% show ~1.0 correlation even if their daily moves are uncorrelated. Log-return correlation measures co-movement of actual price changes, which is what matters for IL.

### Threshold adjustments (return correlation is stricter, so thresholds are slightly relaxed)
- T1 pairs: >= 0.95 (was 0.98)
- T2 pairs: >= 0.60 (was 0.70)
- Strategy A entry gate: >= 0.60 (was 0.70)
- Strategy A correlation breach exit: < 0.40 (was < 0.50)

---

## CHANGE 2: Block on Missing Data (was Pass by Default)

### Current behaviour
If fewer than 10 data points are returned from DeFiLlama, the pool passes the correlation check by default.

### New behaviour
If fewer than 10 data points → **BLOCK by default**. Missing data usually means a new or illiquid token, which is higher risk.

### Exception
Allow the pool through ONLY if BOTH conditions are met:
- Pool TVL >= $10M (double the normal $1M minimum)
- The pair is classified as Tier 1

---

## CHANGE 3: APY Stability Filter (New Pool Filter)

### Current behaviour
No check on APY stability. A pool that spiked from 5% to 60% overnight passes if current APY is in the 5-80% range.

### New behaviour
Add a new filter to LP pool candidate selection. Calculate the **coefficient of variation (CoV)** of the pool's APY over the last 7 days. If CoV >= 0.5, reject the pool.

### Implementation
```
CoV = standard_deviation(apy_samples_7d) / mean(apy_samples_7d)
if CoV >= 0.5 → reject pool
```

### Where to get data
DeFiLlama pool endpoint returns historical APY data. Use the last 7 days of data points.

### Why
DeFiLlama APY is trailing/backward-looking. A pool that spiked once will show high APY but you won't earn that going forward. This filters out noise.

---

## CHANGE 4: Gas Cost Model (New)

### Current behaviour
No gas cost consideration. The agent rotates freely regardless of chain.

### New behaviour
Before entering any pool, check that the projected yield exceeds the gas cost.

### Gas cost lookup table (store as config, not hardcoded)
```json
{
  "base":     { "enter": 0.05, "exit": 0.05, "minHoldDays": 0 },
  "arbitrum": { "enter": 0.10, "exit": 0.10, "minHoldDays": 0 },
  "solana":   { "enter": 0.02, "exit": 0.02, "minHoldDays": 0 },
  "ethereum": { "enter": 30.00, "exit": 25.00, "minHoldDays": 3 }
}
```

### Entry gate formula
```
gas_roundtrip = gasCosts[chain].enter + gasCosts[chain].exit
min_hold = max(gasCosts[chain].minHoldDays, 1)
projected_yield = 500 * (apy / 100) / 365 * min_hold

if projected_yield < 2 * gas_roundtrip → skip this pool
```

### Also apply on exit
When calculating earnings for a position that is exiting, subtract the gas_roundtrip from the crystallised earnings.

---

## CHANGE 5: Dynamic IL Estimation (Replaces Static Buckets)

### Current behaviour
Strategy B uses static IL penalty: 1.0 for lending, 0.85 for "low IL", 0.65 for "high IL".

### New behaviour
Calculate actual IL estimate from the 7-day price ratio between pool tokens.

### Implementation
```
ratio_now = price_tokenA_now / price_tokenB_now
ratio_7d_ago = price_tokenA_7d_ago / price_tokenB_7d_ago
ratio_change = ratio_now / ratio_7d_ago

IL_estimate = 2 * sqrt(ratio_change) / (1 + ratio_change) - 1
// IL_estimate will be negative (a loss). Take abs() for use in scoring.
```

### How it plugs into Strategy B scoring
Replace the old static IL_penalty with:
```
For lending positions: IL_dynamic = 1.0
For LP positions: IL_dynamic = 1.0 - abs(IL_estimate * 52)
// *52 annualises the weekly IL estimate
// Clamp IL_dynamic to minimum 0.0
```

---

## CHANGE 6: Strategy B Scoring Formula Update

### Current formula
```
score = (APY/80) * 0.5 + log10(TVL/1000000)/3 * 0.35 + IL_penalty * 0.15
```

### New formula
```
score = (APY/80) * 0.45
      + log10(TVL/1000000)/3 * 0.30
      + IL_dynamic * 0.15
      + APY_stability * 0.10
```

### New component: APY_stability
```
APY_stability = 1.0 - CoV(apy_samples_7d)
// Clamp to minimum 0.0
// Rewards pools with consistent yield
```

### New component: tax_efficiency (add to rotation logic, see Change 13)
When comparing pool candidates during rotation, lending positions get a tax_efficiency bonus of 1.0, LP positions get 0.85. This is used as a tiebreaker, not a scoring weight.

---

## CHANGE 7: 7-Day Window — Change from Forced Exit to Review-and-Renew

### Current behaviour
Position open > 7 days → always exit, no exceptions.

### New behaviour
Position open > 7 days → **REVIEW**:
1. Run all entry criteria against the current pool (correlation check, APY filters, gas gate)
2. If the pool STILL passes all entry criteria → reset the window timer, keep the position open
3. If the pool would NO LONGER be selected → exit as normal

### Why
The old logic forced exits from perfectly good positions just to re-enter the same pool moments later, paying gas and creating a CGT event for zero benefit.

---

## CHANGE 8: APY Collapse — Add Absolute Floor

### Current behaviour
Exit if current APY dropped > 50% from entry APY. That's the only check.

### New behaviour
Exit if current APY dropped > 50% from entry APY **AND** current APY is below an absolute floor:
- Strategy A floor: 5%
- Strategy B floor: the current best lending rate (query this from pool data)

### Example
- Entered at 60%, now at 29% → 50%+ drop but 29% > 5% → STAY (still earning well)
- Entered at 8%, now at 3.5% → 50%+ drop and 3.5% < 5% → EXIT (not worth the risk)

---

## CHANGE 9: Yield Override — Add TVL and IL Checks

### Current behaviour
Strategy A holds through correlation dips if the pair is in the override list AND APY >= 50%.

### New behaviour
Override conditions — ALL three must be true:
1. APY still >= 50% (unchanged)
2. **NEW:** Pool TVL has NOT dropped > 15% in the last 24 hours
3. **NEW:** Dynamic IL estimate (abs value, annualised) < current APY

### Implementation for TVL check
Store `tvl_24h_ago` in state for each position. On each cycle:
```
tvl_drop = (tvl_24h_ago - tvl_now) / tvl_24h_ago
if tvl_drop > 0.15 → yield override DENIED, exit the position
```

### Implementation for IL vs yield check
```
annual_IL = abs(IL_estimate) * 52   // annualise the 7-day IL
if annual_IL >= (APY / 100) → yield override DENIED, exit
```

---

## CHANGE 10: Strategy B — Dynamic Lending/LP Split

### Current behaviour
Fixed allocation: up to 2 lending + 3 LP = 5 positions.

### New behaviour
**Default:** up to 2 lending + 3 LP (same as before).

**Dynamic adjustment:**
- If fewer than 3 LP candidates pass the correlation gate → fill remaining slots with lending instead of forcing bad LP entries
- If the circuit breaker is active (see Change 11) → move ALL 5 positions to lending

### Implementation
```
lp_candidates = filterAndScore(pools)  // only those passing correlation + APY + gas
lp_count = min(3, lp_candidates.length)
lending_count = 5 - lp_count

// If circuit breaker active:
if circuitBreaker.active:
  lp_count = 0
  lending_count = 5
```

---

## CHANGE 11: Portfolio Circuit Breaker (New)

### Current behaviour
No portfolio-level risk management. The agent keeps rotating even during a market crash.

### New behaviour
Track a rolling 24-hour peak portfolio value. If total portfolio drops > 5% from peak:

1. Set `circuitBreaker.active = true` in state
2. At next cron cycle: exit ALL LP positions in both strategies
3. Move all capital to highest-APY stablecoin lending positions
4. Log the event with timestamp and drawdown amount

### Resume condition
After 24 hours of stability (portfolio value flat or rising across 8 consecutive cycles):
```
circuitBreaker.active = false
// Resume normal Strategy A and B logic on next cycle
```

### State fields to add
```json
{
  "circuitBreaker": {
    "active": false,
    "triggeredAt": null,
    "peakValue24h": 5000,
    "stableCount": 0
  }
}
```

### Update peak every cycle
```
if portfolioValue > state.circuitBreaker.peakValue24h:
  state.circuitBreaker.peakValue24h = portfolioValue

// Reset peak every 24 hours (8 cycles) to prevent stale peaks
// Use a rolling window, not a fixed 24h clock
```

---

## CHANGE 12: Profit Booking Logic (New — entire new module)

### Current behaviour
Earnings accrue on each position and only crystallise at exit. No protection during the position's life.

### 12a: Cycle-Level Crystallisation
Every 3-hour cycle, split each position's earnings into two buckets:
```json
{
  "crystallisedEarnings": 0,   // banked, safe
  "atRiskCapital": 500         // original capital + unbanked profit
}
```

### 12b: High-Water Mark Protection
When a position's cumulative earnings exceed 2% of position size ($10 on $500):
```
banked = cumulative_earnings * 0.70
at_risk = cumulative_earnings * 0.30
position.crystallisedEarnings += banked
// at_risk stays exposed to IL/exit risk
```

Apply this check every cycle once the threshold is crossed.

### 12c: Strategy-Specific Profit Rules

**Strategy A (aggressive):**
```
// Compound profits back into position up to 120% of original
max_position = 500 * 1.20  // $600
if position.value > max_position:
  excess = position.value - max_position
  sweep excess to profitVault (stablecoin lending position)
  position.value = max_position
```

**Strategy B (conservative):**
```
// Sweep ALL profits to lending every cycle
if position.earnings_this_cycle > 0:
  sweep position.earnings_this_cycle to profitVault
  // Position stays at base $500 value
```

### 12d: Idle Capital Parking
When a position exits and the agent hasn't found a replacement yet:
```
idle_capital = position.value + position.crystallisedEarnings
// Immediately place in highest-APY stablecoin lending pool
// Track as a temporary "parking" position
// Replace with real position when a candidate is found
```

### 12e: Profit-Based Early Exit (New Exit Trigger)
Add this as the FIRST exit trigger checked (before window end):
```
if position.cumulative_return >= 0.05:  // 5% return ($25 on $500)
  → EXIT with profit
  // Log as "profit_take" exit reason
```

---

## CHANGE 13: Australian Tax-Aware Logic (New — entire new module)

### Overview
The agent now tracks tax implications to give meaningful after-tax comparisons. This is for SIMULATION purposes — no actual tax filing.

### 13a: New State Fields per Position
Add these to every position object in the state file:
```json
{
  "costBasisAUD": 0,           // AUD value of assets at entry
  "proceedsAUD": 0,            // AUD value at exit (filled on exit)
  "cgtGain": 0,                // proceedsAUD - costBasisAUD (filled on exit)
  "yieldIncomeAUD": 0,         // running total of yield income in AUD
  "gasDeductibleAUD": 0,       // total gas costs in AUD (tax deductible)
  "isLending": false,          // lending positions may avoid CGT on entry/exit
  "audSnapshots": []           // AUD value at each 3-hour cycle for yield income tracking
}
```

### 13b: AUD Valuation on Every Cycle
Every 3-hour cycle, for every open position:
```
yield_this_cycle_aud = position_earnings_this_cycle_in_usd * usd_to_aud_rate
position.yieldIncomeAUD += yield_this_cycle_aud
position.audSnapshots.push({
  timestamp: now,
  yieldAUD: yield_this_cycle_aud,
  totalYieldAUD: position.yieldIncomeAUD
})
```

For USD/AUD rate: use a simple API call or hardcode a reasonable rate (e.g. 1.55) with a config option to update.

### 13c: CGT Tracking on Entry and Exit

**On entry:**
```
position.costBasisAUD = position_value_usd * usd_to_aud_rate
```

**On exit:**
```
position.proceedsAUD = position_value_usd * usd_to_aud_rate
position.cgtGain = position.proceedsAUD - position.costBasisAUD
// Note: for lending positions where you get the same stablecoin back,
// the CGT gain is likely $0 or near-$0. Flag isLending = true for these.
```

### 13d: Tax-Aware Rotation Threshold
Before rotating OUT of a profitable position into a new one, check:
```
unrealised_gain = current_value_aud - costBasisAUD
estimated_tax = unrealised_gain * marginal_rate   // default 0.32 (30% + 2% Medicare)

new_pool_benefit = (new_apy - current_apy) / 100 * 500 / 365 * expected_hold_days
gas_cost = gasCosts[chain].enter + gasCosts[chain].exit

if new_pool_benefit <= estimated_tax + gas_cost:
  → DO NOT ROTATE, keep current position
```

### 13e: Marginal Rate Configuration
Store as a config value, default to 0.32 (the 30% bracket + 2% Medicare). The user should be able to set this based on their actual income:
```json
{
  "tax": {
    "marginalRate": 0.32,
    "medicareLevy": 0.02,
    "effectiveRate": 0.32,
    "cgtDiscount": false,
    "usdToAud": 1.55
  }
}
```
Note: `cgtDiscount` is always false because positions are held < 12 months.

### 13f: After-Tax Return Calculation
On every cycle, calculate and store in state:
```
For each strategy:
  gross_return = sum of all position earnings
  total_cgt = sum of all cgtGain from exited positions * marginalRate
  total_income_tax = sum of all yieldIncomeAUD * marginalRate
  total_gas_deduction = sum of all gasDeductibleAUD * marginalRate  // tax saving
  
  after_tax_return = gross_return - total_cgt - total_income_tax + total_gas_deduction
```

### 13g: Lending Tax Efficiency in Strategy B Scoring
When Strategy B is scoring pool candidates for rotation:
```
// After computing the main score, apply tax efficiency bonus
if pool.isLending:
  adjusted_score = score * 1.05   // 5% bonus for avoiding CGT drag
// LP positions keep their raw score
```

### 13h: EOFY Tax Export
Add a function that can be called to export tax data:
```
exportTaxSummary(startDate, endDate) → CSV file with columns:
  - date, event_type (entry/exit/yield), pool, chain, pair
  - costBasisAUD, proceedsAUD, cgtGainAUD
  - yieldIncomeAUD
  - gasDeductibleAUD
  - strategy (A or B)
```
This CSV can be imported into Koinly, CryptoTaxCalculator, or given to an accountant.

---

## CHANGE 14: Earnings Calculation Updates

### Current formula
```
earnings = 500 * (apy / 100) / 365 * daysSince
```

### New formula (same base, but with deductions and tracking)
```
gross_earnings = position.atRiskCapital * (apy / 100) / 365 * daysSince
// Note: atRiskCapital, not always $500 — Strategy A compounds up to $600

gas_this_cycle = (any rotations happened?) ? gas_roundtrip : 0
net_earnings = gross_earnings - gas_this_cycle

// Record AUD value for tax
yield_aud = net_earnings * usd_to_aud_rate
position.yieldIncomeAUD += yield_aud

// Apply profit booking
applyProfitBooking(position, net_earnings)  // see Change 12
```

---

## CHANGE 15: State File Updates

### New fields to add to yield-sim-state.json

```json
{
  "version": "2.1",
  "circuitBreaker": {
    "active": false,
    "triggeredAt": null,
    "peakValue24h": 5000,
    "stableCount": 0
  },
  "profitVault": {
    "strategyA": { "balance": 0, "pool": null },
    "strategyB": { "balance": 0, "pool": null }
  },
  "tax": {
    "marginalRate": 0.32,
    "usdToAud": 1.55,
    "strategyA": {
      "totalCGT_AUD": 0,
      "totalYieldIncome_AUD": 0,
      "totalGasDeductible_AUD": 0,
      "afterTaxReturn_AUD": 0
    },
    "strategyB": {
      "totalCGT_AUD": 0,
      "totalYieldIncome_AUD": 0,
      "totalGasDeductible_AUD": 0,
      "afterTaxReturn_AUD": 0
    }
  },
  "positions": {
    "strategyA": [
      {
        "pool": "...",
        "chain": "...",
        "pair": "...",
        "isLending": false,
        "entryDate": "...",
        "entryApy": 0,
        "entryCorrelation": 0,
        "estimatedGas": 0,
        "costBasisAUD": 0,
        "proceedsAUD": 0,
        "cgtGain": 0,
        "yieldIncomeAUD": 0,
        "gasDeductibleAUD": 0,
        "crystallisedEarnings": 0,
        "atRiskCapital": 500,
        "cumulativeReturn": 0,
        "tvl_24h_ago": 0,
        "audSnapshots": []
      }
    ],
    "strategyB": []
  }
}
```

---

## CHANGE 16: Final Recommendation Update

### Current behaviour
Day 14: whichever strategy has higher balance wins.

### New behaviour
**Day 30** (extended from 14). The recommendation fires only if:
1. At least one circuit breaker activation has occurred (proves stress-tested)
2. If no drawdown by Day 30, extend to Day 60 max

### Winner determination
```
// NOT just raw balance. Use after-tax, risk-adjusted return:
sharpe_A = afterTaxReturn_A / maxDrawdown_A
sharpe_B = afterTaxReturn_B / maxDrawdown_B

winner = (sharpe_A > sharpe_B) ? "Strategy A" : "Strategy B"
```

Strategy B may win even with lower gross yield because:
- Fewer CGT events (lending avoids rotation CGT)
- Lower drawdowns (conservative allocation)
- Tax-adjusted returns can flip the result

---

## SUMMARY: Order of Implementation

1. Correlation engine → log-returns + new thresholds + block on missing data
2. APY stability filter (CoV < 0.5)
3. Gas cost model + entry gate
4. Dynamic IL estimation
5. Strategy B scoring formula update
6. 7-day window → review-and-renew
7. APY collapse → add absolute floor
8. Yield override → add TVL + IL checks
9. Strategy B → dynamic lending/LP split
10. Circuit breaker (new module)
11. Profit booking (new module)
12. Australian tax tracking (new module)
13. Tax-aware rotation threshold
14. Earnings calculation updates
15. State file schema update
16. Final recommendation → Day 30, after-tax, risk-adjusted
17. EOFY tax export function

> **Important:** After implementing, update `logic.txt` to match v2.1 so the documentation stays in sync with the code.
