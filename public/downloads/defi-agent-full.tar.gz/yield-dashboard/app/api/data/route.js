import { NextResponse } from 'next/server';

const RAW_URL = 'https://raw.githubusercontent.com/ghodzilla/abbilabs_xyz/main/data/yield-sim-state.json';

export async function GET() {
  try {
    const res = await fetch(RAW_URL, {
      headers: { 'User-Agent': 'AbbiLabs/1.0' },
      next: { revalidate: 300 },
    });
    if (!res.ok) throw new Error('Simulation not started yet — run yield-sim.cjs on the VPS first.');
    return NextResponse.json({ ok: true, data: await res.json() });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e.message }, { status: 500 });
  }
}
