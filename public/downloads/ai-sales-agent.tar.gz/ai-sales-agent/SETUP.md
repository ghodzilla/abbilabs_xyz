# AI Sales Agent — Setup Guide

Total time: ~15 minutes

---

## Step 1: HubSpot (5 minutes)

You need a HubSpot account with API access. Free tier works.

### Create a Private App
1. Go to **Settings → Integrations → Private Apps**
   - New HubSpot UI: Settings → Account Management → Integrations → Legacy Apps → Private Apps
2. Click **Create a private app**
3. Name it: `AI Sales Agent`
4. Under **Scopes**, enable:
   - `crm.objects.contacts.read`
   - `crm.objects.contacts.write`
   - `crm.objects.deals.read`
   - `crm.objects.deals.write`
   - `crm.objects.companies.read`
5. Click **Create app** → copy the **Access Token**

### Set Environment Variable
```bash
export HUBSPOT_ACCESS_TOKEN="pat-xx-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
```

---

## Step 2: Google Sheets (5 minutes)

### Create a Service Account
1. Go to **https://console.cloud.google.com/iam-admin/serviceaccounts**
2. Create a new service account (any name)
3. Grant it **Editor** role
4. Create a **JSON key** → download it

### Enable APIs
1. Go to **https://console.cloud.google.com/apis/library**
2. Enable **Google Sheets API**
3. Enable **Google Drive API**

### Create Your Tracking Spreadsheet
1. Go to Google Sheets → create a new spreadsheet
2. Name it: `Sales Pipeline Tracker`
3. Create 4 tabs:
   - **Leads** — headers: `Date | Name | Email | Company | Title | Score | Source | Status`
   - **Deals** — headers: `Date | Deal Name | Company | Old Stage | New Stage | Amount | Owner`
   - **Follow-ups** — headers: `Date | Contact | Deal | Days Since Contact | Value | Recommended Action`
   - **Reports** — headers: `Date | Pipeline Value | New Leads | Deals Progressed | Closed Won | Closed Lost | Revenue | Conversion Rate`
4. Click **Share** → add your service account email as **Editor**

### Set Environment Variables
```bash
export GOOGLE_SERVICE_ACCOUNT_KEY_FILE="/path/to/your/service-account-key.json"
```

### Update config.json
Replace `YOUR_SPREADSHEET_ID` with your spreadsheet ID (from the URL: `docs.google.com/spreadsheets/d/{THIS_PART}/edit`)

---

## Step 3: Slack (3 minutes)

### Create a Slack App
1. Go to **https://api.slack.com/apps**
2. Click **Create New App → From scratch**
3. Name it: `Sales Agent`
4. Under **OAuth & Permissions**, add scopes:
   - `chat:write`
   - `channels:read`
   - `channels:join`
5. **Install to workspace** → copy the **Bot User OAuth Token**

### Create Slack Channels
Create these channels in your workspace (or use existing ones):
- `#sales` — daily reports and warm lead notifications
- `#sales-alerts` — hot leads and high-value deal alerts

### Invite the Bot
In each channel, type: `/invite @Sales Agent`

### Set Environment Variable
```bash
export SLACK_BOT_TOKEN="xoxb-your-token-here"
```

---

## Step 4: Configure Your Agent (2 minutes)

### Edit config.json
1. Set your **spreadsheet_id**
2. Adjust **scoring rules** to match your ideal customer profile
3. Set **thresholds** (hot/warm lead scores)
4. Set **Slack channel names**
5. Set **follow-up timing** (days before flagging stale leads)

### Edit AGENT.md
1. Adjust the agent's behaviour to match your sales process
2. Modify escalation rules if needed
3. Set your preferred communication style

---

## Step 5: Run It

### OpenClaw
```bash
# Copy the template to your skills directory
cp -r ai-sales-agent/ /path/to/openclaw/workspace/skills/

# The agent will pick it up automatically
```

### Claude API
```python
# Load AGENT.md as system prompt
system_prompt = open("AGENT.md").read()

# Define tools pointing to the scripts
tools = [
    {"name": "hubspot", "command": "node scripts/hubspot.cjs"},
    {"name": "sheets", "command": "node scripts/sheets.cjs"},
    {"name": "slack", "command": "node scripts/slack.cjs"},
    {"name": "lead_scorer", "command": "node scripts/lead-scorer.cjs"},
]
```

### GPT API
```python
# Same approach — load AGENT.md as system message
# Define function schemas for each script
# The scripts are called the same way regardless of LLM
```

### LangChain / CrewAI / Other
```python
# Use subprocess to call scripts as tools
# WORKFLOWS.md defines the chain/task logic
# config.json parameterises everything
```

---

## Verification Checklist

After setup, verify each integration:

```bash
# Test HubSpot
node scripts/hubspot.cjs list-contacts
# Should return your contacts

# Test Google Sheets
node scripts/sheets.cjs read YOUR_SPREADSHEET_ID Leads!A1:H1
# Should return your headers

# Test Slack
node scripts/slack.cjs send "#sales" "🤖 Sales Agent is online!"
# Should post to your channel

# Test Lead Scorer
node scripts/lead-scorer.cjs score --test
# Should return a sample score breakdown
```

If all 4 work, your AI Sales Agent is ready. 🚀

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| HubSpot 401 | Check your access token. Make sure scopes are correct. |
| Sheets 403 | Share the spreadsheet with your service account email. |
| Slack `not_in_channel` | Invite the bot to the channel: `/invite @Sales Agent` |
| Score always 0 | Check that HubSpot contact properties match your scoring rules. |
| No new leads detected | The agent checks contacts created since last run. First run may show 0. |
