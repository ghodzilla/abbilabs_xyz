import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

const ALCHEMY_NETWORKS = {
  ethereum: 'eth-mainnet',
  base: 'base-mainnet',
  arbitrum: 'arb-mainnet',
  optimism: 'opt-mainnet',
  polygon: 'polygon-mainnet',
};

/**
 * Normalise an Alchemy asset transfer to the shared transaction format:
 * { hash, from, to, value, asset, timestamp, type: 'in'|'out' }
 */
function normaliseAlchemyTransfer(transfer, direction) {
  const value = transfer.value != null
    ? parseFloat(transfer.value).toFixed(6)
    : '0.000000';

  // metadata.blockTimestamp is ISO-8601 when withMetadata: true
  const timestamp = transfer.metadata?.blockTimestamp
    ? new Date(transfer.metadata.blockTimestamp).toISOString()
    : new Date().toISOString();

  return {
    hash: transfer.hash,
    from: transfer.from,
    to: transfer.to,
    value,
    asset: transfer.asset || 'ETH',
    timestamp,
    type: direction,
    category: transfer.category,   // 'external' | 'internal' | 'erc20' | 'erc721' | 'erc1155'
    tokenId: transfer.tokenId || null,
    rawContract: transfer.rawContract || null,
  };
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const address = searchParams.get('address');
  const network = searchParams.get('network') || 'ethereum';

  if (!address || !/^0x[a-fA-F0-9]{40}$/.test(address)) {
    return NextResponse.json({ error: 'Invalid address' }, { status: 400 });
  }

  // Resolve Alchemy network up front — undefined means unsupported chain
  const alchemyNetwork = ALCHEMY_NETWORKS[network];
  const alchemyKey = process.env.ALCHEMY_API_KEY;

  // Network not in Alchemy map (e.g. solana) — return empty gracefully
  if (!alchemyNetwork) {
    console.warn(`[transactions] Network '${network}' not in Alchemy map — returning empty`);
    return NextResponse.json({
      address,
      network,
      transactions: [],
      dataSource: 'none',
      source: 'none',
      fetchedAt: new Date().toISOString(),
    });
  }

  try {
    // ── 1. Try Alchemy alchemy_getAssetTransfers (all chains) ────────────────
    if (alchemyKey) {
      const alchemyUrl = `https://${alchemyNetwork}.g.alchemy.com/v2/${alchemyKey}`;

      try {
        // Fetch incoming and outgoing transfers in parallel
        const [inRes, outRes] = await Promise.all([
          fetch(alchemyUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              jsonrpc: '2.0',
              id: 1,
              method: 'alchemy_getAssetTransfers',
              params: [{
                toAddress: address,
                category: ['external', 'internal', 'erc20', 'erc721', 'erc1155'],
                maxCount: '0x32',  // 50
                order: 'desc',
                withMetadata: true,
              }],
            }),
          }),
          fetch(alchemyUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              jsonrpc: '2.0',
              id: 2,
              method: 'alchemy_getAssetTransfers',
              params: [{
                fromAddress: address,
                category: ['external', 'internal', 'erc20', 'erc721', 'erc1155'],
                maxCount: '0x32',
                order: 'desc',
                withMetadata: true,
              }],
            }),
          }),
        ]);

        const [inData, outData] = await Promise.all([inRes.json(), outRes.json()]);

        if (inData.error || outData.error) {
          const errMsg = inData.error?.message || outData.error?.message || 'Alchemy error';
          throw new Error(errMsg);
        }

        const inTransfers = (inData.result?.transfers || []).map(t => normaliseAlchemyTransfer(t, 'in'));
        const outTransfers = (outData.result?.transfers || []).map(t => normaliseAlchemyTransfer(t, 'out'));

        // Merge and sort by timestamp desc; deduplicate by hash+type
        const seen = new Set();
        const transactions = [...inTransfers, ...outTransfers]
          .filter(tx => {
            const key = `${tx.hash}-${tx.type}`;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
          })
          .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
          .slice(0, 100); // cap at 100

        return NextResponse.json({
          address,
          network,
          transactions,
          dataSource: 'alchemy',
          source: `alchemy:${alchemyNetwork}`,
          fetchedAt: new Date().toISOString(),
        });
      } catch (alchemyErr) {
        console.warn('[transactions] Alchemy failed, falling back to Etherscan:', alchemyErr.message);
        // Fall through to Etherscan fallback
      }
    }

    // ── 2. Etherscan fallback (Ethereum mainnet only) ────────────────────────
    const etherscanKey = process.env.ETHERSCAN_API_KEY || 'YourApiKeyToken';
    const res = await fetch(
      `https://api.etherscan.io/api?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&page=1&offset=50&sort=desc&apikey=${etherscanKey}`
    );
    const data = await res.json();

    if (data.status !== '1' && data.message !== 'No transactions found') {
      return NextResponse.json({
        error: data.message || 'Etherscan error',
        transactions: [],
        dataSource: 'etherscan',
      }, { status: 200 });
    }

    const addrLower = address.toLowerCase();
    const transactions = (data.result || []).map(tx => ({
      hash: tx.hash,
      from: tx.from,
      to: tx.to,
      value: (parseInt(tx.value, 10) / 1e18).toFixed(6),
      asset: 'ETH',
      timestamp: new Date(parseInt(tx.timeStamp, 10) * 1000).toISOString(),
      type: tx.to?.toLowerCase() === addrLower ? 'in' : 'out',
      category: 'external',
      gasUsed: tx.gasUsed,
    }));

    return NextResponse.json({
      address,
      network,
      transactions,
      dataSource: 'etherscan',
      source: 'etherscan',
      fetchedAt: new Date().toISOString(),
    });
  } catch (err) {
    return NextResponse.json({ error: err.message || 'Failed to fetch transactions' }, { status: 500 });
  }
}
