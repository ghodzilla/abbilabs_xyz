@echo off
echo Opening Yield Dashboard tunnel...
echo Keep this window open while using the dashboard.
echo.
echo Dashboard will open at: http://localhost:3001
echo Username: admin
echo Password: aXCe18erULLA5qgBidPznw==
echo.
start "" "http://localhost:3001"
ssh -L 3001:localhost:3001 root@209.38.93.29 -N
