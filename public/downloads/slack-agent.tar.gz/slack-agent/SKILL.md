---
name: slack-agent
description: "Send messages, read channels, manage threads, and automate workflows in Slack via the Web API. Use when: the agent needs to post updates, monitor channels, respond to mentions, manage threads, or integrate Slack into automated workflows. Requires a Slack Bot Token."
homepage: https://api.slack.com/methods
metadata:
  openclaw:
    emoji: "💬"
    requires:
      env:
        - SLACK_BOT_TOKEN
      node: true
    category: "Communication"
    price: "$29"
    platforms: ["OpenClaw"]
    llm_compatible: ["Claude", "GPT", "Any"]
---

# Slack Agent Skill

Full Slack integration for AI agents. Send messages, read channels, manage threads, search conversations, and automate team communication.

## When to Use

✅ **USE this skill when:**
- Sending messages or updates to Slack channels
- Reading channel history or monitoring for keywords
- Responding to mentions or threads
- Creating automated reports that post to Slack
- Managing channel topics, pins, or bookmarks
- Searching across Slack for information
- Building notification systems (alerts, reminders, status updates)

## When NOT to Use

❌ **DON'T use this skill when:**
- Real-time websocket listening → use Slack's Events API or Socket Mode
- Building interactive Slack apps with buttons/modals → use Bolt framework
- Managing Slack workspace settings (admin functions) → use Admin API
- Handling Slack Connect (cross-org channels) → requires Enterprise Grid

## Setup (One-Time)

### 1. Create a Slack App
1. Go to [api.slack.com/apps](https://api.slack.com/apps)
2. Click **Create New App** → **From scratch**
3. Name it (e.g., `AI Agent`) and select your workspace

### 2. Configure Bot Token Scopes
Go to **OAuth & Permissions** → **Scopes** → **Bot Token Scopes** and add:
- `channels:history` — Read messages in public channels
- `channels:read` — List public channels
- `chat:write` — Send messages
- `chat:write.customize` — Send messages with custom username/icon
- `groups:history` — Read messages in private channels (if needed)
- `groups:read` — List private channels (if needed)
- `im:history` — Read DMs (if needed)
- `im:write` — Send DMs (if needed)
- `pins:read` — Read pinned items
- `pins:write` — Pin/unpin messages
- `reactions:read` — Read reactions
- `reactions:write` — Add reactions
- `search:read` — Search messages
- `users:read` — Read user profiles

### 3. Install the App
1. Click **Install to Workspace**
2. Authorize the permissions
3. Copy the **Bot User OAuth Token** (starts with `xoxb-`)

### 4. Configure the Skill
```bash
export SLACK_BOT_TOKEN="xoxb-your-token-here"
```

### 5. Invite the Bot
Invite the bot to any channel it needs to access:
```
/invite @AI Agent
```

## Commands

All commands use the script at `scripts/slack.cjs`.

### Send Message

```bash
# Send to a channel
node scripts/slack.cjs send <channel> "<message>"

# Send to #general
node scripts/slack.cjs send "#general" "Daily report: Revenue up 15% 📈"

# Send with markdown
node scripts/slack.cjs send "#engineering" "*Deploy complete* ✅\n• Service A: v2.3.1\n• Service B: v1.8.0"

# Send to a user (DM)
node scripts/slack.cjs send "@alice" "Hey, your report is ready"
```

### Reply to Thread

```bash
# Reply in a thread
node scripts/slack.cjs reply <channel> <thread_ts> "<message>"

# Example
node scripts/slack.cjs reply "#support" "1710000000.000100" "I'll handle this ticket"
```

### Read Channel History

```bash
# Read last N messages
node scripts/slack.cjs history <channel> [limit]

# Read last 10 messages from #general
node scripts/slack.cjs history "#general" 10

# Read last 50 messages
node scripts/slack.cjs history "#sales" 50
```

### Search Messages

```bash
# Search across all channels
node scripts/slack.cjs search "<query>"

# Search for a keyword
node scripts/slack.cjs search "deployment error"

# Search in a specific channel
node scripts/slack.cjs search "in:#engineering bug"

# Search from a specific user
node scripts/slack.cjs search "from:@alice action items"
```

### List Channels

```bash
# List all public channels
node scripts/slack.cjs channels

# Includes: name, id, member count, topic
```

### Get User Info

```bash
# Get user profile
node scripts/slack.cjs user <user_id_or_name>

# Example
node scripts/slack.cjs user "U01ABC123"
```

### React to Message

```bash
# Add a reaction
node scripts/slack.cjs react <channel> <timestamp> <emoji>

# Example
node scripts/slack.cjs react "#general" "1710000000.000100" "white_check_mark"
```

### Pin Message

```bash
# Pin a message
node scripts/slack.cjs pin <channel> <timestamp>

# Unpin
node scripts/slack.cjs unpin <channel> <timestamp>
```

### Set Channel Topic

```bash
# Update channel topic
node scripts/slack.cjs topic <channel> "<topic>"

# Example
node scripts/slack.cjs topic "#daily-standup" "Post your update by 10am UTC"
```

### Upload File / Snippet

```bash
# Share a text snippet
node scripts/slack.cjs snippet <channel> "<title>" "<content>"

# Example: Share a code snippet
node scripts/slack.cjs snippet "#engineering" "Error Log" "$(cat /var/log/error.log | tail -20)"
```

## Common Patterns

### Daily Standup Bot
```bash
# Post standup prompt
node scripts/slack.cjs send "#daily-standup" "🌅 *Daily Standup*\nPlease share:\n• What you did yesterday\n• What you're doing today\n• Any blockers"

# Collect and summarize responses (read, then process)
node scripts/slack.cjs history "#daily-standup" 20
```

### Alert System
```bash
# Revenue alert
node scripts/slack.cjs send "#revenue" "🚨 *Revenue Alert*\nNew sale: $49.00 from Gumroad\nDaily total: $127.00\nMTD: $2,340.00"

# Error alert
node scripts/slack.cjs send "#alerts" "⚠️ *Error Rate Spike*\nService: API Gateway\nRate: 5.2% (threshold: 2%)\nStarted: 14:23 UTC"
```

### Customer Support Queue
```bash
# Search for unresolved tickets
node scripts/slack.cjs search "in:#support -:white_check_mark: -resolved"

# Reply to customer thread
node scripts/slack.cjs reply "#support" "1710000000.000100" "Looking into this now. ETA: 30 minutes."

# Mark as resolved
node scripts/slack.cjs react "#support" "1710000000.000100" "white_check_mark"
```

## Error Handling

| Error | Cause | Fix |
|-------|-------|-----|
| `not_in_channel` | Bot not invited to channel | Run `/invite @BotName` in the channel |
| `channel_not_found` | Wrong channel name or ID | Use `channels` command to list valid channels |
| `invalid_auth` | Bad or expired token | Regenerate the Bot User OAuth Token |
| `missing_scope` | Token lacks required permission | Add the scope in OAuth & Permissions, reinstall |
| `ratelimited` | Too many requests | Script auto-retries with backoff |

## Rate Limits

- Slack Web API: ~1 request/second per method per workspace
- The skill handles rate limiting automatically with exponential backoff
- Burst: up to 30 requests in quick succession, then throttled
- Search API: more restrictive, ~20 requests/minute

## Notes

- Channel names should include `#` prefix (e.g., `#general`)
- User mentions use `@` prefix (e.g., `@alice`)
- Thread timestamps look like `1710000000.000100` — get them from history output
- Messages support Slack's mrkdwn format (not standard markdown)
- The bot can only access channels it's been invited to
