# Yield Agent — v2.2 Self-Improvement Engine

> **Purpose:** This document specifies three levels of self-improvement logic that allow the Yield Agent to learn from its own performance data and get smarter over time. Each level builds on the previous one. Implement in order.
>
> **Prerequisite:** The v2.1 implementation spec must be fully implemented first. This spec assumes all v2.1 state fields, profit booking, tax tracking, circuit breaker, and gas cost model are already in place.

---

## ARCHITECTURE OVERVIEW

### How Self-Improvement Fits Into the Existing Cron Cycle

The current 3-hour cron cycle is:
```
1. Fetch pool data from DeFiLlama
2. Run exit checks on current positions
3. Calculate earnings
4. Rotate into new positions if slots are open
5. Save state, push to GitHub
```

The new cycle becomes:
```
1. Fetch pool data from DeFiLlama
2. Run exit checks on current positions
3. Calculate earnings
4. ──► SELF-IMPROVEMENT: Run learning engine (every 8th cycle = every 24h)
5. Rotate into new positions if slots are open (using updated parameters)
6. Save state, push to GitHub
```

The learning engine runs BEFORE rotation so that any parameter changes apply to the current cycle's decisions.

### New Top-Level State Fields
```json
{
  "learning": {
    "version": "2.2",
    "lastLearnCycle": null,
    "learnCycleCount": 0,
    "parameterHistory": [],
    "poolScores": {},
    "chainScores": {},
    "protocolScores": {},
    "marketRegime": {
      "current": "unknown",
      "confidence": 0,
      "history": []
    }
  }
}
```

---

# LEVEL 1: PARAMETER AUTO-TUNING

## Concept

The agent has ~15 tuneable parameters that are currently hardcoded. Every 24 hours, the agent reviews its recent performance and nudges parameters toward values that would have produced better results. Changes are small and bounded — the agent can't suddenly flip everything upside down.

## 1.1: Tuneable Parameters Registry

Create a config object listing every parameter that can be auto-tuned. Each parameter has a current value, min/max bounds, and a step size (how much it can change per learning cycle).

```json
{
  "tuneableParams": {
    "correlationThreshold_T1": {
      "current": 0.95,
      "min": 0.85,
      "max": 0.99,
      "step": 0.01,
      "description": "Minimum return correlation for Tier 1 pairs"
    },
    "correlationThreshold_T2": {
      "current": 0.60,
      "min": 0.40,
      "max": 0.80,
      "step": 0.02,
      "description": "Minimum return correlation for Tier 2 pairs"
    },
    "correlationEntryGate_A": {
      "current": 0.60,
      "min": 0.40,
      "max": 0.80,
      "step": 0.02,
      "description": "Strategy A entry correlation threshold"
    },
    "correlationBreachExit_A": {
      "current": 0.40,
      "min": 0.20,
      "max": 0.55,
      "step": 0.02,
      "description": "Strategy A correlation breach exit threshold"
    },
    "apyCollapseFloor_A": {
      "current": 5.0,
      "min": 2.0,
      "max": 10.0,
      "step": 0.5,
      "description": "Strategy A absolute APY floor (%)"
    },
    "apyStabilityCoV": {
      "current": 0.50,
      "min": 0.30,
      "max": 0.70,
      "step": 0.05,
      "description": "Maximum APY coefficient of variation for pool entry"
    },
    "profitTakeThreshold": {
      "current": 0.05,
      "min": 0.02,
      "max": 0.10,
      "step": 0.005,
      "description": "Cumulative return % to trigger profit-take exit"
    },
    "circuitBreakerDrop": {
      "current": 0.05,
      "min": 0.03,
      "max": 0.10,
      "step": 0.005,
      "description": "Portfolio drawdown % to trigger circuit breaker"
    },
    "yieldOverrideMinAPY": {
      "current": 50.0,
      "min": 30.0,
      "max": 70.0,
      "step": 2.0,
      "description": "Minimum APY for yield override to hold through correlation dips"
    },
    "tvlDropOverrideMax": {
      "current": 0.15,
      "min": 0.05,
      "max": 0.25,
      "step": 0.02,
      "description": "Max 24h TVL drop allowed during yield override"
    },
    "scoringWeight_APY": {
      "current": 0.45,
      "min": 0.30,
      "max": 0.60,
      "step": 0.025,
      "description": "Strategy B scoring weight for APY component"
    },
    "scoringWeight_TVL": {
      "current": 0.30,
      "min": 0.15,
      "max": 0.40,
      "step": 0.025,
      "description": "Strategy B scoring weight for TVL component"
    },
    "scoringWeight_IL": {
      "current": 0.15,
      "min": 0.05,
      "max": 0.30,
      "step": 0.025,
      "description": "Strategy B scoring weight for IL component"
    },
    "scoringWeight_stability": {
      "current": 0.10,
      "min": 0.05,
      "max": 0.25,
      "step": 0.025,
      "description": "Strategy B scoring weight for APY stability component"
    },
    "highWaterMarkBankPercent": {
      "current": 0.70,
      "min": 0.50,
      "max": 0.90,
      "step": 0.05,
      "description": "Percentage of earnings to bank at high-water mark"
    }
  }
}
```

**IMPORTANT CONSTRAINT:** Scoring weights (scoringWeight_*) must always sum to 1.0. When adjusting any scoring weight, proportionally adjust the others to maintain the sum. Use this normalisation:
```
total = sum of all scoringWeight values
for each scoringWeight:
  scoringWeight.current = scoringWeight.current / total
```

## 1.2: Performance Evaluation Function

Every 24 hours (every 8th cycle), run this evaluation across all positions that were active or exited in the past 7 days:

```
function evaluatePerformance(positions_last_7d):

  metrics = {
    profitable_exits: 0,
    unprofitable_exits: 0,
    correlation_breach_exits_that_recovered: 0,
    correlation_breach_exits_that_didnt: 0,
    apy_collapse_exits_that_were_right: 0,
    apy_collapse_exits_that_were_wrong: 0,
    profit_takes_where_position_kept_climbing: 0,
    profit_takes_where_position_declined_after: 0,
    yield_overrides_that_paid_off: 0,
    yield_overrides_that_lost: 0,
    avg_position_return: 0,
    avg_hold_duration_days: 0,
    circuit_breaker_activations: 0,
    false_alarm_circuit_breakers: 0
  }

  for each exited position:
    // Was the exit profitable?
    if position.netReturn > 0:
      metrics.profitable_exits++
    else:
      metrics.unprofitable_exits++

    // For correlation breach exits: did the pool recover within 24h?
    if position.exitReason == "correlation_breach":
      pool_data_after_exit = fetchPoolData(position.pool, position.exitDate, +24h)
      if pool_correlation_recovered_above_threshold:
        metrics.correlation_breach_exits_that_recovered++
      else:
        metrics.correlation_breach_exits_that_didnt++

    // For profit-take exits: did the pool keep climbing?
    if position.exitReason == "profit_take":
      pool_apy_24h_later = fetchPoolAPY(position.pool, position.exitDate + 24h)
      if pool_apy_24h_later > position.exitApy * 0.8:  // still going strong
        metrics.profit_takes_where_position_kept_climbing++
      else:
        metrics.profit_takes_where_position_declined_after++

  return metrics
```

## 1.3: Parameter Adjustment Rules

Based on the metrics, adjust each parameter by ONE step in the appropriate direction. Never adjust more than one step per learning cycle. This prevents wild swings.

```
function adjustParameters(metrics, params):

  // --- Correlation thresholds ---
  // If we're exiting for correlation breach but pools keep recovering,
  // our thresholds are too tight → loosen them
  if metrics.correlation_breach_exits_that_recovered > metrics.correlation_breach_exits_that_didnt:
    params.correlationBreachExit_A.current -= params.correlationBreachExit_A.step
    params.correlationEntryGate_A.current -= params.correlationEntryGate_A.step

  // If correlation breaches are leading to real losses, tighten
  if metrics.correlation_breach_exits_that_didnt > metrics.correlation_breach_exits_that_recovered * 2:
    params.correlationBreachExit_A.current += params.correlationBreachExit_A.step
    params.correlationEntryGate_A.current += params.correlationEntryGate_A.step

  // --- Profit take threshold ---
  // If most profit-takes were followed by the pool still climbing,
  // we're taking profit too early → raise threshold
  if metrics.profit_takes_where_position_kept_climbing > metrics.profit_takes_where_position_declined_after * 1.5:
    params.profitTakeThreshold.current += params.profitTakeThreshold.step

  // If most profit-takes were followed by decline, threshold is right or too high
  if metrics.profit_takes_where_position_declined_after > metrics.profit_takes_where_position_kept_climbing * 1.5:
    params.profitTakeThreshold.current -= params.profitTakeThreshold.step

  // --- Circuit breaker ---
  // If circuit breaker fires but portfolio recovers quickly (false alarm)
  if metrics.false_alarm_circuit_breakers > 0 && metrics.circuit_breaker_activations > 0:
    false_alarm_rate = metrics.false_alarm_circuit_breakers / metrics.circuit_breaker_activations
    if false_alarm_rate > 0.5:
      params.circuitBreakerDrop.current += params.circuitBreakerDrop.step  // make less sensitive

  // If circuit breaker never fires but we had significant drawdowns
  if metrics.circuit_breaker_activations == 0 && metrics.max_drawdown > params.circuitBreakerDrop.current:
    params.circuitBreakerDrop.current -= params.circuitBreakerDrop.step  // make more sensitive

  // --- APY floor ---
  // If most APY collapse exits were from positions still earning decent yield,
  // floor is too high
  if metrics.apy_collapse_exits_that_were_wrong > metrics.apy_collapse_exits_that_were_right:
    params.apyCollapseFloor_A.current -= params.apyCollapseFloor_A.step

  // --- Scoring weights ---
  // Track which scoring component best predicted actual returns
  // Increase weight of the most predictive component, decrease others
  component_correlations = correlateComponentsToReturns(positions_last_7d)
  best_component = max(component_correlations)
  worst_component = min(component_correlations)
  params["scoringWeight_" + best_component].current += params["scoringWeight_" + best_component].step
  params["scoringWeight_" + worst_component].current -= params["scoringWeight_" + worst_component].step
  normaliseScoringWeights(params)  // ensure they sum to 1.0

  // --- Enforce bounds on all parameters ---
  for each param in params:
    param.current = clamp(param.current, param.min, param.max)

  return params
```

## 1.4: Parameter History and Rollback

Every time parameters change, log the old and new values with a timestamp:
```json
{
  "parameterHistory": [
    {
      "timestamp": "2026-04-05T00:00:00Z",
      "cycle": 56,
      "changes": [
        {
          "param": "correlationBreachExit_A",
          "from": 0.40,
          "to": 0.38,
          "reason": "67% of correlation breach exits recovered within 24h"
        }
      ],
      "performanceBefore": { "avgReturn7d": 0.023 },
      "performanceAfter": null  // filled 7 days later
    }
  ]
}
```

**Rollback safety:** After each parameter change, compare the 7-day performance before and after. If performance declined by more than 20%:
```
if performanceAfter.avgReturn7d < performanceBefore.avgReturn7d * 0.80:
  // Revert the parameter change
  param.current = parameterHistory.lastChange.from
  log("ROLLBACK: {param} reverted from {to} to {from} — performance declined")
```

---

# LEVEL 2: POOL & CHAIN LEARNING

## Concept

Over time, certain protocols, chains, and trading pairs prove more reliable than others. The agent builds a reputation system from its own trade history. This reputation feeds into entry decisions — pools on reliable protocols get a boost, while those on historically unreliable ones get penalised.

## 2.1: Reputation Score Data Structure

```json
{
  "poolScores": {
    "aerodrome-base-WETH/USDC": {
      "totalPositions": 12,
      "profitablePositions": 10,
      "avgReturn": 0.031,
      "avgHoldDays": 5.2,
      "correlationBreaches": 1,
      "apyAccuracy": 0.85,
      "reputationScore": 0.82,
      "lastUpdated": "2026-04-10T12:00:00Z"
    }
  },
  "chainScores": {
    "base": {
      "totalPositions": 25,
      "profitablePositions": 21,
      "avgGasCostActual": 0.04,
      "avgReturn": 0.028,
      "reputationScore": 0.88,
      "lastUpdated": "2026-04-10T12:00:00Z"
    }
  },
  "protocolScores": {
    "aerodrome": {
      "totalPositions": 15,
      "profitablePositions": 13,
      "avgReturn": 0.032,
      "dataReliability": 0.95,
      "reputationScore": 0.85,
      "lastUpdated": "2026-04-10T12:00:00Z"
    }
  }
}
```

## 2.2: Reputation Score Calculation

Run this after each position exit:

```
function updateReputation(position, outcome):

  // --- Pool-level reputation ---
  key = "{protocol}-{chain}-{pair}"
  pool = poolScores[key] || createNewPoolRecord(key)

  pool.totalPositions++
  if outcome.netReturn > 0:
    pool.profitablePositions++

  pool.avgReturn = runningAverage(pool.avgReturn, outcome.netReturn, pool.totalPositions)
  pool.avgHoldDays = runningAverage(pool.avgHoldDays, outcome.holdDays, pool.totalPositions)

  // APY accuracy: how close was actual yield to expected yield at entry?
  expected_yield = position.entryApy / 100 * position.atRiskCapital / 365 * outcome.holdDays
  apy_accuracy = min(outcome.grossEarnings / expected_yield, 1.0)  // capped at 1.0
  pool.apyAccuracy = runningAverage(pool.apyAccuracy, apy_accuracy, pool.totalPositions)

  if outcome.exitReason == "correlation_breach":
    pool.correlationBreaches++

  // Composite reputation score (0 to 1)
  win_rate = pool.profitablePositions / pool.totalPositions
  pool.reputationScore = (
    win_rate * 0.40 +
    pool.apyAccuracy * 0.30 +
    (1 - pool.correlationBreaches / pool.totalPositions) * 0.20 +
    min(pool.avgReturn / 0.05, 1.0) * 0.10  // normalised against 5% target
  )

  // --- Chain-level reputation ---
  chain = chainScores[position.chain] || createNewChainRecord()
  // Same pattern: update totals, calculate composite score
  chain.totalPositions++
  if outcome.netReturn > 0: chain.profitablePositions++
  chain.avgReturn = runningAverage(chain.avgReturn, outcome.netReturn, chain.totalPositions)
  chain.reputationScore = chain.profitablePositions / chain.totalPositions

  // --- Protocol-level reputation ---
  proto = protocolScores[position.protocol] || createNewProtocolRecord()
  proto.totalPositions++
  if outcome.netReturn > 0: proto.profitablePositions++
  proto.avgReturn = runningAverage(proto.avgReturn, outcome.netReturn, proto.totalPositions)
  proto.reputationScore = proto.profitablePositions / proto.totalPositions
```

## 2.3: How Reputation Feeds Into Entry Decisions

### Strategy A — APY ranking modifier
When sorting pools by APY for Strategy A entry, apply a reputation multiplier:
```
effective_apy = pool.apy * reputationMultiplier(pool)

function reputationMultiplier(pool):
  poolRep = poolScores[pool.key]?.reputationScore || 0.50  // default for unknown
  protoRep = protocolScores[pool.protocol]?.reputationScore || 0.50
  chainRep = chainScores[pool.chain]?.reputationScore || 0.50

  // Weighted average — pool-specific data matters most
  combined = poolRep * 0.50 + protoRep * 0.30 + chainRep * 0.20

  // Convert to multiplier: 0.80x to 1.20x range
  // A reputation of 0.50 (neutral/unknown) = 1.0x (no change)
  // A reputation of 1.0 (perfect) = 1.20x (20% boost)
  // A reputation of 0.0 (terrible) = 0.80x (20% penalty)
  return 0.80 + (combined * 0.40)
```

### Strategy B — Scoring formula addition
Add reputation as a bonus after the main score is calculated:
```
base_score = (APY/80) * w1 + log10(TVL/1M)/3 * w2 + IL_dynamic * w3 + APY_stability * w4
reputation_bonus = reputationMultiplier(pool) - 1.0  // range: -0.20 to +0.20
final_score = base_score + (reputation_bonus * 0.10)  // dampened so it doesn't dominate
```

## 2.4: Cold Start Problem

New pools and protocols with zero history shouldn't be blocked. Handle this:
```
if pool.totalPositions < 3:
  // Not enough data — use neutral reputation (0.50)
  // But ADD a small exploration bonus to encourage trying new pools
  exploration_bonus = 0.02 * (3 - pool.totalPositions)  // 0.06, 0.04, 0.02
  effective_reputation = 0.50 + exploration_bonus
```

This gives unknown pools a slight advantage over known-bad pools, encouraging the agent to explore while still penalising proven failures.

## 2.5: Reputation Decay

Pool conditions change. A protocol that was great 30 days ago might have changed its incentives. Apply time decay:
```
// Every 24h learning cycle, decay all reputation scores toward neutral (0.50)
decay_rate = 0.02  // 2% per day toward neutral

for each record in [poolScores, chainScores, protocolScores]:
  record.reputationScore = record.reputationScore + (0.50 - record.reputationScore) * decay_rate
  // After 35 days with no new data, score is ~50% decayed toward neutral
```

This ensures the agent doesn't permanently blacklist a pool based on one bad week, and doesn't permanently trust a pool based on one good week.

---

# LEVEL 3: MARKET REGIME DETECTION

## Concept

The agent classifies the current market environment and adjusts its overall strategy profile accordingly. Markets behave very differently during a quiet range vs a volatile crash vs a steady uptrend. A single set of parameters can't be optimal for all conditions.

## 3.1: Regime Classification

The agent identifies one of five regimes using data it already collects:

| Regime | Description | Detection Signal |
|--------|-------------|-----------------|
| `bull_trending` | Prices rising steadily | BTC + ETH 7d returns > +5%, low volatility |
| `bear_trending` | Prices falling steadily | BTC + ETH 7d returns < -5%, low volatility |
| `high_volatility` | Large swings both ways | 7d realised volatility > 2x 30d average |
| `low_volatility` | Quiet, range-bound | 7d realised volatility < 0.5x 30d average |
| `regime_transition` | Unclear, possibly changing | None of the above triggers clearly |

### Detection Implementation
```
function detectRegime():

  // Fetch BTC and ETH 7d price data (already available from correlation engine)
  btc_return_7d = (btc_price_now - btc_price_7d_ago) / btc_price_7d_ago
  eth_return_7d = (eth_price_now - eth_price_7d_ago) / eth_price_7d_ago
  avg_return_7d = (btc_return_7d + eth_return_7d) / 2

  // Calculate realised volatility
  // Use the hourly returns from the correlation engine (already computed for log-returns)
  btc_vol_7d = standardDeviation(btc_hourly_returns_7d) * sqrt(24 * 7)  // annualise
  btc_vol_30d = standardDeviation(btc_hourly_returns_30d) * sqrt(24 * 30)
  vol_ratio = btc_vol_7d / btc_vol_30d  // >1 means recent vol is above average

  // Classify
  if avg_return_7d > 0.05 && vol_ratio < 1.5:
    regime = "bull_trending"
    confidence = min(avg_return_7d / 0.10, 1.0)  // stronger trend = higher confidence
  
  else if avg_return_7d < -0.05 && vol_ratio < 1.5:
    regime = "bear_trending"
    confidence = min(abs(avg_return_7d) / 0.10, 1.0)

  else if vol_ratio > 2.0:
    regime = "high_volatility"
    confidence = min((vol_ratio - 1.0) / 2.0, 1.0)

  else if vol_ratio < 0.5:
    regime = "low_volatility"
    confidence = min((1.0 - vol_ratio) / 0.5, 1.0)

  else:
    regime = "regime_transition"
    confidence = 0.3  // low confidence by definition

  return { regime, confidence }
```

### 30-Day Data Bootstrapping
The 30-day volatility baseline needs 30 days of data. During the first 30 days of operation:
```
if days_running < 30:
  // Use a hardcoded baseline for BTC annualised volatility: 45%
  // This is a reasonable long-term average
  btc_vol_30d = 0.45
  // Once 30 days of data exist, switch to calculated
```

## 3.2: Regime-Specific Parameter Overrides

Each regime has a set of parameter multipliers that temporarily override the base parameters (from Level 1). These don't change the base values — they apply on top.

```json
{
  "regimeOverrides": {
    "bull_trending": {
      "correlationEntryGate_A": 0.90,
      "correlationBreachExit_A": 0.85,
      "scoringWeight_APY": 1.15,
      "scoringWeight_IL": 0.80,
      "profitTakeThreshold": 1.20,
      "maxLPpositions_B": 4,
      "maxLendingPositions_B": 1,
      "description": "Loosen correlation, chase yield, raise profit target, more LP"
    },
    "bear_trending": {
      "correlationEntryGate_A": 1.15,
      "correlationBreachExit_A": 1.20,
      "scoringWeight_APY": 0.80,
      "scoringWeight_IL": 1.30,
      "profitTakeThreshold": 0.70,
      "maxLPpositions_B": 1,
      "maxLendingPositions_B": 4,
      "description": "Tighten correlation, favour stability, take profit early, mostly lending"
    },
    "high_volatility": {
      "correlationEntryGate_A": 1.20,
      "correlationBreachExit_A": 1.30,
      "scoringWeight_APY": 0.70,
      "scoringWeight_stability": 1.50,
      "profitTakeThreshold": 0.60,
      "circuitBreakerDrop": 0.80,
      "maxLPpositions_B": 0,
      "maxLendingPositions_B": 5,
      "description": "Maximum caution. Tighten everything, lower circuit breaker, Strategy B goes full lending"
    },
    "low_volatility": {
      "correlationEntryGate_A": 0.95,
      "correlationBreachExit_A": 0.95,
      "scoringWeight_APY": 1.10,
      "profitTakeThreshold": 1.30,
      "maxLPpositions_B": 3,
      "maxLendingPositions_B": 2,
      "description": "Slightly loosen, raise profit target (let positions run in calm markets)"
    },
    "regime_transition": {
      "description": "No overrides — use base parameters as-is"
    }
  }
}
```

### How to apply overrides
```
function getEffectiveParam(paramName):
  base = tuneableParams[paramName].current  // from Level 1
  regime = marketRegime.current
  override = regimeOverrides[regime][paramName]
  confidence = marketRegime.confidence

  if override exists:
    // Blend based on confidence. At 100% confidence, full override.
    // At 50% confidence, half override (move halfway from base to overridden value).
    effective = base * (1 - confidence) + (base * override) * confidence
    return clamp(effective, tuneableParams[paramName].min, tuneableParams[paramName].max)
  else:
    return base
```

This confidence-weighted blending means the agent doesn't suddenly flip to "bear mode" on a single bad day. The transition is gradual.

## 3.3: Regime Change Handling

When the regime changes, don't immediately re-allocate everything. Use a transition period:

```
function handleRegimeChange(oldRegime, newRegime, confidence):
  state.learning.marketRegime.history.push({
    from: oldRegime,
    to: newRegime,
    timestamp: now,
    confidence: confidence
  })

  // Only act on high-confidence regime changes
  if confidence < 0.60:
    // Low confidence — log the change but don't override parameters yet
    log("Regime shift detected ({old} → {new}) but confidence too low ({confidence})")
    return

  // High confidence — apply overrides
  state.learning.marketRegime.current = newRegime
  state.learning.marketRegime.confidence = confidence

  // CRITICAL: If shifting TO high_volatility or bear_trending, 
  // trigger an immediate position review (don't wait for next cycle)
  if newRegime in ["high_volatility", "bear_trending"]:
    log("URGENT regime shift to {newRegime} — triggering immediate exit review")
    runExitChecks()  // re-run with new stricter parameters
```

## 3.4: Strategy B Dynamic Allocation per Regime

The regime overrides include `maxLPpositions_B` and `maxLendingPositions_B`. This extends the existing dynamic lending/LP split from v2.1:

```
function getStrategyBAllocation():
  regime = marketRegime.current

  if circuitBreaker.active:
    return { lp: 0, lending: 5 }  // circuit breaker overrides everything

  maxLP = regimeOverrides[regime].maxLPpositions_B || 3
  maxLending = regimeOverrides[regime].maxLendingPositions_B || 2

  // Still respect the existing rule: if not enough LP candidates, fill with lending
  available_lp = countQualifiedLPCandidates()
  actual_lp = min(maxLP, available_lp)
  actual_lending = 5 - actual_lp

  return { lp: actual_lp, lending: actual_lending }
```

## 3.5: Regime Detection State

```json
{
  "marketRegime": {
    "current": "low_volatility",
    "confidence": 0.75,
    "detectedAt": "2026-04-08T12:00:00Z",
    "btcReturn7d": 0.023,
    "ethReturn7d": 0.018,
    "volRatio": 0.42,
    "history": [
      {
        "from": "regime_transition",
        "to": "low_volatility",
        "timestamp": "2026-04-08T12:00:00Z",
        "confidence": 0.75
      }
    ]
  }
}
```

---

# INTEGRATION: HOW ALL THREE LEVELS WORK TOGETHER

## Decision Flow for Every Entry

```
1. Fetch candidate pools from DeFiLlama (existing)
2. Apply base filters: TVL, APY range, pair tier (existing)
3. Apply APY stability filter: CoV < getEffectiveParam("apyStabilityCoV") (v2.1)
4. Apply gas gate using getEffectiveParam thresholds (v2.1)
5. Check correlation using getEffectiveParam("correlationEntryGate_A") (Level 1 + Level 3)
6. For Strategy A: sort by effective_apy = apy * reputationMultiplier(pool) (Level 2)
7. For Strategy B: score = base_score + reputation_bonus, using regime-adjusted weights (Level 1 + 2 + 3)
8. Respect regime-specific LP/lending allocation limits (Level 3)
```

## Decision Flow for Every Exit

```
1. Check profit-take: cumReturn >= getEffectiveParam("profitTakeThreshold") (Level 1 + 3)
2. Check window end: 7-day review-and-renew (v2.1, using effective params)
3. Check APY collapse: > 50% drop AND < getEffectiveParam("apyCollapseFloor_A") (Level 1 + 3)
4. Check correlation breach: < getEffectiveParam("correlationBreachExit_A") (Level 1 + 3)
5. Check yield override: with regime-adjusted thresholds (Level 3)
6. Check tax-aware rotation: only rotate if benefit > tax + gas (v2.1)
7. Check circuit breaker: getEffectiveParam("circuitBreakerDrop") (Level 1 + 3)
```

## Learning Cycle (Every 24 Hours)

```
1. Detect market regime (Level 3)
2. If regime changed → handle transition
3. Evaluate past 7 days performance (Level 1)
4. Update reputation scores for all pools, chains, protocols (Level 2)
5. Adjust tuneable parameters based on evaluation (Level 1)
6. Check for parameter rollbacks (Level 1)
7. Apply regime overrides to get effective parameters (Level 3)
8. Log all changes to parameterHistory
9. Save state
```

---

# SAFETY CONSTRAINTS

These hard rules prevent the self-improvement engine from going off the rails:

1. **Maximum one step change per parameter per 24h cycle.** No parameter can jump from min to max in a single day.

2. **Scoring weights must always sum to 1.0.** Normalise after every adjustment.

3. **Rollback on performance decline.** If 7-day performance drops > 20% after a parameter change, auto-revert.

4. **Regime overrides are multipliers, not replacements.** They amplify or dampen the base value, never set an absolute.

5. **Confidence gating on regime changes.** Below 60% confidence, log but don't act.

6. **Exploration vs exploitation.** The cold-start bonus (Level 2.4) ensures the agent doesn't get stuck only using pools it already knows. Minimum 1 out of 5 positions should be on a pool with < 3 historical data points, if any such pool passes all filters.

7. **Human override.** Add a `learningEnabled` flag to config. If false, all three levels are bypassed and the agent uses hardcoded v2.1 parameters. This is the kill switch.

```json
{
  "learning": {
    "enabled": true,
    "level1_paramTuning": true,
    "level2_reputation": true,
    "level3_regimeDetection": true
  }
}
```

Each level can be independently enabled/disabled for testing.

---

# DASHBOARD ADDITIONS

The Vercel dashboard should display the self-improvement data:

### Parameter Tuning Panel
- Current value of each tuneable parameter
- History chart showing how each parameter has drifted over time
- Rollback events highlighted in red

### Reputation Panel
- Top 5 and bottom 5 pools by reputation score
- Chain reputation comparison (bar chart)
- Protocol reliability ranking

### Market Regime Panel
- Current regime with confidence indicator
- Regime history timeline
- How current regime is affecting parameters (show effective vs base values)

### Learning Activity Log
- Chronological list of all parameter changes, regime shifts, and rollbacks
- Filterable by level (1, 2, 3) and type (adjustment, rollback, regime change)

---

# SUMMARY: Implementation Order

1. **Level 1 first** — tuneable parameters registry, evaluation function, adjustment rules, rollback logic
2. **Level 2 second** — reputation data structures, update-on-exit logic, entry decision integration, decay
3. **Level 3 third** — regime detection, override multipliers, confidence blending, regime change handling
4. **Integration** — wire all three into the main cron cycle decision flow
5. **Dashboard** — add panels for parameter history, reputation, and regime
6. **Safety** — implement kill switches and the exploration minimum

> **Testing approach:** Enable Level 1 only for the first 7 days. Add Level 2 on day 8. Add Level 3 on day 15. This lets you verify each level independently before they interact.
