'use strict';

require('dotenv').config({ path: '/home/node/.openclaw/workspace/.env' });

const express = require('express');
const fs      = require('fs');
const path    = require('path');
const { spawn } = require('child_process');

// ─── Config ──────────────────────────────────────────────────────────────────

const PORT           = 3002;
const DASHBOARD_SECRET = process.env.DASHBOARD_SECRET;
const CACHE_DIR      = path.join(__dirname, 'cache');
const MANIFEST_FILE  = path.join(CACHE_DIR, 'manifest.json');
const SYNC_SCRIPT    = path.join(__dirname, 'wallet-sync.cjs');

if (!DASHBOARD_SECRET) {
  console.error('[FATAL] DASHBOARD_SECRET not found in .env');
  process.exit(1);
}

const ALLOWED_ORIGINS = [
  'https://passiveblocks-dashboard.vercel.app',
  'http://localhost:3000',
  'http://localhost:3001',
  'http://localhost:3002',
];

const app = express();
app.use(express.json());

// ─── CORS ─────────────────────────────────────────────────────────────────────

app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && ALLOWED_ORIGINS.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Sync-Token');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// ─── Auth middleware ──────────────────────────────────────────────────────────

function authRequired(req, res, next) {
  const token = req.headers['x-sync-token'];
  if (!token || token !== DASHBOARD_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

// ─── Routes ───────────────────────────────────────────────────────────────────

// Health — no auth required
app.get('/sync/health', (req, res) => {
  res.json({ status: 'ok', uptime: Math.floor(process.uptime()) });
});

// Status — returns manifest
app.get('/sync/status', authRequired, (req, res) => {
  if (!fs.existsSync(MANIFEST_FILE)) {
    return res.status(404).json({ error: 'No manifest found — sync has not run yet' });
  }
  try {
    const manifest = JSON.parse(fs.readFileSync(MANIFEST_FILE, 'utf8'));
    res.json(manifest);
  } catch (e) {
    res.status(500).json({ error: 'Failed to read manifest', detail: e.message });
  }
});

// Transactions — returns cached data for address (+optional chain)
app.get('/sync/transactions', authRequired, (req, res) => {
  const { address, chain } = req.query;
  if (!address) {
    return res.status(400).json({ error: 'address query param required' });
  }

  if (chain) {
    // Single chain
    const file = path.join(CACHE_DIR, `${address}-${chain}.json`);
    if (!fs.existsSync(file)) {
      return res.status(404).json({ error: `No cache for ${address} on ${chain}` });
    }
    try {
      const data = JSON.parse(fs.readFileSync(file, 'utf8'));
      return res.json(data);
    } catch (e) {
      return res.status(500).json({ error: 'Failed to read cache', detail: e.message });
    }
  }

  // All chains for address
  const files = fs.readdirSync(CACHE_DIR)
    .filter(f => f.startsWith(`${address}-`) && f.endsWith('.json') && f !== 'manifest.json');

  if (files.length === 0) {
    return res.status(404).json({ error: `No cached data for ${address}` });
  }

  const merged = {
    address,
    syncedAt:  new Date().toISOString(),
    chains:    {},
    transfers: [],
  };

  for (const f of files) {
    const chainName = f.replace(`${address}-`, '').replace('.json', '');
    try {
      const data = JSON.parse(fs.readFileSync(path.join(CACHE_DIR, f), 'utf8'));
      merged.chains[chainName] = { count: data.count, syncedAt: data.syncedAt };
      merged.transfers.push(...(data.transfers || []));
    } catch (e) {
      merged.chains[chainName] = { error: e.message };
    }
  }

  merged.totalCount = merged.transfers.length;
  res.json(merged);
});

// Trigger — spawn a fresh sync in background
let syncRunning = false;
app.post('/sync/trigger', authRequired, (req, res) => {
  if (syncRunning) {
    return res.status(409).json({ error: 'Sync already in progress' });
  }

  syncRunning = true;
  res.json({ status: 'sync_started', startedAt: new Date().toISOString() });

  const child = spawn(process.execPath, [SYNC_SCRIPT], {
    detached: true,
    stdio:    ['ignore', 'pipe', 'pipe'],
  });

  child.stdout.on('data', d => process.stdout.write(`[sync-worker] ${d}`));
  child.stderr.on('data', d => process.stderr.write(`[sync-worker:err] ${d}`));

  child.on('close', code => {
    syncRunning = false;
    console.log(`[${new Date().toISOString()}] Sync process exited with code ${code}`);
  });

  child.unref();
});

// ─── Start ────────────────────────────────────────────────────────────────────

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[${new Date().toISOString()}] Sync server listening on port ${PORT}`);
  console.log(`  Health:       GET  /sync/health`);
  console.log(`  Status:       GET  /sync/status        (auth required)`);
  console.log(`  Transactions: GET  /sync/transactions  (auth required)`);
  console.log(`  Trigger:      POST /sync/trigger       (auth required)`);
});
