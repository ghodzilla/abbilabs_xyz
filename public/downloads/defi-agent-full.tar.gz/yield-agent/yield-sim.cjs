#!/usr/bin/env node
/**
 * Yield Agent Simulator v2.1 — A/B Test Mode
 * Simulates $5,000 across two strategies using live DeFiLlama data
 * No real money moves — tracks virtual P&L over time
 *
 * Strategy A: Maximize APY (highest yielding correlated pools)
 * Strategy B: Maximize safety (best risk-adjusted: TVL × APY score)
 *
 * v2.1 Changes:
 *   - Log-return correlation engine
 *   - Block on missing data (with T1+TVL exception)
 *   - APY stability filter (CoV)
 *   - Gas cost model
 *   - Dynamic IL estimation
 *   - Updated Strategy B scoring
 *   - Review-and-renew (replaces forced window exit)
 *   - APY collapse absolute floor
 *   - Yield override TVL+IL checks
 *   - Dynamic lending/LP split
 *   - Portfolio circuit breaker
 *   - Profit booking module
 *   - Australian tax tracking
 *   - Day 30 after-tax risk-adjusted recommendation
 *
 * Run: node yield-sim.cjs [--reset] [--report] [--export-tax]
 */

const https = require('https');
const fs = require('fs');
const path = require('path');
const taxEngine = require('./tax-engine.cjs');

const STATE_FILE = path.join(__dirname, 'yield-sim-state.json');
const CAPITAL = 5000;
const TARGET_CHAINS = ['Base', 'Arbitrum', 'Solana', 'Ethereum'];
const MIN_TVL = 1_000_000;
const MIN_APY = 5;
const MAX_APY = 80;
const POSITIONS_PER_STRATEGY = 5;
const WINDOW_DAYS = 7;
const APY_DROP_THRESHOLD = 0.50;
const RECOMMENDATION_DAY = 30;
const MAX_RECOMMENDATION_DAY = 60;
const COV_THRESHOLD = 0.5;

// ── CHANGE 1: Updated correlation thresholds (log-return based) ──────────────
const CORR_THRESHOLD_T1 = 0.95;   // was 0.98
const CORR_THRESHOLD_T2 = 0.60;   // was 0.70
const ENTRY_CORR_MIN = 0.60;      // was 0.70
const CORR_EXIT_STRAT_A = 0.40;   // was 0.50

// ── CHANGE 4: Gas cost model ─────────────────────────────────────────────────
const GAS_COSTS = {
  'base':     { enter: 0.05, exit: 0.05, minHoldDays: 0 },
  'arbitrum': { enter: 0.10, exit: 0.10, minHoldDays: 0 },
  'solana':   { enter: 0.02, exit: 0.02, minHoldDays: 0 },
  'ethereum': { enter: 30.00, exit: 25.00, minHoldDays: 3 },
};

// ── TOKEN SETS ───────────────────────────────────────────────────────────────
const ETH_BASE     = new Set(['eth','weth']);
const ETH_LSTS     = new Set(['steth','wsteth','cbeth','reth','weeth','ezeth','frxeth','sweth','oseth']);
const SOL_BASE     = new Set(['sol','wsol']);
const SOL_LSTS     = new Set(['msol','jitosol','bsol','bbsol']);
const BTC_VARIANTS = new Set(['wbtc','cbbtc','tbtc','sbtc','lbtc','btcb','btc']);
const USD_STABLES  = new Set(['usdc','usdt','dai','usde','crvusd','frax','usds','lusd','susd','usdz','susdz','gho','pyusd','busd','tusd']);

// ── v2.2: REGIME OVERRIDES ───────────────────────────────────────────────────
const REGIME_OVERRIDES = {
  bull_trending: { correlationEntryGate_A: 0.90, correlationBreachExit_A: 0.85, scoringWeight_APY: 1.15, scoringWeight_IL: 0.80, profitTakeThreshold: 1.20, maxLPpositions_B: 4, maxLendingPositions_B: 1 },
  bear_trending: { correlationEntryGate_A: 1.15, correlationBreachExit_A: 1.20, scoringWeight_APY: 0.80, scoringWeight_IL: 1.30, profitTakeThreshold: 0.70, maxLPpositions_B: 1, maxLendingPositions_B: 4 },
  high_volatility: { correlationEntryGate_A: 1.20, correlationBreachExit_A: 1.30, scoringWeight_APY: 0.70, scoringWeight_stability: 1.50, profitTakeThreshold: 0.60, circuitBreakerDrop: 0.80, maxLPpositions_B: 0, maxLendingPositions_B: 5 },
  low_volatility: { correlationEntryGate_A: 0.95, correlationBreachExit_A: 0.95, scoringWeight_APY: 1.10, profitTakeThreshold: 1.30, maxLPpositions_B: 3, maxLendingPositions_B: 2 },
  regime_transition: {},
  unknown: {},
};

const CONVICTION_PAIRS = [
  ['eth','btc'],['weth','wbtc'],['eth','sol'],['sol','usdc'],
  ['sol','usdt'],['eth','usdc'],['eth','usdt'],['weth','usdc'],
  ['btc','usdc'],['wbtc','usdc'],['wbtc','usdt'],['sol','btc'],
];

function tokenize(sym) {
  return (sym||'').toLowerCase().split(/[^a-z0-9]+/).filter(t => t.length > 0);
}

function pairTier(sym) {
  const tokens = tokenize(sym);
  if (tokens.length < 2) return null;
  const isEthFamily = t => ETH_BASE.has(t) || ETH_LSTS.has(t);
  const isSolFamily = t => SOL_BASE.has(t) || SOL_LSTS.has(t);
  const isBtcFamily = t => BTC_VARIANTS.has(t);
  const isStable    = t => USD_STABLES.has(t);
  if (tokens.every(isEthFamily) && tokens.some(t => ETH_LSTS.has(t))) return 1;
  if (tokens.every(isSolFamily) && tokens.some(t => SOL_LSTS.has(t))) return 1;
  if (tokens.every(isBtcFamily) && tokens.length >= 2) return 1;
  if (tokens.every(isStable)    && tokens.length >= 2) return 1;
  const sorted = [...tokens].sort();
  if (CONVICTION_PAIRS.some(p => {
    const sp = [...p].sort();
    return sp[0] === sorted[0] && sp[1] === sorted[1];
  })) return 2;
  return null;
}

function isCorrelated(sym) { return pairTier(sym) !== null; }

// ── TOKEN IDS FOR DEFI LLAMA ─────────────────────────────────────────────────

const TOKEN_IDS = {
  'weth':    'coingecko:weth',
  'eth':     'coingecko:ethereum',
  'steth':   'coingecko:staked-ether',
  'wsteth':  'coingecko:wrapped-steth',
  'cbeth':   'coingecko:coinbase-wrapped-staked-eth',
  'reth':    'coingecko:rocket-pool-eth',
  'weeth':   'coingecko:wrapped-eeth',
  'ezeth':   'coingecko:renzo-restaked-eth',
  'sol':     'coingecko:solana',
  'wsol':    'coingecko:solana',
  'msol':    'coingecko:msol',
  'jitosol': 'coingecko:jito-staked-sol',
  'bsol':    'coingecko:blazestake-staked-sol',
  'wbtc':    'coingecko:wrapped-bitcoin',
  'cbbtc':   'coingecko:coinbase-wrapped-btc',
  'tbtc':    'coingecko:tbtc',
  'btc':     'coingecko:bitcoin',
  'usdc':    'coingecko:usd-coin',
  'usdt':    'coingecko:tether',
  'dai':     'coingecko:dai',
  'usde':    'coingecko:ethena-usde',
  'crvusd':  'coingecko:crvusd',
  'frax':    'coingecko:frax',
  'usds':    'coingecko:usds',
  'pyusd':   'coingecko:paypal-usd',
  'lusd':    'coingecko:liquity-usd',
  'susd':    'coingecko:nusd',
  'gho':     'coingecko:gho',
};

// Unified price cache (shared across entry checks & position checks)
const priceCache = {};

// ── CHANGE 3: APY stability cache ────────────────────────────────────────────
const apyHistoryCache = {};

// ── HTTP HELPERS ──────────────────────────────────────────────────────────────

function fetch(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'AbbiLabs-YieldSim/2.1' } }, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch(e) { reject(e); } });
    }).on('error', reject);
  });
}

function fetchHttps(opts) {
  return new Promise((resolve, reject) => {
    https.get(opts, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => { try { resolve(JSON.parse(d)); } catch(e) { reject(e); } });
    }).on('error', reject);
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── PRICE FETCHING ────────────────────────────────────────────────────────────

async function fetchPrices(llamaId) {
  if (priceCache[llamaId]) return priceCache[llamaId];
  const start = Math.floor(Date.now() / 1000) - 7 * 24 * 3600;
  const encoded = encodeURIComponent(llamaId);
  const url = `/chart/${encoded}?start=${start}&span=168&period=1h`;
  return new Promise((resolve, reject) => {
    https.get({
      hostname: 'coins.llama.fi', path: url,
      headers: { 'User-Agent': 'AbbiLabs-YieldSim/2.1', 'Accept': 'application/json' }
    }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try {
          const r = JSON.parse(d);
          const coinData = r.coins?.[llamaId];
          if (coinData?.prices?.length > 0) {
            const prices = coinData.prices.map(p => p.price);
            priceCache[llamaId] = prices;
            resolve(prices);
          } else {
            resolve([]);
          }
        } catch(e) { reject(e); }
      });
    }).on('error', reject);
  });
}

// ── CHANGE 1: Log-returns conversion ─────────────────────────────────────────

function toLogReturns(prices) {
  const returns = [];
  for (let i = 1; i < prices.length; i++) {
    if (prices[i - 1] > 0) {
      returns.push(Math.log(prices[i] / prices[i - 1]));
    }
  }
  return returns;
}

function pearsonCorr(a, b) {
  const n = Math.min(a.length, b.length);
  if (n < 10) return null;
  const ax = a.slice(-n), bx = b.slice(-n);
  const meanA = ax.reduce((s, v) => s + v, 0) / n;
  const meanB = bx.reduce((s, v) => s + v, 0) / n;
  let num = 0, denA = 0, denB = 0;
  for (let i = 0; i < n; i++) {
    const da = ax[i] - meanA, db = bx[i] - meanB;
    num += da * db; denA += da * da; denB += db * db;
  }
  if (denA === 0 || denB === 0) return 1;
  return num / Math.sqrt(denA * denB);
}

/** Compute Pearson correlation on log-returns of two price series */
function logReturnCorrelation(pricesA, pricesB) {
  const retA = toLogReturns(pricesA);
  const retB = toLogReturns(pricesB);
  return pearsonCorr(retA, retB);
}

function getCorrThreshold(tokens) {
  const [t1, t2] = tokens;
  const isEthFam = t => ETH_BASE.has(t) || ETH_LSTS.has(t);
  const isSolFam = t => SOL_BASE.has(t) || SOL_LSTS.has(t);
  const isBtcVar = t => BTC_VARIANTS.has(t);
  const isStable = t => USD_STABLES.has(t);
  if ([t1,t2].every(isEthFam) || [t1,t2].every(isSolFam) ||
      [t1,t2].every(isBtcVar) || [t1,t2].every(isStable)) return CORR_THRESHOLD_T1;
  return CORR_THRESHOLD_T2;
}

// ── CHANGE 2: Block on missing data helper ───────────────────────────────────

function shouldAllowMissingData(pool, tokens) {
  const tier = pairTier(pool.symbol || '');
  return tier === 1 && (pool.tvlUsd || 0) >= 10_000_000;
}

// ── CHANGE 3: APY Stability (CoV) ───────────────────────────────────────────

async function fetchPoolApyHistory(poolId) {
  if (apyHistoryCache[poolId]) return apyHistoryCache[poolId];
  try {
    const data = await fetch(`https://yields.llama.fi/chartPoolData/${poolId}`);
    const entries = Array.isArray(data) ? data : (data?.data || []);
    apyHistoryCache[poolId] = entries;
    return entries;
  } catch {
    apyHistoryCache[poolId] = [];
    return [];
  }
}

async function calcApyCoV(poolId) {
  const history = await fetchPoolApyHistory(poolId);
  if (!history || history.length === 0) return null;
  // Take last 7 days of entries
  const now = Date.now();
  const sevenDaysAgo = now - 7 * 24 * 3600 * 1000;
  const recent = history.filter(e => {
    const ts = typeof e.timestamp === 'string' ? new Date(e.timestamp).getTime() : e.timestamp * 1000;
    return ts >= sevenDaysAgo;
  });
  const apys = recent.map(e => e.apy).filter(a => a != null && !isNaN(a));
  if (apys.length < 2) return null;
  const mean = apys.reduce((s, v) => s + v, 0) / apys.length;
  if (mean === 0) return null;
  const variance = apys.reduce((s, v) => s + (v - mean) ** 2, 0) / apys.length;
  const stddev = Math.sqrt(variance);
  return stddev / Math.abs(mean);
}

// ── CHANGE 5: Dynamic IL Estimation ──────────────────────────────────────────

function calcDynamicIL(pricesA, pricesB) {
  if (!pricesA || !pricesB || pricesA.length < 2 || pricesB.length < 2) return 0;
  const priceA_now = pricesA[pricesA.length - 1];
  const priceA_7d = pricesA[0];
  const priceB_now = pricesB[pricesB.length - 1];
  const priceB_7d = pricesB[0];
  if (priceB_now === 0 || priceB_7d === 0 || priceA_7d === 0) return 0;

  const ratio_now = priceA_now / priceB_now;
  const ratio_7d = priceA_7d / priceB_7d;
  const ratio_change = ratio_now / ratio_7d;

  const il = 2 * Math.sqrt(ratio_change) / (1 + ratio_change) - 1;
  return il; // negative value
}

function getILDynamic(ilEstimate, isLending) {
  if (isLending) return 1.0;
  return Math.max(0, 1.0 - Math.abs(ilEstimate * 52));
}

// ── CHANGE 4: Gas gate check ─────────────────────────────────────────────────

function passesGasGate(pool) {
  const chain = (pool.chain || '').toLowerCase();
  const gas = GAS_COSTS[chain] || { enter: 0.10, exit: 0.10, minHoldDays: 1 };
  const minHold = Math.max(gas.minHoldDays, 1);
  const projectedYield = 500 * ((pool.apy || 0) / 100) / 365 * minHold;
  const gasRoundtrip = gas.enter + gas.exit;
  return projectedYield >= 2 * gasRoundtrip;
}

function getGasForChain(chain) {
  return GAS_COSTS[(chain || '').toLowerCase()] || { enter: 0.10, exit: 0.10, minHoldDays: 1 };
}

// ── CORRELATION CHECKS (shared logic) ────────────────────────────────────────

/**
 * CHANGE 1: Uses log-return correlation
 * CHANGE 2: Blocks on missing data (with T1+TVL>=10M exception)
 */
async function entryCorrelationPass(pool) {
  const symbol = pool.symbol || '';
  const tokens = tokenize(symbol).slice(0, 2);
  if (tokens.length < 2) return { pass: true, corr: null }; // single token — pass

  const id1 = TOKEN_IDS[tokens[0]];
  const id2 = TOKEN_IDS[tokens[1]];
  if (!id1 || !id2) return { pass: true, corr: null }; // unknown tokens

  // Both stablecoins — always pass
  if ([tokens[0], tokens[1]].every(t => USD_STABLES.has(t))) return { pass: true, corr: 1.0 };

  try {
    const [p1, p2] = await Promise.all([fetchPrices(id1), fetchPrices(id2)]);

    // CHANGE 2: Block on missing data
    if (p1.length < 10 || p2.length < 10) {
      if (shouldAllowMissingData(pool, tokens)) {
        return { pass: true, corr: null }; // T1 + TVL>=10M exception
      }
      return { pass: false, corr: null }; // BLOCK
    }

    const corr = logReturnCorrelation(p1, p2);
    if (corr === null) {
      if (shouldAllowMissingData(pool, tokens)) return { pass: true, corr: null };
      return { pass: false, corr: null };
    }
    return { pass: corr >= ENTRY_CORR_MIN, corr };
  } catch {
    if (shouldAllowMissingData(pool, tokens)) return { pass: true, corr: null };
    return { pass: false, corr: null };
  }
}

async function checkPositionCorr(pos) {
  if (pos.type === 'lending') return null;
  const tokens = tokenize(pos.symbol || '').slice(0, 2);
  if (tokens.length < 2) return null;
  const id1 = TOKEN_IDS[tokens[0]];
  const id2 = TOKEN_IDS[tokens[1]];
  if (!id1 || !id2) return null;

  // Both stablecoins — always correlated
  if ([tokens[0], tokens[1]].every(t => USD_STABLES.has(t))) return null;

  try {
    const [p1, p2] = await Promise.all([fetchPrices(id1), fetchPrices(id2)]);

    // CHANGE 2: Block on missing data
    if (p1.length < 10 || p2.length < 10) {
      if (shouldAllowMissingData(pos, tokens)) return null;
      return { corr: 0, threshold: getCorrThreshold(tokens) }; // force exit
    }

    const corr = logReturnCorrelation(p1, p2);
    if (corr === null) {
      if (shouldAllowMissingData(pos, tokens)) return null;
      return { corr: 0, threshold: getCorrThreshold(tokens) };
    }
    const threshold = getCorrThreshold(tokens);
    return { corr, threshold };
  } catch {
    return null;
  }
}

// ── CHANGE 5: Get IL estimate for a pool ─────────────────────────────────────

async function getILEstimateForPool(pool) {
  if (pool.type === 'lending') return { ilEstimate: 0, ilDynamic: 1.0 };
  const tokens = tokenize(pool.symbol || '').slice(0, 2);
  if (tokens.length < 2) return { ilEstimate: 0, ilDynamic: 1.0 };
  const id1 = TOKEN_IDS[tokens[0]];
  const id2 = TOKEN_IDS[tokens[1]];
  if (!id1 || !id2) return { ilEstimate: 0, ilDynamic: 0.65 };

  try {
    const [p1, p2] = await Promise.all([fetchPrices(id1), fetchPrices(id2)]);
    if (p1.length < 2 || p2.length < 2) return { ilEstimate: 0, ilDynamic: 0.65 };
    const ilEstimate = calcDynamicIL(p1, p2);
    const ilDynamic = getILDynamic(ilEstimate, false);
    return { ilEstimate, ilDynamic };
  } catch {
    return { ilEstimate: 0, ilDynamic: 0.65 };
  }
}

// ── STATE I/O ────────────────────────────────────────────────────────────────

function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); }
  catch { return null; }
}

function saveState(state) {
  fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

function fmtUSD(n) { return '$' + n.toFixed(2); }
function fmtPct(n) { return (n >= 0 ? '+' : '') + n.toFixed(2) + '%'; }

// ── POOL FILTERING ────────────────────────────────────────────────────────────

const STABLE_SYMS = ['usdc','usdt','dai','usde','crvusd','frax','usds'];
const LENDING_PROJS = ['aave','compound','morpho','marginfi','kamino-lend',
  'drift','solend','save','jupiter-lend','euler','fluid','spark'];

function isStableLending(p) {
  const sym = (p.symbol||'').toLowerCase();
  const proj = (p.project||'').toLowerCase();
  const isLender = LENDING_PROJS.some(l => proj.includes(l));
  const isStable = STABLE_SYMS.some(s => sym === s || sym === s+'.e');
  return isLender && isStable;
}

async function getPools() {
  let lastErr;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const data = await fetch('https://yields.llama.fi/pools');
      const all = data.data || [];

      // LP pools — base filter
      let lpPools = all
        .filter(p => TARGET_CHAINS.includes(p.chain))
        .filter(p => (p.tvlUsd||0) >= MIN_TVL)
        .filter(p => (p.apy||0) >= MIN_APY && (p.apy||0) <= MAX_APY)
        .filter(p => isCorrelated(p.symbol))
        .map(p => ({ ...p, type: 'lp' }));

      // CHANGE 3: APY stability filter (CoV) — only check top 60 by APY to avoid 500+ API calls
      // Sort first, check CoV only on the candidates we'd actually consider
      const topCandidates = lpPools.sort((a,b) => (b.apy||0) - (a.apy||0)).slice(0, 60);
      const rest = lpPools.slice(60).map(p => ({ ...p, _cov: null })); // pass rest unchecked
      const covResults = await Promise.allSettled(
        topCandidates.map(async p => {
          const cov = await calcApyCoV(p.pool);
          return { pool: p, cov };
        })
      );
      const checkedPools = covResults
        .filter(r => r.status === 'fulfilled')
        .map(r => r.value)
        .filter(({ cov }) => cov === null || cov < COV_THRESHOLD) // null = no data → allow
        .map(({ pool, cov }) => ({ ...pool, _cov: cov }));
      lpPools = [...checkedPools, ...rest];

      // CHANGE 4: Gas gate — reject pools that don't pass gas check
      lpPools = lpPools.filter(p => passesGasGate(p));

      const lendingPools = all
        .filter(p => TARGET_CHAINS.includes(p.chain))
        .filter(p => (p.tvlUsd||0) >= 5_000_000)
        .filter(p => (p.apy||0) >= 3)
        .filter(p => isStableLending(p))
        .map(p => ({ ...p, type: 'lending', ilRisk: 'no', _cov: 0 }));

      return [...lpPools, ...lendingPools];
    } catch(e) {
      lastErr = e;
      if (attempt < 2) await sleep(500);
    }
  }
  throw lastErr;
}

// ── CHANGE 8: Best lending rate helper ───────────────────────────────────────

function getBestLendingRate(pools) {
  const lending = pools.filter(p => p.type === 'lending');
  if (lending.length === 0) return 5; // fallback
  return Math.max(...lending.map(p => p.apy || 0));
}

// ── STRATEGY BUILDERS ────────────────────────────────────────────────────────

const PREFERRED_PAIRS_A = [
  ['eth','weth'],['weth','eth'],
  ['eth','btc'],['btc','eth'],['weth','wbtc'],['wbtc','weth'],
  ['eth','steth'],['steth','eth'],['eth','wsteth'],['wsteth','eth'],
];

function isPreferredPairA(symbol) {
  const tokens = (symbol||'').toLowerCase().replace(/[^a-z0-9]/g,'-').split('-').filter(Boolean).slice(0,2);
  return PREFERRED_PAIRS_A.some(([a,b]) => tokens.includes(a) && tokens.includes(b));
}


async function buildStrategyA(pools, existingIds = new Set(), state = {}) {
  const candidates = pools
    .filter(p => !existingIds.has(p.pool))
    .filter(p => passesGasGate(p))
    .sort((a, b) => {
      const aBoost = isPreferredPairA(a.symbol) ? 1.20 : 1.0;
      const bBoost = isPreferredPairA(b.symbol) ? 1.20 : 1.0;
      // v2.2: Apply reputation multiplier
      const aRep = reputationMultiplier(a, state);
      const bRep = reputationMultiplier(b, state);
      return ((b.apy||0) * bBoost * bRep) - ((a.apy||0) * aBoost * aRep);
    });

  // Strict entry gate — ≥0.60 log-return correlation required
  // If market conditions mean few LP pairs pass, that is correct behaviour
  // Idle slots will be parked in stablecoin lending until conditions improve
  const selected = [];
  for (const pool of candidates) {
    if (selected.length >= POSITIONS_PER_STRATEGY) break;
    const { pass } = await entryCorrelationPass(pool);
    if (pass) selected.push(pool);
  }

  return selected;
}

// CHANGE 6 + 10: Strategy B with dynamic scoring and flexible lending/LP split
async function buildStrategyB(pools, existingIds = new Set(), circuitBreakerActive = false, state = {}) {
  const candidates = pools.filter(p => !existingIds.has(p.pool));

  // If circuit breaker active → all lending
  if (circuitBreakerActive) {
    return candidates
      .filter(p => p.type === 'lending')
      .sort((a,b) => (b.apy||0) - (a.apy||0))
      .slice(0, POSITIONS_PER_STRATEGY);
  }

  const lending = candidates
    .filter(p => p.type === 'lending')
    .sort((a,b) => (b.apy||0) - (a.apy||0))
    .slice(0, 2);

  // Score LP candidates with new formula (Change 6)
  const lpCandidatesRaw = candidates.filter(p => p.type === 'lp' && passesGasGate(p));

  // Check correlation on LP candidates
  const validLPs = [];
  for (const p of lpCandidatesRaw) {
    const { pass } = await entryCorrelationPass(p);
    if (pass) validLPs.push(p);
    if (validLPs.length >= 10) break; // enough candidates
  }

  // Score with new formula
  const scoredLPs = await Promise.all(validLPs.map(async p => {
    const { ilDynamic } = await getILEstimateForPool(p);
    const cov = p._cov != null ? p._cov : (await calcApyCoV(p.pool)) || 0;
    const apyStability = Math.max(0, 1.0 - cov);

    const baseScore = ((p.apy || 0) / 80) * 0.45
      + Math.min(Math.log10((p.tvlUsd || 1) / 1_000_000) / 3, 1) * 0.30
      + ilDynamic * 0.15
      + apyStability * 0.10;
    // v2.2: reputation bonus
    const score = baseScore + (reputationMultiplier(p, state) - 1.0) * 0.10;

    return { ...p, score, ilDynamic, apyStability };
  }));

  scoredLPs.sort((a, b) => {
    // Tiebreaker within 0.01: prefer lending for tax efficiency
    if (Math.abs(a.score - b.score) < 0.01) {
      const taxA = a.type === 'lending' ? 1.0 : 0.85;
      const taxB = b.type === 'lending' ? 1.0 : 0.85;
      return taxB - taxA;
    }
    return b.score - a.score;
  });

  // CHANGE 10: Dynamic split
  const lpCount = Math.min(3, scoredLPs.length);
  const lendingCount = POSITIONS_PER_STRATEGY - lpCount;
  const extraLending = candidates
    .filter(p => p.type === 'lending' && !lending.some(l => l.pool === p.pool))
    .sort((a,b) => (b.apy||0) - (a.apy||0));

  const finalLending = lending.slice(0, lendingCount);
  // Fill remaining lending slots if needed
  if (finalLending.length < lendingCount) {
    for (const l of extraLending) {
      if (finalLending.length >= lendingCount) break;
      if (!finalLending.some(f => f.pool === l.pool)) finalLending.push(l);
    }
  }

  const finalLPs = scoredLPs.slice(0, lpCount);
  return [...finalLending, ...finalLPs].slice(0, POSITIONS_PER_STRATEGY);
}

// ── POSITION INITIALISATION ──────────────────────────────────────────────────

function withEntryFields(pos, now, state) {
  const chain = (pos.chain || '').toLowerCase();
  const gas = GAS_COSTS[chain] || { enter: 0.10, exit: 0.10, minHoldDays: 1 };
  const taxProfile = taxEngine.loadTaxProfile(state?.tax?.country || 'AU');
  const xr = taxProfile.defaultExchangeRate;
  const positionValue = CAPITAL / 2 / POSITIONS_PER_STRATEGY; // $500

  return {
    ...pos,
    entryDate: pos.entryDate || now.toISOString(),
    entryApy:  pos.entryApy  != null ? pos.entryApy : (pos.apy||0),
    weight: 1 / POSITIONS_PER_STRATEGY,
    isLending: pos.type === 'lending',
    // CHANGE 4: Gas tracking
    estimatedGas: gas.enter,
    // CHANGE 9: TVL tracking
    tvl_24h_ago: pos.tvlUsd || 0,
    tvl_24h_updateCycle: 0,
    // CHANGE 12: Profit booking
    crystallisedEarnings: 0,
    atRiskCapital: positionValue,
    cumulativeReturn: 0,
    // CHANGE 13: Tax tracking (global)
    costBasisAUD: positionValue * xr,
    proceedsAUD: 0,
    cgtGain: 0,
    yieldIncomeAUD: 0,
    gasDeductibleAUD: gas.enter * xr,
    audSnapshots: [],
  };
}

// ── CHANGE 7: Review-and-Renew logic ─────────────────────────────────────────

async function reviewAndRenew(pos, freshPools, state) {
  const freshPool = freshPools.find(p => p.pool === pos.pool);
  if (!freshPool) return false; // pool gone — exit

  // Check correlation
  if (pos.type !== 'lending') {
    const { pass } = await entryCorrelationPass(freshPool);
    if (!pass) return false;
  }

  // Check APY still in range
  const currentApy = freshPool.apy || 0;
  if (currentApy < MIN_APY || currentApy > MAX_APY) return false;

  // Check gas gate
  if (!passesGasGate(freshPool)) return false;

  // Check CoV (if LP)
  if (freshPool.type === 'lp') {
    const cov = await calcApyCoV(freshPool.pool);
    if (cov !== null && cov >= COV_THRESHOLD) return false;
  }

  return true; // still good — renew
}

// ── EXIT LOGIC ────────────────────────────────────────────────────────────────

async function checkExits(positions, freshPools, simStartAt, now, strategyType, state) {
  const perPosition = CAPITAL / 2 / POSITIONS_PER_STRATEGY;
  const remaining = [];
  const exits = [];

  for (const pos of positions) {
    const entryDate = new Date(pos.entryDate || simStartAt);
    const entryApy  = pos.entryApy != null ? pos.entryApy : (pos.apy||0);
    const daysSinceEntry = (now - entryDate) / (1000 * 60 * 60 * 24);
    const capital = pos.atRiskCapital || perPosition;
    const earned = capital * (pos.apy||0) / 100 / 365 * Math.max(daysSinceEntry, 0);

    // CHANGE 12e: Profit-take exit (check FIRST)
    // Tax-aware: suppress profit-take if near tax-free threshold (e.g. Germany 12mo)
    let profitTakeSuppressed = false;
    if (state && state.tax) {
      const tp = taxEngine.loadTaxProfile(state.tax?.country || 'AU');
      const ha = taxEngine.getOptimalHoldDuration(tp);
      const ca = taxEngine.getCountryStrategyAdjustments(tp);
      if (ca.profitTakeOverride && ha.minHoldForTaxBenefit > 0) {
        const daysToThreshold = ha.minHoldForTaxBenefit - daysSinceEntry;
        if (daysToThreshold > 0 && daysToThreshold <= 14) {
          profitTakeSuppressed = true; // within 14 days of tax-free — hold
        }
      }
    }
    if ((pos.cumulativeReturn || 0) >= 0.05 && !profitTakeSuppressed) {
      exits.push({ pos, exitReason: 'profit_take', exitCorr: null, earned });
      continue;
    }

    // CHANGE 7: Review-and-renew at window end (replaces forced exit)
    if (daysSinceEntry > WINDOW_DAYS) {
      const stillGood = await reviewAndRenew(pos, freshPools, state);
      if (stillGood) {
        // Reset entry date — position renewed (no gas cost, no CGT event)
        pos.entryDate = now.toISOString();
        remaining.push(pos);
        continue;
      } else {
        exits.push({ pos, exitReason: 'window_review_fail', exitCorr: null, earned });
        continue;
      }
    }

    // CHANGE 8: APY collapse with absolute floor
    const freshPool = freshPools.find(p => p.pool === pos.pool);
    const currentApy = freshPool ? (freshPool.apy||0) : (pos.apy||0);
    if (entryApy > 0 && (entryApy - currentApy) / entryApy > APY_DROP_THRESHOLD) {
      const apyFloor = strategyType === 'A' ? 5 : getBestLendingRate(freshPools);
      if (currentApy < apyFloor) {
        exits.push({ pos, exitReason: 'apy_collapse', exitCorr: null, earned });
        continue;
      }
      // Collapsed but still above floor — STAY
    }

    // Correlation check (LP only)
    if (pos.type !== 'lending') {
      const corrResult = await Promise.race([
        checkPositionCorr(pos),
        new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 5000))
      ]).catch(() => null);

      if (corrResult && corrResult.corr !== null) {
        // Strategy A: exit threshold = 0.40; Strategy B: use T1/T2 defaults
        const threshold = strategyType === 'A' ? CORR_EXIT_STRAT_A : corrResult.threshold;
        if (corrResult.corr < threshold) {
          // CHANGE 9: Yield override with TVL + IL checks
          const sym = (pos.symbol||'').toLowerCase().replace(/[^a-z]/g,'');
          const isYieldException = (
            (sym.includes('sol') && sym.includes('usdc')) ||
            (sym.includes('weth') && sym.includes('usdc')) ||
            (sym.includes('eth') && sym.includes('usdc')) ||
            (sym.includes('wbtc') && sym.includes('usdc')) ||
            (sym.includes('eth') && sym.includes('btc')) ||
            (sym.includes('weth') && sym.includes('wbtc')) ||
            (sym.includes('weth') && sym.includes('btc'))
          );

          let overrideHolds = false;
          if (isYieldException && (pos.apy||0) >= 50) {
            // Check all 3 override conditions
            const cond1_apy = (pos.apy||0) >= 50;

            // TVL check
            const tvl24hAgo = pos.tvl_24h_ago || pos.tvlUsd || 0;
            const currentTvl = freshPool ? (freshPool.tvlUsd || 0) : (pos.tvlUsd || 0);
            const tvlDrop = tvl24hAgo > 0 ? (tvl24hAgo - currentTvl) / tvl24hAgo : 0;
            const cond2_tvl = tvlDrop <= 0.15;

            // IL vs yield check
            const tokens = tokenize(pos.symbol || '').slice(0, 2);
            const id1 = TOKEN_IDS[tokens[0]];
            const id2 = TOKEN_IDS[tokens[1]];
            let cond3_il = true;
            if (id1 && id2) {
              try {
                const [p1, p2] = await Promise.all([fetchPrices(id1), fetchPrices(id2)]);
                const ilEst = calcDynamicIL(p1, p2);
                const annualIL = Math.abs(ilEst) * 52;
                cond3_il = annualIL < (pos.apy || 0) / 100;
              } catch {}
            }

            overrideHolds = cond1_apy && cond2_tvl && cond3_il;
          }

          if (overrideHolds) {
            remaining.push(pos); // yield override — hold
          } else {
            exits.push({ pos, exitReason: 'correlation_breach', exitCorr: corrResult.corr, earned });
          }
        } else {
          remaining.push(pos);
        }
      } else {
        remaining.push(pos); // no data — keep position
      }
    } else {
      remaining.push(pos);
    }
  }

  return { remaining, exits };
}

// ── REPOSITION LOGIC ─────────────────────────────────────────────────────────

async function pickReplacements(activePositions, freshPools, needed, strategyType, now, state) {
  if (needed <= 0) return [];
  const activeIds = new Set(activePositions.map(p => p.pool));
  let replacements;
  if (strategyType === 'A') {
    replacements = (await buildStrategyA(freshPools, activeIds, state)).slice(0, needed);
  } else {
    const cbActive = state?.circuitBreaker?.active || false;
    const activeLendingCount = activePositions.filter(p => p.type === 'lending').length;
    const allCandidates = freshPools.filter(p => !activeIds.has(p.pool));

    if (cbActive) {
      // All lending during circuit breaker
      replacements = allCandidates
        .filter(p => p.type === 'lending')
        .sort((a,b) => (b.apy||0) - (a.apy||0))
        .slice(0, needed);
    } else {
      const lendingNeeded = Math.max(0, 2 - activeLendingCount);
      const lendingCandidates = allCandidates.filter(p => p.type === 'lending')
        .sort((a,b) => (b.apy||0) - (a.apy||0)).slice(0, Math.min(lendingNeeded, needed));

      const lpIds = new Set([...activeIds, ...lendingCandidates.map(p => p.pool)]);
      const lpCandidatesRaw = allCandidates.filter(p => p.type === 'lp' && !lpIds.has(p.pool) && passesGasGate(p));

      // Check correlation on LP candidates
      const validLPs = [];
      for (const p of lpCandidatesRaw) {
        const { pass } = await entryCorrelationPass(p);
        if (pass) validLPs.push(p);
        if (validLPs.length >= needed * 2) break;
      }

      // Score with new formula
      const scoredLPs = await Promise.all(validLPs.map(async p => {
        const { ilDynamic } = await getILEstimateForPool(p);
        const cov = p._cov != null ? p._cov : (await calcApyCoV(p.pool)) || 0;
        const apyStability = Math.max(0, 1.0 - cov);
        const baseScore = ((p.apy || 0) / 80) * 0.45
          + Math.min(Math.log10((p.tvlUsd || 1) / 1_000_000) / 3, 1) * 0.30
          + ilDynamic * 0.15
          + apyStability * 0.10;
        // v2.2: reputation bonus
        const score = baseScore + (reputationMultiplier(p, state) - 1.0) * 0.10;
        return { ...p, score, ilDynamic, apyStability };
      }));
      scoredLPs.sort((a,b) => b.score - a.score);

      const lpNeeded = needed - lendingCandidates.length;
      const lpSlice = scoredLPs.slice(0, Math.max(0, lpNeeded));

      // If not enough LP candidates, fill with more lending
      const remaining = needed - lendingCandidates.length - lpSlice.length;
      let extraLending = [];
      if (remaining > 0) {
        extraLending = allCandidates
          .filter(p => p.type === 'lending' && !lendingCandidates.some(l => l.pool === p.pool) && !lpSlice.some(l => l.pool === p.pool))
          .sort((a,b) => (b.apy||0) - (a.apy||0))
          .slice(0, remaining);
      }

      replacements = [...lendingCandidates, ...lpSlice, ...extraLending].slice(0, needed);
    }
  }
  return replacements.map(p => withEntryFields(p, now, state));
}

// ── CHANGE 12: Profit booking ────────────────────────────────────────────────

function applyProfitBooking(pos, netEarnings, strategyType, profitVault) {
  const baseCapital = CAPITAL / 2 / POSITIONS_PER_STRATEGY; // $500

  if (strategyType === 'B') {
    // Strategy B: sweep ALL earnings to profit vault
    if (netEarnings > 0) {
      profitVault.balance += netEarnings;
    }
    return;
  }

  // Strategy A: compound up to $600
  pos.cumulativeReturn = (pos.crystallisedEarnings || 0) / baseCapital;

  if (pos.cumulativeReturn >= 0.02) { // 2% threshold ($10 on $500)
    const banked = netEarnings * 0.70;
    pos.crystallisedEarnings = (pos.crystallisedEarnings || 0) + banked;
    // 30% stays at risk — compound into position
    const atRiskGain = netEarnings * 0.30;
    pos.atRiskCapital = (pos.atRiskCapital || baseCapital) + atRiskGain;
  } else {
    // Below threshold — all stays at risk (compounding)
    pos.atRiskCapital = (pos.atRiskCapital || baseCapital) + netEarnings;
    pos.crystallisedEarnings = (pos.crystallisedEarnings || 0) + netEarnings;
  }

  // Strategy A cap: compound up to $600 max
  const maxPos = baseCapital * 1.20; // $600
  if ((pos.atRiskCapital || 0) > maxPos) {
    const excess = pos.atRiskCapital - maxPos;
    profitVault.balance += excess;
    pos.atRiskCapital = maxPos;
  }

  pos.cumulativeReturn = (pos.crystallisedEarnings || 0) / baseCapital;
}

// ── CHANGE 13: Tax-aware rotation check ──────────────────────────────────────

function shouldSkipRotation(currentPos, newPool, state) {
  const taxProfile = taxEngine.loadTaxProfile(state?.tax?.country || 'AU');
  const chain = (currentPos.chain || '').toLowerCase();
  const gas = GAS_COSTS[chain] || { enter: 0.10, exit: 0.10 };
  const gasCost = gas.enter + gas.exit;

  // Use tax engine's shouldRotate (returns true if rotation is beneficial)
  const holdDays = currentPos.entryDate
    ? (Date.now() - new Date(currentPos.entryDate).getTime()) / (1000 * 60 * 60 * 24)
    : 0;
  const posForEngine = {
    ...currentPos,
    currentApy: currentPos.apy || 0,
    costBasisUSD: (currentPos.costBasisAUD || 0) / (taxProfile.defaultExchangeRate || 1),
    holdingDays: holdDays,
    userMarginalRate: state?.tax?.marginalRate || taxProfile.incomeTax.defaultMarginalRate,
  };

  const shouldDoRotation = taxEngine.shouldRotate(posForEngine, newPool, taxProfile, gasCost);
  return !shouldDoRotation; // shouldSkipRotation is inverse of shouldRotate
}

// ── CHANGE 13h: EOFY Tax Export ──────────────────────────────────────────────

function exportTaxSummary(state, startDate, endDate) {
  const rows = [['date','event_type','pool','chain','pair','costBasisAUD','proceedsAUD','cgtGainAUD','yieldIncomeAUD','gasDeductibleAUD','strategy']];

  for (const [strat, stratKey] of [['A', 'strategyA'], ['B', 'strategyB']]) {
    // Active positions
    for (const pos of (state[stratKey]?.positions || [])) {
      rows.push([
        pos.entryDate || '', 'active', pos.pool || '', pos.chain || '', pos.symbol || '',
        (pos.costBasisAUD || 0).toFixed(2), '0.00', '0.00',
        (pos.yieldIncomeAUD || 0).toFixed(2), (pos.gasDeductibleAUD || 0).toFixed(2), strat
      ]);
    }
    // Rotations (exited)
    for (const rot of (state.rotations || [])) {
      if (rot.strategy !== strat) continue;
      const exitDate = rot.exitDate || '';
      if (startDate && exitDate < startDate) continue;
      if (endDate && exitDate > endDate) continue;
      rows.push([
        exitDate, 'exit', rot.pool || '', rot.chain || '', rot.symbol || '',
        (rot.costBasisAUD || 0).toFixed(2), (rot.proceedsAUD || 0).toFixed(2),
        (rot.cgtGain || 0).toFixed(2), (rot.yieldIncomeAUD || 0).toFixed(2),
        (rot.gasDeductibleAUD || 0).toFixed(2), strat
      ]);
    }
  }

  const csv = rows.map(r => r.join(',')).join('\n');
  const year = new Date().getFullYear();
  const outPath = path.join(__dirname, `tax-export-${year}.csv`);
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, csv);
  console.log(`📄 Tax export written to ${outPath}`);
  return outPath;
}

// ── CHANGE 16: Max drawdown calc ─────────────────────────────────────────────

function calcMaxDrawdown(snapshots) {
  let peak = 0, maxDD = 0;
  for (const s of (snapshots || [])) {
    if (s.balance > peak) peak = s.balance;
    if (peak > 0) {
      const dd = (peak - s.balance) / peak;
      if (dd > maxDD) maxDD = dd;
    }
  }
  return maxDD;
}

// ── EARNINGS CALC ─────────────────────────────────────────────────────────────

function calcDailyEarnings(positions) {
  return positions.reduce((sum, p) => {
    const capital = p.atRiskCapital || (CAPITAL / 2 / POSITIONS_PER_STRATEGY);
    return sum + capital * (p.apy||0) / 365 / 100;
  }, 0);
}

// ── v2.2: SELF-IMPROVEMENT ENGINE ─────────────────────────────────────────

function getEffectiveParam(paramName, state) {
  const tp = state.tuneableParams?.[paramName];
  if (!tp) return null;
  const base = tp.current;
  const regime = state.learning?.marketRegime?.current || 'unknown';
  const override = REGIME_OVERRIDES[regime]?.[paramName];
  const confidence = state.learning?.marketRegime?.confidence || 0;
  if (override != null) {
    const effective = base * (1 - confidence) + (base * override) * confidence;
    return Math.max(tp.min, Math.min(tp.max, effective));
  }
  return base;
}

function normaliseScoringWeights(params) {
  const keys = ['scoringWeight_APY', 'scoringWeight_TVL', 'scoringWeight_IL', 'scoringWeight_stability'];
  const total = keys.reduce((s, k) => s + (params[k]?.current || 0), 0);
  if (total > 0 && Math.abs(total - 1.0) > 0.001) {
    for (const k of keys) {
      if (params[k]) params[k].current = params[k].current / total;
    }
  }
}

function evaluatePerformance(exitHistory) {
  const sevenDaysAgo = Date.now() - 7 * 24 * 3600 * 1000;
  const recent = (exitHistory || []).filter(e => {
    const ts = e.exitDate ? new Date(e.exitDate).getTime() : 0;
    return ts >= sevenDaysAgo;
  });

  const metrics = {
    profitable_exits: 0,
    unprofitable_exits: 0,
    correlation_breach_exits_that_recovered: 0,
    correlation_breach_exits_that_didnt: 0,
    profit_takes_where_position_kept_climbing: 0,
    profit_takes_where_position_declined_after: 0,
    apy_collapse_exits_that_were_right: 0,
    apy_collapse_exits_that_were_wrong: 0,
    avg_position_return: 0,
    total_exits: recent.length,
  };

  let totalReturn = 0;
  for (const ex of recent) {
    if ((ex.earned || 0) > 0) metrics.profitable_exits++;
    else metrics.unprofitable_exits++;
    totalReturn += ex.earned || 0;

    if (ex.exitReason === 'correlation_breach') {
      // Without post-exit data, assume didnt recover (conservative)
      metrics.correlation_breach_exits_that_didnt++;
    }
    if (ex.exitReason === 'profit_take') {
      // Without post-exit data, assume declined (conservative — validates the take)
      metrics.profit_takes_where_position_declined_after++;
    }
    if (ex.exitReason === 'apy_collapse') {
      metrics.apy_collapse_exits_that_were_right++;
    }
  }
  metrics.avg_position_return = recent.length > 0 ? totalReturn / recent.length : 0;
  return metrics;
}

function adjustParameters(metrics, state) {
  const params = state.tuneableParams;
  if (!params) return [];
  const changes = [];

  function nudge(paramName, direction) {
    const p = params[paramName];
    if (!p) return;
    const oldVal = p.current;
    if (direction > 0) p.current = Math.min(p.max, p.current + p.step);
    else p.current = Math.max(p.min, p.current - p.step);
    if (p.current !== oldVal) {
      changes.push({ param: paramName, from: parseFloat(oldVal.toFixed(6)), to: parseFloat(p.current.toFixed(6)) });
    }
  }

  // Correlation thresholds
  if (metrics.correlation_breach_exits_that_recovered > metrics.correlation_breach_exits_that_didnt) {
    nudge('correlationBreachExit_A', -1);
    nudge('correlationEntryGate_A', -1);
  }
  if (metrics.correlation_breach_exits_that_didnt > (metrics.correlation_breach_exits_that_recovered || 0) * 2) {
    nudge('correlationBreachExit_A', 1);
    nudge('correlationEntryGate_A', 1);
  }

  // Profit take
  if (metrics.profit_takes_where_position_kept_climbing > (metrics.profit_takes_where_position_declined_after || 0) * 1.5) {
    nudge('profitTakeThreshold', 1);
  }
  if (metrics.profit_takes_where_position_declined_after > (metrics.profit_takes_where_position_kept_climbing || 0) * 1.5) {
    nudge('profitTakeThreshold', -1);
  }

  // APY floor
  if (metrics.apy_collapse_exits_that_were_wrong > metrics.apy_collapse_exits_that_were_right) {
    nudge('apyCollapseFloor_A', -1);
  }

  // Normalise scoring weights
  normaliseScoringWeights(params);

  // Clamp all
  for (const key of Object.keys(params)) {
    const p = params[key];
    p.current = Math.max(p.min, Math.min(p.max, p.current));
  }

  return changes;
}

function recordParameterChanges(changes, metrics, state) {
  if (!state.learning) return;
  if (changes.length === 0) return;
  state.learning.parameterHistory = state.learning.parameterHistory || [];
  state.learning.parameterHistory.push({
    timestamp: new Date().toISOString(),
    cycle: state.cycles,
    changes,
    performanceBefore: { avgReturn7d: metrics.avg_position_return },
    performanceAfter: null,
  });
  // Keep last 100 entries
  if (state.learning.parameterHistory.length > 100) {
    state.learning.parameterHistory = state.learning.parameterHistory.slice(-100);
  }
}

function checkRollbacks(state) {
  if (!state.learning?.parameterHistory) return;
  const history = state.learning.parameterHistory;
  if (history.length < 2) return;

  // Check entries from ~7 days ago
  const sevenDaysAgo = Date.now() - 7 * 24 * 3600 * 1000;
  for (const entry of history) {
    if (entry.performanceAfter != null) continue; // already evaluated
    const entryTs = new Date(entry.timestamp).getTime();
    if (entryTs > sevenDaysAgo) continue; // not old enough

    // Fill in performanceAfter with current metrics
    const currentMetrics = evaluatePerformance(state.exitHistory || []);
    entry.performanceAfter = { avgReturn7d: currentMetrics.avg_position_return };

    // Check for decline > 20%
    const before = entry.performanceBefore?.avgReturn7d || 0;
    const after = entry.performanceAfter.avgReturn7d;
    if (before > 0 && after < before * 0.80) {
      // Rollback
      for (const change of entry.changes) {
        if (state.tuneableParams[change.param]) {
          console.log(`   ⏪ ROLLBACK: ${change.param} reverted ${change.to} → ${change.from}`);
          state.tuneableParams[change.param].current = change.from;
        }
      }
    }
  }
}

function updateReputation(pos, outcome, state) {
  if (!state.learning) return;
  const protocol = (pos.project || 'unknown').toLowerCase();
  const chain = (pos.chain || 'unknown').toLowerCase();
  const pair = (pos.symbol || 'unknown');
  const poolKey = `${protocol}-${chain}-${pair}`;

  // Helper for running average
  const runAvg = (old, val, n) => n <= 1 ? val : old + (val - old) / n;

  // Pool scores
  if (!state.learning.poolScores) state.learning.poolScores = {};
  const pool = state.learning.poolScores[poolKey] || {
    totalPositions: 0, profitablePositions: 0, avgReturn: 0, avgHoldDays: 0,
    correlationBreaches: 0, apyAccuracy: 0.5, reputationScore: 0.5, lastUpdated: null
  };
  pool.totalPositions++;
  if ((outcome.earned || 0) > 0) pool.profitablePositions++;
  pool.avgReturn = runAvg(pool.avgReturn, outcome.earned || 0, pool.totalPositions);

  const holdDays = outcome.holdDays || 0;
  pool.avgHoldDays = runAvg(pool.avgHoldDays, holdDays, pool.totalPositions);

  if (outcome.exitReason === 'correlation_breach') pool.correlationBreaches++;

  const winRate = pool.totalPositions > 0 ? pool.profitablePositions / pool.totalPositions : 0.5;
  const breachRate = pool.totalPositions > 0 ? pool.correlationBreaches / pool.totalPositions : 0;
  pool.reputationScore = winRate * 0.40 + pool.apyAccuracy * 0.30 + (1 - breachRate) * 0.20 + Math.min((pool.avgReturn || 0) / 0.05, 1.0) * 0.10;
  pool.lastUpdated = new Date().toISOString();
  state.learning.poolScores[poolKey] = pool;

  // Chain scores
  if (!state.learning.chainScores) state.learning.chainScores = {};
  const ch = state.learning.chainScores[chain] || {
    totalPositions: 0, profitablePositions: 0, avgReturn: 0, reputationScore: 0.5, lastUpdated: null
  };
  ch.totalPositions++;
  if ((outcome.earned || 0) > 0) ch.profitablePositions++;
  ch.avgReturn = runAvg(ch.avgReturn, outcome.earned || 0, ch.totalPositions);
  ch.reputationScore = ch.totalPositions > 0 ? ch.profitablePositions / ch.totalPositions : 0.5;
  ch.lastUpdated = new Date().toISOString();
  state.learning.chainScores[chain] = ch;

  // Protocol scores
  if (!state.learning.protocolScores) state.learning.protocolScores = {};
  const pr = state.learning.protocolScores[protocol] || {
    totalPositions: 0, profitablePositions: 0, avgReturn: 0, reputationScore: 0.5, lastUpdated: null
  };
  pr.totalPositions++;
  if ((outcome.earned || 0) > 0) pr.profitablePositions++;
  pr.avgReturn = runAvg(pr.avgReturn, outcome.earned || 0, pr.totalPositions);
  pr.reputationScore = pr.totalPositions > 0 ? pr.profitablePositions / pr.totalPositions : 0.5;
  pr.lastUpdated = new Date().toISOString();
  state.learning.protocolScores[protocol] = pr;
}

function reputationMultiplier(pool, state) {
  if (!state.learning) return 1.0;
  const protocol = (pool.project || 'unknown').toLowerCase();
  const chain = (pool.chain || 'unknown').toLowerCase();
  const pair = (pool.symbol || 'unknown');
  const poolKey = `${protocol}-${chain}-${pair}`;

  let poolRep = state.learning.poolScores?.[poolKey]?.reputationScore;
  let protoRep = state.learning.protocolScores?.[protocol]?.reputationScore;
  let chainRep = state.learning.chainScores?.[chain]?.reputationScore;

  // Cold start: unknown = 0.50 + exploration bonus
  const poolData = state.learning.poolScores?.[poolKey];
  if (!poolData || poolData.totalPositions < 3) {
    const positions = poolData?.totalPositions || 0;
    poolRep = 0.50 + 0.02 * (3 - positions);
  }
  if (poolRep == null) poolRep = 0.50;
  if (protoRep == null) protoRep = 0.50;
  if (chainRep == null) chainRep = 0.50;

  const combined = poolRep * 0.50 + protoRep * 0.30 + chainRep * 0.20;
  return 0.80 + (combined * 0.40); // range: 0.80 to 1.20
}

function decayReputation(state) {
  if (!state.learning) return;
  const decayRate = 0.02;
  const neutral = 0.50;

  for (const scores of [state.learning.poolScores, state.learning.chainScores, state.learning.protocolScores]) {
    if (!scores) continue;
    for (const key of Object.keys(scores)) {
      const rec = scores[key];
      if (rec.reputationScore != null) {
        rec.reputationScore = rec.reputationScore + (neutral - rec.reputationScore) * decayRate;
      }
    }
  }
}

async function detectMarketRegime(state) {
  if (!state.learning) return;
  try {
    const btcId = 'coingecko:bitcoin';
    const ethId = 'coingecko:ethereum';
    const [btcPrices, ethPrices] = await Promise.all([fetchPrices(btcId), fetchPrices(ethId)]);

    if (!btcPrices || btcPrices.length < 10 || !ethPrices || ethPrices.length < 10) {
      console.log('   Level 3: insufficient price data for regime detection');
      return;
    }

    const btcNow = btcPrices[btcPrices.length - 1];
    const btc7d = btcPrices[0];
    const ethNow = ethPrices[ethPrices.length - 1];
    const eth7d = ethPrices[0];

    const btcReturn7d = btc7d > 0 ? (btcNow - btc7d) / btc7d : 0;
    const ethReturn7d = eth7d > 0 ? (ethNow - eth7d) / eth7d : 0;
    const avgReturn7d = (btcReturn7d + ethReturn7d) / 2;

    // Calculate 7d realised vol from hourly returns
    const btcReturns = toLogReturns(btcPrices);
    const vol7d = btcReturns.length > 1
      ? Math.sqrt(btcReturns.reduce((s, r) => s + r * r, 0) / btcReturns.length) * Math.sqrt(24 * 7)
      : 0;

    // Use hardcoded 30d baseline (0.45 annualised) until we have enough data
    const vol30d = 0.45;
    const volRatio = vol30d > 0 ? vol7d / vol30d : 1;

    let regime = 'regime_transition';
    let confidence = 0.3;

    if (avgReturn7d > 0.05 && volRatio < 1.5) {
      regime = 'bull_trending';
      confidence = Math.min(Math.abs(avgReturn7d) / 0.10, 1.0);
    } else if (avgReturn7d < -0.05 && volRatio < 1.5) {
      regime = 'bear_trending';
      confidence = Math.min(Math.abs(avgReturn7d) / 0.10, 1.0);
    } else if (volRatio > 2.0) {
      regime = 'high_volatility';
      confidence = Math.min((volRatio - 1.0) / 2.0, 1.0);
    } else if (volRatio < 0.5) {
      regime = 'low_volatility';
      confidence = Math.min((1.0 - volRatio) / 0.5, 1.0);
    }

    const mr = state.learning.marketRegime;
    const oldRegime = mr.current;
    if (regime !== oldRegime && confidence >= 0.60) {
      mr.history = mr.history || [];
      mr.history.push({ from: oldRegime, to: regime, timestamp: new Date().toISOString(), confidence });
      if (mr.history.length > 50) mr.history = mr.history.slice(-50);
      mr.current = regime;
      console.log(`   Level 3: regime ${oldRegime} → ${regime} (confidence ${(confidence * 100).toFixed(0)}%)`);
    } else if (regime !== oldRegime) {
      console.log(`   Level 3: regime shift ${oldRegime} → ${regime} detected but confidence too low (${(confidence * 100).toFixed(0)}%)`);
    } else {
      console.log(`   Level 3: regime ${regime} (confidence ${(confidence * 100).toFixed(0)}%)`);
    }

    mr.confidence = confidence;
    mr.detectedAt = new Date().toISOString();
    mr.btcReturn7d = parseFloat(btcReturn7d.toFixed(4));
    mr.ethReturn7d = parseFloat(ethReturn7d.toFixed(4));
    mr.volRatio = parseFloat(volRatio.toFixed(4));
  } catch (err) {
    console.log(`   Level 3: regime detection error — ${err.message}`);
  }
}

// ── MAIN SIMULATION ───────────────────────────────────────────────────────────

function initState(now) {
  return {
    version: '2.1',
    startedAt: now.toISOString(),
    lastUpdatedAt: now.toISOString(),
    capital: CAPITAL,
    rotations: [],
    strategyA: {
      name: 'Max APY',
      positions: [],
      virtualBalance: CAPITAL / 2,
      totalEarned: 0,
      totalRotations: 0,
      snapshots: [],
    },
    strategyB: {
      name: 'Risk-Adjusted',
      positions: [],
      virtualBalance: CAPITAL / 2,
      totalEarned: 0,
      totalRotations: 0,
      snapshots: [],
    },
    cycles: 0,
    history: [],
    // CHANGE 11: Circuit breaker
    circuitBreaker: {
      active: false,
      triggeredAt: null,
      peakValue24h: CAPITAL,
      stableCount: 0,
      cyclesSinceReset: 0,
    },
    // CHANGE 12: Profit vault
    profitVault: {
      strategyA: { balance: 0, pool: null },
      strategyB: { balance: 0, pool: null },
    },
    // CHANGE 13: Tax tracking (global tax module)
    tax: {
      country: 'AU',
      marginalRate: 0.32,
      costBasisMethod: 'fifo',
      usdToAud: 1.55,
      events: [],
      annualSummary: {},
      strategyA: { totalCGT_AUD: 0, totalYieldIncome_AUD: 0, totalGasDeductible_AUD: 0, afterTaxReturn_AUD: 0 },
      strategyB: { totalCGT_AUD: 0, totalYieldIncome_AUD: 0, totalGasDeductible_AUD: 0, afterTaxReturn_AUD: 0 },
    },
    // v2.2: Self-improvement engine
    tuneableParams: {
      correlationThreshold_T1:  { current: 0.95, min: 0.85, max: 0.99, step: 0.01 },
      correlationThreshold_T2:  { current: 0.60, min: 0.40, max: 0.80, step: 0.02 },
      correlationEntryGate_A:   { current: 0.60, min: 0.40, max: 0.80, step: 0.02 },
      correlationBreachExit_A:  { current: 0.40, min: 0.20, max: 0.55, step: 0.02 },
      apyCollapseFloor_A:       { current: 5.0,  min: 2.0,  max: 10.0, step: 0.5  },
      apyStabilityCoV:          { current: 0.50, min: 0.30, max: 0.70, step: 0.05 },
      profitTakeThreshold:      { current: 0.05, min: 0.02, max: 0.10, step: 0.005 },
      circuitBreakerDrop:       { current: 0.05, min: 0.03, max: 0.10, step: 0.005 },
      yieldOverrideMinAPY:      { current: 50.0, min: 30.0, max: 70.0, step: 2.0  },
      tvlDropOverrideMax:       { current: 0.15, min: 0.05, max: 0.25, step: 0.02 },
      scoringWeight_APY:        { current: 0.45, min: 0.30, max: 0.60, step: 0.025 },
      scoringWeight_TVL:        { current: 0.30, min: 0.15, max: 0.40, step: 0.025 },
      scoringWeight_IL:         { current: 0.15, min: 0.05, max: 0.30, step: 0.025 },
      scoringWeight_stability:  { current: 0.10, min: 0.05, max: 0.25, step: 0.025 },
      highWaterMarkBankPercent: { current: 0.70, min: 0.50, max: 0.90, step: 0.05  },
    },
    learning: {
      version: '2.2', enabled: true,
      level1_paramTuning: true, level2_reputation: true, level3_regimeDetection: true,
      lastLearnCycle: null, learnCycleCount: 0, parameterHistory: [],
      poolScores: {}, chainScores: {}, protocolScores: {},
      marketRegime: { current: 'unknown', confidence: 0, detectedAt: null, btcReturn7d: 0, ethReturn7d: 0, volRatio: 1, history: [] },
    },
    exitHistory: [],
  };
}

// CHANGE 15: Migrate old state to v2.1
function migrateState(state) {
  if (state.version === '2.1') return state;

  state.version = '2.1';
  if (!state.rotations) state.rotations = [];
  if (!state.strategyA.totalRotations) state.strategyA.totalRotations = 0;
  if (!state.strategyB.totalRotations) state.strategyB.totalRotations = 0;

  if (!state.circuitBreaker) {
    state.circuitBreaker = {
      active: false,
      triggeredAt: null,
      peakValue24h: (state.strategyA.virtualBalance || 0) + (state.strategyB.virtualBalance || 0),
      stableCount: 0,
      cyclesSinceReset: 0,
    };
  }
  if (!state.circuitBreaker.cyclesSinceReset) state.circuitBreaker.cyclesSinceReset = 0;

  if (!state.profitVault) {
    state.profitVault = {
      strategyA: { balance: 0, pool: null },
      strategyB: { balance: 0, pool: null },
    };
  }

  if (!state.tax) {
    state.tax = {
      country: 'AU',
      marginalRate: 0.32,
      costBasisMethod: 'fifo',
      usdToAud: 1.55,
      events: [],
      annualSummary: {},
      strategyA: { totalCGT_AUD: 0, totalYieldIncome_AUD: 0, totalGasDeductible_AUD: 0, afterTaxReturn_AUD: 0 },
      strategyB: { totalCGT_AUD: 0, totalYieldIncome_AUD: 0, totalGasDeductible_AUD: 0, afterTaxReturn_AUD: 0 },
    };
  }
  if (!state.tax.country) state.tax.country = 'AU';
  if (!state.tax.costBasisMethod) state.tax.costBasisMethod = 'fifo';
  if (!state.tax.events) state.tax.events = [];
  if (!state.tax.annualSummary) state.tax.annualSummary = {};
  if (!state.tax.strategyA) state.tax.strategyA = { totalCGT_AUD: 0, totalYieldIncome_AUD: 0, totalGasDeductible_AUD: 0, afterTaxReturn_AUD: 0 };
  if (!state.tax.strategyB) state.tax.strategyB = { totalCGT_AUD: 0, totalYieldIncome_AUD: 0, totalGasDeductible_AUD: 0, afterTaxReturn_AUD: 0 };

  // v2.2: Self-improvement engine fields
  if (!state.tuneableParams) state.tuneableParams = {
    correlationThreshold_T1:  { current: 0.95, min: 0.85, max: 0.99, step: 0.01 },
    correlationThreshold_T2:  { current: 0.60, min: 0.40, max: 0.80, step: 0.02 },
    correlationEntryGate_A:   { current: 0.60, min: 0.40, max: 0.80, step: 0.02 },
    correlationBreachExit_A:  { current: 0.40, min: 0.20, max: 0.55, step: 0.02 },
    apyCollapseFloor_A:       { current: 5.0,  min: 2.0,  max: 10.0, step: 0.5  },
    apyStabilityCoV:          { current: 0.50, min: 0.30, max: 0.70, step: 0.05 },
    profitTakeThreshold:      { current: 0.05, min: 0.02, max: 0.10, step: 0.005 },
    circuitBreakerDrop:       { current: 0.05, min: 0.03, max: 0.10, step: 0.005 },
    yieldOverrideMinAPY:      { current: 50.0, min: 30.0, max: 70.0, step: 2.0  },
    tvlDropOverrideMax:       { current: 0.15, min: 0.05, max: 0.25, step: 0.02 },
    scoringWeight_APY:        { current: 0.45, min: 0.30, max: 0.60, step: 0.025 },
    scoringWeight_TVL:        { current: 0.30, min: 0.15, max: 0.40, step: 0.025 },
    scoringWeight_IL:         { current: 0.15, min: 0.05, max: 0.30, step: 0.025 },
    scoringWeight_stability:  { current: 0.10, min: 0.05, max: 0.25, step: 0.025 },
    highWaterMarkBankPercent: { current: 0.70, min: 0.50, max: 0.90, step: 0.05  },
  };
  if (!state.learning) state.learning = {
    version: '2.2', enabled: true,
    level1_paramTuning: true, level2_reputation: true, level3_regimeDetection: true,
    lastLearnCycle: null, learnCycleCount: 0, parameterHistory: [],
    poolScores: {}, chainScores: {}, protocolScores: {},
    marketRegime: { current: 'unknown', confidence: 0, detectedAt: null, btcReturn7d: 0, ethReturn7d: 0, volRatio: 1, history: [] },
  };
  if (!state.exitHistory) state.exitHistory = [];

  // Migrate positions
  const perPosition = CAPITAL / 2 / POSITIONS_PER_STRATEGY;
  for (const strat of ['strategyA', 'strategyB']) {
    for (const pos of (state[strat].positions || [])) {
      if (pos.crystallisedEarnings == null) pos.crystallisedEarnings = 0;
      if (pos.atRiskCapital == null) pos.atRiskCapital = perPosition;
      if (pos.cumulativeReturn == null) pos.cumulativeReturn = 0;
      if (pos.isLending == null) pos.isLending = pos.type === 'lending';
      if (pos.costBasisAUD == null) pos.costBasisAUD = perPosition * (state.tax.usdToAud || 1.55);
      if (pos.proceedsAUD == null) pos.proceedsAUD = 0;
      if (pos.cgtGain == null) pos.cgtGain = 0;
      if (pos.yieldIncomeAUD == null) pos.yieldIncomeAUD = 0;
      if (pos.gasDeductibleAUD == null) pos.gasDeductibleAUD = 0;
      if (pos.audSnapshots == null) pos.audSnapshots = [];
      if (pos.estimatedGas == null) {
        const gas = getGasForChain(pos.chain);
        pos.estimatedGas = gas.enter;
      }
      if (pos.tvl_24h_ago == null) pos.tvl_24h_ago = pos.tvlUsd || 0;
      if (pos.tvl_24h_updateCycle == null) pos.tvl_24h_updateCycle = 0;
    }
  }

  return state;
}

async function runSimulation(reset = false) {
  console.log('\n🤖 YIELD AGENT SIMULATOR v2.2 — A/B TEST MODE (Self-Improvement Engine)');
  console.log('═'.repeat(60));

  const now = new Date();
  let state = loadState();

  if (!state || reset) {
    console.log('🆕 Initialising new v2.1 simulation...');
    state = initState(now);
  } else {
    state = migrateState(state);
  }

  console.log(`\n📡 Fetching live pool data from DeFiLlama...`);
  const pools = await getPools();
  console.log(`✅ Found ${pools.length} pools meeting criteria (after CoV + gas filters)\n`);

  const lastUpdate = new Date(state.lastUpdatedAt);
  const hoursSince = (now - lastUpdate) / (1000 * 60 * 60);
  const daysSince  = hoursSince / 24;

  const rotationLog = [];
  const taxProfile = taxEngine.loadTaxProfile(state.tax?.country || 'AU');
  const countryAdj = taxEngine.getCountryStrategyAdjustments(taxProfile);
  const holdAdvice = taxEngine.getOptimalHoldDuration(taxProfile);
  const usdToAud = taxProfile.defaultExchangeRate;
  const marginalRate = state.tax.marginalRate || taxProfile.incomeTax.defaultMarginalRate;

  if (state.cycles === 0) {
    // First run — initialise positions
    const posA = (await buildStrategyA(pools, new Set(), state)).slice(0, POSITIONS_PER_STRATEGY);
    const cbActive = state.circuitBreaker?.active || false;
    const posB = (await buildStrategyB(pools, new Set(), cbActive, state)).slice(0, POSITIONS_PER_STRATEGY);
    state.strategyA.positions = posA.map(p => withEntryFields(p, now, state));
    state.strategyB.positions = posB.map(p => withEntryFields(p, now, state));
    console.log('🌱 Positions initialised (v2.1 with gas/tax/profit tracking).');
  } else {
    // ── CHANGE 11: Circuit breaker check ─────────────────────────────────────
    const portfolioValue = state.strategyA.virtualBalance + state.strategyB.virtualBalance;
    const cb = state.circuitBreaker;

    // Update rolling peak
    if (portfolioValue > cb.peakValue24h) cb.peakValue24h = portfolioValue;

    // Reset peak every 8 cycles (~24h)
    cb.cyclesSinceReset = (cb.cyclesSinceReset || 0) + 1;
    if (cb.cyclesSinceReset >= 8) {
      cb.peakValue24h = portfolioValue;
      cb.cyclesSinceReset = 0;
    }

    // Check drawdown
    const drawdown = cb.peakValue24h > 0 ? (cb.peakValue24h - portfolioValue) / cb.peakValue24h : 0;
    if (!cb.active && drawdown > 0.05) {
      cb.active = true;
      cb.triggeredAt = now.toISOString();
      cb.stableCount = 0;
      console.log(`🚨 CIRCUIT BREAKER TRIGGERED — drawdown ${(drawdown*100).toFixed(1)}%`);
      console.log(`   Peak: ${fmtUSD(cb.peakValue24h)} → Current: ${fmtUSD(portfolioValue)}`);
    }

    // Resume check: 8 consecutive stable cycles
    if (cb.active) {
      if (portfolioValue >= (cb._lastValue || 0)) {
        cb.stableCount = (cb.stableCount || 0) + 1;
      } else {
        cb.stableCount = 0;
      }
      cb._lastValue = portfolioValue;

      if (cb.stableCount >= 8) {
        console.log('✅ Circuit breaker RESUMED — 8 stable cycles');
        cb.active = false;
        cb.stableCount = 0;
      }
    }

    // ── EVICT PARKING POSITIONS — retry LP slots every cycle ─────────────────
    // Parking positions are temporary placeholders. Always exit them so LP
    // selection is retried each cycle with fresh pool data.
    state.strategyA.positions = state.strategyA.positions.filter(p => p.type !== 'parking');
    state.strategyB.positions = state.strategyB.positions.filter(p => p.type !== 'parking');

    // ── EXIT CHECKS ──────────────────────────────────────────────────────────
    console.log('🔍 Checking positions for exit conditions...');

    const { remaining: remA, exits: exitsA } = await checkExits(
      state.strategyA.positions, pools, state.startedAt, now, 'A', state
    );
    const { remaining: remB, exits: exitsB } = await checkExits(
      state.strategyB.positions, pools, state.startedAt, now, 'B', state
    );

    // If circuit breaker just triggered → force exit all LP positions
    if (cb.active && cb.stableCount === 0) {
      const forceExitLP = (remaining, strat) => {
        const kept = [];
        const forced = [];
        for (const pos of remaining) {
          if (pos.type !== 'lending') {
            const daysSinceEntry = (now - new Date(pos.entryDate || state.startedAt)) / (1000*60*60*24);
            const capital = pos.atRiskCapital || (CAPITAL/2/POSITIONS_PER_STRATEGY);
            const earned = capital * (pos.apy||0)/100/365 * Math.max(daysSinceEntry, 0);
            forced.push({ pos, exitReason: 'circuit_breaker', exitCorr: null, earned });
          } else {
            kept.push(pos);
          }
        }
        return { kept, forced };
      };
      const { kept: keptA, forced: forcedA } = forceExitLP(remA, 'A');
      const { kept: keptB, forced: forcedB } = forceExitLP(remB, 'B');
      exitsA.push(...forcedA);
      exitsB.push(...forcedB);
      remA.length = 0; remA.push(...keptA);
      remB.length = 0; remB.push(...keptB);
    }

    // Record exits + apply gas deductions and tax tracking (global tax engine)
    for (const { pos, exitReason, exitCorr, earned } of exitsA) {
      const gasOut = getGasForChain(pos.chain).exit;
      const gasIn = pos.estimatedGas || 0.10;
      const netEarned = Math.max(0, earned - gasIn - gasOut);
      const posValue = (pos.atRiskCapital || 500) + (pos.crystallisedEarnings || 0);
      const gainUSD = Math.max(0, posValue - (CAPITAL / 2 / POSITIONS_PER_STRATEGY));
      const holdDaysA = (now - new Date(pos.entryDate || state.startedAt)) / (1000 * 60 * 60 * 24);
      const isLP = !pos.isLending && pos.type !== 'lending';
      const isCGTEvent = taxEngine.isRotationCGTEvent(pos, taxProfile);
      const cgtUSD = isCGTEvent ? taxEngine.calculateCGT(gainUSD, holdDaysA, taxProfile, marginalRate) : 0;
      const yieldTaxUSD = taxEngine.calculateIncomeTax(netEarned, taxProfile, marginalRate);

      // Convert to local currency for tracking
      const proceedsLocal = posValue * usdToAud;
      const cgtLocal = cgtUSD * usdToAud;

      state.tax.strategyA.totalCGT_AUD += cgtLocal;
      state.tax.strategyA.totalYieldIncome_AUD += pos.yieldIncomeAUD || 0;
      state.tax.strategyA.totalGasDeductible_AUD += (gasIn + gasOut) * usdToAud;
      state.strategyA.virtualBalance += netEarned;
      state.strategyA.totalEarned += netEarned;

      // Sweep crystallised earnings to profit vault
      state.profitVault.strategyA.balance += pos.crystallisedEarnings || 0;

      // Push tax event
      state.tax.events.push({
        date: now.toISOString(),
        type: isLP ? 'lp_exit' : 'lending_exit',
        gain: gainUSD,
        holdDays: holdDaysA,
        isCGTEvent: isCGTEvent,
        taxEstimate: cgtUSD,
        strategy: 'A',
        pool: pos.pool,
        symbol: pos.symbol,
      });

      const record = {
        strategy: 'A', symbol: pos.symbol, chain: pos.chain, project: pos.project,
        entryDate: pos.entryDate || state.startedAt, exitDate: now.toISOString(),
        exitReason, entryApy: pos.entryApy || pos.apy,
        exitCorr: exitCorr !== null ? parseFloat(exitCorr.toFixed(4)) : null,
        earned: parseFloat(netEarned.toFixed(4)),
        costBasisAUD: pos.costBasisAUD || 0, proceedsAUD: proceedsLocal, cgtGain: cgtLocal,
        yieldIncomeAUD: pos.yieldIncomeAUD || 0, gasDeductibleAUD: (gasIn + gasOut) * usdToAud,
      };
      state.rotations.push(record);
      rotationLog.push({ ...record, action: 'exit' });
      state.strategyA.totalRotations++;

      // v2.2: Update reputation and exit history
      updateReputation(pos, { earned: netEarned, exitReason, holdDays: holdDaysA }, state);
      state.exitHistory.push({ exitDate: now.toISOString(), exitReason, earned: netEarned, entryApy: pos.entryApy || pos.apy, pool: pos.pool, symbol: pos.symbol, chain: pos.chain });
      if (state.exitHistory.length > 200) state.exitHistory = state.exitHistory.slice(-200);
    }

    for (const { pos, exitReason, exitCorr, earned } of exitsB) {
      const gasOut = getGasForChain(pos.chain).exit;
      const gasIn = pos.estimatedGas || 0.10;
      const netEarned = Math.max(0, earned - gasIn - gasOut);
      const posValue = (pos.atRiskCapital || 500) + (pos.crystallisedEarnings || 0);
      const gainUSD = Math.max(0, posValue - (CAPITAL / 2 / POSITIONS_PER_STRATEGY));
      const holdDaysB = (now - new Date(pos.entryDate || state.startedAt)) / (1000 * 60 * 60 * 24);
      const isLP = !pos.isLending && pos.type !== 'lending';
      const isCGTEvent = taxEngine.isRotationCGTEvent(pos, taxProfile);
      const cgtUSD = isCGTEvent ? taxEngine.calculateCGT(gainUSD, holdDaysB, taxProfile, marginalRate) : 0;

      const proceedsLocal = posValue * usdToAud;
      const cgtLocal = cgtUSD * usdToAud;

      state.tax.strategyB.totalCGT_AUD += cgtLocal;
      state.tax.strategyB.totalYieldIncome_AUD += pos.yieldIncomeAUD || 0;
      state.tax.strategyB.totalGasDeductible_AUD += (gasIn + gasOut) * usdToAud;
      state.strategyB.virtualBalance += netEarned;
      state.strategyB.totalEarned += netEarned;

      state.profitVault.strategyB.balance += pos.crystallisedEarnings || 0;

      // Push tax event
      state.tax.events.push({
        date: now.toISOString(),
        type: isLP ? 'lp_exit' : 'lending_exit',
        gain: gainUSD,
        holdDays: holdDaysB,
        isCGTEvent: isCGTEvent,
        taxEstimate: cgtUSD,
        strategy: 'B',
        pool: pos.pool,
        symbol: pos.symbol,
      });

      const record = {
        strategy: 'B', symbol: pos.symbol, chain: pos.chain, project: pos.project,
        entryDate: pos.entryDate || state.startedAt, exitDate: now.toISOString(),
        exitReason, entryApy: pos.entryApy || pos.apy,
        exitCorr: exitCorr !== null ? parseFloat(exitCorr.toFixed(4)) : null,
        earned: parseFloat(netEarned.toFixed(4)),
        costBasisAUD: pos.costBasisAUD || 0, proceedsAUD: proceedsLocal, cgtGain: cgtLocal,
        yieldIncomeAUD: pos.yieldIncomeAUD || 0, gasDeductibleAUD: (gasIn + gasOut) * usdToAud,
      };
      state.rotations.push(record);
      rotationLog.push({ ...record, action: 'exit' });
      state.strategyB.totalRotations++;

      // v2.2: Update reputation and exit history
      updateReputation(pos, { earned: netEarned, exitReason, holdDays: holdDaysB }, state);
      state.exitHistory.push({ exitDate: now.toISOString(), exitReason, earned: netEarned, entryApy: pos.entryApy || pos.apy, pool: pos.pool, symbol: pos.symbol, chain: pos.chain });
      if (state.exitHistory.length > 200) state.exitHistory = state.exitHistory.slice(-200);
    }

    // ── EARN on remaining positions (CHANGE 14) ──────────────────────────────
    if (daysSince > 0) {
      for (const pos of remA) {
        const capital = pos.atRiskCapital || (CAPITAL / 2 / POSITIONS_PER_STRATEGY);
        const grossEarnings = capital * (pos.apy||0) / 100 / 365 * daysSince;
        const netEarnings = grossEarnings; // gas only deducted on exit/rotation

        // AUD tracking
        pos.yieldIncomeAUD = (pos.yieldIncomeAUD || 0) + netEarnings * usdToAud;

        // AUD snapshot (keep last 10)
        pos.audSnapshots = pos.audSnapshots || [];
        pos.audSnapshots.push({
          timestamp: now.toISOString(),
          yieldAUD: netEarnings * usdToAud,
          totalYieldAUD: pos.yieldIncomeAUD,
        });
        if (pos.audSnapshots.length > 10) pos.audSnapshots = pos.audSnapshots.slice(-10);

        // Profit booking
        applyProfitBooking(pos, netEarnings, 'A', state.profitVault.strategyA);

        state.strategyA.virtualBalance += netEarnings;
        state.strategyA.totalEarned += netEarnings;

        // CHANGE 9: Update tvl_24h_ago every 8 cycles
        pos.tvl_24h_updateCycle = (pos.tvl_24h_updateCycle || 0) + 1;
        if (pos.tvl_24h_updateCycle >= 8) {
          const fresh = pools.find(p => p.pool === pos.pool);
          if (fresh) pos.tvl_24h_ago = fresh.tvlUsd || 0;
          pos.tvl_24h_updateCycle = 0;
        }
      }

      for (const pos of remB) {
        const capital = pos.atRiskCapital || (CAPITAL / 2 / POSITIONS_PER_STRATEGY);
        const grossEarnings = capital * (pos.apy||0) / 100 / 365 * daysSince;
        const netEarnings = grossEarnings;

        pos.yieldIncomeAUD = (pos.yieldIncomeAUD || 0) + netEarnings * usdToAud;
        pos.audSnapshots = pos.audSnapshots || [];
        pos.audSnapshots.push({
          timestamp: now.toISOString(),
          yieldAUD: netEarnings * usdToAud,
          totalYieldAUD: pos.yieldIncomeAUD,
        });
        if (pos.audSnapshots.length > 10) pos.audSnapshots = pos.audSnapshots.slice(-10);

        applyProfitBooking(pos, netEarnings, 'B', state.profitVault.strategyB);

        state.strategyB.virtualBalance += netEarnings;
        state.strategyB.totalEarned += netEarnings;

        pos.tvl_24h_updateCycle = (pos.tvl_24h_updateCycle || 0) + 1;
        if (pos.tvl_24h_updateCycle >= 8) {
          const fresh = pools.find(p => p.pool === pos.pool);
          if (fresh) pos.tvl_24h_ago = fresh.tvlUsd || 0;
          pos.tvl_24h_updateCycle = 0;
        }
      }
    }

    // ── UPDATE APY on remaining positions from fresh data ─────────────────────
    state.strategyA.positions = remA.map(pos => {
      const fresh = pools.find(p => p.pool === pos.pool);
      return fresh ? { ...pos, apy: fresh.apy, tvlUsd: fresh.tvlUsd } : pos;
    });
    state.strategyB.positions = remB.map(pos => {
      const fresh = pools.find(p => p.pool === pos.pool);
      return fresh ? { ...pos, apy: fresh.apy, tvlUsd: fresh.tvlUsd } : pos;
    });

    // ── LEARNING ENGINE (every 8th cycle = ~24h) ──────────────────────────────
    if (state.learning?.enabled && state.cycles > 0 && state.cycles % 8 === 0) {
      console.log('\n🧠 LEARNING CYCLE');
      state.learning.learnCycleCount = (state.learning.learnCycleCount || 0) + 1;
      state.learning.lastLearnCycle = new Date().toISOString();
      if (state.learning.level3_regimeDetection) await detectMarketRegime(state);
      if (state.learning.level1_paramTuning) {
        const metrics = evaluatePerformance(state.exitHistory || []);
        const changes = adjustParameters(metrics, state);
        recordParameterChanges(changes, metrics, state);
        checkRollbacks(state);
        if (changes.length > 0) changes.forEach(c => console.log(`   🔧 ${c.param}: ${c.from} → ${c.to}`));
        else console.log('   Level 1: no changes');
      }
      if (state.learning.level2_reputation) { decayReputation(state); console.log('   Level 2: reputation decayed'); }
    }

    // ── REPOSITION if below 5 ─────────────────────────────────────────────────
    const needA = POSITIONS_PER_STRATEGY - state.strategyA.positions.length;
    const needB = POSITIONS_PER_STRATEGY - state.strategyB.positions.length;

    if (needA > 0) {
      const replacements = await pickReplacements(state.strategyA.positions, pools, needA, 'A', now, state);
      for (const rep of replacements) {
        state.strategyA.positions.push(rep);
        rotationLog.push({ action: 'enter', strategy: 'A', symbol: rep.symbol, chain: rep.chain, project: rep.project, apy: rep.apy, tvlUsd: rep.tvlUsd });
      }
    }
    if (needB > 0) {
      // CHANGE 12d: If no replacement found, park in lending
      const replacements = await pickReplacements(state.strategyB.positions, pools, needB, 'B', now, state);
      if (replacements.length < needB) {
        // Park idle capital in best lending pool
        const parked = needB - replacements.length;
        const bestLending = pools
          .filter(p => p.type === 'lending' && !state.strategyB.positions.some(s => s.pool === p.pool) && !replacements.some(r => r.pool === p.pool))
          .sort((a,b) => (b.apy||0) - (a.apy||0));
        for (let i = 0; i < Math.min(parked, bestLending.length); i++) {
          const parkPos = withEntryFields({ ...bestLending[i], type: 'parking' }, now, state);
          replacements.push(parkPos);
          rotationLog.push({ action: 'enter', strategy: 'B', symbol: parkPos.symbol, chain: parkPos.chain, project: parkPos.project, apy: parkPos.apy, tvlUsd: parkPos.tvlUsd, note: 'parking' });
        }
      }
      for (const rep of replacements) {
        state.strategyB.positions.push(rep);
        if (!rotationLog.some(r => r.action === 'enter' && r.symbol === rep.symbol && r.strategy === 'B')) {
          rotationLog.push({ action: 'enter', strategy: 'B', symbol: rep.symbol, chain: rep.chain, project: rep.project, apy: rep.apy, tvlUsd: rep.tvlUsd });
        }
      }
    }

    // Also park idle Strategy A capital
    if (needA > 0) {
      const actualA = state.strategyA.positions.length;
      if (actualA < POSITIONS_PER_STRATEGY) {
        const parkedNeeded = POSITIONS_PER_STRATEGY - actualA;
        const bestLending = pools
          .filter(p => p.type === 'lending' && !state.strategyA.positions.some(s => s.pool === p.pool))
          .sort((a,b) => (b.apy||0) - (a.apy||0));
        for (let i = 0; i < Math.min(parkedNeeded, bestLending.length); i++) {
          const parkPos = withEntryFields({ ...bestLending[i], type: 'parking' }, now, state);
          state.strategyA.positions.push(parkPos);
          rotationLog.push({ action: 'enter', strategy: 'A', symbol: parkPos.symbol, chain: parkPos.chain, project: parkPos.project, apy: parkPos.apy, tvlUsd: parkPos.tvlUsd, note: 'parking' });
        }
      }
    }

    // ── CHANGE 13f: After-tax return calculation (global tax engine) ─────────
    for (const [strat, taxKey] of [['strategyA', 'strategyA'], ['strategyB', 'strategyB']]) {
      const t = state.tax[taxKey];
      const grossReturn = state[strat].totalEarned;
      const grossReturnAUD = grossReturn * usdToAud;
      const yieldTax = taxEngine.calculateIncomeTax(t.totalYieldIncome_AUD, taxProfile, marginalRate);
      const gasDeduction = taxProfile.deductions.gasFees ? t.totalGasDeductible_AUD * marginalRate : 0;
      t.afterTaxReturn_AUD = grossReturnAUD
        - t.totalCGT_AUD
        - yieldTax
        + gasDeduction;
    }
  }

  // ── ROTATION REPORT ───────────────────────────────────────────────────────
  if (rotationLog.length > 0) {
    ['A','B'].forEach(strat => {
      const stratExits   = rotationLog.filter(r => r.strategy === strat && r.action === 'exit');
      const stratEntries = rotationLog.filter(r => r.strategy === strat && r.action === 'enter');
      if (stratExits.length === 0 && stratEntries.length === 0) return;
      console.log(`\n🔄 ROTATION — Strategy ${strat}`);
      for (const e of stratExits) {
        const corrStr = e.exitCorr !== null ? `, corr: ${(e.exitCorr*100).toFixed(1)}%` : '';
        console.log(`  EXIT:  ${e.symbol} on ${e.chain}/${e.project}`);
        console.log(`         reason: ${e.exitReason}${corrStr} | earned: ${fmtUSD(e.earned)}`);
      }
      for (const e of stratEntries) {
        const noteStr = e.note ? ` [${e.note}]` : '';
        console.log(`  ENTER: ${e.symbol} on ${e.chain}/${e.project}${noteStr}`);
        console.log(`         APY: ${(e.apy||0).toFixed(1)}%, TVL: $${((e.tvlUsd||0)/1e6).toFixed(1)}M`);
      }
    });
  } else if (state.cycles > 0) {
    console.log('✅ No rotations this cycle — all positions holding.');
  }

  // ── APY ALERTS ──────────────────────────────────────────────────────────────
  const apyAlerts = [];
  for (const [strat, positions] of [['A', state.strategyA.positions], ['B', state.strategyB.positions]]) {
    for (const pos of positions) {
      const entryApy = pos.entryApy || pos.apy;
      if (entryApy > 0) {
        const drop = (entryApy - (pos.apy||0)) / entryApy;
        if (drop >= APY_DROP_THRESHOLD) {
          apyAlerts.push(`⚠️  [${strat}] ${pos.symbol} APY dropped ${(drop*100).toFixed(0)}%: ${entryApy.toFixed(1)}% → ${(pos.apy||0).toFixed(1)}%`);
        }
      }
    }
  }
  state.apyAlerts = apyAlerts;
  if (apyAlerts.length > 0) {
    console.log('\n🚨 APY ALERTS:');
    apyAlerts.forEach(a => console.log('  ', a));
  } else if (state.cycles > 0) {
    console.log('\n✅ APY check: all positions within normal range');
  }

  state.lastUpdatedAt = now.toISOString();
  state.cycles++;

  // Snapshots (keep last 90)
  state.strategyA.snapshots.push({ ts: now.toISOString(), balance: state.strategyA.virtualBalance });
  state.strategyB.snapshots.push({ ts: now.toISOString(), balance: state.strategyB.virtualBalance });
  if (state.strategyA.snapshots.length > 90) state.strategyA.snapshots = state.strategyA.snapshots.slice(-90);
  if (state.strategyB.snapshots.length > 90) state.strategyB.snapshots = state.strategyB.snapshots.slice(-90);

  saveState(state);

  // ── FULL REPORT ───────────────────────────────────────────────────────────

  const startDate  = new Date(state.startedAt);
  const daysRunning = (now - startDate) / (1000 * 60 * 60 * 24);
  const taxCountryName = taxProfile.countryName;
  const taxCurrency = taxProfile.localCurrency;

  console.log(`\n📅 Simulation started: ${startDate.toISOString().split('T')[0]}`);
  console.log(`⏱️  Running for: ${daysRunning.toFixed(1)} days (${state.cycles} cycles)`);
  console.log(`🔄 Total rotations — A: ${state.strategyA.totalRotations} | B: ${state.strategyB.totalRotations}`);
  console.log(`🛡️  Circuit breaker: ${state.circuitBreaker.active ? '🔴 ACTIVE' : '🟢 Inactive'}`);
  console.log(`💰 Profit vault — A: ${fmtUSD(state.profitVault.strategyA.balance)} | B: ${fmtUSD(state.profitVault.strategyB.balance)}\n`);

  // Strategy A
  const retA  = ((state.strategyA.virtualBalance - CAPITAL/2) / (CAPITAL/2) * 100);
  const apyA  = daysRunning > 0 ? (retA / daysRunning * 365) : 0;
  const dailyA = calcDailyEarnings(state.strategyA.positions);

  console.log('─'.repeat(60));
  console.log(`📊 STRATEGY A — ${state.strategyA.name}`);
  console.log('─'.repeat(60));
  console.log(`   Starting capital:  ${fmtUSD(CAPITAL/2)}`);
  console.log(`   Current balance:   ${fmtUSD(state.strategyA.virtualBalance)}`);
  console.log(`   Total earned:      ${fmtUSD(state.strategyA.totalEarned)}`);
  console.log(`   Return:            ${fmtPct(retA)}`);
  console.log(`   Projected APY:     ${apyA.toFixed(1)}%`);
  console.log(`   Daily earnings:    ${fmtUSD(dailyA)}`);
  console.log(`   After-tax (${taxCurrency}):  ${taxCurrency} ${(state.tax.strategyA.afterTaxReturn_AUD || 0).toFixed(2)}`);
  console.log(`   Active positions:  ${state.strategyA.positions.length}/${POSITIONS_PER_STRATEGY}`);
  console.log(`\n   Positions:`);
  state.strategyA.positions.forEach((p, i) => {
    const entryDays = p.entryDate ? ((now - new Date(p.entryDate)) / (1000*60*60*24)).toFixed(1) : '?';
    const typeTag = p.type === 'parking' ? ' [PARKED]' : '';
    console.log(`   ${i+1}. ${p.chain} | ${p.project} | ${(p.symbol||'').substring(0,20)} | ${(p.apy||0).toFixed(1)}% APY | $${((p.tvlUsd||0)/1e6).toFixed(1)}M TVL | ${entryDays}d${typeTag}`);
  });

  // Strategy B
  const retB  = ((state.strategyB.virtualBalance - CAPITAL/2) / (CAPITAL/2) * 100);
  const apyB  = daysRunning > 0 ? (retB / daysRunning * 365) : 0;
  const dailyB = calcDailyEarnings(state.strategyB.positions);

  console.log('\n─'.repeat(60));
  console.log(`📊 STRATEGY B — ${state.strategyB.name}`);
  console.log('─'.repeat(60));
  console.log(`   Starting capital:  ${fmtUSD(CAPITAL/2)}`);
  console.log(`   Current balance:   ${fmtUSD(state.strategyB.virtualBalance)}`);
  console.log(`   Total earned:      ${fmtUSD(state.strategyB.totalEarned)}`);
  console.log(`   Return:            ${fmtPct(retB)}`);
  console.log(`   Projected APY:     ${apyB.toFixed(1)}%`);
  console.log(`   Daily earnings:    ${fmtUSD(dailyB)}`);
  console.log(`   After-tax (${taxCurrency}):  ${taxCurrency} ${(state.tax.strategyB.afterTaxReturn_AUD || 0).toFixed(2)}`);
  console.log(`   Active positions:  ${state.strategyB.positions.length}/${POSITIONS_PER_STRATEGY}`);
  console.log(`\n   Positions:`);
  state.strategyB.positions.forEach((p, i) => {
    const entryDays = p.entryDate ? ((now - new Date(p.entryDate)) / (1000*60*60*24)).toFixed(1) : '?';
    const typeTag = p.type === 'parking' ? ' [PARKED]' : (p.type === 'lending' ? ' [LEND]' : '');
    console.log(`   ${i+1}. ${p.chain} | ${p.project} | ${(p.symbol||'').substring(0,20)} | ${(p.apy||0).toFixed(1)}% APY | $${((p.tvlUsd||0)/1e6).toFixed(1)}M TVL | ${entryDays}d${typeTag}`);
  });

  // Tax summary
  console.log('\n─'.repeat(60));
  console.log(`🏛️  TAX SUMMARY (${taxCurrency}) — ${taxCountryName}`);
  console.log('─'.repeat(60));
  console.log(`   Country:           ${taxCountryName} (${state.tax?.country || 'AU'})`);
  console.log(`   Marginal rate:     ${(marginalRate * 100).toFixed(0)}%`);
  console.log(`   USD/${taxCurrency}:          ${usdToAud}`);
  console.log(`   Rotation mode:     ${countryAdj.rotationFrequency}`);
  if (holdAdvice.minHoldForTaxBenefit > 0) {
    console.log(`   Hold benefit:      ${holdAdvice.taxBenefit} after ${holdAdvice.minHoldForTaxBenefit} days`);
  }
  const yieldTaxA = taxEngine.calculateIncomeTax(state.tax.strategyA.totalYieldIncome_AUD, taxProfile, marginalRate);
  const yieldTaxB = taxEngine.calculateIncomeTax(state.tax.strategyB.totalYieldIncome_AUD, taxProfile, marginalRate);
  const gasDeductA = taxProfile.deductions.gasFees ? state.tax.strategyA.totalGasDeductible_AUD * marginalRate : 0;
  const gasDeductB = taxProfile.deductions.gasFees ? state.tax.strategyB.totalGasDeductible_AUD * marginalRate : 0;
  console.log(`   Strategy A — CGT: ${taxCurrency} ${state.tax.strategyA.totalCGT_AUD.toFixed(2)} | Yield tax: ${taxCurrency} ${yieldTaxA.toFixed(2)} | Gas deduction: ${taxCurrency} ${gasDeductA.toFixed(2)}`);
  console.log(`   Strategy B — CGT: ${taxCurrency} ${state.tax.strategyB.totalCGT_AUD.toFixed(2)} | Yield tax: ${taxCurrency} ${yieldTaxB.toFixed(2)} | Gas deduction: ${taxCurrency} ${gasDeductB.toFixed(2)}`);

  // Rotation history (last 5)
  if (state.rotations.length > 0) {
    const recent = state.rotations.slice(-5);
    console.log('\n─'.repeat(60));
    console.log(`📋 RECENT ROTATIONS (last ${recent.length}):`);
    recent.forEach(r => {
      const corrStr = r.exitCorr !== null ? ` corr:${(r.exitCorr*100).toFixed(1)}%` : '';
      console.log(`   [${r.strategy}] ${r.symbol} | ${r.exitReason}${corrStr} | earned: ${fmtUSD(r.earned)}`);
    });
  }

  // Winner
  console.log('\n═'.repeat(60));
  const winner = state.strategyA.virtualBalance >= state.strategyB.virtualBalance ? 'A' : 'B';
  const winnerName = winner === 'A' ? state.strategyA.name : state.strategyB.name;
  const lead = Math.abs(state.strategyA.virtualBalance - state.strategyB.virtualBalance);
  console.log(`\n🏆 CURRENT LEADER: Strategy ${winner} (${winnerName})`);
  console.log(`   Lead: ${fmtUSD(lead)} | Combined portfolio: ${fmtUSD(state.strategyA.virtualBalance + state.strategyB.virtualBalance)}`);

  // CHANGE 16: Day 30 after-tax risk-adjusted recommendation
  if (daysRunning >= RECOMMENDATION_DAY) {
    if (!state.circuitBreaker.triggeredAt && daysRunning < MAX_RECOMMENDATION_DAY) {
      console.log(`\n⏳ No stress test yet — extending recommendation to Day ${MAX_RECOMMENDATION_DAY}`);
      console.log(`   Circuit breaker hasn't fired. Need real drawdown data for risk-adjusted comparison.`);
    } else {
      const maxDrawdownA = calcMaxDrawdown(state.strategyA.snapshots);
      const maxDrawdownB = calcMaxDrawdown(state.strategyB.snapshots);
      const sharpeA = (state.tax.strategyA.afterTaxReturn_AUD || 0) / (maxDrawdownA || 0.01);
      const sharpeB = (state.tax.strategyB.afterTaxReturn_AUD || 0) / (maxDrawdownB || 0.01);
      const finalWinner = sharpeA > sharpeB ? 'A' : 'B';
      const finalName = finalWinner === 'A' ? state.strategyA.name : state.strategyB.name;

      console.log(`\n🏆 FINAL RECOMMENDATION: Strategy ${finalWinner} (${finalName})`);
      console.log(`   After-tax Sharpe — A: ${sharpeA.toFixed(2)} | B: ${sharpeB.toFixed(2)}`);
      console.log(`   Max Drawdown — A: ${(maxDrawdownA*100).toFixed(2)}% | B: ${(maxDrawdownB*100).toFixed(2)}%`);
      console.log(`   After-tax Return (${taxCurrency}) — A: ${taxCurrency} ${(state.tax.strategyA.afterTaxReturn_AUD||0).toFixed(2)} | B: ${taxCurrency} ${(state.tax.strategyB.afterTaxReturn_AUD||0).toFixed(2)}`);
      console.log(`\n💡 Deploy real capital into Strategy ${finalWinner}`);
    }
  } else if (daysRunning >= 7) {
    const projectedAnnualA = (state.strategyA.totalEarned / daysRunning) * 365;
    const projectedAnnualB = (state.strategyB.totalEarned / daysRunning) * 365;
    console.log(`\n📈 INTERIM PROJECTION (annualised from actual data):`);
    console.log(`   Strategy A: ${fmtUSD(projectedAnnualA)}/year`);
    console.log(`   Strategy B: ${fmtUSD(projectedAnnualB)}/year`);
    const daysLeft = RECOMMENDATION_DAY - daysRunning;
    console.log(`\n⏳ Final recommendation in ${daysLeft.toFixed(1)} more days (Day ${RECOMMENDATION_DAY})`);
  } else {
    const daysLeft = RECOMMENDATION_DAY - daysRunning;
    console.log(`\n⏳ Run for ${daysLeft.toFixed(1)} more days before recommendation (Day ${RECOMMENDATION_DAY})`);
  }
  console.log('');

  return state;
}

async function pushStateToGitHub(state) {
  const https = require('https');
  const envPath = require('path').join(__dirname, '../.env');
  let token;
  try {
    const envVars = require('fs').readFileSync(envPath, 'utf8').split('\n')
      .filter(l => l && !l.startsWith('#') && l.includes('='))
      .reduce((acc, l) => { const [k, ...v] = l.split('='); acc[k.trim()] = v.join('=').trim(); return acc; }, {});
    token = envVars['GITHUB_TOKEN'];
  } catch {}
  if (!token) { console.log('⚠️  No GITHUB_TOKEN — skipping push'); return; }

  const content = Buffer.from(JSON.stringify(state, null, 2)).toString('base64');
  const owner = 'ghodzilla', repo = 'abbilabs_xyz', filePath = 'data/yield-sim-state.json';

  let sha;
  try {
    const existing = await new Promise((resolve, reject) => {
      https.get({
        hostname: 'api.github.com', path: `/repos/${owner}/${repo}/contents/${filePath}`,
        headers: { 'Authorization': `token ${token}`, 'User-Agent': 'AbbiLabs/2.1' }
      }, res => { let d = ''; res.on('data', c => d += c); res.on('end', () => resolve(JSON.parse(d))); }).on('error', reject);
    });
    sha = existing.sha;
  } catch {}

  const body = JSON.stringify({ message: 'chore: update yield sim state (v2.1)', content, ...(sha ? { sha } : {}) });
  return new Promise((resolve) => {
    const req = https.request({
      hostname: 'api.github.com', path: `/repos/${owner}/${repo}/contents/${filePath}`, method: 'PUT',
      headers: { 'Authorization': `token ${token}`, 'User-Agent': 'AbbiLabs/2.1', 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    }, res => {
      let d = ''; res.on('data', c => d += c);
      res.on('end', () => {
        try { const r = JSON.parse(d); console.log(r.content ? '✅ State pushed to GitHub' : '⚠️  Push issue: ' + JSON.stringify(r).substring(0, 100)); }
        catch {}
        resolve();
      });
    });
    req.on('error', e => { console.log('⚠️  GitHub push failed:', e.message); resolve(); });
    req.write(body); req.end();
  });
}

// ── ENTRY POINT ────────────────────────────────────────────────────────────────
const args = process.argv.slice(2);
const reset = args.includes('--reset');
const exportTax = args.includes('--export-tax');

if (exportTax) {
  const state = loadState();
  if (!state) { console.log('❌ No state file found'); process.exit(1); }
  exportTaxSummary(state);
  process.exit(0);
}

runSimulation(reset).then(state => pushStateToGitHub(state)).catch(console.error);