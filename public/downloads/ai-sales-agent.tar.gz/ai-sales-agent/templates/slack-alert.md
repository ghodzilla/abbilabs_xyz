# Slack Message Templates

## Hot Lead Alert
```
🔥 HOT LEAD — Score: {score}/100

{name} — {title}
{company} ({industry}, {employees} employees)

Why hot:
{scoring_breakdown}

HubSpot: {hubspot_link}
Action: Review and contact within 2 hours.
```

## Warm Lead Notification
```
📊 New warm lead: {name}, {title} at {company}
Score: {score}/100
Source: {source}
```

## Deal Closed Won
```
🎉 DEAL CLOSED!

{deal_name} — {amount}
Company: {company}
Stage: Closed Won
Close date: {date}

Total pipeline impact: {remaining_pipeline_value}
```

## Deal Closed Lost
```
❌ Deal lost: {deal_name} — {amount}
Reason: {close_reason}
Time in pipeline: {days_in_pipeline} days
```

## Follow-up Reminder
```
📋 Follow-up needed:

• {name} — {deal_name} — {amount}
  Last contact: {days} days ago
  Stage: {stage}
  Suggested action: {recommendation}
```

## Daily Report Header
```
📊 DAILY PIPELINE REPORT — {date}

💰 Pipeline: {total_value}
📈 Open Deals: {open_count}
🆕 New Leads: {new_leads}
✅ Won: {won_value}
❌ Lost: {lost_value}
```
