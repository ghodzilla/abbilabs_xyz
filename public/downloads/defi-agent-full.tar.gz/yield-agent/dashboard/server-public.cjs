#!/usr/bin/env node
/**
 * Yield Dashboard — public binding with Basic Auth
 * Accessible directly via http://209.38.93.29:3001
 * Protected by username/password — no SSH tunnel needed
 */
const express = require('../node_modules/express');
const fs = require('fs');
const path = require('path');

// Load env manually
const envPath = path.join(__dirname, '../.env');
const envVars = fs.readFileSync(envPath, 'utf8').split('\n')
  .filter(l => l && !l.startsWith('#') && l.includes('='))
  .reduce((acc, l) => { const [k,...v] = l.split('='); acc[k.trim()] = v.join('=').trim(); return acc; }, {});

const app = express();
const PORT = 3001;
const STATE_FILE = path.join(__dirname, '../memory/yield-sim-state.json');
const PASS = envVars['DASHBOARD_PASS'];

function auth(req, res, next) {
  const header = req.headers['authorization'];
  if (!header) return challenge(res);
  const b64 = header.replace('Basic ', '');
  const [, pass] = Buffer.from(b64, 'base64').toString().split(':');
  if (pass === PASS) return next();
  return challenge(res);
}
function challenge(res) {
  res.set('WWW-Authenticate', 'Basic realm="Yield Dashboard"');
  res.status(401).send('Unauthorised');
}

app.get('/', auth, (req, res) => res.sendFile(path.join(__dirname, 'index.html')));

app.get('/api/yield', auth, (req, res) => {
  try {
    const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    res.json({ ok: true, data: state });
  } catch (e) {
    res.status(404).json({ ok: false, error: 'No simulation data yet.' });
  }
});

// Bind to all interfaces — protected by Basic Auth
app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ Dashboard running at http://209.38.93.29:${PORT}`);
  console.log(`🔑 Login: admin / ${PASS}`);
});
