'use client';
import { useEffect, useState, useRef } from 'react';
import ModeToggle from '../../components/ModeToggle';

const TAX_COUNTRIES = [
  { code: 'AU', flag: '🇦🇺', name: 'Australia', note: '50% CGT discount >12mo' },
  { code: 'US', flag: '🇺🇸', name: 'United States', note: 'Short-term = ordinary income' },
  { code: 'GB', flag: '🇬🇧', name: 'United Kingdom', note: '£3k CGT allowance' },
  { code: 'CA', flag: '🇨🇦', name: 'Canada', note: '50% CGT inclusion rate' },
  { code: 'DE', flag: '🇩🇪', name: 'Germany', note: 'Tax-free after 12 months' },
  { code: 'JP', flag: '🇯🇵', name: 'Japan', note: 'Misc. income up to 55%' },
  { code: 'SG', flag: '🇸🇬', name: 'Singapore', note: 'No CGT for individuals' },
  { code: 'AE', flag: '🇦🇪', name: 'UAE', note: 'No personal income/CGT tax' },
  { code: 'IN', flag: '🇮🇳', name: 'India', note: 'Flat 30% on all gains' },
  { code: 'NZ', flag: '🇳🇿', name: 'New Zealand', note: 'No CGT generally' },
];

export default function YieldDashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [lastUpdate, setLastUpdate] = useState('');
  const [taxCountry, setTaxCountry] = useState('AU');
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [userInfo, setUserInfo] = useState({ email: '', tier: 'explorer', isAdmin: false });
  const [pbMode, setPbMode] = useState('simulation'); // 'simulation' | 'advisory'
  const [wallets, setWallets] = useState([]);
  const [advisoryWallets, setAdvisoryWallets] = useState([]);
  const [showAddWallet, setShowAddWallet] = useState(false);
  const [newWalletAddress, setNewWalletAddress] = useState('');
  const [newWalletLabel, setNewWalletLabel] = useState('');
  const [newWalletType, setNewWalletType] = useState('safe');
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  useEffect(() => {
    // Cookie-based auth gate
    if (typeof window !== 'undefined') {
      const hasCookie = document.cookie.split(';').some(c => c.trim().startsWith('pb_token='));
      if (!hasCookie) {
        window.location.href = '/login';
        return;
      }
    }
    const saved = localStorage.getItem('yield_tax_country');
    if (saved) setTaxCountry(saved);
    // Load persisted mode
    try {
      const savedMode = localStorage.getItem('pb_mode');
      if (savedMode === 'advisory' || savedMode === 'simulation') setPbMode(savedMode);
      // Load connected wallets (tax/portfolio page)
      const savedWallets = localStorage.getItem('pb_wallets');
      if (savedWallets) setWallets(JSON.parse(savedWallets));
      // Load advisory deployment wallets (separate from tax wallets)
      const savedAdvisory = localStorage.getItem('pb_advisory_wallets');
      if (savedAdvisory) setAdvisoryWallets(JSON.parse(savedAdvisory));
    } catch (_) {}
    // Fetch user tier info
    fetch('/api/auth/me').then(r => r.json()).then(d => {
      if (d.email) setUserInfo(d);
    }).catch(() => {});
  }, []);

  function selectCountry(code) {
    setTaxCountry(code);
    localStorage.setItem('yield_tax_country', code);
    setShowCountryPicker(false);
  }

  async function fetchData() {
    try {
      const res = await fetch('/api/data');
      const json = await res.json();
      if (!json.ok) throw new Error(json.error);
      setData(json.data);
      setLastUpdate(new Date().toLocaleTimeString());
    } catch (e) { setError(e.message); }
  }

  useEffect(() => { fetchData(); const t = setInterval(fetchData, 30000); return () => clearInterval(t); }, []);

  useEffect(() => {
    if (!data || !chartRef.current) return;
    const existing = document.getElementById('chartjs');
    if (existing) { renderChart(data); return; }
    const s = document.createElement('script');
    s.id = 'chartjs';
    s.src = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js';
    s.onload = () => renderChart(data);
    document.head.appendChild(s);
  }, [data]);

  function renderChart(s) {
    if (!window.Chart || !chartRef.current) return;
    if (chartInstance.current) chartInstance.current.destroy();
    const snapsA = s.strategyA.snapshots || [], snapsB = s.strategyB.snapshots || [];
    const labels = snapsA.map(x => { const d = new Date(x.ts); return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); });
    chartInstance.current = new window.Chart(chartRef.current, {
      type: 'line',
      data: { labels, datasets: [
        { label: 'Strategy A (Max APY)', data: snapsA.map(x => x.balance), borderColor: '#6789ed', backgroundColor: '#6789ed18', fill: true, tension: 0.4, pointRadius: snapsA.length > 20 ? 0 : 3 },
        { label: 'Strategy B (Risk-Adjusted)', data: snapsB.map(x => x.balance), borderColor: '#8aad8a', backgroundColor: '#8aad8a18', fill: true, tension: 0.4, pointRadius: snapsB.length > 20 ? 0 : 3 }
      ]},
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { labels: { color: '#edeef0' } } }, scales: { x: { ticks: { color: '#6b6c72', maxTicksLimit: 8 }, grid: { color: '#ffffff0a' } }, y: { ticks: { color: '#6b6c72', callback: v => '$' + Number(v).toFixed(2) }, grid: { color: '#ffffff0a' } } } }
    });
  }

  const S = { bg: '#111214', card: { background: '#18191d', border: '1px solid #2a2b30', borderRadius: 16, padding: 24 } };
  const fmt = n => '$' + Number(n).toFixed(2);
  const fmtPct = n => (Number(n) >= 0 ? '+' : '') + Number(n).toFixed(2) + '%';
  const fmtTVL = n => n >= 1e9 ? '$' + (n/1e9).toFixed(1) + 'B' : n >= 1e6 ? '$' + (n/1e6).toFixed(1) + 'M' : '$' + (n/1e3).toFixed(0) + 'K';
  const CHAIN = { Base: '#6789ed', Arbitrum: '#93c5fd', Solana: '#a78bfa', Ethereum: '#818cf8' };
  const TYPE = { lp: '#ff9317', lending: '#8aad8a' };

  // Position classification by yield source
  // Ref: https://cryptolabsresearch.com/cryptocrashcourse/
  // Classify each position by yield source type
  function classifyPosition(p) {
    const sym = (p.symbol||'').toLowerCase();
    const proj = (p.project||'').toLowerCase();
    const toks = sym.split(/[^a-z0-9]+/).filter(Boolean);
    const STABLES = new Set(['usdc','usdt','dai','usde','crvusd','frax','usds','lusd','susd','usdz','susdz','gho','pyusd']);
    const LSTS = new Set(['steth','wsteth','cbeth','reth','weeth','ezeth','msol','jitosol','bsol']);
    const BLUE_CHIPS = new Set(['eth','weth','btc','wbtc','cbbtc','sol','wsol']);

    const allStable = toks.every(t => STABLES.has(t));
    const hasLST    = toks.some(t => LSTS.has(t));
    const allBlue   = toks.every(t => BLUE_CHIPS.has(t) || STABLES.has(t));
    const isLend    = p.type === 'lending';

    if (isLend && allStable) return { label:'Stable Lending', tier:'T1', src:'Borrower interest', risk:'Low', color:'#8aad8a', icon:'🏦' };
    if (allStable)           return { label:'Stable LP', tier:'T1', src:'Trading fees', risk:'Low', color:'#8aad8a', icon:'💵' };
    if (hasLST)              return { label:'LST LP', tier:'T1', src:'Fees + staking yield', risk:'Low', color:'#6789ed', icon:'⚡' };
    if (allBlue)             return { label:'Blue Chip LP', tier:'T2', src:'Trading fees', risk:'Medium', color:'#ff9317', icon:'🔵' };
    return                          { label:'Conviction LP', tier:'T2', src:'Fees + incentives', risk:'Medium', color:'#f97316', icon:'💎' };
  }

  if (error) return <div style={{ background: S.bg, minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#ef4444', fontFamily: 'monospace', padding: 32, textAlign: 'center' }}>❌ {error}</div>;
  if (!data) return <div style={{ background: S.bg, minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#edeef0', fontFamily: 'sans-serif' }}>⏳ Loading...</div>;

  const days = (Date.now() - new Date(data.startedAt)) / 86400000;
  const retA = (data.strategyA.virtualBalance - data.capital/2) / (data.capital/2) * 100;
  const retB = (data.strategyB.virtualBalance - data.capital/2) / (data.capital/2) * 100;
  const apyA = days > 0 ? retA / days * 365 : 0;
  const apyB = days > 0 ? retB / days * 365 : 0;
  const dailyA = data.strategyA.positions.reduce((s, p) => s + (data.capital/2/data.strategyA.positions.length) * (p.apy||0)/365/100, 0);
  const dailyB = data.strategyB.positions.reduce((s, p) => s + (data.capital/2/data.strategyB.positions.length) * (p.apy||0)/365/100, 0);
  // Pool APY = live weighted avg from DeFiLlama (visible from Day 0)
  const poolApyA = data.strategyA.positions.reduce((s,p)=>s+(p.apy||0),0) / (data.strategyA.positions.length||1);
  const poolApyB = data.strategyB.positions.reduce((s,p)=>s+(p.apy||0),0) / (data.strategyB.positions.length||1);
  const combined = data.strategyA.virtualBalance + data.strategyB.virtualBalance;
  const gain = combined - data.capital;
  const winner = data.strategyA.virtualBalance >= data.strategyB.virtualBalance ? 'A' : 'B';
  const progress = Math.min(days / 7 * 100, 100);
  const daysLeft = Math.max(0, 7 - days);

  return (
    <div style={{ background: S.bg, minHeight: '100vh', color: '#e2e8f0', fontFamily: '-apple-system, BlinkMacSystemFont, Segoe UI, sans-serif' }}>
      {/* Header */}
      <div style={{ background: '#18191d', borderBottom: '1px solid #2a2b30', padding: '0 28px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', height: 80, boxSizing: 'border-box', overflow: 'visible', position: 'relative', zIndex: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, overflow: 'visible' }}>
          <img src="/passiveblocks_logo.png" alt="PassiveBlocks" style={{ height: 44, width: "auto", objectFit: "contain", filter: "brightness(0) invert(1)" }} />
        </div>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          {/* Mode pill */}
          {pbMode === 'simulation' ? (
            <span style={{ background: '#2a2b3066', color: '#6b7280', border: '1px solid #2a2b30', borderRadius: 20, padding: '3px 12px', fontSize: 12, fontWeight: 700, letterSpacing: '0.06em' }}>SIM</span>
          ) : (
            <span style={{ background: '#ff931722', color: '#ff9317', border: '1px solid #ff931744', borderRadius: 20, padding: '3px 12px', fontSize: 12, fontWeight: 700, letterSpacing: '0.06em' }}>🟠 LIVE</span>
          )}
          <span style={{ fontSize: 12, color: '#6b6c72' }}>Updated: {lastUpdate}</span>
          {/* Tier badge */}
          {userInfo.isAdmin ? (
            <span style={{ background: '#ff931722', color: '#ff9317', border: '1px solid #ff931744', borderRadius: 20, padding: '3px 12px', fontSize: 12, fontWeight: 700 }}>👑 ADMIN</span>
          ) : userInfo.tier === 'elite' ? (
            <span style={{ background: '#8aad8a22', color: '#8aad8a', border: '1px solid #8aad8a44', borderRadius: 20, padding: '3px 12px', fontSize: 12, fontWeight: 700 }}>⚡ ELITE</span>
          ) : userInfo.tier === 'pro' ? (
            <span style={{ background: '#6789ed22', color: '#6789ed', border: '1px solid #6789ed44', borderRadius: 20, padding: '3px 12px', fontSize: 12, fontWeight: 700 }}>🔹 PRO</span>
          ) : (
            <span style={{ background: '#2a2b3044', color: '#6b6c72', border: '1px solid #2a2b30', borderRadius: 20, padding: '3px 12px', fontSize: 12, fontWeight: 700 }}>FREE</span>
          )}
          <a href="/tax" style={{ color: '#6b6c72', textDecoration: 'none', fontSize: 13, fontWeight: 500, padding: '5px 10px', borderRadius: 6, border: '1px solid #2a2b30' }}>🏛️ Tax</a>
          <a href="/wallets" style={{ color: '#6b6c72', textDecoration: 'none', fontSize: 13, fontWeight: 500, padding: '5px 10px', borderRadius: 6, border: '1px solid #2a2b30' }}>👛 Wallets</a>
          {/* Tax Country Selector */}
          <div style={{ position: 'relative' }}>
            <button onClick={() => setShowCountryPicker(v => !v)} style={{ background: '#1e3a5f', color: '#93c5fd', border: '1px solid #6789ed44', borderRadius: 6, padding: '6px 12px', fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
              {TAX_COUNTRIES.find(c => c.code === taxCountry)?.flag} {taxCountry} <span style={{ fontSize: 10 }}>▼</span>
            </button>
            {showCountryPicker && (
              <div style={{ position: 'absolute', right: 0, top: '110%', background: '#18191d', border: '1px solid #2a2b30', borderRadius: 10, zIndex: 100, minWidth: 260, boxShadow: '0 8px 32px #0008', overflow: 'hidden' }}>
                <div style={{ padding: '8px 12px', fontSize: 11, color: '#6b6c72', borderBottom: '1px solid #2a2b30', fontWeight: 700 }}>SELECT TAX JURISDICTION</div>
                {TAX_COUNTRIES.map(c => (
                  <div key={c.code} onClick={() => selectCountry(c.code)} style={{ padding: '10px 14px', cursor: 'pointer', background: c.code === taxCountry ? '#6789ed22' : 'transparent', borderLeft: c.code === taxCountry ? '3px solid #6789ed' : '3px solid transparent', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontWeight: 600 }}>{c.flag} {c.name}</span>
                    <span style={{ fontSize: 11, color: '#6b6c72' }}>{c.note}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
          <button onClick={async () => { await fetch('/api/auth/logout', { method: 'POST' }); window.location.href = '/login'; }} style={{ background: '#ef4444', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>🔒 Logout</button>
        </div>
      </div>

      {/* MODE TOGGLE BAR */}
      <div style={{
        background: '#18191d',
        borderBottom: '1px solid #2a2b30',
        padding: '16px 28px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 20,
      }}>
        <ModeToggle mode={pbMode} onChange={next => setPbMode(next)} />
      </div>

      {/* MODE BANNER */}
      {pbMode === 'simulation' && (
        <div style={{
          background: '#8aad8a10',
          borderBottom: '1px solid #8aad8a22',
          padding: '10px 28px',
          textAlign: 'center',
          fontSize: 13,
          color: '#8aad8a',
          fontWeight: 500,
          letterSpacing: '0.01em',
        }}>
          🔬 Simulation mode — virtual capital, no real funds
        </div>
      )}

      <div style={{ maxWidth: 1300, margin: '0 auto', padding: '24px 28px' }}>

        {/* ADVISORY MODE CARD */}
        {pbMode === 'advisory' && (
          <div style={{ background: '#18191d', border: '1px solid #ff931755', borderRadius: 16, padding: 28, marginBottom: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
              <div style={{ fontSize: 18, fontWeight: 800, color: '#ff9317' }}>💼 Advisory Mode — Deployment Wallets</div>
              <button
                onClick={() => setShowAddWallet(!showAddWallet)}
                style={{ background: '#6789ed', border: 'none', borderRadius: 8, color: '#fff', fontSize: 13, fontWeight: 700, padding: '7px 16px', cursor: 'pointer' }}
              >
                + Add Wallet
              </button>
            </div>
            <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 20 }}>
              Add your Safe multisig or Phantom wallet. Advisory mode prepares unsigned transaction bundles — you always approve before anything executes.
            </div>

            {/* Add wallet form */}
            {showAddWallet && (
              <div style={{ background: '#111214', border: '1px solid #2a2b30', borderRadius: 12, padding: '18px 20px', marginBottom: 20 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: '#edeef0', marginBottom: 14 }}>Add Deployment Wallet</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
                  <div>
                    <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 6, fontWeight: 600, textTransform: 'uppercase' }}>Wallet Type</div>
                    <select
                      value={newWalletType}
                      onChange={e => setNewWalletType(e.target.value)}
                      style={{ width: '100%', background: '#18191d', border: '1px solid #2a2b30', borderRadius: 8, color: '#edeef0', fontSize: 13, padding: '8px 10px' }}
                    >
                      <option value="safe">Safe Multisig (EVM)</option>
                      <option value="phantom">Phantom (Solana)</option>
                      <option value="eoa">Regular Wallet (EOA)</option>
                    </select>
                  </div>
                  <div>
                    <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 6, fontWeight: 600, textTransform: 'uppercase' }}>Label (optional)</div>
                    <input
                      value={newWalletLabel}
                      onChange={e => setNewWalletLabel(e.target.value)}
                      placeholder="e.g. Base Safe, Arbitrum Safe"
                      style={{ width: '100%', boxSizing: 'border-box', background: '#18191d', border: '1px solid #2a2b30', borderRadius: 8, color: '#edeef0', fontSize: 13, padding: '8px 10px' }}
                    />
                  </div>
                </div>
                <div style={{ marginBottom: 14 }}>
                  <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 6, fontWeight: 600, textTransform: 'uppercase' }}>Wallet Address</div>
                  <input
                    value={newWalletAddress}
                    onChange={e => setNewWalletAddress(e.target.value)}
                    placeholder={newWalletType === 'phantom' ? 'Solana address (base58)' : '0x... (EVM address)'}
                    style={{ width: '100%', boxSizing: 'border-box', background: '#18191d', border: '1px solid #2a2b30', borderRadius: 8, color: '#edeef0', fontSize: 13, padding: '8px 10px', fontFamily: 'monospace' }}
                  />
                </div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <button
                    onClick={() => {
                      if (!newWalletAddress.trim()) return;
                      const entry = { address: newWalletAddress.trim(), label: newWalletLabel.trim() || newWalletType, type: newWalletType, addedAt: new Date().toISOString() };
                      const updated = [...advisoryWallets, entry];
                      setAdvisoryWallets(updated);
                      localStorage.setItem('pb_advisory_wallets', JSON.stringify(updated));
                      setNewWalletAddress(''); setNewWalletLabel(''); setShowAddWallet(false);
                    }}
                    style={{ background: '#6789ed', border: 'none', borderRadius: 8, color: '#fff', fontSize: 13, fontWeight: 700, padding: '8px 20px', cursor: 'pointer' }}
                  >
                    Save Wallet
                  </button>
                  <button
                    onClick={() => { setShowAddWallet(false); setNewWalletAddress(''); setNewWalletLabel(''); }}
                    style={{ background: '#2a2b30', border: 'none', borderRadius: 8, color: '#6b7280', fontSize: 13, fontWeight: 600, padding: '8px 16px', cursor: 'pointer' }}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {/* Advisory wallet list */}
            {advisoryWallets.length === 0 ? (
              <div style={{ background: '#111214', borderRadius: 10, padding: '24px', textAlign: 'center', color: '#6b7280', fontSize: 14, marginBottom: 20 }}>
                <div style={{ fontSize: 28, marginBottom: 8 }}>🏦</div>
                <div style={{ fontWeight: 600, marginBottom: 4 }}>No deployment wallets added yet</div>
                <div style={{ fontSize: 12 }}>Add your Safe multisig address to get started</div>
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 12, marginBottom: 20 }}>
                {advisoryWallets.map((w, i) => (
                  <div key={i} style={{ background: '#111214', border: '1px solid #2a2b30', borderRadius: 10, padding: '14px 18px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                        <span style={{ fontSize: 11, background: w.type === 'safe' ? '#6789ed22' : '#ff931722', color: w.type === 'safe' ? '#6789ed' : '#ff9317', border: `1px solid ${w.type === 'safe' ? '#6789ed44' : '#ff931744'}`, borderRadius: 4, padding: '2px 7px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                          {w.type === 'safe' ? '🔒 Safe' : w.type === 'phantom' ? '👻 Phantom' : '👛 EOA'}
                        </span>
                        <span style={{ fontSize: 12, color: '#edeef0', fontWeight: 600 }}>{w.label}</span>
                      </div>
                      <div style={{ fontSize: 12, color: '#6b7280', fontFamily: 'monospace', wordBreak: 'break-all' }}>{w.address}</div>
                    </div>
                    <button
                      onClick={() => {
                        const updated = advisoryWallets.filter((_, j) => j !== i);
                        setAdvisoryWallets(updated);
                        localStorage.setItem('pb_advisory_wallets', JSON.stringify(updated));
                      }}
                      style={{ background: 'none', border: 'none', color: '#6b7280', cursor: 'pointer', fontSize: 16, padding: '0 4px', flexShrink: 0 }}
                      title="Remove wallet"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Coming Soon: Deploy bundles */}
            <div style={{ background: '#ff931710', border: '1px solid #ff931733', borderRadius: 12, padding: '18px 20px' }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#ff9317', marginBottom: 6 }}>🚀 Deploy Bundles — Coming in Phase 2</div>
              <div style={{ fontSize: 13, color: '#6b7280', lineHeight: 1.6 }}>
                Agent will prepare one-click deployment recommendations for your Safe wallet. You sign once — approve + deposit in a single transaction.
              </div>
            </div>
          </div>
        )}

        {/* Stat cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16, marginBottom: 20 }}>
          {[
            { val: fmt(combined), label: pbMode === 'simulation' ? '📊 Simulation Portfolio — Virtual Capital' : '💼 Live Portfolio — Real Wallets', sub: `${fmt(gain)} earned`, sc: gain >= 0 ? '#8aad8a' : '#ef4444' },
            { val: fmt(dailyA + dailyB), label: 'Daily Earnings (projected)', sub: `APY refreshed: ${new Date(data.lastUpdatedAt).toLocaleTimeString()}`, sc: '#6789ed', vc: '#8aad8a' },
            { val: `${days.toFixed(1)}d`, label: 'Simulation Running', sub: `${data.cycles} cycles`, sc: '#6b6c72', vc: '#ff9317' },
            { val: `🏆 Strat ${winner}`, label: 'Current Leader', sub: daysLeft > 0 ? `${daysLeft.toFixed(1)}d to call` : '✅ Ready to deploy!', sc: '#8aad8a', vc: '#6789ed' },
          ].map((x, i) => (
            <div key={i} style={{ ...S.card, textAlign: 'center' }}>
              <div style={{ fontSize: 26, fontWeight: 800, color: x.vc || '#fff', marginBottom: 4 }}>{x.val}</div>
              <div style={{ fontSize: 12, color: '#6b6c72', marginBottom: 5 }}>{x.label}</div>
              <div style={{ fontSize: 13, fontWeight: 600, color: x.sc }}>{x.sub}</div>
            </div>
          ))}
        </div>

        {/* Progress */}
        <div style={{ ...S.card, marginBottom: 18 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 13, color: '#edeef0' }}>⏳ Progress to real capital recommendation (7 days)</span>
            <span style={{ fontSize: 14, fontWeight: 700 }}>{progress.toFixed(0)}%</span>
          </div>
          <div style={{ height: 6, background: '#2a2b30', borderRadius: 3 }}>
            <div style={{ height: '100%', width: `${progress}%`, background: 'linear-gradient(90deg,#6789ed,#8aad8a)', borderRadius: 3, transition: 'width .5s' }} />
          </div>
          <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 6 }}>{daysLeft > 0 ? `${daysLeft.toFixed(1)} days until recommendation` : `🎉 Done — Strategy ${winner} wins!`}</div>
        </div>

        {/* Strategy cards */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginBottom: 18 }}>
          {[
            { k: 'A', name: 'Max APY', sub: 'Highest yielding correlated pools', color: '#6789ed', bg: '#1e3a5f', poolApy: poolApyA, realApy: apyA, ret: retA, bal: data.strategyA.virtualBalance, earned: data.strategyA.totalEarned, daily: dailyA },
            { k: 'B', name: 'Risk-Adjusted', sub: 'Lending anchors + best LPs', color: '#8aad8a', bg: '#1a3a2a', poolApy: poolApyB, realApy: apyB, ret: retB, bal: data.strategyB.virtualBalance, earned: data.strategyB.totalEarned, daily: dailyB },
          ].map(s => (
            <div key={s.k} style={{ background: `linear-gradient(135deg,${s.bg},#18191d)`, border: `1px solid ${s.color}44`, borderRadius: 16, padding: 22 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18 }}>
                <div><div style={{ fontSize: 17, fontWeight: 700 }}>Strategy {s.k} — {s.name}</div><div style={{ fontSize: 12, color: '#edeef0', marginTop: 3 }}>{s.sub}</div></div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 34, fontWeight: 900, color: s.color, lineHeight: 1 }}>{s.poolApy.toFixed(1)}%</div>
                  <div style={{ fontSize: 11, color: '#6b6c72', marginTop: 3 }}>pool APY (live)</div>
                  {s.realApy > 0 && <div style={{ fontSize: 12, color: '#edeef0', marginTop: 2 }}>{s.realApy.toFixed(1)}% realised</div>}
                </div>
              </div>
              {[['Balance', fmt(s.bal), '#fff'], ['Total Earned', fmt(s.earned), '#8aad8a'], ['Return', fmtPct(s.ret), s.ret >= 0 ? '#8aad8a' : '#ef4444'], ['Daily', fmt(s.daily)+'/day', '#fff'], ['Monthly (projected)', fmt(s.daily*30)+'/mo', s.color]].map(([l, v, c]) => (
                <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #ffffff0d', fontSize: 13 }}>
                  <span style={{ color: '#edeef0' }}>{l}</span><span style={{ fontWeight: 600, color: c }}>{v}</span>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Chart */}
        <div style={{ ...S.card, marginBottom: 18 }}>
          <div style={{ fontSize: 12, color: '#edeef0', textTransform: 'uppercase', letterSpacing: '.05em', marginBottom: 14 }}>Portfolio Balance Over Time</div>
          <div style={{ height: 220 }}><canvas ref={chartRef} /></div>
        </div>

        {/* APY Alerts */}
        {data.apyAlerts && data.apyAlerts.length > 0 && (
          <div style={{ ...S.card, marginBottom: 18, border: '1px solid #ef444466', background: '#1a0a0a' }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#ef4444', marginBottom: 10 }}>🚨 APY ALERTS — Review Required</div>
            {data.apyAlerts.map((a,i) => <div key={i} style={{ fontSize: 12, color: '#fca5a5', padding: '4px 0' }}>{a}</div>)}
          </div>
        )}

        {/* Tax Summary Panel */}
        {(() => {
          const country = TAX_COUNTRIES.find(c => c.code === taxCountry) || TAX_COUNTRIES[0];
          const totalEarned = (data.strategyA?.totalEarned || 0) + (data.strategyB?.totalEarned || 0);
          const TAX_RATES = { AU: 0.32, US: 0.24, GB: 0.20, CA: 0.26, DE: 0.42, JP: 0.45, SG: 0.00, AE: 0.00, IN: 0.30, NZ: 0.33 };
          const CGT_DISCOUNTS = { AU: 0.50, DE: 1.00, CA: 0.50 };
          const TAX_FREE = ['SG', 'AE'];
          const rate = TAX_RATES[taxCountry] ?? 0.25;
          const discount = CGT_DISCOUNTS[taxCountry] ?? 0;
          const isFree = TAX_FREE.includes(taxCountry);
          const taxableGain = totalEarned * (1 - discount);
          const estimatedTax = isFree ? 0 : taxableGain * rate;
          const afterTax = totalEarned - estimatedTax;
          return (
            <div style={{ ...S.card, marginBottom: 18 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.05em', textTransform: 'uppercase', color: '#edeef0' }}>🏛️ Tax Estimate — {country.flag} {country.name}</div>
                  <div style={{ fontSize: 11, color: '#6b6c72', marginTop: 3 }}>{country.note} · Change country using the selector in the header</div>
                </div>
                {isFree && <span style={{ background: '#8aad8a22', color: '#8aad8a', border: '1px solid #8aad8a44', borderRadius: 20, padding: '3px 12px', fontSize: 12, fontWeight: 700 }}>✅ Tax Free</span>}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12 }}>
                {[
                  { label: 'Gross Earnings', val: `$${totalEarned.toFixed(2)}`, color: '#8aad8a' },
                  { label: `Est. Tax (${(rate*100).toFixed(0)}%${discount > 0 ? ` after ${(discount*100).toFixed(0)}% discount` : ''})`, val: isFree ? '$0.00' : `-$${estimatedTax.toFixed(2)}`, color: isFree ? '#8aad8a' : '#ef4444' },
                  { label: 'After-Tax Return', val: `$${afterTax.toFixed(2)}`, color: '#6789ed' },
                  { label: 'Effective Rate', val: isFree ? '0%' : `${totalEarned > 0 ? ((estimatedTax/totalEarned)*100).toFixed(1) : 0}%`, color: '#edeef0' },
                ].map((item, i) => (
                  <div key={i} style={{ background: '#111214', borderRadius: 10, padding: '14px 16px' }}>
                    <div style={{ fontSize: 11, color: '#6b6c72', marginBottom: 6 }}>{item.label}</div>
                    <div style={{ fontSize: 20, fontWeight: 700, color: item.color }}>{item.val}</div>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 10, fontSize: 11, color: '#2a2b30' }}>⚠️ Estimates only — not financial or tax advice. Consult a tax professional.</div>
            </div>
          );
        })()}

        {/* Strategy Framework */}
        <div style={{ ...S.card, marginBottom: 18 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.05em', textTransform: 'uppercase', color: '#edeef0' }}>📚 Position Classification</div>
              <div style={{ fontSize: 11, color: '#6b6c72', marginTop: 3 }}>Yield source breakdown across active positions</div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              {[['T1','Near-zero IL','#8aad8a'],['T2','Conviction hold','#ff9317']].map(([t,l,c])=>(
                <div key={t} style={{ background: c+'22', border: `1px solid ${c}44`, borderRadius: 8, padding: '4px 10px', fontSize: 11, color: c, fontWeight: 700 }}>{t} — {l}</div>
              ))}
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {[...data.strategyA.positions.map(p=>({...p,strat:'A'})), ...data.strategyB.positions.map(p=>({...p,strat:'B'}))].map((p,i) => {
              const cls = classifyPosition(p);
              return (
                <div key={i} style={{ background: '#111214', border: `1px solid ${cls.color}33`, borderRadius: 10, padding: '10px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                      <span style={{ fontSize: 14 }}>{cls.icon}</span>
                      <span style={{ fontWeight: 700, fontSize: 13 }}>{p.symbol}</span>
                      <span style={{ background: cls.color+'22', color: cls.color, borderRadius: 4, padding: '1px 6px', fontSize: 10, fontWeight: 700 }}>{cls.tier}</span>
                      <span style={{ color: '#6b6c72', fontSize: 10 }}>Strat {p.strat}</span>
                    </div>
                    <div style={{ fontSize: 11, color: '#6b6c72' }}>{cls.label} · {cls.src}</div>
                    <div style={{ fontSize: 11, color: '#6b6c72', marginTop: 2 }}>{p.project} · {p.chain}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 20, fontWeight: 900, color: cls.color }}>{(p.apy||0).toFixed(1)}%</div>
                    <div style={{ fontSize: 10, color: cls.risk==='Low'?'#8aad8a':cls.risk==='Medium'?'#ff9317':'#ef4444', marginTop: 2 }}>⚡ {cls.risk} risk</div>
                    <div style={{ fontSize: 10, color: '#6b6c72' }}>{fmtTVL(p.tvlUsd)}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Positions */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
          {[data.strategyA, data.strategyB].map((strat, si) => (
            <div key={si} style={S.card}>
              <div style={{ fontSize: 12, color: '#edeef0', textTransform: 'uppercase', letterSpacing: '.05em', marginBottom: 14 }}>Strategy {si===0?'A':'B'} Positions</div>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead><tr>{['Chain','Protocol','Pool','APY','TVL','Strategy'].map(h => <th key={h} style={{ textAlign: 'left', color: '#6b6c72', padding: '5px 7px', borderBottom: '1px solid #2a2b30', fontWeight: 500, fontSize: 11, textTransform: 'uppercase' }}>{h}</th>)}</tr></thead>
                <tbody>
                  {strat.positions.map((p, i) => {
                    const cls = classifyPosition(p);
                    return (
                    <tr key={i} style={{ borderBottom: '1px solid #18191d' }}>
                      <td style={{ padding: '9px 7px', color: CHAIN[p.chain]||'#edeef0', fontWeight: 600 }}>{p.chain}</td>
                      <td style={{ padding: '9px 7px', color: '#edeef0' }}>{(p.project||'').substring(0,13)}</td>
                      <td style={{ padding: '9px 7px', fontWeight: 600 }}>{(p.symbol||'').substring(0,15)}</td>
                      <td style={{ padding: '9px 7px', color: '#8aad8a', fontWeight: 700 }}>{(p.apy||0).toFixed(1)}%</td>
                      <td style={{ padding: '9px 7px', color: '#edeef0' }}>{fmtTVL(p.tvlUsd||0)}</td>
                      <td style={{ padding: '9px 7px' }}><span style={{ background: cls.color+'22', color: cls.color, borderRadius: 4, padding: '2px 6px', fontSize: 10, fontWeight: 700 }}>{cls.tier} {cls.icon}</span></td>
                    </tr>
                  )})}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
