# Yield Intelligence Report — 2026-03-21 00:03 UTC

**Generated:** 2026-03-21 00:03 UTC  
**Sim Start:** 2026-03-20  
**Days Elapsed:** ~1 day (7 monitoring cycles)  
**Days Remaining:** ~6 days (7-day simulation)

---

## Strategy Standings

### Strategy A — Max APY 🏆 (LEADER)
| Field | Value |
|-------|-------|
| Starting Capital | $2,500.00 |
| Current Balance | $2,500.04 |
| Total Earned | $0.04 |
| Projected APY | 33.5% |
| Daily Earnings | $3.98 |
| After-tax (AUD) | A$0.06/day |
| Active Positions | 5/5 |

**Positions:**
1. Base / Aerodrome Slipstream — USDZ-SUSDZ — 32.3% APY — $1.3M TVL ✅
2. Base / PancakeSwap AMM v3 — WETH-USDC — 70.4% APY — $2.1M TVL ⚠️ IL RISK
3. Arbitrum / Beefy — WBTC-USDC — 66.3% APY — $1.1M TVL ⚠️ IL RISK
4. Solana / Orca DEX — SOL-USDC — 62.5% APY — $29.5M TVL ⚠️ IL RISK
5. Base / Uniswap v4 — ETH-USDC — 58.8% APY — $1.7M TVL ⚠️ IL RISK

---

### Strategy B — Risk-Adjusted
| Field | Value |
|-------|-------|
| Starting Capital | $2,500.00 |
| Current Balance | $2,500.01 |
| Total Earned | $0.01 |
| Projected APY | 10.1% |
| Daily Earnings | $0.69 |
| After-tax (AUD) | A$0.02/day |
| Active Positions | 5/5 |

**Positions:**
1. Solana / Jupiter Lend — USDS — 5.1% APY — $28.2M TVL ✅
2. Arbitrum / Fluid Lending — USDC — 4.9% APY — $37.6M TVL ✅
3. Ethereum / Fluid Lending — USDT — 4.2% APY — $141.3M TVL ✅
4. Ethereum / SparkLend — USDS — 4.1% APY — $619.5M TVL ✅
5. Base / Aerodrome Slipstream — USDZ-SUSDZ — 32.3% APY — $1.3M TVL ✅

---

## Pool APY Changes Since Last Report
No prior report to compare against (baseline run). No APY alerts triggered by simulator (all within normal range).

---

## Correlation Status 🔴 ALERTS

| Position | Strategy | Correlation | Status |
|----------|----------|-------------|--------|
| USDZ-SUSDZ | A & B | Unknown | ⚪ Watchlist (token IDs not in CoinGecko) |
| WETH-USDC | A | **-26.81%** | 🔴 DECOUPLED — below 70% threshold |
| WBTC-USDC | A | **-18.29%** | 🔴 DECOUPLED — below 70% threshold |
| SOL-USDC | A | **-22.35%** | 🔴 DECOUPLED — below 70% threshold |
| ETH-USDC | A | **-26.42%** | 🔴 DECOUPLED — below 70% threshold |
| USDS (lending) | B | N/A | ✅ Single-asset, no IL |
| USDC (lending) | B | N/A | ✅ Single-asset, no IL |
| USDT (lending) | B | N/A | ✅ Single-asset, no IL |

**Note:** All Strategy A volatile/stablecoin pairs are flagging DECOUPLED. This is expected behaviour for crypto/stablecoin LP pairs (they are structurally inversely correlated). The correlation checker is designed for correlated-pair LPs. These pairs carry structural IL risk which the high APY (62–70%) is meant to compensate. Recommendation: monitor IL drag over the 7-day test period rather than treating these as emergency exits.

---

## Market Context — Price Movements (24h)

| Asset | Price | 24h Change | Alert? |
|-------|-------|-----------|--------|
| BTC | $70,536 | +0.96% | ✅ No alert |
| ETH | $2,147.17 | +0.52% | ✅ No alert |
| SOL | $89.86 | +1.09% | ✅ No alert |

**Result:** No asset moved >5% in 24h. No elevated IL risk from price action. No asset down >10% (no Telegram alert triggered on price).

---

## Recommendations

| Position | Action | Reason |
|----------|--------|--------|
| USDZ-SUSDZ (A & B) | HOLD | Stablecoin pair, unknown correlation — watchlist only |
| WETH-USDC (A) | HOLD — MONITOR | High APY (70.4%) compensates IL risk; market calm |
| WBTC-USDC (A) | HOLD — MONITOR | High APY (66.3%); BTC flat in 24h |
| SOL-USDC (A) | HOLD — MONITOR | High APY (62.5%); SOL +1.09% — no IL pressure |
| ETH-USDC (A) | HOLD — MONITOR | High APY (58.8%); ETH flat in 24h |
| All Strategy B | HOLD | Clean stablecoin lending, all green |

**Overall:** Strategy A leading on absolute earnings ($0.04 vs $0.01) with 3.3× projected APY advantage. However, all 4 volatile LP positions carry structural IL risk. Given calm market conditions today, **HOLD** all positions and continue 7-day test. Re-evaluate if any underlying asset moves >5% in a single session.

---

## Alert Summary

| Alert Type | Triggered? | Detail |
|-----------|-----------|--------|
| Correlation below threshold | 🔴 YES | 4 Strategy A pairs flagged DECOUPLED |
| Pool APY dropped >50% | ✅ No | All APYs stable |
| Stablecoin peg deviation >0.2% | ✅ No | No stablecoin depegs detected |
| Underlying asset down >10% | ✅ No | BTC/ETH/SOL all near flat |
| Simulation Day 7 reached | ✅ No | ~Day 1 of 7 |

**⚠️ ALERT TO SEND → Pritesh via Telegram:**
4 Strategy A positions (WETH-USDC, WBTC-USDC, SOL-USDC, ETH-USDC) are flagging correlation below 70% threshold. Context: this is structural for volatile/stablecoin LP pairs and market is currently calm. High APYs (58–70%) may justify holding through the 7-day test. Recommend monitoring rather than immediate exit given flat 24h price action.

---

*Next report: 2026-03-21 06:00 UTC (6h cadence)*
