'use client';
import { useEffect, useState } from 'react';

const NETWORKS = [
  { id: 'ethereum', label: 'Ethereum', icon: '⟠' },
  { id: 'base',     label: 'Base',     icon: '🔵' },
  { id: 'arbitrum', label: 'Arbitrum', icon: '🔷' },
  { id: 'optimism', label: 'Optimism', icon: '🔴' },
  { id: 'polygon',  label: 'Polygon',  icon: '🟣' },
  { id: 'solana',   label: 'Solana',   icon: '◎'  },
];

const CHAIN_META = [
  { id: 'ethereum', label: 'Ethereum', icon: '⟠' },
  { id: 'base',     label: 'Base',     icon: '🔵' },
  { id: 'arbitrum', label: 'Arbitrum', icon: '🔷' },
  { id: 'optimism', label: 'Optimism', icon: '🔴' },
  { id: 'polygon',  label: 'Polygon',  icon: '🟣' },
];

const NAV_LINKS = [
  { label: 'Features',  href: '/#features' },
  { label: 'Pricing',   href: '/pricing'   },
  { label: 'Tax',       href: '/tax'       },
  { label: 'Dashboard', href: '/dashboard' },
  { label: 'Wallets',   href: '/wallets'   },
];

const CHAIN_MAP = {
  '0x1':    'ethereum',
  '0x2105': 'base',
  '0xa4b1': 'arbitrum',
  '0xa':    'optimism',
  '0x89':   'polygon',
};

const S = {
  bg:   '#111214',
  card: { background: '#18191d', border: '1px solid #2a2b30', borderRadius: 16, padding: 24 },
};

/* ── provider helpers ─────────────────────────────────────────────────────── */
function hasProvider(flag) {
  if (typeof window === 'undefined' || !window.ethereum) return false;
  if (window.ethereum[flag]) return true;
  if (Array.isArray(window.ethereum.providers))
    return window.ethereum.providers.some(p => p[flag]);
  return false;
}
function getProvider(flag) {
  if (typeof window === 'undefined' || !window.ethereum) return null;
  if (window.ethereum[flag]) return window.ethereum;
  if (Array.isArray(window.ethereum.providers))
    return window.ethereum.providers.find(p => p[flag]) || null;
  return null;
}

/* ═══════════════════════════════════════════════════════════════════════════ */
export default function WalletsPage() {
  const [wallets,           setWallets]           = useState([]);
  const [address,           setAddress]           = useState('');
  const [label,             setLabel]             = useState('');
  const [network,           setNetwork]           = useState('ethereum');
  const [error,             setError]             = useState('');
  const [balances,          setBalances]          = useState({});
  const [rocketpoolData,    setRocketpoolData]    = useState({}); // address -> RP node data
  const [multichainData,    setMultichainData]    = useState({}); // address -> multichain scan result
  const [multichainLoading, setMultichainLoading] = useState({}); // address -> bool
  const [loading,           setLoading]           = useState(false);
  const [hoveredCard,       setHoveredCard]       = useState(null);
  const [ledgerConnecting,  setLedgerConnecting]  = useState(false);
  const [showPhantomPicker, setShowPhantomPicker] = useState(false);
  const [installed,         setInstalled]         = useState({
    metamask: false, rabby: false, phantom: false,
    coinbase: false, rainbow: false, trust: false,
    ledger: false, walletconnect: false,
  });

  /* auth + load */
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const hasCookie = document.cookie.split(';').some(c => c.trim().startsWith('pb_token='));
    if (!hasCookie) { window.location.href = '/login'; return; }
    const stored = localStorage.getItem('pb_wallets');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setWallets(parsed);
        // Load any previously cached multichain data from wallet objects
        const cached = {};
        for (const w of parsed) {
          if (w.chains) cached[w.address] = w.chains;
        }
        if (Object.keys(cached).length > 0) setMultichainData(cached);
        // Auto-scan wallets that don't have chain data yet
        parsed.forEach(w => {
          if (w.network !== 'solana' && !w.chains) {
            scanMultichain(w.address);
          }
        });
      } catch {}
    }
  }, []);

  /* detect installed wallets */
  function detectWallets() {
    if (typeof window === 'undefined') return;
    const eth = window.ethereum;
    setInstalled({
      metamask:    !!(eth?.isMetaMask && !eth?.isRabby),
      rabby:       !!(eth?.isRabby),
      phantom:     !!(window.phantom?.ethereum || window.phantom?.solana || window.solana?.isPhantom),
      coinbase:    !!(eth?.isCoinbaseWallet || window.coinbaseWalletExtension),
      rainbow:     !!(eth?.isRainbow),
      trust:       !!(eth?.isTrust || eth?.isTrustWallet || window.trustwallet),
      ledger:      !!(typeof navigator !== 'undefined' && navigator.usb),
      walletconnect: false,
    });
  }

  useEffect(() => {
    // Initial detection
    detectWallets();
    // Re-detect after delays to catch late-injecting extensions
    const timer  = setTimeout(detectWallets, 500);
    const timer2 = setTimeout(detectWallets, 1500);
    return () => { clearTimeout(timer); clearTimeout(timer2); };
  }, []);

  /* account-change listener */
  useEffect(() => {
    if (typeof window !== 'undefined' && window.ethereum)
      window.ethereum.on('accountsChanged', () => {});
  }, []);

  /* close phantom picker on outside click */
  useEffect(() => {
    if (!showPhantomPicker) return;
    const close = (e) => {
      if (!e.target.closest('[data-phantom-picker]')) setShowPhantomPicker(false);
    };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [showPhantomPicker]);

  /* ── multichain scan ──────────────────────────────────────────────────── */
  async function scanMultichain(addr) {
    if (!/^0x[a-fA-F0-9]{40}$/i.test(addr)) return;
    setMultichainLoading(prev => ({ ...prev, [addr]: true }));
    try {
      const res  = await fetch(`/api/wallet/multichain?address=${addr}`);
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      setMultichainData(prev => ({ ...prev, [addr]: data }));

      // Persist chains into the wallet object in localStorage
      const existing = JSON.parse(localStorage.getItem('pb_wallets') || '[]');
      const updated  = existing.map(w =>
        w.address.toLowerCase() === addr.toLowerCase()
          ? { ...w, chains: data }
          : w
      );
      localStorage.setItem('pb_wallets', JSON.stringify(updated));
      setWallets(updated);
    } catch (err) {
      console.warn('[multichain scan failed]', err.message);
    } finally {
      setMultichainLoading(prev => ({ ...prev, [addr]: false }));
    }
  }

  /* ── persist helper ─────────────────────────────────────────────────────── */
  function persistWallet(addr, net, wLabel) {
    const existing = JSON.parse(localStorage.getItem('pb_wallets') || '[]');
    if (existing.find(w => w.address.toLowerCase() === addr.toLowerCase())) return;
    const newWallet = { address: addr, network: net, label: wLabel, addedAt: new Date().toISOString() };
    const updated = [...existing, newWallet];
    localStorage.setItem('pb_wallets', JSON.stringify(updated));
    setWallets(updated);
    if (net !== 'solana') {
      fetchBalance(addr, net);
      fetchRocketpoolData(addr);
      scanMultichain(addr);
    }
  }

  /* ── generic EVM connect ────────────────────────────────────────────────── */
  async function connectEVM(provider, wLabel) {
    if (!provider) { alert('Wallet not detected. Is it installed and unlocked?'); return; }
    try {
      const accounts = await provider.request({ method: 'eth_requestAccounts' });
      if (!accounts?.length) return;
      const chainId = await provider.request({ method: 'eth_chainId' });
      persistWallet(accounts[0], CHAIN_MAP[chainId] || 'ethereum', wLabel);
    } catch (err) {
      if (err.code !== 4001) alert('Connection error: ' + err.message);
    }
  }

  /* ── per-wallet connect functions ───────────────────────────────────────── */
  async function connectMetaMask() {
    const p = getProvider('isMetaMask');
    if (!p || p.isRabby) { alert('MetaMask not detected. Please install it.'); return; }
    await connectEVM(p, 'MetaMask');
  }
  async function connectRabby() {
    const p = getProvider('isRabby');
    if (!p) { alert('Rabby not detected. Please install it.'); return; }
    await connectEVM(p, 'Rabby Wallet');
  }
  async function connectCoinbase() {
    const p = getProvider('isCoinbaseWallet');
    if (!p) { alert('Coinbase Wallet not detected. Please install it.'); return; }
    await connectEVM(p, 'Coinbase Wallet');
  }
  async function connectRainbow() {
    const p = getProvider('isRainbow');
    if (!p) { alert('Rainbow not detected. Please install it.'); return; }
    await connectEVM(p, 'Rainbow Wallet');
  }
  async function connectTrust() {
    const p = getProvider('isTrust') || getProvider('isTrustWallet') || window.trustwallet || null;
    if (!p) { alert('Trust Wallet not detected. Please install it.'); return; }
    await connectEVM(p, 'Trust Wallet');
  }
  async function connectPhantomEVM() {
    setShowPhantomPicker(false);
    const p = window.phantom?.ethereum;
    if (!p) { alert('Phantom EVM provider not found. Enable EVM in Phantom settings.'); return; }
    await connectEVM(p, 'Phantom (EVM)');
  }
  async function connectPhantomSolana() {
    setShowPhantomPicker(false);

    // Try all Phantom Solana provider locations
    const sol = window.phantom?.solana
      || (window.solana?.isPhantom ? window.solana : null)
      || window.solana; // last resort

    if (!sol) {
      // Give it one more chance after a brief delay
      await new Promise(r => setTimeout(r, 300));
      const sol2 = window.phantom?.solana || window.solana;
      if (!sol2) {
        alert('Phantom Solana not found. Please:\n1. Install Phantom from phantom.app\n2. Make sure Solana is enabled in Phantom settings\n3. Refresh this page');
        return;
      }
    }

    try {
      const resp = await (sol || window.phantom?.solana || window.solana).connect();
      persistWallet(resp.publicKey.toString(), 'solana', 'Phantom (Solana)');
    } catch (err) {
      if (err.code !== 4001) alert('Phantom Solana error: ' + err.message);
    }
  }
  async function connectLedger() {
    if (typeof navigator === 'undefined' || !navigator.usb) {
      alert("Your browser doesn't support WebUSB. Please use Chrome or Edge.");
      return;
    }
    setLedgerConnecting(true);
    try {
      const { default: TransportWebUSB } = await import('@ledgerhq/hw-transport-webusb');
      const { default: AppEth }          = await import('@ledgerhq/hw-app-eth');
      const transport = await TransportWebUSB.create();
      const eth       = new AppEth(transport);
      const result    = await eth.getAddress("44'/60'/0'/0/0");
      persistWallet(result.address, 'ethereum', 'Ledger Hardware Wallet');
      await transport.close();
    } catch (err) {
      const silent = err.name === 'TransportOpenUserCancelled' || err.message?.includes('cancelled');
      if (!silent) alert('Ledger error: ' + (err.message || err));
    } finally {
      setLedgerConnecting(false);
    }
  }

  /* ── manual form ────────────────────────────────────────────────────────── */
  function saveWallets(updated) {
    setWallets(updated);
    localStorage.setItem('pb_wallets', JSON.stringify(updated));
  }
  function validateAddress(addr) {
    if (/^0x[a-fA-F0-9]{40}$/.test(addr)) return true;           // EVM
    if (/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(addr)) return true; // Solana
    return false;
  }
  async function addWallet(e) {
    e.preventDefault();
    setError('');
    if (!validateAddress(address)) { setError('Enter a valid EVM (0x…) or Solana address.'); return; }
    if (wallets.some(w => w.address.toLowerCase() === address.toLowerCase())) {
      setError('This address is already connected.'); return;
    }
    const newWallet = {
      address, network,
      label: label || `My ${NETWORKS.find(n => n.id === network)?.label} Wallet`,
      addedAt: new Date().toISOString(),
    };
    const updated = [...wallets, newWallet];
    saveWallets(updated);
    setAddress(''); setLabel('');
    if (network !== 'solana') {
      fetchBalance(address, network);
      scanMultichain(address);
    }
  }

  /* ── balance helpers ────────────────────────────────────────────────────── */
  async function fetchBalance(addr, net) {
    try {
      const res  = await fetch(`/api/wallet/balance?address=${addr}&network=${net}`);
      const data = await res.json();
      setBalances(prev => ({ ...prev, [addr]: data }));
    } catch {}
  }
  async function fetchAllBalances(ws) {
    setLoading(true);
    await Promise.all(ws.map(w => fetchBalance(w.address, w.network)));
    setLoading(false);
  }
  useEffect(() => { if (wallets.length > 0) fetchAllBalances(wallets); }, []);

  /* ── Rocket Pool helpers ─────────────────────────────────────────────────── */
  async function fetchRocketpoolData(addr) {
    if (!/^0x[a-fA-F0-9]{40}$/i.test(addr)) return;
    try {
      const res  = await fetch(`/api/wallet/rocketpool?address=${addr}`);
      const data = await res.json();
      console.log('[wallets] RP data for', addr, data);
      setRocketpoolData(prev => ({ ...prev, [addr]: data }));
    } catch (err) {
      console.error('[wallets] RP fetch failed for', addr, err);
      setRocketpoolData(prev => ({ ...prev, [addr]: { error: err.message, isNode: false } }));
    }
  }
  // Check RP status for all EVM wallets whenever wallet list changes (including initial load)
  useEffect(() => {
    wallets.filter(w => w.network !== 'solana').forEach(w => {
      if (!rocketpoolData[w.address]) fetchRocketpoolData(w.address);
    });
  }, [wallets]); // eslint-disable-line react-hooks/exhaustive-deps

  function removeWallet(addr) {
    const updated = wallets.filter(w => w.address !== addr);
    saveWallets(updated);
    setBalances(prev => { const n = { ...prev }; delete n[addr]; return n; });
    setMultichainData(prev => { const n = { ...prev }; delete n[addr]; return n; });
  }

  /* ── card click handler ─────────────────────────────────────────────────── */
  const handleCardClick = (wc) => {
    if (wc.id === 'phantom') {
      // Re-detect first, then always show picker regardless of detection status
      detectWallets();
      setTimeout(() => setShowPhantomPicker(v => !v), 100);
      return;
    }
    const isInstalled = installed[wc.id];
    if (isInstalled) {
      wc.action();
    } else if (wc.install) {
      window.open(wc.install, '_blank');
    }
  };

  /* ── wallet card definitions ────────────────────────────────────────────── */
  const WALLET_CARDS = [
    { id: 'metamask',     icon: '🦊', name: 'MetaMask',       desc: 'Browser Extension', install: 'https://metamask.io',              action: connectMetaMask,                     comingSoon: false },
    { id: 'rabby',        icon: '🐰', name: 'Rabby',          desc: 'Browser Extension', install: 'https://rabby.io',                 action: connectRabby,                        comingSoon: false },
    { id: 'phantom',      icon: '👻', name: 'Phantom',        desc: 'EVM + Solana',      install: 'https://phantom.app',              action: () => setShowPhantomPicker(v => !v), comingSoon: false },
    { id: 'coinbase',     icon: '🔵', name: 'Coinbase Wallet',desc: 'Browser Extension', install: 'https://www.coinbase.com/wallet', action: connectCoinbase,                     comingSoon: false },
    { id: 'rainbow',      icon: '🌈', name: 'Rainbow',        desc: 'Browser Extension', install: 'https://rainbow.me',               action: connectRainbow,                      comingSoon: false },
    { id: 'trust',        icon: '🛡️', name: 'Trust Wallet',   desc: 'Browser Extension', install: 'https://trustwallet.com',          action: connectTrust,                        comingSoon: false },
    { id: 'ledger',       icon: ledgerConnecting ? '⏳' : '🔒', name: 'Ledger', desc: ledgerConnecting ? 'Connecting via USB…' : 'Hardware · WebUSB', install: null, action: connectLedger, comingSoon: false },
    { id: 'walletconnect',icon: '📡', name: 'WalletConnect',  desc: 'Mobile & Desktop',  install: null,                               action: null,                                comingSoon: true  },
  ];

  /* ── chain breakdown renderer ─────────────────────────────────────────── */
  function ChainBreakdown({ addr }) {
    const mc      = multichainData[addr];
    const loading = multichainLoading[addr];

    if (loading) {
      return (
        <div style={{ marginTop: 12, padding: '10px 14px', background: '#111214', borderRadius: 10, border: '1px solid #6789ed33', fontSize: 12, color: '#6789ed', display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ display: 'inline-block', width: 12, height: 12, border: '2px solid #6789ed44', borderTopColor: '#6789ed', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
          🔍 Scanning all chains…
        </div>
      );
    }

    if (!mc) return null;

    const { chains, activeChains, totalBalanceUsd } = mc;

    return (
      <div style={{ marginTop: 12, background: '#111214', borderRadius: 10, border: '1px solid #2a2b30', overflow: 'hidden' }}>
        {/* Summary row */}
        <div style={{ padding: '8px 14px', borderBottom: '1px solid #2a2b30', fontSize: 12, color: '#6b6c72', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>
            Total: <span style={{ color: '#edeef0', fontWeight: 700 }}>${totalBalanceUsd.toLocaleString()}</span>
            {' '}across <span style={{ color: '#6789ed', fontWeight: 700 }}>{activeChains.length} active chain{activeChains.length !== 1 ? 's' : ''}</span>
          </span>
          <button
            onClick={() => scanMultichain(addr)}
            style={{ background: 'none', border: 'none', color: '#6b6c72', cursor: 'pointer', fontSize: 11, padding: '2px 6px' }}
            title="Re-scan chains"
          >
            🔄
          </button>
        </div>

        {/* Per-chain rows */}
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {CHAIN_META.map((cm, i) => {
            const chain = chains?.[cm.id];
            if (!chain) return null;
            const active = chain.hasActivity;
            return (
              <div key={cm.id} style={{
                display: 'grid',
                gridTemplateColumns: '20px 100px 1fr 80px 60px',
                alignItems: 'center',
                gap: 10,
                padding: '7px 14px',
                borderBottom: i < CHAIN_META.length - 1 ? '1px solid #18191d' : 'none',
                opacity: active ? 1 : 0.45,
              }}>
                <span style={{ fontSize: 12 }}>{active ? '✅' : '⚪'}</span>
                <span style={{ fontSize: 12, color: active ? '#edeef0' : '#6b6c72', fontWeight: active ? 600 : 400 }}>
                  {cm.icon} {cm.label}
                </span>
                <span style={{ fontSize: 12, color: '#8aad8a', fontFamily: 'monospace' }}>
                  {active ? `${chain.balance} ${chain.ticker}` : '—'}
                </span>
                <span style={{ fontSize: 12, color: active ? '#6789ed' : '#6b6c72', textAlign: 'right' }}>
                  {active ? `$${chain.balanceUsd.toLocaleString()}` : '$0'}
                </span>
                <span style={{ fontSize: 11, color: '#6b6c72', textAlign: 'right' }}>
                  {active ? `${chain.txCount} txns` : '—'}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  /* ═════════════════════════════════════════════════════════════════════════ */
  return (
    <div style={{ background: S.bg, minHeight: '100vh', color: '#edeef0', fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" }}>

      {/* NAVBAR */}
      <nav style={{ position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100, backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', background: 'rgba(17,18,20,0.85)', borderBottom: '1px solid #2a2b30' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
          <a href="/" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
            <img src="/passiveblocks_logo.png" alt="PassiveBlocks" style={{ height: 44, width: 'auto', objectFit: 'contain', filter: 'brightness(0) invert(1)' }} />
          </a>
          <div style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
            {NAV_LINKS.map(l => (
              <a key={l.label} href={l.href} style={{ color: l.label === 'Wallets' ? '#edeef0' : '#6b6c72', textDecoration: 'none', fontSize: 14, fontWeight: 500 }}>
                {l.label}
              </a>
            ))}
            <button onClick={async () => { await fetch('/api/auth/logout', { method: 'POST' }); window.location.href = '/login'; }}
              style={{ background: '#ef4444', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
              🔒 Logout
            </button>
          </div>
        </div>
      </nav>

      {/* PAGE HEADER */}
      <div style={{ background: '#18191d', borderBottom: '1px solid #2a2b30', padding: '0 28px', marginTop: 64, display: 'flex', justifyContent: 'space-between', alignItems: 'center', height: 72, boxSizing: 'border-box' }}>
        <div>
          <div style={{ fontSize: 18, fontWeight: 800 }}>👛 Connected Wallets</div>
          <div style={{ fontSize: 12, color: '#6b6c72', marginTop: 3 }}>Track on-chain balances across Ethereum, L2s and Solana</div>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button
            onClick={() => wallets.filter(w => w.network !== 'solana').forEach(w => scanMultichain(w.address))}
            disabled={wallets.filter(w => w.network !== 'solana').length === 0}
            style={{ background: '#6789ed22', color: '#6789ed', border: '1px solid #6789ed55', borderRadius: 8, padding: '8px 18px', fontSize: 13, fontWeight: 600, cursor: wallets.filter(w => w.network !== 'solana').length === 0 ? 'not-allowed' : 'pointer', opacity: wallets.filter(w => w.network !== 'solana').length === 0 ? 0.5 : 1 }}>
            🔍 Scan All Chains
          </button>
          <button onClick={() => fetchAllBalances(wallets)} disabled={loading || wallets.length === 0}
            style={{ background: '#6789ed', color: '#fff', border: 'none', borderRadius: 8, padding: '8px 18px', fontSize: 13, fontWeight: 600, cursor: wallets.length === 0 ? 'not-allowed' : 'pointer', opacity: wallets.length === 0 ? 0.5 : 1 }}>
            {loading ? '⏳ Refreshing...' : '🔄 Refresh All'}
          </button>
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: '0 auto', padding: '28px 24px 64px' }}>

        {/* ── CONNECT SECTION ─────────────────────────────────────────────── */}
        <div style={{ ...S.card, marginBottom: 24 }}>
          <div style={{ fontSize: 13, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#edeef0', marginBottom: 4 }}>
            Connect a Wallet
          </div>
          <div style={{ fontSize: 12, color: '#6b6c72', marginBottom: 20 }}>
            ✓ green badge = detected in your browser &nbsp;·&nbsp; grey = not installed (click for install link)
          </div>

          {/* 8-card grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 4 }}>
            {WALLET_CARDS.map(wc => {
              const isInstalled    = installed[wc.id];
              const isHovered      = hoveredCard === wc.id;
              const isLedgerBusy   = wc.id === 'ledger' && ledgerConnecting;
              const isPhantomOpen  = wc.id === 'phantom' && showPhantomPicker;

              /* Coming-soon card */
              if (wc.comingSoon) return (
                <div key={wc.id} title="Coming soon — WalletConnect project ID required"
                  style={{ position: 'relative', background: '#111214', border: '1px solid #2a2b30', borderRadius: 12, padding: '18px 12px 14px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, opacity: 0.48, cursor: 'not-allowed', minHeight: 120, justifyContent: 'center' }}>
                  <span style={{ fontSize: 30 }}>{wc.icon}</span>
                  <div style={{ fontWeight: 700, fontSize: 13, color: '#edeef0' }}>{wc.name}</div>
                  <div style={{ fontSize: 10, color: '#6b6c72', lineHeight: 1.4 }}>{wc.desc}</div>
                  <span style={{ position: 'absolute', top: 8, right: 8, background: '#6789ed33', color: '#6789ed', border: '1px solid #6789ed55', borderRadius: 5, padding: '1px 6px', fontSize: 9, fontWeight: 700, letterSpacing: '0.05em' }}>SOON</span>
                </div>
              );

              /* Regular card wrapper — relative for Phantom sub-picker */
              return (
                <div key={wc.id} data-phantom-picker={wc.id === 'phantom' ? 'true' : undefined} style={{ position: 'relative' }}>
                  <button
                    onClick={() => handleCardClick(wc)}
                    disabled={isLedgerBusy}
                    onMouseEnter={() => setHoveredCard(wc.id)}
                    onMouseLeave={() => setHoveredCard(null)}
                    style={{
                      width: '100%',
                      background: isPhantomOpen ? '#18111f' : '#111214',
                      border: isPhantomOpen
                        ? '1px solid #a855f7'
                        : isHovered && !isLedgerBusy
                          ? isInstalled ? '1px solid #6789ed' : '1px solid #6b6c72'
                          : '1px solid #2a2b30',
                      borderRadius: 12,
                      padding: '18px 12px 14px',
                      color: '#edeef0',
                      cursor: isLedgerBusy ? 'wait' : 'pointer',
                      textAlign: 'center',
                      transition: 'border-color 0.15s, background 0.15s',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: 8,
                      opacity: isLedgerBusy ? 0.65 : isInstalled ? 1 : 0.55,
                      minHeight: 120,
                      justifyContent: 'center',
                    }}>
                    <span style={{ fontSize: 30 }}>{wc.icon}</span>
                    <div style={{ fontWeight: 700, fontSize: 13 }}>{wc.name}</div>
                    <div style={{ fontSize: 10, color: '#6b6c72', lineHeight: 1.4 }}>
                      {isInstalled ? wc.desc : wc.install ? 'Install →' : wc.desc}
                    </div>
                    {/* Installed badge */}
                    {isInstalled && (
                      <span style={{ position: 'absolute', top: 8, right: 8, background: '#22c55e22', color: '#22c55e', border: '1px solid #22c55e44', borderRadius: 5, padding: '1px 6px', fontSize: 9, fontWeight: 700 }}>✓</span>
                    )}
                  </button>

                  {/* Phantom sub-picker dropdown */}
                  {isPhantomOpen && (
                    <div style={{ position: 'absolute', top: 'calc(100% + 6px)', left: 0, right: 0, background: '#1e1124', border: '1px solid #a855f7', borderRadius: 10, padding: 8, zIndex: 50, display: 'flex', flexDirection: 'column', gap: 6 }}>
                      <button onClick={connectPhantomEVM}
                        style={{ background: '#2d1042', border: '1px solid #a855f744', borderRadius: 8, padding: '8px 10px', color: '#edeef0', fontSize: 12, fontWeight: 600, cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span>⟠</span> EVM (Ethereum)
                      </button>
                      <button onClick={connectPhantomSolana}
                        style={{ background: '#2d1042', border: '1px solid #a855f744', borderRadius: 8, padding: '8px 10px', color: '#edeef0', fontSize: 12, fontWeight: 600, cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span>◎</span> Solana
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Divider */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '24px 0 20px' }}>
            <div style={{ flex: 1, height: 1, background: '#2a2b30' }} />
            <span style={{ fontSize: 12, color: '#6b6c72', whiteSpace: 'nowrap' }}>or add address manually</span>
            <div style={{ flex: 1, height: 1, background: '#2a2b30' }} />
          </div>

          {/* Manual form */}
          <form onSubmit={addWallet} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <div>
                <label style={{ fontSize: 12, color: '#6b6c72', display: 'block', marginBottom: 6 }}>Wallet Address *</label>
                <input type="text" value={address} onChange={e => setAddress(e.target.value)} placeholder="0x… or Solana address"
                  style={{ width: '100%', background: '#111214', border: '1px solid #2a2b30', borderRadius: 8, padding: '10px 14px', color: '#edeef0', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
              </div>
              <div>
                <label style={{ fontSize: 12, color: '#6b6c72', display: 'block', marginBottom: 6 }}>Label (optional)</label>
                <input type="text" value={label} onChange={e => setLabel(e.target.value)} placeholder="My DeFi Wallet"
                  style={{ width: '100%', background: '#111214', border: '1px solid #2a2b30', borderRadius: 8, padding: '10px 14px', color: '#edeef0', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
              </div>
            </div>
            <div>
              <label style={{ fontSize: 12, color: '#6b6c72', display: 'block', marginBottom: 8 }}>Network</label>
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                {NETWORKS.map(n => (
                  <button key={n.id} type="button" onClick={() => setNetwork(n.id)}
                    style={{ background: network === n.id ? '#6789ed22' : '#111214', border: network === n.id ? '1px solid #6789ed' : '1px solid #2a2b30', color: network === n.id ? '#6789ed' : '#6b6c72', borderRadius: 8, padding: '8px 16px', fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
                    {n.icon} {n.label}
                  </button>
                ))}
              </div>
            </div>
            {error && (
              <div style={{ background: '#ef444422', border: '1px solid #ef444444', borderRadius: 8, padding: '10px 14px', color: '#ef4444', fontSize: 13 }}>
                ⚠️ {error}
              </div>
            )}
            <button type="submit"
              style={{ background: 'linear-gradient(135deg, #6789ed, #583fdd)', color: '#fff', border: 'none', borderRadius: 10, padding: '12px 24px', fontSize: 14, fontWeight: 700, cursor: 'pointer', alignSelf: 'flex-start' }}>
              ➕ Add Wallet
            </button>
          </form>
        </div>

        {/* ── CONNECTED WALLETS LIST ───────────────────────────────────────── */}
        {wallets.length === 0 ? (
          <div style={{ ...S.card, textAlign: 'center', padding: '48px 24px' }}>
            <div style={{ fontSize: 40, marginBottom: 14 }}>📭</div>
            <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 8 }}>No wallets connected yet</div>
            <div style={{ fontSize: 13, color: '#6b6c72' }}>Connect a wallet above or paste an address manually.</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {wallets.map(w => {
              const bal = balances[w.address];
              const net = NETWORKS.find(n => n.id === w.network);
              const rp  = rocketpoolData[w.address];
              return (
                <div key={w.address} style={{ ...S.card }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ display: 'flex', gap: 16, alignItems: 'center', flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 32 }}>{net?.icon || '👛'}</div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                          <span style={{ fontWeight: 700, fontSize: 15 }}>{w.label}</span>
                          <span style={{ background: '#6789ed22', color: '#6789ed', border: '1px solid #6789ed33', borderRadius: 6, padding: '1px 8px', fontSize: 11, fontWeight: 600 }}>{net?.label || w.network}</span>
                          {rp?.isNode && (
                            <span style={{ background: '#f97316' + '22', color: '#f97316', border: '1px solid #f97316' + '44', borderRadius: 6, padding: '1px 8px', fontSize: 11, fontWeight: 700 }}>
                              🚀 Rocket Pool Node
                            </span>
                          )}
                          {rp && !rp.isNode && !rp.error && rp.hasRpInteraction && (
                            <span style={{ background: '#6789ed22', color: '#6789ed', border: '1px solid #6789ed44', borderRadius: 6, padding: '1px 8px', fontSize: 11, fontWeight: 600 }}>
                              🪙 rETH/RPL holder
                            </span>
                          )}
                          {rp && !rp.isNode && !rp.error && !rp.hasRpInteraction && w.network !== 'solana' && (
                            <span style={{ color: '#6b6c72', fontSize: 11 }} title="Not detected as a Rocket Pool node or rETH holder for this address">Not RP node</span>
                          )}
                          {rp === undefined && w.network !== 'solana' && (
                            <span style={{ color: '#6b6c72', fontSize: 11 }}>⏳ Checking RP...</span>
                          )}
                          {rp?.error && (
                            <span style={{ color: '#ef4444', fontSize: 11 }} title={rp.error}>⚠️ RP check failed</span>
                          )}
                        </div>
                        <div style={{ fontSize: 12, color: '#6b6c72', fontFamily: 'monospace', wordBreak: 'break-all' }}>{w.address}</div>
                        <div style={{ fontSize: 11, color: '#2a2b30', marginTop: 3 }}>Added {new Date(w.addedAt).toLocaleDateString()}</div>
                        {/* Rocket Pool node details */}
                        {rp?.isNode && (() => {
                          const totalMinipoolEth = rp.minipools?.reduce((sum, mp) => sum + (mp.stakedEth || mp.balance || mp.nodeEth || 0), 0) || 0;
                          return (
                            <div style={{ marginTop: 8, background: '#f97316' + '11', border: '1px solid #f97316' + '33', borderRadius: 8, padding: '10px 14px', fontSize: 12, color: '#f97316' }}>
                              <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'center', marginBottom: 8 }}>
                                <span>🔧 {rp.minipools?.length ?? rp.minipoolCount ?? 0} minipool{((rp.minipools?.length ?? rp.minipoolCount ?? 0) !== 1) ? 's' : ''}</span>
                                {totalMinipoolEth > 0 && <span>🔒 {totalMinipoolEth.toFixed(4)} ETH locked</span>}
                                {rp.totalEthRewards > 0 && <span>⟠ {rp.totalEthRewards.toFixed(4)} ETH rewards</span>}
                                {rp.rplStaked > 0 && <span>🔵 {rp.rplStaked.toFixed(2)} RPL staked</span>}
                                {rp.smoothingPool?.optedIn && <span style={{ color: '#8aad8a' }}>🏊 Smoothing pool ✅</span>}
                                <button onClick={() => fetchRocketpoolData(w.address)} style={{ marginLeft: 'auto', background: 'none', border: '1px solid #f9731655', color: '#f97316', borderRadius: 5, padding: '2px 8px', fontSize: 11, cursor: 'pointer' }}>🔄 Refresh</button>
                              </div>
                              {rp.rewards && (
                                <div style={{ borderTop: '1px solid #f9731622', paddingTop: 8, display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
                                  <span style={{ fontWeight: 700, color: '#edeef0' }}>📋 Reward periods:</span>
                                  <span style={{ color: '#8aad8a' }}>✅ {rp.rewards.claimedCount} claimed</span>
                                  {rp.rewards.unclaimedCount > 0 && (
                                    <span style={{ color: '#ef4444', fontWeight: 700 }}>⚠️ {rp.rewards.unclaimedCount} unclaimed</span>
                                  )}
                                  <span style={{ color: '#6b6c72', fontSize: 11 }}>of {rp.rewards.currentPeriod} total</span>
                                  {rp.rewards.unclaimedCount > 0 && (
                                    <a href="https://node.rocketpool.net" target="_blank" rel="noopener noreferrer"
                                      style={{ marginLeft: 'auto', background: '#ef444422', border: '1px solid #ef444455', color: '#ef4444', borderRadius: 5, padding: '3px 10px', fontSize: 11, fontWeight: 700, textDecoration: 'none', cursor: 'pointer' }}>
                                      Claim now →
                                    </a>
                                  )}
                                </div>
                              )}
                            </div>
                          );
                        })()}
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 20, flexShrink: 0, marginLeft: 16 }}>
                      <div style={{ textAlign: 'right' }}>
                        {w.network === 'solana' && bal ? (
                          <>
                            <div style={{ fontSize: 20, fontWeight: 900, color: '#8aad8a' }}>{bal.balanceEth} SOL</div>
                            <div style={{ fontSize: 13, color: '#6b6c72' }}>${bal.balanceUsd?.toLocaleString() || '—'} USD</div>
                            <div style={{ fontSize: 11, color: '#6b6c72' }}>@ ${bal.nativeTokenUsd?.toLocaleString() || '—'}/SOL</div>
                          </>
                        ) : w.network !== 'solana' && bal ? (
                          <>
                            <div style={{ fontSize: 20, fontWeight: 900, color: '#8aad8a' }}>{bal.balanceEth} ETH</div>
                            <div style={{ fontSize: 13, color: '#6b6c72' }}>${bal.balanceUsd?.toLocaleString() || '—'} USD</div>
                            <div style={{ fontSize: 11, color: '#2a2b30' }}>@ ${bal.nativeTokenUsd?.toLocaleString() || '—'}/ETH</div>
                          </>
                        ) : (
                          <div style={{ fontSize: 13, color: '#6b6c72' }}>⏳ Loading...</div>
                        )}
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                        {w.network !== 'solana' && (
                          <button onClick={() => fetchBalance(w.address, w.network)}
                            style={{ background: '#1e3a5f', color: '#6789ed', border: '1px solid #6789ed33', borderRadius: 6, padding: '6px 12px', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
                            🔄
                          </button>
                        )}
                        <button onClick={() => removeWallet(w.address)}
                          style={{ background: '#ef444422', color: '#ef4444', border: '1px solid #ef444433', borderRadius: 6, padding: '6px 12px', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
                          🗑️
                        </button>
                      </div>
                    </div>
                  </div>
                  {/* Chain breakdown — EVM wallets only */}
                  {w.network !== 'solana' && <ChainBreakdown addr={w.address} />}
                </div>
              );
            })}
          </div>
        )}

        {/* INFO */}
        <div style={{ marginTop: 24, background: '#6789ed11', border: '1px solid #6789ed22', borderRadius: 10, padding: '14px 18px', fontSize: 12, color: '#6b6c72', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <span style={{ color: '#6789ed', fontSize: 16 }}>ℹ️</span>
          <div>
            Wallet addresses are stored locally in your browser. EVM balances fetched live via Alchemy across 5 chains. Solana balance tracking coming soon.{' '}
            Wallet data is also visible on the <a href="/tax" style={{ color: '#6789ed' }}>Tax Dashboard →</a>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
