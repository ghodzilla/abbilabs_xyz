'use client';
import { useState, useEffect } from 'react';

const NAV_LINKS = [
  { label: 'Features', href: '#features' },
  { label: 'Pricing', href: '/pricing' },
  { label: 'Tax', href: '/tax' },
  { label: 'Dashboard', href: '/dashboard' },
  { label: 'Wallets', href: '/wallets' },
];

const PROTOCOLS = [
  'Uniswap', 'Aave', 'Curve', 'Compound', 'Lido',
  'Maker', 'Convex', 'Pendle', 'Aerodrome', 'Morpho',
];

const FEATURES = [
  {
    icon: '📊',
    title: 'Real-Time Yield Scanning',
    desc: 'Monitors 200+ pools across 15 chains. Surfaces the highest risk-adjusted yield 24/7.',
  },
  {
    icon: '🧮',
    title: '10-Country Tax Engine',
    desc: 'AU, US, UK, CA, DE, JP, SG, AE, IN, NZ. Auto-classifies trades, tracks holding periods, estimates liability.',
  },
  {
    icon: '🤖',
    title: 'AI Strategy Agent',
    desc: 'Strategy A (capital preservation) vs Strategy B (yield maximisation). Learns from your positions over time.',
  },
  {
    icon: '📈',
    title: 'Correlation Guard',
    desc: 'Detects when stablecoin peg risk spikes before it hits your portfolio.',
  },
  {
    icon: '💸',
    title: 'Gas Cost Modelling',
    desc: 'Factors in gas on every position decision. Profitable moves only.',
  },
  {
    icon: '🔔',
    title: 'Exit Signal Alerts',
    desc: 'Know exactly when and why to reposition. No more guessing.',
  },
];

const HOW_IT_WORKS = [
  {
    num: '01',
    title: 'Connect Your Wallets',
    desc: 'Link your Ethereum, Base, Arbitrum, and Solana wallets. We track everything automatically.',
    color: '#6789ed',
  },
  {
    num: '02',
    title: 'Set Your Strategy',
    desc: 'Capital preservation or yield maximisation? Set your risk profile once.',
    color: '#583fdd',
  },
  {
    num: '03',
    title: 'Watch It Compound',
    desc: 'The agent monitors, repositions, and reports. You check in when you want.',
    color: '#8aad8a',
  },
];

const PRICING = [
  {
    name: 'Explorer',
    price: 'Free',
    features: ['Basic yield tracking', 'Community support'],
    cta: 'Get Started',
    href: '/signup',
    highlight: false,
  },
  {
    name: 'Pro',
    price: '$29/mo',
    features: ['Real wallet connections', 'CSV exports', 'Email alerts'],
    cta: 'Join Waitlist',
    href: '/waitlist',
    highlight: true,
    badge: 'Most Popular',
  },
  {
    name: 'Elite',
    price: '$79/mo',
    features: ['All features', 'PDF tax reports', 'Priority support'],
    cta: 'Join Waitlist',
    href: '/waitlist',
    highlight: false,
  },
];

export default function LandingPage() {
  const [announcementDismissed, setAnnouncementDismissed] = useState(true); // start true, update on mount
  const [emailInput, setEmailInput] = useState('');
  const [emailSubmitted, setEmailSubmitted] = useState(false);

  useEffect(() => {
    try {
      const dismissed = localStorage.getItem('pb_announcement_dismissed') === 'true';
      setAnnouncementDismissed(dismissed);
    } catch (_) {
      setAnnouncementDismissed(false);
    }
  }, []);

  function dismissAnnouncement() {
    try {
      localStorage.setItem('pb_announcement_dismissed', 'true');
    } catch (_) {}
    setAnnouncementDismissed(true);
  }

  function handleNewsletterSubmit(e) {
    e.preventDefault();
    setEmailSubmitted(true);
  }

  const navTop = announcementDismissed ? 0 : 40;

  return (
    <div style={{ background: '#111214', minHeight: '100vh', color: '#edeef0', fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" }}>

      {/* GLOBAL STYLES */}
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .marquee-track {
          display: flex;
          width: max-content;
          animation: marquee 28s linear infinite;
        }
        .feat-card:hover {
          border-color: #6789ed66 !important;
          transform: translateY(-2px);
          transition: border-color 0.2s, transform 0.2s;
        }
        .feat-card {
          transition: border-color 0.2s, transform 0.2s;
        }
        @media (max-width: 768px) {
          .hero-h1 { font-size: 40px !important; }
          .hero-sub { font-size: 16px !important; }
          .hero-btns { flex-direction: column !important; align-items: center !important; }
          .features-grid { grid-template-columns: 1fr !important; }
          .steps-grid { grid-template-columns: 1fr !important; }
          .pricing-grid { grid-template-columns: 1fr !important; }
          .nav-links { display: none !important; }
          .footer-inner { flex-direction: column !important; align-items: flex-start !important; }
        }
      `}</style>

      {/* ANNOUNCEMENT BAR */}
      {!announcementDismissed && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, zIndex: 200,
          height: 40, background: '#583fdd',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 13, fontWeight: 600, color: '#fff',
          padding: '0 16px',
        }}>
          <a href="/waitlist" style={{ color: '#fff', textDecoration: 'none', flexGrow: 1, textAlign: 'center' }}>
            🚀 PassiveBlocks Pro now open — Join the waitlist →
          </a>
          <button
            onClick={dismissAnnouncement}
            style={{
              background: 'transparent', border: 'none', color: '#fff',
              cursor: 'pointer', fontSize: 18, lineHeight: 1,
              padding: '0 4px', opacity: 0.8, flexShrink: 0,
            }}
            aria-label="Dismiss announcement"
          >
            ×
          </button>
        </div>
      )}

      {/* FIXED NAVBAR */}
      <nav style={{
        position: 'fixed', top: navTop, left: 0, right: 0, zIndex: 100,
        backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)',
        background: 'rgba(17,18,20,0.92)',
        borderBottom: '1px solid #2a2b30',
        transition: 'top 0.2s',
      }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
          {/* Logo */}
          <a href="/" style={{ display: 'flex', alignItems: 'center', textDecoration: 'none' }}>
            <img src="/passiveblocks_logo.png" alt="PassiveBlocks" style={{ height: 300, width: 'auto', objectFit: 'contain', filter: 'brightness(0) invert(1)', position: 'relative', zIndex: 20 }} />
          </a>

          {/* Nav links */}
          <div className="nav-links" style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
            {NAV_LINKS.map(l => (
              <a key={l.label} href={l.href} style={{ color: '#6b6c72', textDecoration: 'none', fontSize: 14, fontWeight: 500 }}
                onMouseEnter={e => e.currentTarget.style.color = '#edeef0'}
                onMouseLeave={e => e.currentTarget.style.color = '#6b6c72'}>
                {l.label}
              </a>
            ))}
          </div>

          {/* Auth buttons */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <a href="/login" style={{ color: '#6b6c72', textDecoration: 'none', fontSize: 14, fontWeight: 500 }}
              onMouseEnter={e => e.currentTarget.style.color = '#edeef0'}
              onMouseLeave={e => e.currentTarget.style.color = '#6b6c72'}>
              Log In
            </a>
            <a href="/signup" style={{
              background: 'linear-gradient(135deg, #6789ed, #583fdd)',
              color: '#fff', textDecoration: 'none', borderRadius: 8,
              padding: '8px 18px', fontSize: 14, fontWeight: 600,
            }}>
              Sign Up Free
            </a>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section style={{
        minHeight: '100vh',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: `${(announcementDismissed ? 64 : 104) + 40}px 24px 80px`,
        background: 'radial-gradient(ellipse 70% 45% at 50% 0%, #583fdd18, transparent)',
        flexDirection: 'column',
      }}>
        <div style={{ maxWidth: 1200, width: '100%', display: 'flex', alignItems: 'center', gap: 64, flexWrap: 'wrap', justifyContent: 'center' }}>

          {/* Left: text */}
          <div style={{ flex: '1 1 480px', maxWidth: 600 }}>
            {/* Topline label */}
            <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '0.15em', color: '#583fdd', textTransform: 'uppercase', marginBottom: 20 }}>
              DeFi Yield Intelligence
            </div>

            <h1 className="hero-h1" style={{ fontSize: 64, fontWeight: 900, lineHeight: 1.08, margin: '0 0 24px', letterSpacing: '-0.02em' }}>
              Metrics that matter for your{' '}
              <span style={{ background: 'linear-gradient(135deg, #6789ed, #583fdd)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
                DeFi wealth
              </span>
            </h1>

            <p className="hero-sub" style={{ fontSize: 18, color: '#6b6c72', lineHeight: 1.7, margin: '0 0 36px', maxWidth: 560 }}>
              Track yield positions across 50+ protocols. Optimise for tax. Know when to exit.
            </p>

            <div className="hero-btns" style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginBottom: 24 }}>
              <a href="/signup" style={{
                background: 'linear-gradient(135deg, #6789ed, #583fdd)',
                color: '#fff', textDecoration: 'none', borderRadius: 10,
                padding: '14px 32px', fontSize: 16, fontWeight: 700,
                boxShadow: '0 4px 24px #6789ed33',
              }}>
                Start for Free →
              </a>
              <a href="/dashboard" style={{
                background: 'transparent', color: '#edeef0', textDecoration: 'none',
                borderRadius: 10, padding: '14px 32px', fontSize: 16, fontWeight: 700,
                border: '1px solid #2a2b30',
              }}
                onMouseEnter={e => e.currentTarget.style.borderColor = '#6789ed66'}
                onMouseLeave={e => e.currentTarget.style.borderColor = '#2a2b30'}>
                See the Dashboard
              </a>
            </div>

            <div style={{ fontSize: 13, color: '#6b6c72' }}>
              🔒 Join 2,400+ DeFi investors tracking yield
            </div>
          </div>

          {/* Right: hero card */}
          <div style={{ flex: '0 0 auto' }}>
            <div style={{
              background: '#18191d',
              border: '1px solid #8aad8a55',
              borderLeft: '3px solid #8aad8a',
              borderRadius: 14,
              padding: '24px 28px',
              width: 320,
              boxShadow: '0 8px 40px #8aad8a18, 0 2px 8px #00000055',
              transform: 'translateY(-6px)',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
                <span style={{ fontSize: 14, fontWeight: 700, color: '#edeef0' }}>Strategy A Performance</span>
                <span style={{ fontSize: 16 }}>✅</span>
              </div>

              <div style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 13, color: '#6b6c72', marginBottom: 4 }}>Position</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
                  <span style={{ fontSize: 18, fontWeight: 800, color: '#edeef0' }}>USDZ-SUSDZ</span>
                  <span style={{ fontSize: 20, fontWeight: 900, color: '#8aad8a' }}>32.3% APY</span>
                </div>
              </div>

              <div style={{ display: 'flex', gap: 20, marginBottom: 16 }}>
                <div>
                  <div style={{ fontSize: 11, color: '#6b6c72', marginBottom: 2 }}>7d return</div>
                  <div style={{ fontSize: 15, fontWeight: 700, color: '#8aad8a' }}>+2.1%</div>
                </div>
                <div>
                  <div style={{ fontSize: 11, color: '#6b6c72', marginBottom: 2 }}>Gas cost</div>
                  <div style={{ fontSize: 15, fontWeight: 700, color: '#edeef0' }}>$0.12</div>
                </div>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                  <span style={{ fontSize: 11, color: '#6b6c72' }}>Correlation score</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: '#8aad8a' }}>87%</span>
                </div>
                <div style={{ background: '#2a2b30', borderRadius: 4, height: 8, overflow: 'hidden' }}>
                  <div style={{ background: 'linear-gradient(90deg, #8aad8a, #6789ed)', width: '87%', height: '100%', borderRadius: 4 }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PROTOCOL TICKER */}
      <section style={{ padding: '28px 0', borderTop: '1px solid #2a2b30', borderBottom: '1px solid #2a2b30', overflow: 'hidden', background: '#111214' }}>
        <div style={{ textAlign: 'center', marginBottom: 16 }}>
          <span style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.15em', color: '#6b6c72', textTransform: 'uppercase' }}>
            Tracks positions across
          </span>
        </div>
        <div style={{ overflow: 'hidden', position: 'relative' }}>
          <div className="marquee-track">
            {[...PROTOCOLS, ...PROTOCOLS].map((proto, i) => (
              <div key={i} style={{
                display: 'inline-flex', alignItems: 'center', gap: 8,
                background: '#18191d', border: '1px solid #2a2b30',
                borderRadius: 100, padding: '7px 20px',
                margin: '0 8px', whiteSpace: 'nowrap',
                fontSize: 13, fontWeight: 600, color: '#6b6c72',
                flexShrink: 0,
              }}>
                <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#6789ed', display: 'inline-block' }} />
                {proto}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" style={{ padding: '100px 24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 64 }}>
            <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '0.15em', color: '#583fdd', textTransform: 'uppercase', marginBottom: 14 }}>
              What PassiveBlocks Does
            </div>
            <h2 style={{ fontSize: 42, fontWeight: 800, margin: '0 0 16px', letterSpacing: '-0.02em' }}>
              Yield intelligence. Tax clarity. Wealth compounding.
            </h2>
            <p style={{ fontSize: 16, color: '#6b6c72', maxWidth: 480, margin: '0 auto' }}>
              Built for serious DeFi participants who want data-driven decisions, not guesswork.
            </p>
          </div>

          <div className="features-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
            {FEATURES.map((f, i) => (
              <div key={i} className="feat-card" style={{
                background: '#18191d', border: '1px solid #2a2b30',
                borderRadius: 16, padding: 28, cursor: 'default',
              }}>
                <div style={{ fontSize: 30, marginBottom: 14 }}>{f.icon}</div>
                <h3 style={{ fontSize: 17, fontWeight: 700, margin: '0 0 10px', color: '#edeef0' }}>{f.title}</h3>
                <p style={{ fontSize: 14, color: '#6b6c72', lineHeight: 1.7, margin: 0 }}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section style={{ padding: '100px 24px', background: '#18191d', borderTop: '1px solid #2a2b30', borderBottom: '1px solid #2a2b30' }}>
        <div style={{ maxWidth: 1100, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 64 }}>
            <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '0.15em', color: '#583fdd', textTransform: 'uppercase', marginBottom: 14 }}>
              How It Works
            </div>
            <h2 style={{ fontSize: 42, fontWeight: 800, margin: '0 0 16px', letterSpacing: '-0.02em' }}>
              From setup to yield in 30 minutes
            </h2>
          </div>

          <div className="steps-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 40 }}>
            {HOW_IT_WORKS.map((step, i) => (
              <div key={i} style={{ position: 'relative', textAlign: 'center', padding: '0 12px' }}>
                {/* Connector line */}
                {i < HOW_IT_WORKS.length - 1 && (
                  <div style={{
                    position: 'absolute', top: 28, left: 'calc(50% + 28px)', right: 'calc(-50% + 28px)',
                    height: 1, background: 'linear-gradient(90deg, #2a2b30, transparent)',
                  }} />
                )}
                <div style={{
                  width: 56, height: 56, borderRadius: '50%',
                  background: step.color + '18',
                  border: `2px solid ${step.color}55`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  margin: '0 auto 20px',
                  fontSize: 20, fontWeight: 900, color: step.color,
                }}>
                  {step.num}
                </div>
                <h3 style={{ fontSize: 20, fontWeight: 800, margin: '0 0 12px', color: '#edeef0' }}>{step.title}</h3>
                <p style={{ fontSize: 15, color: '#6b6c72', lineHeight: 1.7, margin: 0 }}>{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING PREVIEW */}
      <section style={{ padding: '100px 24px' }}>
        <div style={{ maxWidth: 960, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 64 }}>
            <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '0.15em', color: '#583fdd', textTransform: 'uppercase', marginBottom: 14 }}>
              Simple Pricing
            </div>
            <h2 style={{ fontSize: 42, fontWeight: 800, margin: '0 0 16px', letterSpacing: '-0.02em' }}>
              Start free. Scale when ready.
            </h2>
          </div>

          <div className="pricing-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
            {PRICING.map((tier, i) => (
              <div key={i} style={{
                background: tier.highlight ? 'linear-gradient(180deg, #1a2240 0%, #18191d 100%)' : '#18191d',
                border: tier.highlight ? '2px solid #6789ed' : '1px solid #2a2b30',
                borderRadius: 16, padding: '32px 24px',
                display: 'flex', flexDirection: 'column',
                position: 'relative',
              }}>
                {tier.badge && (
                  <div style={{
                    position: 'absolute', top: -13, left: '50%', transform: 'translateX(-50%)',
                    background: '#6789ed', color: '#fff', borderRadius: 100,
                    padding: '4px 16px', fontSize: 11, fontWeight: 800,
                    whiteSpace: 'nowrap', letterSpacing: '0.05em',
                  }}>
                    {tier.badge}
                  </div>
                )}

                <div style={{ fontSize: 20, fontWeight: 800, marginBottom: 6 }}>{tier.name}</div>
                <div style={{ marginBottom: 24 }}>
                  <span style={{ fontSize: 32, fontWeight: 900, color: tier.highlight ? '#6789ed' : '#edeef0' }}>
                    {tier.price.replace('/mo', '')}
                  </span>
                  {tier.price.includes('/mo') && (
                    <span style={{ fontSize: 14, color: '#6b6c72' }}>/mo</span>
                  )}
                </div>

                <ul style={{ listStyle: 'none', margin: '0 0 28px', padding: 0, flex: 1 }}>
                  {tier.features.map((f, j) => (
                    <li key={j} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', padding: '8px 0', borderBottom: '1px solid #2a2b3055', fontSize: 14, color: '#6b6c72' }}>
                      <span style={{ color: '#8aad8a', flexShrink: 0, fontWeight: 700 }}>✓</span>
                      {f}
                    </li>
                  ))}
                </ul>

                <a href={tier.href} style={{
                  display: 'block', textAlign: 'center', textDecoration: 'none',
                  background: tier.highlight ? 'linear-gradient(135deg, #6789ed, #583fdd)' : 'transparent',
                  color: tier.highlight ? '#fff' : '#6789ed',
                  border: tier.highlight ? 'none' : '1px solid #6789ed55',
                  borderRadius: 8, padding: '12px 16px',
                  fontSize: 14, fontWeight: 700,
                }}>
                  {tier.cta}
                </a>
              </div>
            ))}
          </div>

          <div style={{ textAlign: 'center', marginTop: 32 }}>
            <a href="/pricing" style={{ color: '#6789ed', fontSize: 14, textDecoration: 'none', fontWeight: 600 }}>
              See full pricing →
            </a>
          </div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section style={{
        padding: '100px 24px',
        background: 'linear-gradient(135deg, #1a1040 0%, #111530 50%, #111214 100%)',
        borderTop: '1px solid #583fdd33',
        textAlign: 'center',
      }}>
        <div style={{ maxWidth: 600, margin: '0 auto' }}>
          <h2 style={{ fontSize: 44, fontWeight: 900, margin: '0 0 16px', letterSpacing: '-0.02em' }}>
            Start tracking your yield today
          </h2>
          <p style={{ fontSize: 17, color: '#6b6c72', margin: '0 0 36px' }}>
            Free forever. No credit card required.
          </p>
          <a href="/signup" style={{
            display: 'inline-block', background: 'linear-gradient(135deg, #6789ed, #583fdd)',
            color: '#fff', textDecoration: 'none', borderRadius: 10,
            padding: '16px 40px', fontSize: 17, fontWeight: 700,
            boxShadow: '0 4px 30px #6789ed44',
          }}>
            Create Free Account →
          </a>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ background: '#18191d', borderTop: '1px solid #2a2b30', padding: '60px 24px 40px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div className="footer-inner" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 40, marginBottom: 48 }}>

            {/* Brand */}
            <div style={{ flex: '0 0 auto' }}>
              <img src="/passiveblocks_logo.png" alt="PassiveBlocks" style={{ height: 400, width: 'auto', objectFit: 'contain', filter: 'brightness(0) invert(1)', marginBottom: 12 }} />
              <p style={{ fontSize: 13, color: '#6b6c72', margin: 0, maxWidth: 220, lineHeight: 1.6 }}>
                Build Wealth Block by Block.<br />DeFi yield intelligence for serious investors.
              </p>
            </div>

            {/* Links */}
            <div style={{ display: 'flex', gap: 48, flexWrap: 'wrap' }}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#6b6c72', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 14 }}>Product</div>
                {[...NAV_LINKS, { label: 'Waitlist', href: '/waitlist' }].map(l => (
                  <div key={l.label} style={{ marginBottom: 10 }}>
                    <a href={l.href} style={{ color: '#6b6c72', textDecoration: 'none', fontSize: 14 }}
                      onMouseEnter={e => e.currentTarget.style.color = '#edeef0'}
                      onMouseLeave={e => e.currentTarget.style.color = '#6b6c72'}>
                      {l.label}
                    </a>
                  </div>
                ))}
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#6b6c72', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 14 }}>Account</div>
                {[{ label: 'Log In', href: '/login' }, { label: 'Sign Up', href: '/signup' }].map(l => (
                  <div key={l.label} style={{ marginBottom: 10 }}>
                    <a href={l.href} style={{ color: '#6b6c72', textDecoration: 'none', fontSize: 14 }}
                      onMouseEnter={e => e.currentTarget.style.color = '#edeef0'}
                      onMouseLeave={e => e.currentTarget.style.color = '#6b6c72'}>
                      {l.label}
                    </a>
                  </div>
                ))}
              </div>
            </div>

            {/* Newsletter */}
            <div style={{ flex: '0 1 280px' }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#6b6c72', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 14 }}>Stay updated</div>
              <p style={{ fontSize: 13, color: '#6b6c72', margin: '0 0 14px', lineHeight: 1.5 }}>Yield insights and product updates. No spam.</p>
              {emailSubmitted ? (
                <div style={{ fontSize: 14, color: '#8aad8a', fontWeight: 600 }}>✅ You're on the list!</div>
              ) : (
                <form onSubmit={handleNewsletterSubmit} style={{ display: 'flex', gap: 8 }}>
                  <input
                    type="email"
                    required
                    value={emailInput}
                    onChange={e => setEmailInput(e.target.value)}
                    placeholder="your@email.com"
                    style={{
                      flex: 1, background: '#111214', border: '1px solid #2a2b30',
                      borderRadius: 8, padding: '9px 14px', fontSize: 13,
                      color: '#edeef0', outline: 'none',
                    }}
                  />
                  <button type="submit" style={{
                    background: 'linear-gradient(135deg, #6789ed, #583fdd)',
                    border: 'none', borderRadius: 8, padding: '9px 16px',
                    fontSize: 13, fontWeight: 700, color: '#fff', cursor: 'pointer',
                    whiteSpace: 'nowrap',
                  }}>
                    Subscribe
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Bottom bar */}
          <div style={{ borderTop: '1px solid #2a2b30', paddingTop: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
            <div style={{ fontSize: 13, color: '#6b6c72' }}>© {new Date().getFullYear()} PassiveBlocks. Build Wealth Block by Block.</div>
            <div style={{ fontSize: 13, color: '#6b6c72' }}>Not financial advice. DeFi involves risk.</div>
          </div>
        </div>
      </footer>
    </div>
  );
}