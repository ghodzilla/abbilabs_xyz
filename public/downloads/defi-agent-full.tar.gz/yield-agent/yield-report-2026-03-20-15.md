# Yield Intelligence Report
**Generated:** 2026-03-20 15:04 UTC
**Simulation Day:** ~1.2 of 7 | **Days Remaining:** ~5.8

---

## 📊 Strategy Standings

### Strategy A — Max APY
| Field | Value |
|-------|-------|
| Starting Capital | $2,500.00 |
| Current Balance | $2,504.54 |
| Total Earned | $4.54 |
| Return | +0.18% |
| Projected APY | **56.1%** |
| Daily Earnings | $1.28 |
| Active Positions | 5/5 |

**Positions:**
1. Base → aerodrome-slipstream → USDZ-SUSDZ | **32.3% APY** | $1.3M TVL
2. Arbitrum → uniswap-v3 → WBTC-WETH | **19.5% APY** | $53.8M TVL
3. Arbitrum → pancakeswap-amm-v3 → WBTC-WETH | **18.1% APY** | $1.4M TVL
4. Ethereum → uniswap-v3 → WBTC-WETH | **11.0% APY** | $47.5M TVL
5. Ethereum → supernova-cl → USDC-USDT | **12.8% APY** | $1.6M TVL

---

### Strategy B — Risk-Adjusted
| Field | Value |
|-------|-------|
| Starting Capital | $2,500.00 |
| Current Balance | $2,503.00 |
| Total Earned | $3.00 |
| Return | +0.12% |
| Projected APY | **37.1%** |
| Daily Earnings | $2.52 |
| Active Positions | 5/5 |

**Positions:**
1. Solana → jupiter-lend → USDS | **5.1% APY** | $28.3M TVL ✅
2. Ethereum → fluid-lending → USDT | **4.3% APY** | $142.2M TVL ✅
3. Solana → orca-dex → SOL-USDC | **62.5% APY** | $29.5M TVL 🔴 CORRELATION BREACH
4. Base → pancakeswap-amm-v3 → WETH-USDC | **70.9% APY** | $2.1M TVL 🔴 CORRELATION BREACH
5. Ethereum → uniswap-v3 → USDC-WETH | **41.1% APY** | $93.6M TVL 🔴 CORRELATION BREACH

---

## 🏆 Current Leader
**Strategy A** leads by **$1.54** | Combined portfolio: **$5,007.54**

---

## 🔗 Correlation Status

| Pair | Strategy | Correlation | Status |
|------|----------|-------------|--------|
| USDZ-SUSDZ | A | Unknown (stablecoin pair) | ⚪ Watchlist |
| WBTC-WETH | A (×3) | 88.99% | ✅ PASS (threshold: 70%) |
| USDC-USDT | A | Peg stable (max 0.046% deviation) | ✅ PASS |
| USDS | B | Single-asset lending | ✅ N/A |
| USDT | B | Single-asset lending | ✅ N/A |
| SOL-USDC | B | **-23.15%** | 🔴 FAIL |
| WETH-USDC | B | **-27.36%** | 🔴 FAIL |
| USDC-WETH | B | **-27.36%** | 🔴 FAIL |

**⚠️ 3 CORRELATION BREACHES in Strategy B** — All Tier 2 volatile pairs are decoupled.
Recommendation: EXIT SOL-USDC, WETH-USDC, USDC-WETH → redeploy to stablecoin lending.

---

## 📈 Market Context (CoinGecko 24h)

| Asset | Price | 24h Change | Alert? |
|-------|-------|-----------|--------|
| BTC | $69,731 | +0.26% | ✅ No |
| ETH | $2,129.52 | +0.18% | ✅ No |
| SOL | $89.05 | +0.86% | ✅ No |

**No assets moved >5% in 24h.** IL risk for Tier 2 volatile pairs is NOT elevated by market moves today. Correlation breaches appear structural (crypto vs stablecoin pairs inherently decoupled).

---

## 🔔 Alert Summary

| Rule | Status |
|------|--------|
| Correlation below threshold | 🔴 **3 BREACHES — ALERT TRIGGERED** |
| Pool APY dropped >50% | ✅ No (insufficient prior data) |
| Stablecoin peg deviation >0.2% | ✅ No (USDC 0.019%, USDT 0.046%) |
| Asset down >10% in 24h | ✅ No |
| Simulation Day 7 reached | ✅ No (Day ~1.2) |

**ALERT REQUIRED: Telegram message to Pritesh re: 3 correlation breaches in Strategy B.**

---

## 📋 Recent Rotations (Strategy B — Last 5)

All 5 recent rotations were triggered by `correlation_breach` — confirming the volatile/stablecoin pairs are persistently decoupled:
- SOL-USDC: corr -24.5%
- USDC-WETH: corr -27.7%
- WETH-USDC: corr -27.7%
- USDC-WETH: corr -41.4%
- USDC-WETH: corr -28.9%

This is a systemic issue, not a one-off breach.

---

## ✅ Recommendations

| Position | Strategy | Action |
|----------|----------|--------|
| USDZ-SUSDZ | A | **HOLD** — stablecoin pair, high APY (32.3%) |
| WBTC-WETH (×3) | A | **HOLD** — correlated at 89%, healthy |
| USDC-USDT | A | **HOLD** — peg stable |
| USDS | B | **HOLD** — single-asset, no IL |
| USDT | B | **HOLD** — single-asset, no IL |
| SOL-USDC | B | **EXIT** → move to stablecoin lending |
| WETH-USDC | B | **EXIT** → move to stablecoin lending |
| USDC-WETH | B | **EXIT** → move to stablecoin lending |

**Overall:** Strategy A performing well — no issues. Strategy B's volatile pairs are persistently breaching correlation thresholds; the high APY (41–71%) does not justify the IL risk given decoupling. Rotating B's 3 flagged positions into stablecoins would reduce projected APY but improve risk-adjusted performance (which is Strategy B's stated mandate).

---

*Next report: 2026-03-20-18 (3-hour cadence) | Simulation completes: ~2026-03-27*
