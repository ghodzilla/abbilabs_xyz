#!/usr/bin/env node
/**
 * ⚠️  DEPRECATED — Standalone correlation checker
 * 
 * As of v2.1, all correlation checks are handled directly inside yield-sim.cjs
 * using LOG-RETURN correlation (not raw-price Pearson as this file uses).
 * 
 * This file is kept for reference/manual spot-checks only.
 * Do NOT use this as an exit signal — it uses outdated v1.0 thresholds
 * and raw-price correlation which inflates during trending markets.
 * 
 * For the current correlation engine, see yield-sim.cjs:
 *   - toLogReturns() + logReturnCorrelation()
 *   - entryCorrelationPass() with v2.2 getEffectiveParam() thresholds
 * 
 * Original description:
 * Fetches 7-day price history via CoinGecko (free, no key)
 * Calculates Pearson correlation coefficient for each active position pair
 * Flags if correlation drops below threshold — exit signal for yield agent
 * 
 * Run: node correlation-checker.cjs
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const STATE_FILE = path.join(__dirname, 'yield-sim-state.json');
const CORR_FILE  = path.join(__dirname, 'correlation-state.json');

// TWO-TIER CORRELATION THRESHOLDS (Pritesh mandate, 2026-03-19)
//
// Tier 1 — Strictly correlated (near-zero IL): correlation must be close to 1
const THRESHOLDS_T1 = {
  lst:    0.98,   // ETH/stETH, SOL/mSOL — near-identical
  btc:    0.97,   // cbBTC/wBTC — very tight peg
  stable: 0.995,  // USDC/USDT — essentially same asset
};
//
// Tier 2 — Conviction holds (Pritesh holds both assets anyway, accepts some IL)
// eg ETH/BTC, SOL/USDC, ETH/SOL — lower threshold, accepts divergence
const THRESHOLDS_T2 = {
  conviction: 0.70, // minimum for conviction pairs — exit if below this
};

// Conviction pairs — both assets Pritesh is happy holding regardless
// Note: include WETH variants explicitly (weth = eth wrapper)
const CONVICTION_PAIRS = [
  ['eth','btc'], ['weth','wbtc'], ['eth','sol'], ['sol','usdc'],
  ['sol','usdt'], ['eth','usdc'], ['eth','usdt'], ['btc','usdc'],
  ['wbtc','usdc'], ['wbtc','usdt'], ['sol','btc'],
  ['weth','usdc'], ['weth','usdt'], ['weth','sol'], ['weth','btc'],  // WETH variants
  ['usdc','weth'], ['usdt','weth'], ['usdc','eth'], ['usdt','eth'],  // reversed order variants
  ['usdc','sol'], ['usdt','sol'], ['usdc','btc'], ['usdt','btc'],
];

// DeFiLlama coin IDs (format: coingecko:{id} or chain:address)
// No API key needed, no rate limits on free usage
const TOKEN_IDS = {
  // ETH family
  'weth': 'coingecko:weth', 'eth': 'coingecko:ethereum',
  'steth': 'coingecko:staked-ether', 'wsteth': 'coingecko:wrapped-steth',
  'cbeth': 'coingecko:coinbase-wrapped-staked-eth', 'reth': 'coingecko:rocket-pool-eth',
  'weeth': 'coingecko:wrapped-eeth', 'ezeth': 'coingecko:renzo-restaked-eth',
  // SOL family
  'sol': 'coingecko:solana', 'wsol': 'coingecko:solana',
  'msol': 'coingecko:msol', 'jitosol': 'coingecko:jito-staked-sol',
  'bsol': 'coingecko:blazestake-staked-sol',
  // BTC family
  'wbtc': 'coingecko:wrapped-bitcoin', 'cbbtc': 'coingecko:coinbase-wrapped-btc',
  'tbtc': 'coingecko:tbtc', 'btc': 'coingecko:bitcoin',
  // Stables (USD-pegged)
  'usdc': 'coingecko:usd-coin', 'usdt': 'coingecko:tether', 'dai': 'coingecko:dai',
  'usde': 'coingecko:ethena-usde', 'crvusd': 'coingecko:crvusd', 'frax': 'coingecko:frax',
  'usds': 'coingecko:usds', 'pyusd': 'coingecko:paypal-usd',
  'lusd': 'coingecko:liquity-usd', 'susd': 'coingecko:nusd',
  'gho': 'coingecko:gho', 'tusd': 'coingecko:true-usd',
};

// USD-pegged stablecoins — use peg deviation check instead of price correlation
// (Pearson correlation is meaningless when both prices hover at exactly $1.000)
const USD_PEG_TOKENS = new Set(['usdc','usdt','dai','usde','crvusd','frax','usds',
  'lusd','susd','usdz','susdz','gho','pyusd','tusd','busd']);
const MAX_PEG_DEVIATION = 0.002; // 0.2% max deviation from $1.00 — exit if exceeded

function detectPairType(sym) {
  const s = sym.toLowerCase();
  if (s.includes('steth') || s.includes('wsteth') || s.includes('cbeth') ||
      s.includes('reth') || s.includes('weeth') || s.includes('msol') ||
      s.includes('jitosol') || s.includes('bsol')) return 'lst';
  if (s.includes('tbtc') || s.includes('cbbtc') || s.includes('wbtc')) return 'btc';
  if ((s.includes('usdc') || s.includes('usdt') || s.includes('dai') || s.includes('usde'))
      && (s.includes('usdc') || s.includes('usdt') || s.includes('dai') || s.includes('usde'))) return 'stable';
  return 'default';
}

function extractTokens(symbol) {
  // Split on common separators
  const parts = symbol.toLowerCase().replace(/[^a-z0-9]/g, '-').split('-').filter(p => p.length > 0);
  return parts.slice(0, 2); // take first two tokens
}

function resolveCoinGeckoId(token) {
  const t = token.toLowerCase().replace(/[^a-z0-9]/g, '');
  return TOKEN_IDS[t] || null;
}

// Fetch 7-day hourly price history via DeFiLlama Coins API
// No API key, no rate limits, supports coingecko:{id} format
function fetchPrice(llamaId, days = 7) {
  return new Promise((resolve, reject) => {
    const start = Math.floor(Date.now() / 1000) - days * 24 * 3600;
    const span = days * 24; // hourly data points
    const encoded = encodeURIComponent(llamaId);
    const url = `/chart/${encoded}?start=${start}&span=${span}&period=1h`;
    https.get({
      hostname: 'coins.llama.fi', path: url,
      headers: { 'User-Agent': 'AbbiLabs-YieldAgent/1.0', 'Accept': 'application/json' }
    }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try {
          const r = JSON.parse(d);
          const coinData = r.coins?.[llamaId];
          if (coinData?.prices && coinData.prices.length > 0) {
            resolve(coinData.prices.map(p => p.price));
          } else {
            reject(new Error(`No price data for ${llamaId}`));
          }
        } catch(e) { reject(e); }
      });
    }).on('error', reject);
  });
}

function pearsonCorr(a, b) {
  const n = Math.min(a.length, b.length);
  if (n < 10) return null; // not enough data
  const ax = a.slice(-n), bx = b.slice(-n);
  const meanA = ax.reduce((s, v) => s + v, 0) / n;
  const meanB = bx.reduce((s, v) => s + v, 0) / n;
  let num = 0, denA = 0, denB = 0;
  for (let i = 0; i < n; i++) {
    const da = ax[i] - meanA, db = bx[i] - meanB;
    num += da * db; denA += da * da; denB += db * db;
  }
  if (denA === 0 || denB === 0) return 1; // identical = perfect correlation
  return num / Math.sqrt(denA * denB);
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// Price cache — avoid duplicate calls for same coin
const priceCache = {};
async function fetchPriceCached(llamaId, days = 7) {
  const key = `${llamaId}_${days}`;
  if (priceCache[key]) return priceCache[key];
  const data = await fetchPrice(llamaId, days);
  priceCache[key] = data;
  return data;
}

async function checkCorrelations() {
  console.log('\n🔍 PAIR CORRELATION CHECKER');
  console.log('═'.repeat(55));
  console.log(`📅 ${new Date().toISOString()}\n`);

  let state;
  try { state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); }
  catch { console.log('⚠️  No sim state found. Run yield-sim.cjs first.'); return; }

  // Collect unique pairs
  const allPositions = [
    ...state.strategyA.positions.map(p => ({ ...p, strat: 'A' })),
    ...state.strategyB.positions.map(p => ({ ...p, strat: 'B' })),
  ];

  const results = [];
  const alerts = [];

  for (const pos of allPositions) {
    if (pos.type === 'lending') {
      results.push({ symbol: pos.symbol, strat: pos.strat, type: 'lending', corr: null, status: '✅', note: 'Single-asset lending — no IL, no correlation needed' });
      continue;
    }

    const tokens = extractTokens(pos.symbol || '');
    if (tokens.length < 2) {
      results.push({ symbol: pos.symbol, strat: pos.strat, type: pos.type, corr: null, status: '⚪', note: 'Cannot parse pair' });
      continue;
    }

    const [t1, t2] = tokens;
    const id1 = resolveCoinGeckoId(t1);
    const id2 = resolveCoinGeckoId(t2);

    if (!id1 || !id2) {
      results.push({ symbol: pos.symbol, strat: pos.strat, type: pos.type, corr: null, status: '⚪', note: `Token IDs unknown (${t1}/${t2}) — adding to watchlist` });
      continue;
    }

    // For stable-stable pairs: use peg deviation check (not Pearson — meaningless at $1.000)
    const bothStable = USD_PEG_TOKENS.has(t1) && USD_PEG_TOKENS.has(t2);
    if (bothStable) {
      console.log(`💵 Checking ${pos.symbol} peg stability (${id1} vs ${id2})...`);
      try {
        const prices1 = await fetchPriceCached(id1, 7);
        const prices2 = await fetchPriceCached(id2, 7);
        const maxDev1 = Math.max(...prices1.map(p => Math.abs(p - 1.0)));
        const maxDev2 = Math.max(...prices2.map(p => Math.abs(p - 1.0)));
        const avgDev1 = prices1.reduce((s,p) => s + Math.abs(p-1.0), 0) / prices1.length;
        const avgDev2 = prices2.reduce((s,p) => s + Math.abs(p-1.0), 0) / prices2.length;
        const worstDev = Math.max(maxDev1, maxDev2);
        const note_detail = `${t1.toUpperCase()} max ${(maxDev1*100).toFixed(3)}% | ${t2.toUpperCase()} max ${(maxDev2*100).toFixed(3)}% from $1.00`;
        let status, note;
        if (worstDev <= MAX_PEG_DEVIATION) {
          status = '✅';
          note = `Peg stable — ${note_detail}`;
        } else if (worstDev <= MAX_PEG_DEVIATION * 2) {
          status = '🟡';
          note = `Peg soft — watch: ${note_detail}`;
        } else {
          status = '🔴';
          note = `PEG DEVIATION ${(worstDev*100).toFixed(3)}% — EXIT: ${note_detail}`;
          alerts.push({ pos, corr: 1 - worstDev, threshold: 1 - MAX_PEG_DEVIATION });
        }
        results.push({ symbol: pos.symbol, strat: pos.strat, type: 'stable', corr: 1 - worstDev, corrPct: `peg±${(worstDev*100).toFixed(3)}%`, status, note });
      } catch (e) {
        results.push({ symbol: pos.symbol, strat: pos.strat, type: 'stable', corr: null, status: '⚪', note: `API error: ${e.message}` });
      }
      continue;
    }

    console.log(`🔗 Checking ${pos.symbol} (${id1} vs ${id2})...`);
    try {
      const prices1 = await fetchPriceCached(id1);
      const prices2 = await fetchPriceCached(id2);
      const corr = pearsonCorr(prices1, prices2);

      const pairType = detectPairType(pos.symbol);
      const corrPct = corr !== null ? (corr * 100).toFixed(2) + '%' : 'N/A';

      // Determine threshold: T1 or T2 (conviction pair)
      const toks = [t1, t2];
      const isConviction = CONVICTION_PAIRS.some(([a, b]) =>
        (toks.includes(a) && toks.includes(b))
      );
      const threshold = isConviction
        ? THRESHOLDS_T2.conviction
        : (THRESHOLDS_T1[pairType] || THRESHOLDS_T1.lst); // default to LST threshold

      let status, note;
      if (corr === null) { status = '⚪'; note = 'Insufficient data'; }
      else if (corr >= threshold) { status = '✅'; note = `Correlated (${corrPct}) — above ${(threshold*100).toFixed(0)}% threshold [${isConviction ? 'T2' : 'T1'}]`; }
      else if (corr >= threshold - 0.03) { status = '🟡'; note = `Weakening (${corrPct}) — watch closely [${isConviction ? 'T2' : 'T1'}]`; }
      else { status = '🔴'; note = `DECOUPLED (${corrPct}) — BELOW threshold! Consider exit. [${isConviction ? 'T2' : 'T1'}]`; alerts.push({ pos, corr, threshold }); }

      results.push({ symbol: pos.symbol, strat: pos.strat, type: pairType, corr, corrPct, status, note });
    } catch (e) {
      console.log(`  ⚠️  Failed: ${e.message}`);
      results.push({ symbol: pos.symbol, strat: pos.strat, type: pos.type, corr: null, status: '⚪', note: `API error: ${e.message}` });
    }
  }

  // Print results
  console.log('\n' + '─'.repeat(80));
  console.log('RESULTS:');
  console.log('─'.repeat(80));
  results.forEach(r => {
    console.log(`${r.status} [Strat ${r.strat}] ${(r.symbol||'').substring(0,20).padEnd(22)} ${r.note}`);
  });

  // Alerts
  if (alerts.length > 0) {
    console.log('\n🚨 CORRELATION ALERTS — REVIEW THESE POSITIONS:');
    alerts.forEach(a => {
      console.log(`   ⛔ ${a.pos.symbol} on ${a.pos.chain}/${a.pos.project}: correlation ${(a.corr*100).toFixed(1)}% below ${(a.threshold*100).toFixed(0)}% threshold`);
      console.log(`      → Recommend: EXIT position, move to stablecoin lending`);
    });
  } else {
    console.log('\n✅ All pairs within correlation thresholds — no action needed.');
  }

  // Save state
  const corrState = {
    checkedAt: new Date().toISOString(),
    results,
    alerts: alerts.map(a => ({ symbol: a.pos.symbol, chain: a.pos.chain, corr: a.corr, threshold: a.threshold })),
  };
  fs.writeFileSync(CORR_FILE, JSON.stringify(corrState, null, 2));
  console.log(`\n💾 Results saved to memory/correlation-state.json\n`);

  return corrState;
}

checkCorrelations().catch(console.error);
