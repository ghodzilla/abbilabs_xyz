#!/usr/bin/env node
/**
 * Notion Agent Skill — Core Script
 * Full CRUD operations on Notion pages, databases, and blocks.
 * Auth: Internal Integration Token.
 *
 * Usage:
 *   node notion.cjs search "<query>" [page|database]
 *   node notion.cjs get-page <pageId>
 *   node notion.cjs get-blocks <blockId>
 *   node notion.cjs create-page <parentPageId> "<title>" "<markdown>"
 *   node notion.cjs create-db-entry <databaseId> '<properties_json>'
 *   node notion.cjs update-page <pageId> '<properties_json>'
 *   node notion.cjs append-blocks <pageId> "<markdown>"
 *   node notion.cjs query-db <databaseId> [filter_json]
 *   node notion.cjs get-db <databaseId>
 *   node notion.cjs archive <pageId>
 */
'use strict';

const https = require('https');

const TOKEN = process.env.NOTION_API_KEY;
if (!TOKEN) {
  console.error(JSON.stringify({ error: 'NOTION_API_KEY environment variable not set' }));
  process.exit(1);
}

const NOTION_VERSION = '2022-06-28';

// ─── HTTP Helper ────────────────────────────────────────────────────────────

function notionApi(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null;
    const opts = {
      method,
      hostname: 'api.notion.com',
      path: `/v1/${path}`,
      headers: {
        Authorization: `Bearer ${TOKEN}`,
        'Notion-Version': NOTION_VERSION,
        'Content-Type': 'application/json',
      },
    };
    if (payload) opts.headers['Content-Length'] = Buffer.byteLength(payload);

    const req = https.request(opts, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString();
        try {
          const data = JSON.parse(raw);
          if (res.statusCode === 429) {
            const retryAfter = parseInt(res.headers['retry-after'] || '2', 10);
            console.error(`Rate limited. Retrying in ${retryAfter}s...`);
            setTimeout(() => notionApi(method, path, body).then(resolve).catch(reject), retryAfter * 1000);
            return;
          }
          resolve(data);
        } catch {
          resolve({ error: 'parse_error', _raw: raw.substring(0, 200), _status: res.statusCode });
        }
      });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function normalizeId(id) {
  return id.replace(/-/g, '');
}

function markdownToBlocks(markdown) {
  const lines = markdown.split('\n');
  const blocks = [];

  for (const line of lines) {
    if (!line.trim()) continue;

    // Headings
    if (line.startsWith('### ')) {
      blocks.push({ object: 'block', type: 'heading_3', heading_3: { rich_text: [{ type: 'text', text: { content: line.slice(4) } }] } });
    } else if (line.startsWith('## ')) {
      blocks.push({ object: 'block', type: 'heading_2', heading_2: { rich_text: [{ type: 'text', text: { content: line.slice(3) } }] } });
    } else if (line.startsWith('# ')) {
      blocks.push({ object: 'block', type: 'heading_1', heading_1: { rich_text: [{ type: 'text', text: { content: line.slice(2) } }] } });
    }
    // Checklist
    else if (line.match(/^- \[x\] /i)) {
      blocks.push({ object: 'block', type: 'to_do', to_do: { rich_text: [{ type: 'text', text: { content: line.slice(6) } }], checked: true } });
    } else if (line.match(/^- \[ \] /)) {
      blocks.push({ object: 'block', type: 'to_do', to_do: { rich_text: [{ type: 'text', text: { content: line.slice(6) } }], checked: false } });
    }
    // Bullet list
    else if (line.startsWith('- ') || line.startsWith('* ')) {
      blocks.push({ object: 'block', type: 'bulleted_list_item', bulleted_list_item: { rich_text: [{ type: 'text', text: { content: line.slice(2) } }] } });
    }
    // Numbered list
    else if (line.match(/^\d+\. /)) {
      blocks.push({ object: 'block', type: 'numbered_list_item', numbered_list_item: { rich_text: [{ type: 'text', text: { content: line.replace(/^\d+\. /, '') } }] } });
    }
    // Divider
    else if (line.match(/^---+$/)) {
      blocks.push({ object: 'block', type: 'divider', divider: {} });
    }
    // Quote
    else if (line.startsWith('> ')) {
      blocks.push({ object: 'block', type: 'quote', quote: { rich_text: [{ type: 'text', text: { content: line.slice(2) } }] } });
    }
    // Paragraph
    else {
      blocks.push({ object: 'block', type: 'paragraph', paragraph: { rich_text: [{ type: 'text', text: { content: line } }] } });
    }
  }
  return blocks;
}

function buildProperties(simpleProps) {
  const props = {};
  for (const [key, val] of Object.entries(simpleProps)) {
    // Handle simple string shorthand: {"title": "My Title"} → title property
    if (typeof val === 'string') {
      if (key === 'title') {
        props[key] = { title: [{ text: { content: val } }] };
      } else {
        props[key] = { rich_text: [{ text: { content: val } }] };
      }
    } else if (val.title !== undefined) {
      props[key] = { title: [{ text: { content: val.title } }] };
    } else if (val.rich_text !== undefined) {
      props[key] = { rich_text: [{ text: { content: val.rich_text } }] };
    } else if (val.number !== undefined) {
      props[key] = { number: val.number };
    } else if (val.select !== undefined) {
      props[key] = { select: { name: val.select } };
    } else if (val.multi_select !== undefined) {
      props[key] = { multi_select: val.multi_select.map(s => ({ name: s })) };
    } else if (val.date !== undefined) {
      props[key] = { date: { start: val.date } };
    } else if (val.checkbox !== undefined) {
      props[key] = { checkbox: val.checkbox };
    } else if (val.email !== undefined) {
      props[key] = { email: val.email };
    } else if (val.url !== undefined) {
      props[key] = { url: val.url };
    } else if (val.status !== undefined) {
      props[key] = { status: { name: val.status } };
    } else if (val.people !== undefined) {
      props[key] = { people: val.people.map(id => ({ id })) };
    } else {
      // Pass through as-is (raw Notion format)
      props[key] = val;
    }
  }
  return props;
}

function extractPageProperties(page) {
  const result = { id: page.id, url: page.url, created: page.created_time, updated: page.last_edited_time };
  if (page.properties) {
    result.properties = {};
    for (const [key, val] of Object.entries(page.properties)) {
      const t = val.type;
      if (t === 'title') result.properties[key] = val.title?.[0]?.plain_text || '';
      else if (t === 'rich_text') result.properties[key] = val.rich_text?.map(r => r.plain_text).join('') || '';
      else if (t === 'number') result.properties[key] = val.number;
      else if (t === 'select') result.properties[key] = val.select?.name || null;
      else if (t === 'multi_select') result.properties[key] = val.multi_select?.map(s => s.name) || [];
      else if (t === 'date') result.properties[key] = val.date?.start || null;
      else if (t === 'checkbox') result.properties[key] = val.checkbox;
      else if (t === 'email') result.properties[key] = val.email;
      else if (t === 'url') result.properties[key] = val.url;
      else if (t === 'status') result.properties[key] = val.status?.name || null;
      else if (t === 'people') result.properties[key] = val.people?.map(p => p.name || p.id) || [];
      else if (t === 'formula') result.properties[key] = val.formula?.[val.formula?.type] || null;
      else if (t === 'rollup') result.properties[key] = val.rollup?.[val.rollup?.type] || null;
      else if (t === 'created_time') result.properties[key] = val.created_time;
      else if (t === 'last_edited_time') result.properties[key] = val.last_edited_time;
      else result.properties[key] = `[${t}]`;
    }
  }
  return result;
}

// ─── Commands ───────────────────────────────────────────────────────────────

async function cmdSearch(query, filter) {
  const body = { query, page_size: 20 };
  if (filter === 'page') body.filter = { value: 'page', property: 'object' };
  if (filter === 'database') body.filter = { value: 'database', property: 'object' };
  const resp = await notionApi('POST', 'search', body);
  if (resp.code) return { error: resp.message, code: resp.code };
  return {
    results: resp.results?.map(r => ({
      id: r.id,
      type: r.object,
      title: r.properties?.title?.title?.[0]?.plain_text || r.properties?.Name?.title?.[0]?.plain_text || r.title?.[0]?.plain_text || '[untitled]',
      url: r.url,
      updated: r.last_edited_time,
    })),
    count: resp.results?.length,
  };
}

async function cmdGetPage(pageId) {
  const resp = await notionApi('GET', `pages/${normalizeId(pageId)}`, null);
  if (resp.code) return { error: resp.message, code: resp.code };
  return extractPageProperties(resp);
}

async function cmdGetBlocks(blockId) {
  const resp = await notionApi('GET', `blocks/${normalizeId(blockId)}/children?page_size=100`, null);
  if (resp.code) return { error: resp.message, code: resp.code };
  return {
    blocks: resp.results?.map(b => {
      const content = b[b.type];
      const text = content?.rich_text?.map(r => r.plain_text).join('') || '';
      return { type: b.type, text, id: b.id, has_children: b.has_children };
    }),
    count: resp.results?.length,
  };
}

async function cmdCreatePage(parentPageId, title, markdown) {
  const children = markdown ? markdownToBlocks(markdown) : [];
  const resp = await notionApi('POST', 'pages', {
    parent: { page_id: normalizeId(parentPageId) },
    properties: { title: { title: [{ text: { content: title } }] } },
    children,
  });
  if (resp.code) return { error: resp.message, code: resp.code };
  return { success: true, id: resp.id, url: resp.url };
}

async function cmdCreateDbEntry(databaseId, propertiesJson) {
  const simpleProps = JSON.parse(propertiesJson);
  const properties = buildProperties(simpleProps);
  const resp = await notionApi('POST', 'pages', {
    parent: { database_id: normalizeId(databaseId) },
    properties,
  });
  if (resp.code) return { error: resp.message, code: resp.code };
  return { success: true, id: resp.id, url: resp.url };
}

async function cmdUpdatePage(pageId, propertiesJson) {
  const simpleProps = JSON.parse(propertiesJson);
  const properties = buildProperties(simpleProps);
  const resp = await notionApi('PATCH', `pages/${normalizeId(pageId)}`, { properties });
  if (resp.code) return { error: resp.message, code: resp.code };
  return { success: true, id: resp.id, url: resp.url };
}

async function cmdAppendBlocks(pageId, markdown) {
  const children = markdownToBlocks(markdown);
  const resp = await notionApi('PATCH', `blocks/${normalizeId(pageId)}/children`, { children });
  if (resp.code) return { error: resp.message, code: resp.code };
  return { success: true, blocksAdded: children.length };
}

async function cmdQueryDb(databaseId, filterJson) {
  const body = { page_size: 100 };
  if (filterJson) {
    const f = JSON.parse(filterJson);
    body.filter = f;
  }
  const resp = await notionApi('POST', `databases/${normalizeId(databaseId)}/query`, body);
  if (resp.code) return { error: resp.message, code: resp.code };
  return {
    results: resp.results?.map(extractPageProperties),
    count: resp.results?.length,
    has_more: resp.has_more,
  };
}

async function cmdGetDb(databaseId) {
  const resp = await notionApi('GET', `databases/${normalizeId(databaseId)}`, null);
  if (resp.code) return { error: resp.message, code: resp.code };
  const properties = {};
  for (const [key, val] of Object.entries(resp.properties || {})) {
    properties[key] = {
      type: val.type,
      ...(val.select ? { options: val.select.options?.map(o => o.name) } : {}),
      ...(val.multi_select ? { options: val.multi_select.options?.map(o => o.name) } : {}),
      ...(val.status ? { options: val.status.options?.map(o => o.name), groups: val.status.groups?.map(g => g.name) } : {}),
    };
  }
  return {
    id: resp.id,
    title: resp.title?.[0]?.plain_text,
    url: resp.url,
    properties,
  };
}

async function cmdArchive(pageId) {
  const resp = await notionApi('PATCH', `pages/${normalizeId(pageId)}`, { archived: true });
  if (resp.code) return { error: resp.message, code: resp.code };
  return { success: true, archived: true };
}

// ─── Main ───────────────────────────────────────────────────────────────────

async function main() {
  const [,, command, ...args] = process.argv;

  if (!command) {
    console.log('Usage: node notion.cjs <command> [args...]');
    console.log('Commands: search, get-page, get-blocks, create-page, create-db-entry, update-page, append-blocks, query-db, get-db, archive');
    process.exit(1);
  }

  let result;
  switch (command) {
    case 'search':
      result = await cmdSearch(args[0], args[1]);
      break;
    case 'get-page':
      result = await cmdGetPage(args[0]);
      break;
    case 'get-blocks':
      result = await cmdGetBlocks(args[0]);
      break;
    case 'create-page':
      result = await cmdCreatePage(args[0], args[1], args.slice(2).join(' '));
      break;
    case 'create-db-entry':
      result = await cmdCreateDbEntry(args[0], args.slice(1).join(' '));
      break;
    case 'update-page':
      result = await cmdUpdatePage(args[0], args.slice(1).join(' '));
      break;
    case 'append-blocks':
      result = await cmdAppendBlocks(args[0], args.slice(1).join(' '));
      break;
    case 'query-db':
      result = await cmdQueryDb(args[0], args[1]);
      break;
    case 'get-db':
      result = await cmdGetDb(args[0]);
      break;
    case 'archive':
      result = await cmdArchive(args[0]);
      break;
    default:
      result = { error: `Unknown command: ${command}` };
  }

  console.log(JSON.stringify(result, null, 2));
}

main().catch(err => {
  console.error(JSON.stringify({ error: err.message }));
  process.exit(1);
});
