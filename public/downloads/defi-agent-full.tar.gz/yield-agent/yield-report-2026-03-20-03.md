# Yield Intelligence Report — 2026-03-20 03:00 UTC

**Generated:** 2026-03-20T03:04 UTC
**Simulation Day:** 0.7 / 7 (6 cycles elapsed)
**Days Remaining:** ~6.3

---

## 1. Strategy Balances & Earnings

| Metric | Strategy A (Max APY) | Strategy B (Risk-Adjusted) |
|---|---|---|
| Starting Capital | $2,500.00 | $2,500.00 |
| Current Balance | $2,503.04 | $2,501.84 |
| Total Earned | $3.04 | $1.84 |
| Return | +0.12% | +0.07% |
| Projected APY | 65.1% | 39.4% |
| Daily Earnings (est.) | $4.64/day | $2.76/day |

**Combined Portfolio:** $5,004.88
**Strategy A Lead:** +$1.20

### Strategy A — Top Positions (Max APY)
1. Base | Uniswap-v4 | ETH-USDC | 74.3% APY | $1.6M TVL
2. Solana | Orca DEX | SOL-USDC | 71.6% APY | $29.5M TVL
3. Base | PancakeSwap AMM v3 | WETH-USDC | 68.4% APY | $2.1M TVL
4. Arbitrum | Beefy | WBTC-USDC | 62.3% APY | $1.1M TVL
5. Base | PancakeSwap AMM v3 | WETH-USDC | 62.3% APY | $4.7M TVL

### Strategy B — Top Positions (Risk-Adjusted)
1. Solana | Jupiter Lend | USDS | 5.1% APY | $28.3M TVL ✅ Single-asset, no IL
2. Ethereum | Fluid Lending | USDT | 4.5% APY | $141.4M TVL ✅ Single-asset, no IL
3. Solana | Orca DEX | SOL-USDC | 71.6% APY | $29.5M TVL
4. Ethereum | Uniswap-v3 | USDC-WETH | 45.8% APY | $93.4M TVL
5. Base | Uniswap-v4 | ETH-USDC | 74.3% APY | $1.6M TVL

---

## 2. APY Changes vs Last Report

- Strategy A projected APY: 65.1% (no prior checkpoint for comparison — first 03:xx report)
- Key note: ETH-USDC (Base/Uniswap-v4) has **apyPct1D: +4.47%** (rising short-term) but **apyPct7D: -5.75%** (moderate weekly drift)
- SOL-USDC (Orca): **apyPct1D: -0.52%**, **apyPct7D: -13.64%** — notable 7-day decline, monitor for continued erosion
- No APY drop >50% detected — no alert triggered

---

## 3. Correlation Check

**Status:** ⚠️ API Rate-Limited (CoinGecko 429 on all pair checks)

| Pair | Strategy | Type | Status |
|---|---|---|---|
| ETH-USDC | A | LP | ⚪ API error (THRESHOLDS not defined — script bug) |
| SOL-USDC | A | LP | ⚪ API error |
| WETH-USDC | A | LP | ⚪ API error (rate limit) |
| WBTC-USDC | A | LP | ⚪ API error (rate limit) |
| WETH-USDC | A | LP | ⚪ API error (rate limit) |
| USDS | B | Lending | ✅ PASS — single-asset, no IL/correlation |
| USDT | B | Lending | ✅ PASS — single-asset, no IL/correlation |
| SOL-USDC | B | LP | ⚪ API error (rate limit) |
| USDC-WETH | B | LP | ⚪ API error (rate limit) |
| ETH-USDC | B | LP | ⚪ API error (rate limit) |

**Note:** CoinGecko rate-limited this run. No correlation alerts triggered. `correlation-checker.cjs` also has a `THRESHOLDS is not defined` bug affecting first 3 pairs — script needs a fix.

---

## 4. Market Context — Price Movements (CryptoCompare)

| Asset | Price | 24h Change |
|---|---|---|
| ETH | $2,146.50 | **-2.98%** |
| BTC | $70,447.40 | **-1.08%** |
| SOL | $89.31 | **-1.59%** |

**Assessment:**
- No asset moved >5% in 24h — no IL risk flag triggered
- No asset down >10% — no Telegram alert required
- Mild broad market pullback; all LP pairs (ETH, SOL, WBTC vs stablecoins) have modest divergence risk but within normal operating range
- Stablecoin lending positions (Strategy B: USDS, USDT) are **unaffected** — no IL exposure

---

## 5. Alert Status

| Alert Condition | Status |
|---|---|
| Correlation below threshold | ⚪ Unable to check (API rate limit) |
| Pool APY dropped >50% | ✅ Clear |
| Stablecoin peg deviation >0.2% | ✅ Clear (no peg data anomaly) |
| Any asset down >10% in 24h | ✅ Clear (max: ETH -2.98%) |
| Simulation day 7 reached | ✅ Clear — Day 0.7 only |

**No Telegram alert required this cycle.**

---

## 6. Recommendation

**HOLD — no action needed.**

- Both strategies performing as expected at this early stage (Day 0.7)
- Strategy A is outperforming by $1.20 and projecting 65.1% APY vs 39.4% for B — consistent with higher-risk positioning
- SOL-USDC's 7-day APY drift (-13.64%) warrants monitoring; if it continues declining over next 2 days, consider whether B should swap this position
- Market is mildly bearish but far from alert territory
- Fix needed: `correlation-checker.cjs` has `THRESHOLDS is not defined` bug — correlation data will be unreliable until resolved

---

## 7. Script Health

| Script | Status |
|---|---|
| yield-sim.cjs | ✅ OK — state pushed to GitHub |
| correlation-checker.cjs | ⚠️ Bug: `THRESHOLDS is not defined` on first 3 pairs; also rate-limited by CoinGecko |
| CoinGecko API | ⚠️ 429 Rate Limited — fell back to CryptoCompare for price data |

---

*Next report: yield-report-2026-03-20-06.md (06:00 UTC)*
