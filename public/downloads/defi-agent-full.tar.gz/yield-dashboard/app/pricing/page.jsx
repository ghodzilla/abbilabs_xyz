'use client';

const NAV_LINKS = [
  { label: 'Features', href: '/#features' },
  { label: 'Pricing', href: '/pricing' },
  { label: 'Tax', href: '/tax' },
  { label: 'Dashboard', href: '/dashboard' },
  { label: 'Wallets', href: '/wallets' },
];

const TIERS = [
  {
    name: 'Explorer',
    price: 'Free',
    model: 'SaaS',
    highlight: false,
    color: '#6b6c72',
    features: [
      'Virtual capital simulation',
      'A/B strategy testing (live DeFiLlama data)',
      'Live yield scanner (1,000+ pools)',
      'Tax preview — 10 countries',
      'Portfolio balance chart',
      'Position classification engine',
      'Community Discord access',
    ],
    cta: 'Start Free',
    href: '/dashboard',
  },
  {
    name: 'Pro',
    price: '$29',
    model: 'SaaS',
    highlight: true,
    badge: 'MOST POPULAR',
    color: '#6789ed',
    features: [
      'Everything in Explorer',
      'Real wallet connections (up to 5)',
      'Transaction import & FIFO cost basis',
      'CSV tax report export',
      'Portfolio tracker with P&L',
      'Email alerts for APY changes',
      'Priority support',
    ],
    cta: 'Join Waitlist',
    href: '/waitlist',
  },
  {
    name: 'Elite',
    price: '$79',
    model: 'SaaS',
    highlight: false,
    color: '#583fdd',
    features: [
      'Everything in Pro',
      'Unlimited wallet connections',
      'All cost basis methods (FIFO, LIFO, HIFO, ACB)',
      'Tax-loss harvesting engine',
      'Holding period alerts',
      'PDF reports: Form 8949, ATO myTax, HMRC SA100',
      'Advanced analytics & projections',
    ],
    cta: 'Join Waitlist',
    href: '/waitlist',
  },
  {
    name: 'Node Pro',
    price: '$149',
    model: 'Self-hosted',
    highlight: false,
    color: '#ff9317',
    features: [
      'Everything in Elite',
      'Intelligence feed (pool signal API)',
      'Full REST API access',
      'All data on your own machine',
      'Docker deploy kit included',
      'No data sent to PassiveBlocks servers',
      'Community + GitHub access',
    ],
    cta: 'Join Waitlist',
    href: '/waitlist',
  },
  {
    name: 'Node Whale',
    price: '$299',
    model: 'Self-hosted',
    highlight: false,
    color: '#8aad8a',
    features: [
      'Everything in Node Pro',
      'White-label dashboard',
      'Multi-portfolio management',
      'DAO treasury mode',
      'Custom strategy rules engine',
      'Dedicated onboarding call',
      'SLA-backed uptime guarantee',
    ],
    cta: 'Join Waitlist',
    href: '/waitlist',
  },
];

const FAQS = [
  {
    q: 'Is my wallet safe? Do you need my private keys?',
    a: 'Never. PassiveBlocks uses read-only wallet connections via public address lookup only. We never ask for private keys, seed phrases, or signing permissions. Your funds stay entirely in your control.',
  },
  {
    q: 'Can I start without connecting a wallet?',
    a: 'Yes — the Explorer tier is fully functional with simulated/virtual capital. You can run real A/B strategy tests and see live yields from DeFiLlama without ever connecting a wallet or entering a credit card.',
  },
  {
    q: 'Which countries are supported for tax reporting?',
    a: 'Australia (ATO CGT), United States (IRS Form 8949), United Kingdom (HMRC SA100), Canada (CRA ACB), Germany (BZSt), Japan, Singapore, UAE, India, and New Zealand. Each jurisdiction applies the correct CGT discount, exemption threshold, and income classification rules.',
  },
  {
    q: 'What\'s the difference between SaaS and Self-hosted?',
    a: 'SaaS tiers (Explorer, Pro, Elite) run on PassiveBlocks infrastructure — nothing to install, just sign in. Self-hosted tiers (Node Pro, Node Whale) give you a Docker image that runs entirely on your own server. Your wallet data, transaction history, and tax calculations never leave your machine.',
  },
  {
    q: 'Can I export my tax data for TurboTax, Koinly, or my accountant?',
    a: 'Pro and above export CSV files compatible with most crypto tax platforms and accountant workflows. Elite and above generate jurisdiction-specific PDF reports (Form 8949 for US, ATO pre-fill for AU, HMRC SA supplementary pages for UK) that can be lodged directly or handed to your accountant.',
  },
];

export default function PricingPage() {
  return (
    <div style={{ background: '#111214', minHeight: '100vh', color: '#edeef0', fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" }}>

      {/* NAVBAR */}
      <nav style={{ position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100, backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', background: 'rgba(17,18,20,0.85)', borderBottom: '1px solid #2a2b30' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
          <a href="/" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
            <img src="/passiveblocks_logo.png" alt="PassiveBlocks" style={{ height: 44, width: 'auto', objectFit: 'contain', filter: 'brightness(0) invert(1)' }} />
          </a>
          <div style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
            {NAV_LINKS.map(l => (
              <a key={l.label} href={l.href} style={{ color: l.label === 'Pricing' ? '#edeef0' : '#6b6c72', textDecoration: 'none', fontSize: 14, fontWeight: 500 }}>
                {l.label}
              </a>
            ))}
            <a href="/login" style={{ color: '#6b6c72', textDecoration: 'none', fontSize: 14, fontWeight: 500 }}>
              Log In
            </a>
            <a href="/signup" style={{ background: 'linear-gradient(135deg, #6789ed, #583fdd)', color: '#fff', textDecoration: 'none', borderRadius: 8, padding: '8px 18px', fontSize: 14, fontWeight: 600 }}>
              Sign Up Free
            </a>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section style={{ paddingTop: 140, paddingBottom: 60, textAlign: 'center', padding: '140px 24px 60px' }}>
        <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.1em', color: '#8aad8a', textTransform: 'uppercase', marginBottom: 12 }}>PRICING</div>
        <h1 style={{ fontSize: 52, fontWeight: 900, margin: '0 0 16px' }}>Simple, transparent pricing</h1>
        <p style={{ fontSize: 18, color: '#6b6c72', maxWidth: 500, margin: '0 auto' }}>Start free. Upgrade when you're ready to deploy real capital or need real tax reports.</p>
      </section>

      {/* PRICING TABLE */}
      <section style={{ padding: '0 24px 80px', maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 16 }}>
          {TIERS.map((tier, i) => (
            <div key={i} style={{
              background: tier.highlight ? 'linear-gradient(180deg, #1e2a4a, #18191d)' : '#18191d',
              border: tier.highlight ? `2px solid ${tier.color}` : '1px solid #2a2b30',
              borderRadius: 16,
              padding: '28px 20px',
              display: 'flex',
              flexDirection: 'column',
              position: 'relative',
            }}>
              {tier.badge && (
                <div style={{ position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)', background: tier.color, color: '#fff', borderRadius: 20, padding: '3px 14px', fontSize: 10, fontWeight: 800, whiteSpace: 'nowrap', letterSpacing: '0.05em' }}>
                  {tier.badge}
                </div>
              )}
              <div style={{ marginBottom: 4 }}>
                <span style={{ fontSize: 11, fontWeight: 700, background: tier.color + '22', color: tier.color, borderRadius: 6, padding: '2px 8px' }}>{tier.model}</span>
              </div>
              <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 4, marginTop: 12 }}>{tier.name}</div>
              <div style={{ marginBottom: 8 }}>
                <span style={{ fontSize: 36, fontWeight: 900, color: tier.highlight ? tier.color : '#edeef0' }}>{tier.price}</span>
                {tier.price !== 'Free' && <span style={{ fontSize: 14, color: '#6b6c72' }}>/mo</span>}
              </div>
              <div style={{ fontSize: 12, color: '#6b6c72', marginBottom: 20, paddingBottom: 16, borderBottom: '1px solid #2a2b30' }}>billed monthly</div>
              <ul style={{ listStyle: 'none', margin: '0 0 24px', padding: 0, flex: 1 }}>
                {tier.features.map((f, j) => (
                  <li key={j} style={{ fontSize: 13, color: '#6b6c72', padding: '7px 0', display: 'flex', alignItems: 'flex-start', gap: 8, borderBottom: '1px solid #2a2b3044' }}>
                    <span style={{ color: tier.color, flexShrink: 0 }}>✓</span> {f}
                  </li>
                ))}
              </ul>
              <a href={tier.href} style={{
                display: 'block',
                textAlign: 'center',
                background: tier.highlight ? `linear-gradient(135deg, ${tier.color}, #583fdd)` : 'transparent',
                color: tier.highlight ? '#fff' : tier.color,
                border: tier.highlight ? 'none' : `1px solid ${tier.color}44`,
                borderRadius: 8,
                padding: '12px',
                fontSize: 14,
                fontWeight: 700,
                textDecoration: 'none',
              }}>
                {tier.cta}
              </a>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section style={{ padding: '60px 24px 100px', maxWidth: 760, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 56 }}>
          <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.1em', color: '#6789ed', textTransform: 'uppercase', marginBottom: 12 }}>FAQ</div>
          <h2 style={{ fontSize: 38, fontWeight: 800, margin: 0 }}>Common questions</h2>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          {FAQS.map((faq, i) => (
            <div key={i} style={{ background: '#18191d', border: '1px solid #2a2b30', borderRadius: 12, padding: '24px 28px' }}>
              <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 12, color: '#edeef0' }}>{faq.q}</div>
              <div style={{ fontSize: 14, color: '#6b6c72', lineHeight: 1.8 }}>{faq.a}</div>
            </div>
          ))}
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ background: '#18191d', borderTop: '1px solid #2a2b30', padding: '48px 24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <img src="/passiveblocks_logo.png" alt="PassiveBlocks" style={{ height: 320, width: 'auto', objectFit: 'contain', filter: 'brightness(0) invert(1)' }} />
          </div>
          <div style={{ fontSize: 13, color: '#6b6c72' }}>© {new Date().getFullYear()} PassiveBlocks. Build Wealth Block by Block.</div>
          <div style={{ display: 'flex', gap: 24 }}>
            {[...NAV_LINKS, { label: 'Waitlist', href: '/waitlist' }].map(l => (
              <a key={l.label} href={l.href} style={{ color: '#6b6c72', textDecoration: 'none', fontSize: 13 }}>{l.label}</a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
