'use client';
import { useEffect, useState } from 'react';

/**
 * ModeToggle — Simulation vs Advisory mode switch
 * Persists to localStorage key `pb_mode`
 * Accepts optional `mode` + `onChange` props for controlled usage,
 * or operates standalone (reads/writes localStorage itself).
 */
export default function ModeToggle({ mode: controlledMode, onChange }) {
  const [mode, setMode] = useState('simulation');

  useEffect(() => {
    try {
      const saved = localStorage.getItem('pb_mode');
      if (saved === 'advisory' || saved === 'simulation') {
        setMode(saved);
        if (onChange) onChange(saved);
      }
    } catch (_) {}
  }, []);

  // Keep internal state in sync if parent controls it
  useEffect(() => {
    if (controlledMode && controlledMode !== mode) setMode(controlledMode);
  }, [controlledMode]);

  function toggle(next) {
    setMode(next);
    try { localStorage.setItem('pb_mode', next); } catch (_) {}
    if (onChange) onChange(next);
  }

  const isSimulation = mode === 'simulation';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
      {/* Toggle pill */}
      <div style={{
        display: 'inline-flex',
        background: '#18191d',
        border: '1px solid #2a2b30',
        borderRadius: 12,
        padding: 4,
        gap: 4,
      }}>
        {/* Simulation button */}
        <button
          onClick={() => toggle('simulation')}
          style={{
            display: 'flex', alignItems: 'center', gap: 7,
            background: isSimulation ? '#6789ed' : '#2a2b30',
            color: isSimulation ? '#fff' : '#6b7280',
            border: 'none', borderRadius: 8,
            padding: '8px 18px',
            fontSize: 14, fontWeight: 700,
            cursor: 'pointer',
            transition: 'background 0.18s, color 0.18s',
          }}
        >
          <span>🔬</span>
          <span>Simulation</span>
        </button>

        {/* Live (Advisory) button */}
        <button
          onClick={() => toggle('advisory')}
          style={{
            display: 'flex', alignItems: 'center', gap: 7,
            background: !isSimulation ? '#6789ed' : '#2a2b30',
            color: !isSimulation ? '#fff' : '#6b7280',
            border: 'none', borderRadius: 8,
            padding: '8px 18px',
            fontSize: 14, fontWeight: 700,
            cursor: 'pointer',
            transition: 'background 0.18s, color 0.18s',
          }}
        >
          <span>💼</span>
          <span>Live (Advisory)</span>
        </button>
      </div>

      {/* Badge */}
      <div style={{
        fontSize: 11, fontWeight: 700,
        color: isSimulation ? '#8aad8a' : '#ff9317',
        background: isSimulation ? '#8aad8a18' : '#ff931718',
        border: `1px solid ${isSimulation ? '#8aad8a44' : '#ff931744'}`,
        borderRadius: 100,
        padding: '3px 12px',
        letterSpacing: '0.04em',
      }}>
        {isSimulation ? '💚 Virtual $5,000' : '🟠 Real Wallets'}
      </div>
    </div>
  );
}
