# Yield Intelligence Report — 2026-03-20 06:00 UTC

**Generated:** 2026-03-20T06:04 UTC
**Simulation Day:** ~0.8 / 7 (7 cycles elapsed)
**Days Remaining:** ~6.2

---

## 1. Strategy Balances & Earnings

| Metric | Strategy A (Max APY) | Strategy B (Risk-Adjusted) |
|---|---|---|
| Starting Capital | $2,500.00 | $2,500.00 |
| Current Balance | $2,503.62 | $2,502.18 |
| Total Earned | $3.62 | $2.18 |
| Return | +0.14% | +0.09% |
| Projected APY | 65.5% | 39.5% |
| Daily Earnings (est.) | $4.42/day | $2.54/day |

**Combined Portfolio:** $5,005.80
**Strategy A Lead:** +$1.44

### Strategy A — Top Positions (Max APY)
1. Base | Uniswap-v4 | ETH-USDC | 70.2% APY | $1.6M TVL
2. Solana | Orca DEX | SOL-USDC | 68.5% APY | $29.5M TVL
3. Base | PancakeSwap AMM v3 | WETH-USDC | 67.0% APY | $2.1M TVL
4. Base | PancakeSwap AMM v3 | WETH-USDC | 60.2% APY | $4.7M TVL
5. Ethereum | Uniswap-v4 | WBTC-USDC | 57.0% APY | $8.4M TVL

### Strategy B — Top Positions (Risk-Adjusted)
1. Solana | Jupiter Lend | USDS | 5.1% APY | $28.3M TVL ✅ Single-asset, no IL
2. Ethereum | Fluid Lending | USDT | 4.4% APY | $142.2M TVL ✅ Single-asset, no IL
3. Solana | Orca DEX | SOL-USDC | 68.5% APY | $29.5M TVL
4. Ethereum | Uniswap-v3 | USDC-WETH | 50.5% APY | $93.4M TVL
5. Ethereum | Uniswap-v4 | WBTC-USDC | 57.0% APY | $8.4M TVL

---

## 2. APY Changes vs Last Report (03:00 UTC)

| Position | APY @ 03:00 | APY @ 06:00 | Δ | Alert? |
|---|---|---|---|---|
| ETH-USDC (Base/Uni-v4) | 74.3% | 70.2% | -4.1% | ❌ No (< 10%) |
| SOL-USDC (Orca) | 71.6% | 68.5% | -3.1% | ❌ No |
| WETH-USDC (PCS AMM v3) | 68.4% | 67.0% | -1.4% | ❌ No |
| WBTC-USDC (Uni-v4) | N/A | 57.0% | — | New in rotation |
| USDS (Jupiter Lend) | 5.1% | 5.1% | 0% | ✅ Stable |
| USDT (Fluid) | 4.5% | 4.4% | -0.1% | ✅ Stable |
| USDC-WETH (Uni-v3) | 45.8% | 50.5% | +4.7% | ❌ No |

**No APY drop >50% detected — no alert triggered.**
Note: ETH-USDC and SOL-USDC showing modest downward APY drift across this cycle. Still elevated; no action required.

---

## 3. Correlation Check

**Status:** ⚠️ API Rate-Limited (CoinGecko 429 — persistent across all cycles today)
**Script bug persists:** `THRESHOLDS is not defined` error affecting first 3 pairs in correlation-checker.cjs

| Pair | Strategy | Type | Status |
|---|---|---|---|
| ETH-USDC | A | LP | ⚪ API error (script bug + rate limit) |
| SOL-USDC | A | LP | ⚪ API error (rate limit) |
| WETH-USDC | A | LP | ⚪ API error (rate limit) |
| WBTC-USDC | A | LP | ⚪ API error (rate limit) |
| USDS | B | Lending | ✅ PASS — single-asset, no IL/correlation |
| USDT | B | Lending | ✅ PASS — single-asset, no IL/correlation |
| SOL-USDC | B | LP | ⚪ API error (rate limit) |
| USDC-WETH | B | LP | ⚪ API error (rate limit) |
| WBTC-USDC | B | LP | ⚪ API error (rate limit) |

**No below-threshold correlation triggered. No Telegram alert required.**
⚠️ Ongoing issue: `correlation-checker.cjs` has a `THRESHOLDS is not defined` bug. Recommend fix before Day 3.

---

## 4. Market Context — Price Movements (CryptoCompare fallback)

| Asset | Price | 24h Change | IL Risk Flag? |
|---|---|---|---|
| ETH | $2,139.87 | -1.87% | ❌ No |
| BTC | $70,594.66 | +0.01% | ❌ No |
| SOL | $89.25 | -0.70% | ❌ No |

**Assessment:**
- No asset moved >5% in 24h — no IL risk flag triggered
- No asset down >10% — no Telegram alert required
- Market broadly flat-to-mildly-negative on ETH; BTC/SOL essentially unchanged
- Stablecoin lending positions (USDS, USDT) unaffected
- All LP pairs (ETH/SOL/WBTC vs stablecoins) within normal operating range

*Note: CoinGecko 429 rate-limited; using CryptoCompare as fallback for price data.*

---

## 5. Alert Status

| Alert Condition | Status |
|---|---|
| Correlation below threshold | ⚪ Unable to check (API rate limit + script bug) |
| Pool APY dropped >50% | ✅ Clear |
| Stablecoin peg deviation >0.2% | ✅ Clear |
| Any asset down >10% in 24h | ✅ Clear (max: ETH -1.87%) |
| Simulation day 7 reached | ✅ Clear — Day ~0.8 |

**No Telegram alert required this cycle.**

---

## 6. Recommendation

**HOLD — no action needed.**

- Both strategies performing as expected at Day ~0.8
- Strategy A leads by $1.44; projecting 65.5% APY vs 39.5% for B — gap consistent with higher-risk allocation
- Mild APY compression on ETH-USDC and SOL-USDC (key Strat A positions) — watch over next 2 cycles
- USDC-WETH (Strat B) ticked up +4.7% APY — positive for risk-adjusted strategy
- No market conditions warrant rebalancing or exit
- **Action needed on scripts:** Fix `THRESHOLDS is not defined` bug in correlation-checker.cjs before Day 3 to restore full correlation monitoring

---

## 7. Script Health

| Script | Status |
|---|---|
| yield-sim.cjs | ✅ OK — state pushed to GitHub |
| correlation-checker.cjs | ⚠️ Bug: `THRESHOLDS is not defined` on first 3 pairs; all pairs rate-limited by CoinGecko |
| CoinGecko API | ⚠️ 429 Rate Limited (persistent) — using CryptoCompare fallback |

---

*Next report: yield-report-2026-03-20-09.md (09:00 UTC)*
