#!/usr/bin/env node
// AI Sales Agent — Lead Scoring Engine v3
// Scores HubSpot contacts against configurable rules
// v3 features: engagement scoring (page views, form submissions), score writeback to HubSpot
// v2 features: score breakdown formatting, time-based decay, negative signals
//
// Usage:
//   node lead-scorer.cjs score --contact CONTACT_ID
//   node lead-scorer.cjs score-all --since TIMESTAMP
//   node lead-scorer.cjs --test

'use strict';

const fs = require('fs');
const https = require('https');
const path = require('path');

const configPath = path.join(__dirname, '..', 'config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

const HUBSPOT_TOKEN = process.env.HUBSPOT_ACCESS_TOKEN;
// Token check deferred — only required for API calls, not --test mode

function hubspotGet(endpoint) {
  if (!HUBSPOT_TOKEN) return Promise.reject(new Error('HUBSPOT_ACCESS_TOKEN not set'));
  return new Promise((resolve, reject) => {
    const url = `https://api.hubapi.com${endpoint}`;
    https.get(url, { headers: { 'Authorization': `Bearer ${HUBSPOT_TOKEN}` } }, res => {
      let d = ''; res.on('data', c => d += c);
      res.on('end', () => res.statusCode >= 400 ? reject(new Error(`${res.statusCode}: ${d}`)) : resolve(JSON.parse(d)));
    }).on('error', reject);
  });
}

function hubspotRequest(method, endpoint, body) {
  if (!HUBSPOT_TOKEN) return Promise.reject(new Error('HUBSPOT_ACCESS_TOKEN not set'));
  return new Promise((resolve, reject) => {
    const url = `https://api.hubapi.com${endpoint}`;
    const payload = body ? JSON.stringify(body) : null;
    const opts = {
      method,
      hostname: 'api.hubapi.com',
      path: endpoint,
      headers: {
        'Authorization': `Bearer ${HUBSPOT_TOKEN}`,
        'Content-Type': 'application/json',
      },
    };
    if (payload) opts.headers['Content-Length'] = Buffer.byteLength(payload);
    const req = https.request(opts, res => {
      let d = ''; res.on('data', c => d += c);
      res.on('end', () => {
        if (res.statusCode === 204 || !d.trim()) return resolve({});
        if (res.statusCode >= 400) return reject(new Error(`${res.statusCode}: ${d.substring(0, 300)}`));
        try { resolve(JSON.parse(d)); } catch (e) { resolve({}); }
      });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// ─── Breakdown Formatter ──────────────────────────────────────────────────

/**
 * Format top N scoring factors for Slack alerts.
 * Example: "VP Engineering +30, 500+ employees +30, tech industry +15, email opens +10"
 */
function formatBreakdown(breakdown, maxFactors) {
  if (!breakdown || breakdown.length === 0) return '';
  const n = maxFactors || 5;
  // Sort by absolute value — biggest movers (positive or negative) first
  const sorted = breakdown.slice().sort((a, b) => Math.abs(b.points) - Math.abs(a.points));
  const top = sorted.slice(0, n);
  return top.map(b => {
    const sign = b.points >= 0 ? '+' : '';
    // Show matched value (e.g. "VP Engineering") if it's a short string, else fall back to rule name
    const label = (typeof b.value === 'string' && b.value && b.value.length < 40 && b.value !== 'true')
      ? b.value
      : b.rule;
    return `${label} ${sign}${b.points}`;
  }).join(', ');
}

// ─── Core Scoring Engine ───────────────────────────────────────────────────

function scoreContact(properties) {
  const rules = config.scoring.rules;
  let total = 0;
  const breakdown = [];

  // ── Positive rules ──
  for (const rule of rules) {
    const value = properties[rule.field] || '';

    if (rule.contains) {
      const match = rule.contains.some(term =>
        value.toLowerCase().includes(term.toLowerCase())
      );
      if (match) {
        total += rule.points;
        breakdown.push({ rule: `${rule.field} contains`, value, points: rule.points });
      }
    }

    if (rule.not_empty && value) {
      total += rule.points;
      breakdown.push({ rule: `${rule.field} not empty`, value, points: rule.points });
    }

    if (rule.range) {
      const num = parseInt(value, 10);
      if (!isNaN(num)) {
        const min = rule.range.min || 0;
        const max = rule.range.max || Infinity;
        if (num >= min && num <= max) {
          total += rule.points;
          const fieldLabel = rule.field === 'num_employees' ? 'employees'
            : rule.field === 'hs_analytics_num_page_views' ? 'page views'
            : rule.field === 'num_conversion_events' ? 'conversions'
            : rule.field === 'hs_email_open_count' ? 'email opens'
            : rule.field.replace(/^hs_/, '').replace(/_/g, ' ');
          const rangeLabel = max === Infinity ? `${min}+ ${fieldLabel}` : `${min}–${max} ${fieldLabel}`;
          breakdown.push({ rule: `${rule.field} in range`, value: rangeLabel, points: rule.points });
        }
      }
    }
  }

  // ── Negative signals ──
  const negCfg = config.negative_signals || {};
  const email = (properties.email || '').toLowerCase();
  const emailDomain = email.includes('@') ? email.split('@')[1] : '';

  // Competitor domain check
  const competitorDomains = negCfg.competitor_domains || [];
  if (emailDomain && competitorDomains.some(d => emailDomain.includes(d.toLowerCase()))) {
    const penalty = typeof negCfg.competitor_domain === 'number' ? negCfg.competitor_domain : -100;
    total += penalty;
    breakdown.push({ rule: 'competitor domain', value: emailDomain, points: penalty });
  }

  // Bounced email — HubSpot stores as string 'true' or boolean
  const isBounced = properties.hs_email_bounce === 'true' || properties.hs_email_bounce === true
    || properties.hs_email_is_ineligible === 'true' || properties.hs_email_is_ineligible === true;
  if (isBounced) {
    const penalty = typeof negCfg.email_bounced === 'number' ? negCfg.email_bounced : -30;
    total += penalty;
    breakdown.push({ rule: 'email bounced', value: 'bounced', points: penalty });
  }

  // Unsubscribed — stored under hs_email_optout in HubSpot
  const isUnsubscribed = properties.hs_email_optout === 'true' || properties.hs_email_optout === true
    || properties.unsubscribed === 'true' || properties.unsubscribed === true;
  if (isUnsubscribed) {
    const penalty = typeof negCfg.unsubscribed === 'number' ? negCfg.unsubscribed : -50;
    total += penalty;
    breakdown.push({ rule: 'email unsubscribed', value: 'unsubscribed', points: penalty });
  }

  const rawScore = Math.max(0, Math.min(total, 100));

  // Detect if negative signals caused a hot lead to go cold (useful for "went cold" alerts)
  const positiveTotal = breakdown.filter(b => b.points > 0).reduce((s, b) => s + b.points, 0);
  const wentColdFromNegative = breakdown.some(b => b.points < 0)
    && positiveTotal >= config.scoring.hot_threshold
    && rawScore < config.scoring.hot_threshold;

  const classification = rawScore >= config.scoring.hot_threshold ? 'HOT'
    : rawScore >= config.scoring.warm_threshold ? 'WARM' : 'COLD';

  return { score: rawScore, classification, breakdown, wentColdFromNegative };
}

// ─── Score Decay ───────────────────────────────────────────────────────────

/**
 * Apply time-based decay to a score.
 * A lead who scored 90 three months ago but hasn't engaged since should not still be HOT.
 * Config: decay.enabled, decay.decay_rate_per_week (%), decay.decay_floor
 */
function applyDecay(score, classification, breakdown, lastActivityDate) {
  const decayCfg = config.decay || {};
  if (decayCfg.enabled === false) return { score, classification, breakdown };

  if (!lastActivityDate) return { score, classification, breakdown };

  const weeksInactive = (Date.now() - new Date(lastActivityDate).getTime()) / (7 * 24 * 60 * 60 * 1000);
  if (weeksInactive < 1) return { score, classification, breakdown }; // No decay under 1 week

  const decayRate = (decayCfg.decay_rate_per_week || 5) / 100;
  const decayFloor = typeof decayCfg.decay_floor === 'number' ? decayCfg.decay_floor : 20;
  const decayFactor = Math.max(0, 1 - decayRate * weeksInactive);
  const decayedScore = Math.max(decayFloor, Math.round(score * decayFactor));

  if (decayedScore < score) {
    const weeksRounded = Math.round(weeksInactive * 10) / 10;
    console.log(`[Decay] Score adjusted: ${score} → ${decayedScore} (${weeksRounded} weeks inactive)`);
    const decayPoints = decayedScore - score; // negative number
    const newBreakdown = [...breakdown, {
      rule: 'score decay',
      value: `${weeksRounded} weeks inactive`,
      points: decayPoints
    }];
    const newClassification = decayedScore >= config.scoring.hot_threshold ? 'HOT'
      : decayedScore >= config.scoring.warm_threshold ? 'WARM' : 'COLD';
    return { score: decayedScore, classification: newClassification, breakdown: newBreakdown };
  }

  return { score, classification, breakdown };
}

// ─── HubSpot Score Write-back ─────────────────────────────────────────────

/**
 * Ensure custom score properties exist in HubSpot.
 * Creates them on first run — subsequent runs skip (409 = already exists).
 */
let _propertiesEnsured = false;
async function ensureScoreProperties() {
  if (_propertiesEnsured) return;
  const wb = (config.hubspot && config.hubspot.score_writeback) || {};
  const scoreProp = wb.property_name || 'abbi_lead_score';
  const classProp = wb.classification_property_name || 'abbi_lead_classification';

  const propertyDefs = [
    {
      name: scoreProp,
      label: 'Abbi Lead Score',
      type: 'number',
      fieldType: 'number',
      groupName: 'contactinformation',
      description: 'Lead score calculated by AI Sales Agent (0-100)',
    },
    {
      name: classProp,
      label: 'Abbi Lead Classification',
      type: 'string',
      fieldType: 'text',
      groupName: 'contactinformation',
      description: 'Lead classification: HOT, WARM, or COLD (set by AI Sales Agent)',
    },
  ];

  for (const def of propertyDefs) {
    try {
      await hubspotRequest('POST', '/crm/v3/properties/contacts', def);
      console.log(`[Writeback] Created HubSpot property: ${def.name}`);
    } catch (e) {
      // 409 = property already exists — that's fine
      if (!e.message.includes('409')) {
        console.error(`[Writeback] Warning: could not create property ${def.name}: ${e.message}`);
      }
    }
  }
  _propertiesEnsured = true;
}

/**
 * Write a contact's score and classification back to HubSpot.
 * The score appears on the contact record and can be used in HubSpot lists/views/workflows.
 */
async function writeScoreToHubSpot(contactId, score, classification) {
  const wb = (config.hubspot && config.hubspot.score_writeback) || {};
  if (wb.enabled === false) return;

  await ensureScoreProperties();

  const scoreProp = wb.property_name || 'abbi_lead_score';
  const classProp = wb.classification_property_name || 'abbi_lead_classification';

  try {
    await hubspotRequest('PATCH', `/crm/v3/objects/contacts/${contactId}`, {
      properties: {
        [scoreProp]: String(score),
        [classProp]: classification,
      }
    });
  } catch (e) {
    console.error(`[Writeback] Failed to write score for contact ${contactId}: ${e.message}`);
  }
}

// ─── Contact Properties List ───────────────────────────────────────────────

// Full list of contact properties to fetch — includes v2 additions for decay & negative signals
const CONTACT_PROPERTIES = [
  'firstname', 'lastname', 'email', 'company', 'jobtitle',
  'industry', 'num_employees', 'hs_email_open_count', 'notes_count',
  'phone', 'city', 'state', 'country',
  // Engagement signals
  'hs_analytics_num_page_views', 'num_conversion_events',
  // Decay signals
  'notes_last_updated', 'hs_last_contact_date', 'hs_latest_source_timestamp',
  // Negative signals
  'hs_email_bounce', 'hs_email_is_ineligible', 'hs_email_optout', 'unsubscribed',
].join(',');

// ─── API Functions ─────────────────────────────────────────────────────────

async function scoreContactById(contactId) {
  const contact = await hubspotGet(`/crm/v3/objects/contacts/${contactId}?properties=${CONTACT_PROPERTIES}`);
  const p = contact.properties;

  let result = scoreContact(p);

  // Apply decay — use most recent of: notes_last_updated, hs_last_contact_date, or createdate
  const lastActivity = p.notes_last_updated || p.hs_last_contact_date || p.hs_latest_source_timestamp;
  if (lastActivity) {
    const decayed = applyDecay(result.score, result.classification, result.breakdown, lastActivity);
    result = { ...result, ...decayed };
  }

  const breakdownStr = formatBreakdown(result.breakdown);

  // Write score back to HubSpot contact record
  await writeScoreToHubSpot(contactId, result.score, result.classification);

  return {
    contact_id: contactId,
    name: `${p.firstname || ''} ${p.lastname || ''}`.trim(),
    email: p.email,
    company: p.company,
    title: p.jobtitle,
    score: result.score,
    classification: result.classification,
    breakdown: result.breakdown,
    breakdown_summary: breakdownStr,
    went_cold_from_negative: result.wentColdFromNegative,
    slack_alert: buildLeadAlert({
      name: `${p.firstname || ''} ${p.lastname || ''}`.trim(),
      email: p.email,
      company: p.company,
      title: p.jobtitle,
      score: result.score,
      classification: result.classification,
      breakdownStr,
      wentColdFromNegative: result.wentColdFromNegative,
    }),
  };
}

async function scoreNewContacts(sinceTimestamp) {
  const since = sinceTimestamp || new Date(Date.now() - 30 * 60 * 1000).toISOString();
  const propsArray = CONTACT_PROPERTIES.split(',');

  const data = await hubspotRequest('POST', '/crm/v3/objects/contacts/search', {
    filterGroups: [{
      filters: [{
        propertyName: 'createdate',
        operator: 'GTE',
        value: new Date(since).getTime()
      }]
    }],
    properties: propsArray,
    limit: 100
  });

  const results = (data.results || []).map(c => {
    const p = c.properties;
    let result = scoreContact(p);

    // Apply decay
    const lastActivity = p.notes_last_updated || p.hs_last_contact_date || p.hs_latest_source_timestamp;
    if (lastActivity) {
      const decayed = applyDecay(result.score, result.classification, result.breakdown, lastActivity);
      result = { ...result, ...decayed };
    }

    const breakdownStr = formatBreakdown(result.breakdown);

    return {
      contact_id: c.id,
      name: `${p.firstname || ''} ${p.lastname || ''}`.trim(),
      email: p.email,
      company: p.company,
      title: p.jobtitle,
      created: p.createdate,
      score: result.score,
      classification: result.classification,
      breakdown: result.breakdown,
      breakdown_summary: breakdownStr,
      went_cold_from_negative: result.wentColdFromNegative,
      slack_alert: buildLeadAlert({
        name: `${p.firstname || ''} ${p.lastname || ''}`.trim(),
        email: p.email,
        company: p.company,
        title: p.jobtitle,
        score: result.score,
        classification: result.classification,
        breakdownStr,
        wentColdFromNegative: result.wentColdFromNegative,
      }),
    };
  });

  results.sort((a, b) => b.score - a.score);

  // Write scores back to HubSpot contact records
  for (const r of results) {
    await writeScoreToHubSpot(r.contact_id, r.score, r.classification);
  }

  return results;
}

// ─── Slack Alert Builder ───────────────────────────────────────────────────

/**
 * Build a Slack-formatted hot/cold lead alert string.
 * Example: "🔥 Hot lead: Sarah Chen — VP Engineering at DataCorp
 *           Score: 87 (VP Engineering +30, 500+ employees +30, tech industry +15, email opens +10)"
 */
function buildLeadAlert({ name, email, company, title, score, classification, breakdownStr, wentColdFromNegative }) {
  if (wentColdFromNegative) {
    return `🧊 Lead went cold: ${name || email}${title ? ` — ${title}` : ''}${company ? ` at ${company}` : ''}\n`
      + `Score: ${score}/100 (dropped due to: ${breakdownStr})`;
  }

  if (classification === 'HOT') {
    return `🔥 Hot lead: ${name || email}${title ? ` — ${title}` : ''}${company ? ` at ${company}` : ''}\n`
      + `Score: ${score}/100${breakdownStr ? ` (${breakdownStr})` : ''}`;
  }

  if (classification === 'WARM') {
    return `🟡 Warm lead: ${name || email}${title ? ` — ${title}` : ''}${company ? ` at ${company}` : ''}\n`
      + `Score: ${score}/100${breakdownStr ? ` (${breakdownStr})` : ''}`;
  }

  return `⬇️ Cold lead: ${name || email}${title ? ` — ${title}` : ''}${company ? ` at ${company}` : ''} — Score: ${score}/100`;
}

// ─── Test Mode ─────────────────────────────────────────────────────────────

function runTest() {
  console.log('Running test with sample data (includes decay + negative signals)...\n');

  const testContacts = [
    {
      firstname: 'Sarah', lastname: 'Chen', jobtitle: 'VP Engineering',
      company: 'DataCorp', industry: 'Technology', num_employees: '500',
      hs_email_open_count: '3', hs_analytics_num_page_views: '7', num_conversion_events: '1',
      notes_last_updated: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
    },
    {
      firstname: 'John', lastname: 'Smith', jobtitle: 'CEO',
      company: 'OldCo', industry: 'Software', num_employees: '250',
      hs_analytics_num_page_views: '2',
      // Old contact, no activity for 12 weeks → decay kicks in
      notes_last_updated: new Date(Date.now() - 84 * 24 * 3600 * 1000).toISOString(),
    },
    {
      firstname: 'Lisa', lastname: 'Park', jobtitle: 'Director of Engineering',
      company: 'StartupXYZ', industry: 'SaaS', num_employees: '80',
      email: 'lisa@competitor.com', // Competitor domain → negative signal
    },
    {
      firstname: 'Bob', lastname: 'Jones', jobtitle: 'VP Sales',
      company: 'BigCorp', industry: 'Finance', num_employees: '600',
      hs_email_bounce: 'true', // Bounced email → negative signal
    },
  ];

  for (const contact of testContacts) {
    let result = scoreContact(contact);

    // Apply decay if last activity set
    if (contact.notes_last_updated) {
      const decayed = applyDecay(result.score, result.classification, result.breakdown, contact.notes_last_updated);
      result = { ...result, ...decayed };
    }

    const breakdownStr = formatBreakdown(result.breakdown);
    const alert = buildLeadAlert({
      name: `${contact.firstname} ${contact.lastname}`,
      email: contact.email || '',
      company: contact.company,
      title: contact.jobtitle,
      score: result.score,
      classification: result.classification,
      breakdownStr,
      wentColdFromNegative: result.wentColdFromNegative,
    });

    console.log(`${contact.firstname} ${contact.lastname} — ${contact.jobtitle} at ${contact.company}`);
    console.log(`  Score: ${result.score}/100 — ${result.classification}`);
    if (result.wentColdFromNegative) console.log(`  ⚠️  Would have been HOT without negative signals`);
    console.log(`  Breakdown: ${breakdownStr || '(none)'}`);
    console.log(`  Alert: ${alert}`);
    console.log('');
  }
}

// ─── CLI ───────────────────────────────────────────────────────────────────

const args = process.argv.slice(2);
const cmd = args[0];

if (cmd === '--test') {
  runTest();
} else if (cmd === 'score') {
  const contactIdx = args.indexOf('--contact');
  if (contactIdx === -1) { console.error('Usage: node lead-scorer.cjs score --contact CONTACT_ID'); process.exit(1); }
  scoreContactById(args[contactIdx + 1])
    .then(r => console.log(JSON.stringify(r, null, 2)))
    .catch(e => console.error('Error:', e.message));
} else if (cmd === 'score-all') {
  const sinceIdx = args.indexOf('--since');
  const since = sinceIdx !== -1 ? args[sinceIdx + 1] : undefined;
  scoreNewContacts(since).then(r => {
    console.log(`Scored ${r.length} contacts:\n`);
    for (const c of r) {
      const flag = c.went_cold_from_negative ? ' ⚠️ went cold' : '';
      console.log(`${c.classification} (${c.score}) — ${c.name} — ${c.title || 'No title'} at ${c.company || 'No company'}${flag}`);
      if (c.breakdown_summary) console.log(`  Breakdown: ${c.breakdown_summary}`);
    }
  }).catch(e => console.error('Error:', e.message));
} else {
  console.log(`AI Sales Agent — Lead Scorer v3

Usage:
  node lead-scorer.cjs score --contact CONTACT_ID    Score a specific contact
  node lead-scorer.cjs score-all --since TIMESTAMP    Score all contacts since timestamp
  node lead-scorer.cjs --test                         Run with sample data

v3 features:
  - Engagement scoring: page views, form submissions, email opens
  - Score writeback: writes score + classification to HubSpot contact properties
  - Scores visible on contact records, filterable in HubSpot views

v2 features:
  - Score breakdown in alerts (e.g. "VP Engineering +30, 500+ employees +30")
  - Time-based score decay (configurable in config.json: decay.*)
  - Negative signals: bounced emails, unsubscribes, competitor domains`);
}

module.exports = { scoreContact, applyDecay, formatBreakdown, buildLeadAlert, writeScoreToHubSpot };
