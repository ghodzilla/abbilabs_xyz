# AI Sales Agent Template

> A complete, production-ready AI agent that manages your sales pipeline autonomously. Connects to HubSpot, Slack, and Google Sheets. Works with any LLM — Claude, GPT, Gemini, or any agent framework.

## What This Agent Does

Your AI Sales Agent:
- **Monitors new leads** in HubSpot and qualifies them based on your criteria
- **Logs all activity** to Google Sheets for tracking and reporting
- **Sends alerts** to Slack when high-value leads come in
- **Follows up** with leads that go cold (configurable timing)
- **Generates daily sales reports** — pipeline value, new leads, closed deals
- **Updates deal stages** automatically based on activity
- **Scores leads** using rules you define (company size, industry, engagement)

## What's Included

```
ai-sales-agent/
├── README.md                  ← You're reading this
├── AGENT.md                   ← Agent personality, role, and behaviour rules
├── WORKFLOWS.md               ← Step-by-step workflows the agent follows
├── SETUP.md                   ← Complete setup guide (15 minutes)
├── config.json                ← Customisable settings (scoring rules, thresholds, timing)
├── scripts/
│   ├── hubspot.cjs            ← HubSpot CRM integration (contacts, deals, notes)
│   ├── sheets.cjs             ← Google Sheets integration (logging, reporting)
│   ├── slack.cjs              ← Slack integration (alerts, daily reports)
│   ├── lead-scorer.cjs        ← Lead scoring engine
│   ├── pipeline-report.cjs    ← Daily pipeline report generator
│   └── follow-up-checker.cjs  ← Identifies stale leads needing follow-up
├── templates/
│   ├── slack-alert.md         ← Slack message templates
│   ├── daily-report.md        ← Daily report format
│   └── follow-up-email.md     ← Follow-up email templates
└── examples/
    ├── scoring-rules.json     ← Example lead scoring configuration
    └── sample-workflow.md     ← Example end-to-end workflow
```

## Quick Start

1. **Clone this template** into your agent workspace
2. **Set up API keys** — HubSpot, Google Sheets, Slack (guide in SETUP.md)
3. **Customise config.json** — your lead scoring rules, deal thresholds, Slack channels
4. **Edit AGENT.md** — adjust the agent's personality and behaviour to match your sales process
5. **Run it** — the agent starts monitoring your pipeline immediately

## Framework Compatibility

| Framework | How to Use |
|-----------|-----------|
| **OpenClaw** | Drop the folder into your skills directory. Done. |
| **Claude (API)** | Load AGENT.md as system prompt, call scripts via tool_use |
| **GPT (API)** | Load AGENT.md as system message, call scripts via function_calling |
| **LangChain** | Use scripts as tools, WORKFLOWS.md as chain logic |
| **CrewAI** | Define agent from AGENT.md, tasks from WORKFLOWS.md |
| **Any other** | Scripts are standalone Node.js — call them however you want |

## Requirements

- Node.js 18+
- HubSpot account (free tier works)
- Google account + service account (free)
- Slack workspace (free)
- Any LLM (Claude, GPT, Gemini, Llama, etc.)

## Zero Dependencies

Every script is pure Node.js. No npm install. No package.json. No node_modules. Just copy and run.

## Support

30-day money-back guarantee. If the template doesn't work as described, full refund, no questions asked.

Built by [Abbi Labs](https://abbilabs.xyz) — AI agent templates for real businesses.
