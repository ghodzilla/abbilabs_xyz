#!/usr/bin/env node
/**
 * Stripe Agent Skill — Core Script
 * Full Stripe integration: customers, payments, subscriptions, invoices, products, refunds.
 * Auth: Stripe Secret Key.
 */
'use strict';

const https = require('https');
const querystring = require('querystring');

const SECRET_KEY = process.env.STRIPE_SECRET_KEY;
if (!SECRET_KEY) {
  console.error(JSON.stringify({ error: 'STRIPE_SECRET_KEY environment variable not set' }));
  process.exit(1);
}

// ─── HTTP Helper ────────────────────────────────────────────────────────────

function stripeApi(method, path, params) {
  return new Promise((resolve, reject) => {
    const isGet = method === 'GET';
    let fullPath = `/v1/${path}`;
    let payload = null;

    if (params && isGet) {
      fullPath += '?' + flattenParams(params);
    } else if (params) {
      payload = flattenParams(params);
    }

    const opts = {
      method,
      hostname: 'api.stripe.com',
      path: fullPath,
      headers: {
        Authorization: `Basic ${Buffer.from(SECRET_KEY + ':').toString('base64')}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    };
    if (payload) opts.headers['Content-Length'] = Buffer.byteLength(payload);

    const req = https.request(opts, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString();
        try {
          const data = JSON.parse(raw);
          if (res.statusCode === 429) {
            console.error('Rate limited. Retrying in 2s...');
            setTimeout(() => stripeApi(method, path, params).then(resolve).catch(reject), 2000);
            return;
          }
          if (data.error) {
            resolve({ error: data.error.message, type: data.error.type, code: data.error.code });
          } else {
            resolve(data);
          }
        } catch {
          resolve({ error: 'parse_error', _raw: raw.substring(0, 200) });
        }
      });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// Flatten nested objects for Stripe's form-encoded API
function flattenParams(obj, prefix = '') {
  const parts = [];
  for (const [key, val] of Object.entries(obj)) {
    const fullKey = prefix ? `${prefix}[${key}]` : key;
    if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      parts.push(flattenParams(val, fullKey));
    } else if (Array.isArray(val)) {
      val.forEach((item, i) => {
        if (typeof item === 'object') {
          parts.push(flattenParams(item, `${fullKey}[${i}]`));
        } else {
          parts.push(`${encodeURIComponent(fullKey)}[${i}]=${encodeURIComponent(item)}`);
        }
      });
    } else {
      parts.push(`${encodeURIComponent(fullKey)}=${encodeURIComponent(val)}`);
    }
  }
  return parts.join('&');
}

// ─── Customers ──────────────────────────────────────────────────────────────

async function cmdSearchCustomers(query) {
  const resp = await stripeApi('GET', 'customers/search', { query, limit: 20 });
  if (resp.error) return resp;
  return {
    results: resp.data?.map(c => ({
      id: c.id, name: c.name, email: c.email, created: new Date(c.created * 1000).toISOString(),
      metadata: c.metadata, balance: c.balance,
    })),
    total: resp.total_count,
  };
}

async function cmdGetCustomer(customerId) {
  const resp = await stripeApi('GET', `customers/${customerId}`, null);
  if (resp.error) return resp;
  return {
    id: resp.id, name: resp.name, email: resp.email, phone: resp.phone,
    created: new Date(resp.created * 1000).toISOString(), balance: resp.balance,
    metadata: resp.metadata, currency: resp.currency,
    subscriptions: resp.subscriptions?.data?.length || 0,
  };
}

async function cmdCreateCustomer(propsJson) {
  const props = JSON.parse(propsJson);
  const resp = await stripeApi('POST', 'customers', props);
  if (resp.error) return resp;
  return { success: true, id: resp.id, email: resp.email };
}

async function cmdUpdateCustomer(customerId, propsJson) {
  const props = JSON.parse(propsJson);
  const resp = await stripeApi('POST', `customers/${customerId}`, props);
  if (resp.error) return resp;
  return { success: true, id: resp.id };
}

async function cmdListCustomers(limit = 10) {
  const resp = await stripeApi('GET', 'customers', { limit });
  if (resp.error) return resp;
  return {
    results: resp.data?.map(c => ({
      id: c.id, name: c.name, email: c.email,
      created: new Date(c.created * 1000).toISOString(),
    })),
    has_more: resp.has_more,
  };
}

// ─── Payments ───────────────────────────────────────────────────────────────

async function cmdListPayments(limit = 10) {
  const resp = await stripeApi('GET', 'payment_intents', { limit });
  if (resp.error) return resp;
  return {
    results: resp.data?.map(p => ({
      id: p.id, amount: p.amount, currency: p.currency, status: p.status,
      customer: p.customer, created: new Date(p.created * 1000).toISOString(),
      description: p.description,
    })),
    has_more: resp.has_more,
  };
}

async function cmdGetPayment(paymentId) {
  const resp = await stripeApi('GET', `payment_intents/${paymentId}`, null);
  if (resp.error) return resp;
  return {
    id: resp.id, amount: resp.amount, currency: resp.currency, status: resp.status,
    customer: resp.customer, description: resp.description,
    created: new Date(resp.created * 1000).toISOString(),
    metadata: resp.metadata, payment_method: resp.payment_method,
    charges: resp.latest_charge,
  };
}

async function cmdCustomerCharges(customerId, limit = 10) {
  const resp = await stripeApi('GET', 'charges', { customer: customerId, limit });
  if (resp.error) return resp;
  return {
    results: resp.data?.map(c => ({
      id: c.id, amount: c.amount, currency: c.currency, status: c.status,
      created: new Date(c.created * 1000).toISOString(), description: c.description,
      paid: c.paid, refunded: c.refunded,
    })),
  };
}

// ─── Subscriptions ──────────────────────────────────────────────────────────

async function cmdListSubscriptions(limit = 10) {
  const resp = await stripeApi('GET', 'subscriptions', { limit, status: 'active' });
  if (resp.error) return resp;
  return {
    results: resp.data?.map(s => ({
      id: s.id, customer: s.customer, status: s.status,
      current_period_start: new Date(s.current_period_start * 1000).toISOString(),
      current_period_end: new Date(s.current_period_end * 1000).toISOString(),
      plan: s.items?.data?.[0]?.price?.id,
      amount: s.items?.data?.[0]?.price?.unit_amount,
      interval: s.items?.data?.[0]?.price?.recurring?.interval,
    })),
    has_more: resp.has_more,
  };
}

async function cmdGetSubscription(subId) {
  const resp = await stripeApi('GET', `subscriptions/${subId}`, null);
  if (resp.error) return resp;
  return {
    id: resp.id, customer: resp.customer, status: resp.status,
    current_period_end: new Date(resp.current_period_end * 1000).toISOString(),
    cancel_at_period_end: resp.cancel_at_period_end,
    items: resp.items?.data?.map(i => ({
      price: i.price?.id, amount: i.price?.unit_amount, currency: i.price?.currency,
      interval: i.price?.recurring?.interval,
    })),
  };
}

async function cmdCreateSubscription(propsJson) {
  const props = JSON.parse(propsJson);
  const resp = await stripeApi('POST', 'subscriptions', props);
  if (resp.error) return resp;
  return { success: true, id: resp.id, status: resp.status, customer: resp.customer };
}

async function cmdCancelSubscription(subId) {
  const resp = await stripeApi('DELETE', `subscriptions/${subId}`, null);
  if (resp.error) return resp;
  return { success: true, id: resp.id, status: resp.status };
}

async function cmdUpdateSubscription(subId, propsJson) {
  const props = JSON.parse(propsJson);
  const resp = await stripeApi('POST', `subscriptions/${subId}`, props);
  if (resp.error) return resp;
  return { success: true, id: resp.id };
}

// ─── Invoices ───────────────────────────────────────────────────────────────

async function cmdListInvoices(limit = 10) {
  const resp = await stripeApi('GET', 'invoices', { limit });
  if (resp.error) return resp;
  return {
    results: resp.data?.map(i => ({
      id: i.id, customer: i.customer, status: i.status,
      amount_due: i.amount_due, amount_paid: i.amount_paid, currency: i.currency,
      created: new Date(i.created * 1000).toISOString(),
      due_date: i.due_date ? new Date(i.due_date * 1000).toISOString() : null,
      hosted_invoice_url: i.hosted_invoice_url,
    })),
  };
}

async function cmdGetInvoice(invoiceId) {
  const resp = await stripeApi('GET', `invoices/${invoiceId}`, null);
  if (resp.error) return resp;
  return {
    id: resp.id, customer: resp.customer, status: resp.status,
    amount_due: resp.amount_due, amount_paid: resp.amount_paid,
    lines: resp.lines?.data?.map(l => ({ description: l.description, amount: l.amount })),
    hosted_invoice_url: resp.hosted_invoice_url,
  };
}

async function cmdCreateInvoice(propsJson) {
  const props = JSON.parse(propsJson);
  const resp = await stripeApi('POST', 'invoices', props);
  if (resp.error) return resp;
  return { success: true, id: resp.id, status: resp.status };
}

async function cmdAddInvoiceItem(propsJson) {
  const props = JSON.parse(propsJson);
  const resp = await stripeApi('POST', 'invoiceitems', props);
  if (resp.error) return resp;
  return { success: true, id: resp.id };
}

async function cmdSendInvoice(invoiceId) {
  const resp = await stripeApi('POST', `invoices/${invoiceId}/finalize`, {});
  if (resp.error) return resp;
  const sendResp = await stripeApi('POST', `invoices/${invoiceId}/send`, {});
  return { success: true, id: invoiceId, hosted_url: resp.hosted_invoice_url, sent: !sendResp.error };
}

// ─── Products & Prices ──────────────────────────────────────────────────────

async function cmdListProducts(limit = 10) {
  const resp = await stripeApi('GET', 'products', { limit, active: 'true' });
  if (resp.error) return resp;
  return {
    results: resp.data?.map(p => ({
      id: p.id, name: p.name, description: p.description,
      active: p.active, default_price: p.default_price,
    })),
  };
}

async function cmdCreateProduct(propsJson) {
  const props = JSON.parse(propsJson);
  const resp = await stripeApi('POST', 'products', props);
  if (resp.error) return resp;
  return { success: true, id: resp.id, name: resp.name };
}

async function cmdCreatePrice(propsJson) {
  const props = JSON.parse(propsJson);
  const resp = await stripeApi('POST', 'prices', props);
  if (resp.error) return resp;
  return { success: true, id: resp.id, unit_amount: resp.unit_amount, currency: resp.currency };
}

// ─── Refunds ────────────────────────────────────────────────────────────────

async function cmdRefund(paymentId, amount, reason) {
  const params = { payment_intent: paymentId };
  if (amount && amount !== 'full') params.amount = parseInt(amount, 10);
  if (reason) params.reason = 'requested_by_customer';
  const resp = await stripeApi('POST', 'refunds', params);
  if (resp.error) return resp;
  return { success: true, id: resp.id, amount: resp.amount, status: resp.status };
}

// ─── Revenue Reporting ──────────────────────────────────────────────────────

async function cmdBalance() {
  const resp = await stripeApi('GET', 'balance', null);
  if (resp.error) return resp;
  return {
    available: resp.available?.map(b => ({ amount: b.amount, currency: b.currency })),
    pending: resp.pending?.map(b => ({ amount: b.amount, currency: b.currency })),
  };
}

async function cmdRevenue(days = 30) {
  const since = Math.floor(Date.now() / 1000) - (days * 86400);
  const resp = await stripeApi('GET', 'charges', { limit: 100, created: { gte: since } });
  if (resp.error) return resp;

  const charges = resp.data || [];
  const total = charges.filter(c => c.paid && !c.refunded).reduce((sum, c) => sum + c.amount, 0);
  const refunded = charges.filter(c => c.refunded).reduce((sum, c) => sum + (c.amount_refunded || 0), 0);
  const count = charges.filter(c => c.paid).length;

  return {
    period: `Last ${days} days`,
    total_cents: total,
    total_formatted: `$${(total / 100).toFixed(2)}`,
    refunded_cents: refunded,
    net_cents: total - refunded,
    net_formatted: `$${((total - refunded) / 100).toFixed(2)}`,
    charge_count: count,
    has_more: resp.has_more,
  };
}

async function cmdListPayouts(limit = 10) {
  const resp = await stripeApi('GET', 'payouts', { limit });
  if (resp.error) return resp;
  return {
    results: resp.data?.map(p => ({
      id: p.id, amount: p.amount, currency: p.currency, status: p.status,
      arrival_date: new Date(p.arrival_date * 1000).toISOString(),
    })),
  };
}

// ─── Disputes ───────────────────────────────────────────────────────────────

async function cmdListDisputes(limit = 10) {
  const resp = await stripeApi('GET', 'disputes', { limit });
  if (resp.error) return resp;
  return {
    results: resp.data?.map(d => ({
      id: d.id, amount: d.amount, currency: d.currency, status: d.status,
      reason: d.reason, charge: d.charge,
      created: new Date(d.created * 1000).toISOString(),
    })),
  };
}

// ─── Main ───────────────────────────────────────────────────────────────────

async function main() {
  const [,, command, ...args] = process.argv;

  if (!command) {
    console.log('Usage: node stripe.cjs <command> [args...]');
    console.log('Commands: search-customers, get-customer, create-customer, update-customer, list-customers,');
    console.log('          list-payments, get-payment, customer-charges,');
    console.log('          list-subscriptions, get-subscription, create-subscription, cancel-subscription, update-subscription,');
    console.log('          list-invoices, get-invoice, create-invoice, add-invoice-item, send-invoice,');
    console.log('          list-products, create-product, create-price,');
    console.log('          refund, balance, revenue, list-payouts, list-disputes');
    process.exit(1);
  }

  let result;
  switch (command) {
    case 'search-customers': result = await cmdSearchCustomers(args.join(' ')); break;
    case 'get-customer': result = await cmdGetCustomer(args[0]); break;
    case 'create-customer': result = await cmdCreateCustomer(args.join(' ')); break;
    case 'update-customer': result = await cmdUpdateCustomer(args[0], args.slice(1).join(' ')); break;
    case 'list-customers': result = await cmdListCustomers(parseInt(args[0] || '10', 10)); break;
    case 'list-payments': result = await cmdListPayments(parseInt(args[0] || '10', 10)); break;
    case 'get-payment': result = await cmdGetPayment(args[0]); break;
    case 'customer-charges': result = await cmdCustomerCharges(args[0], parseInt(args[1] || '10', 10)); break;
    case 'list-subscriptions': result = await cmdListSubscriptions(parseInt(args[0] || '10', 10)); break;
    case 'get-subscription': result = await cmdGetSubscription(args[0]); break;
    case 'create-subscription': result = await cmdCreateSubscription(args.join(' ')); break;
    case 'cancel-subscription': result = await cmdCancelSubscription(args[0]); break;
    case 'update-subscription': result = await cmdUpdateSubscription(args[0], args.slice(1).join(' ')); break;
    case 'list-invoices': result = await cmdListInvoices(parseInt(args[0] || '10', 10)); break;
    case 'get-invoice': result = await cmdGetInvoice(args[0]); break;
    case 'create-invoice': result = await cmdCreateInvoice(args.join(' ')); break;
    case 'add-invoice-item': result = await cmdAddInvoiceItem(args.join(' ')); break;
    case 'send-invoice': result = await cmdSendInvoice(args[0]); break;
    case 'list-products': result = await cmdListProducts(parseInt(args[0] || '10', 10)); break;
    case 'create-product': result = await cmdCreateProduct(args.join(' ')); break;
    case 'create-price': result = await cmdCreatePrice(args.join(' ')); break;
    case 'refund': result = await cmdRefund(args[0], args[1], args[2]); break;
    case 'balance': result = await cmdBalance(); break;
    case 'revenue': result = await cmdRevenue(parseInt(args[0] || '30', 10)); break;
    case 'list-payouts': result = await cmdListPayouts(parseInt(args[0] || '10', 10)); break;
    case 'list-disputes': result = await cmdListDisputes(parseInt(args[0] || '10', 10)); break;
    default: result = { error: `Unknown command: ${command}` };
  }

  console.log(JSON.stringify(result, null, 2));
}

main().catch(err => {
  console.error(JSON.stringify({ error: err.message }));
  process.exit(1);
});
