'use client';
import { useState } from 'react';

const NAV_LINKS = [
  { label: 'Features', href: '/#features' },
  { label: 'Pricing', href: '/pricing' },
  { label: 'Tax', href: '/tax' },
  { label: 'Dashboard', href: '/dashboard' },
];

const TIERS = ['Pro — $29/mo', 'Elite — $79/mo', 'Node Pro — $149/mo', 'Node Whale — $299/mo'];

export default function WaitlistPage() {
  const [email, setEmail] = useState('');
  const [tier, setTier] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    if (!email || !tier) return;
    setLoading(true);
    // Simulate async — static for now
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 800);
  }

  return (
    <div style={{ background: '#111214', minHeight: '100vh', color: '#edeef0', fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" }}>

      {/* NAVBAR */}
      <nav style={{ position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100, backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', background: 'rgba(17,18,20,0.85)', borderBottom: '1px solid #2a2b30' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
          <a href="/" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
            <img src="/passiveblocks_logo.png" alt="PassiveBlocks" style={{ height: 200, width: 'auto', objectFit: 'contain', filter: 'brightness(0) invert(1)' }} />
          </a>
          <div style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
            {NAV_LINKS.map(l => (
              <a key={l.label} href={l.href} style={{ color: '#6b6c72', textDecoration: 'none', fontSize: 14, fontWeight: 500 }}>
                {l.label}
              </a>
            ))}
            <a href="/login" style={{ color: '#6b6c72', textDecoration: 'none', fontSize: 14, fontWeight: 500 }}>
              Log In
            </a>
            <a href="/signup" style={{ background: 'linear-gradient(135deg, #6789ed, #583fdd)', color: '#fff', textDecoration: 'none', borderRadius: 8, padding: '8px 18px', fontSize: 14, fontWeight: 600 }}>
              Sign Up Free
            </a>
          </div>
        </div>
      </nav>

      {/* CONTENT */}
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '120px 24px 80px' }}>

        {!submitted ? (
          <div style={{ width: '100%', maxWidth: 480 }}>
            <div style={{ textAlign: 'center', marginBottom: 40 }}>
              <div style={{ background: '#6789ed22', border: '1px solid #6789ed44', borderRadius: 20, padding: '6px 18px', fontSize: 13, fontWeight: 600, color: '#6789ed', marginBottom: 24, display: 'inline-block' }}>
                🚀 Early Access
              </div>
              <h1 style={{ fontSize: 40, fontWeight: 900, margin: '0 0 14px', lineHeight: 1.2 }}>Join the Waitlist</h1>
              <p style={{ fontSize: 16, color: '#6b6c72', lineHeight: 1.7, margin: 0 }}>
                Be first in line when paid tiers launch. Early access members get a 30% lifetime discount.
              </p>
            </div>

            <form onSubmit={handleSubmit} style={{ background: '#18191d', border: '1px solid #2a2b30', borderRadius: 16, padding: 36 }}>
              <div style={{ marginBottom: 20 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#edeef0', marginBottom: 8 }}>Email address</label>
                <input
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  required
                  style={{
                    width: '100%',
                    background: '#111214',
                    border: '1px solid #2a2b30',
                    borderRadius: 8,
                    padding: '12px 14px',
                    color: '#edeef0',
                    fontSize: 15,
                    outline: 'none',
                    boxSizing: 'border-box',
                  }}
                  onFocus={e => e.target.style.borderColor = '#6789ed'}
                  onBlur={e => e.target.style.borderColor = '#2a2b30'}
                />
              </div>
              <div style={{ marginBottom: 28 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#edeef0', marginBottom: 8 }}>Which tier interests you?</label>
                <select
                  value={tier}
                  onChange={e => setTier(e.target.value)}
                  required
                  style={{
                    width: '100%',
                    background: '#111214',
                    border: '1px solid #2a2b30',
                    borderRadius: 8,
                    padding: '12px 14px',
                    color: tier ? '#edeef0' : '#6b6c72',
                    fontSize: 15,
                    outline: 'none',
                    boxSizing: 'border-box',
                    cursor: 'pointer',
                    appearance: 'none',
                    WebkitAppearance: 'none',
                  }}
                  onFocus={e => e.target.style.borderColor = '#6789ed'}
                  onBlur={e => e.target.style.borderColor = '#2a2b30'}
                >
                  <option value="" disabled>Select a tier…</option>
                  {TIERS.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <button
                type="submit"
                disabled={!email || !tier || loading}
                style={{
                  width: '100%',
                  background: email && tier && !loading ? 'linear-gradient(135deg, #6789ed, #583fdd)' : '#2a2b30',
                  color: email && tier && !loading ? '#fff' : '#6b6c72',
                  border: 'none',
                  borderRadius: 8,
                  padding: '14px',
                  fontSize: 16,
                  fontWeight: 700,
                  cursor: email && tier && !loading ? 'pointer' : 'not-allowed',
                  transition: 'all 0.2s',
                }}
              >
                {loading ? '⏳ Joining…' : 'Reserve My Spot →'}
              </button>
            </form>

            <div style={{ display: 'flex', justifyContent: 'center', gap: 32, marginTop: 28, flexWrap: 'wrap' }}>
              {['No spam, ever', 'Cancel anytime', '30% early bird discount'].map(item => (
                <span key={item} style={{ fontSize: 12, color: '#6b6c72', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ color: '#8aad8a' }}>✓</span> {item}
                </span>
              ))}
            </div>
          </div>
        ) : (
          <div style={{ textAlign: 'center', maxWidth: 480 }}>
            <div style={{ fontSize: 64, marginBottom: 24 }}>🎉</div>
            <h2 style={{ fontSize: 36, fontWeight: 900, margin: '0 0 16px' }}>You're on the list!</h2>
            <p style={{ fontSize: 16, color: '#6b6c72', lineHeight: 1.7, marginBottom: 32 }}>
              We've added <strong style={{ color: '#edeef0' }}>{email}</strong> to the waitlist for <strong style={{ color: '#6789ed' }}>{tier}</strong>. We'll be in touch when your tier launches.
            </p>
            <a href="/dashboard" style={{ background: 'linear-gradient(135deg, #6789ed, #583fdd)', color: '#fff', textDecoration: 'none', borderRadius: 10, padding: '14px 32px', fontSize: 16, fontWeight: 700, display: 'inline-block' }}>
              Try the Free Dashboard →
            </a>
          </div>
        )}
      </div>

      {/* FOOTER */}
      <footer style={{ background: '#18191d', borderTop: '1px solid #2a2b30', padding: '48px 24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <img src="/passiveblocks_logo.png" alt="PassiveBlocks" style={{ height: 160, width: 'auto', objectFit: 'contain', filter: 'brightness(0) invert(1)' }} />
          </div>
          <div style={{ fontSize: 13, color: '#6b6c72' }}>© {new Date().getFullYear()} PassiveBlocks. Build Wealth Block by Block.</div>
          <div style={{ display: 'flex', gap: 24 }}>
            {[...NAV_LINKS, { label: 'Waitlist', href: '/waitlist' }].map(l => (
              <a key={l.label} href={l.href} style={{ color: '#6b6c72', textDecoration: 'none', fontSize: 13 }}>{l.label}</a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
