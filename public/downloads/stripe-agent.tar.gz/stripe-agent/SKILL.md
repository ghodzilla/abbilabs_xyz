---
name: stripe-agent
description: "Manage customers, payments, subscriptions, invoices, and products in Stripe via the API. Use when: the agent needs to track revenue, manage subscriptions, handle refunds, create invoices, or monitor payment activity. Requires a Stripe Secret Key."
homepage: https://stripe.com/docs/api
metadata:
  openclaw:
    emoji: "💳"
    requires:
      env:
        - STRIPE_SECRET_KEY
      node: true
    category: "Payments & Revenue"
    price: "$29"
    platforms: ["OpenClaw"]
    llm_compatible: ["Claude", "GPT", "Any"]
---

# Stripe Agent Skill

Full Stripe integration for AI agents. Manage customers, track payments, handle subscriptions, process refunds, and monitor revenue — your agent becomes a financial operator.

## When to Use

✅ **USE this skill when:**
- Searching for customers or payment details
- Tracking revenue (daily, weekly, monthly)
- Managing subscriptions (create, update, cancel)
- Processing refunds
- Creating and sending invoices
- Managing products and prices
- Monitoring payment failures and disputes
- Building revenue dashboards and reports

## When NOT to Use

❌ **DON'T use this skill when:**
- Building checkout UIs → use Stripe Checkout or Elements
- Handling webhooks → use a webhook server
- Managing Stripe account settings → use Stripe Dashboard
- PCI-sensitive card handling → use Stripe.js client-side

## Setup (One-Time)

### 1. Get Your Stripe Secret Key
1. Go to [dashboard.stripe.com/apikeys](https://dashboard.stripe.com/apikeys)
2. Copy the **Secret key** (starts with `sk_live_` or `sk_test_`)
3. **Use test mode** (`sk_test_`) for development

### 2. Configure the Skill
```bash
export STRIPE_SECRET_KEY="sk_live_your_key_here"
```

### Security Note
The secret key has full access to your Stripe account. Use restricted keys in production where possible.

## Commands

All commands use the script at `scripts/stripe.cjs`.

### Customers

```bash
# Search customers
node scripts/stripe.cjs search-customers "<query>"
# Example: search by email
node scripts/stripe.cjs search-customers "email:'alice@company.com'"

# Get customer
node scripts/stripe.cjs get-customer <customerId>

# Create customer
node scripts/stripe.cjs create-customer '{"email":"alice@company.com","name":"Alice Smith","metadata":{"source":"website"}}'

# Update customer
node scripts/stripe.cjs update-customer <customerId> '{"metadata":{"plan":"pro"}}'

# List recent customers
node scripts/stripe.cjs list-customers [limit]
```

### Payments & Charges

```bash
# List recent payments
node scripts/stripe.cjs list-payments [limit]

# Get payment details
node scripts/stripe.cjs get-payment <paymentIntentId>

# List charges for a customer
node scripts/stripe.cjs customer-charges <customerId> [limit]
```

### Subscriptions

```bash
# List active subscriptions
node scripts/stripe.cjs list-subscriptions [limit]

# Get subscription details
node scripts/stripe.cjs get-subscription <subscriptionId>

# Create subscription
node scripts/stripe.cjs create-subscription '{"customer":"cus_xxx","items":[{"price":"price_xxx"}]}'

# Cancel subscription
node scripts/stripe.cjs cancel-subscription <subscriptionId>

# Update subscription
node scripts/stripe.cjs update-subscription <subscriptionId> '{"metadata":{"note":"downgraded"}}'
```

### Invoices

```bash
# List recent invoices
node scripts/stripe.cjs list-invoices [limit]

# Get invoice
node scripts/stripe.cjs get-invoice <invoiceId>

# Create invoice
node scripts/stripe.cjs create-invoice '{"customer":"cus_xxx","collection_method":"send_invoice","days_until_due":30}'

# Add invoice item
node scripts/stripe.cjs add-invoice-item '{"customer":"cus_xxx","amount":5000,"currency":"usd","description":"Consulting - March 2026"}'

# Finalize and send invoice
node scripts/stripe.cjs send-invoice <invoiceId>
```

### Products & Prices

```bash
# List products
node scripts/stripe.cjs list-products [limit]

# Create product
node scripts/stripe.cjs create-product '{"name":"AI Agent Skill Pack","description":"Production-ready AI agent integrations"}'

# Create price
node scripts/stripe.cjs create-price '{"product":"prod_xxx","unit_amount":2900,"currency":"usd"}'

# Create recurring price
node scripts/stripe.cjs create-price '{"product":"prod_xxx","unit_amount":999,"currency":"usd","recurring":{"interval":"month"}}'
```

### Refunds

```bash
# Full refund
node scripts/stripe.cjs refund <paymentIntentId>

# Partial refund (amount in cents)
node scripts/stripe.cjs refund <paymentIntentId> 1500

# Refund with reason
node scripts/stripe.cjs refund <paymentIntentId> full "Customer requested cancellation"
```

### Revenue Reporting

```bash
# Get balance
node scripts/stripe.cjs balance

# Revenue summary (last N days)
node scripts/stripe.cjs revenue [days]
# Example: Last 30 days
node scripts/stripe.cjs revenue 30

# List payouts
node scripts/stripe.cjs list-payouts [limit]
```

### Disputes

```bash
# List open disputes
node scripts/stripe.cjs list-disputes [limit]
```

## Common Patterns

### Daily Revenue Report
```bash
# Get today's payments
node scripts/stripe.cjs revenue 1

# Get monthly revenue
node scripts/stripe.cjs revenue 30

# Check balance
node scripts/stripe.cjs balance
```

### Customer Lifecycle
```bash
# Create customer when they sign up
node scripts/stripe.cjs create-customer '{"email":"new@customer.com","name":"New Customer"}'

# Create subscription
node scripts/stripe.cjs create-subscription '{"customer":"cus_xxx","items":[{"price":"price_xxx"}]}'

# Customer wants to cancel
node scripts/stripe.cjs cancel-subscription "sub_xxx"

# Process refund if needed
node scripts/stripe.cjs refund "pi_xxx"
```

### Subscription Management
```bash
# List all active subscriptions
node scripts/stripe.cjs list-subscriptions 100

# Find subscriptions expiring soon
# (filter in output by current_period_end)

# Send dunning email for failed payments
# (use with Slack/email skill for notifications)
```

## Error Handling

| Error | Cause | Fix |
|-------|-------|-----|
| `authentication_error` | Invalid API key | Check STRIPE_SECRET_KEY |
| `resource_missing` | Wrong ID | Verify the object ID |
| `card_error` | Payment failed | Check payment method |
| `rate_limit_error` | Too many requests | Script auto-retries |
| `invalid_request_error` | Bad parameters | Check the request body |

## Rate Limits

- Stripe API: 100 requests per second (live), 25/s (test)
- Read operations are more permissive than writes
- The skill handles rate limiting automatically

## Notes

- All amounts are in **cents** (e.g., $29.00 = 2900)
- Currency defaults to USD unless specified
- Use test mode (`sk_test_`) for development and testing
- The skill works with both live and test keys
- Stripe API version used: latest stable
- Metadata fields can store up to 50 key-value pairs (500 char limit per value)
